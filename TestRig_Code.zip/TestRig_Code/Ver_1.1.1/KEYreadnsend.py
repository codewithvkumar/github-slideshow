#Boa:Frame:Frame1

import wx
import wx.grid
import win32api
import xlrd
import xlwt
import os
import time
import serial
import re
import struct
import threading,Queue
from threading import Thread
from xlutils.copy import copy
import CDU_TestRig_MainWindow
import display
import ibit_out

import CDU_output

LINE_NO_DAY=0x0
CURSOR_REPLACE=0x0
COLOR=0x1
BACK_COLOR=0x1
checksum=0x0
Header=0xAC
Packet_ID=0xA2
cursor_position=0x0
global filenm_xls,data_packet,data_packet_ibit,flag_data,ibit_flag,ibitfinal_flag
ibitfinal_flag=0
data_packet=[]
data_packet_ibit=[]
##flag=1
ibit_flag=0
flag_data=0

list=['','','','','','','','','','',
      '','','','','','','','','','',
      '','','','','','','','','','',
      '','',' ','!','"','#','','%','','',
      '(',')','','+',',','-','.','/','0','1',
      '2','3','4','5','6','7','8','9',':','~',
      '<','=','>','?','','A','B','C','D','E',
      'F','G','H','I','J','K','L','M','N','O',
	  'P','Q','R','S','T','U','V','W','X','Y',
	  'Z','','','^','$','@']
list1=[0x41,0x42,0x43,0x44,0x45,0x46,0x47,0x48,0x49,0x4A,
        0x4B,0x4C,0x4D,0x4E,0x4F,0x50,0x51,0x52,0x53,0x54,
        0x55,0x56,0x57,0x58,0x59,0x5A,0x31,0x32,0x33,0x34,
        0x35,0x36,0x37,0x38,0x39,0x30]
list2=[0x3E,0x3F,0x0A,0x0B,0x0C,0x0D,0x0E]        
def create(parent):
     global class_var
     class_var=KEYreadnsend(parent)
     return class_var

[wxID_FRAME1, wxID_FRAME1BUTTON1, wxID_FRAME1BUTTON2,wxID_FRAME1BUTTON3, wxID_FRAME1PANEL1, 
 wxID_FRAME1STATICTEXT1, wxID_FRAME1TEXTCTRL1, 
] = [wx.NewId() for _init_ctrls in range(7)]

class KEYreadnsend(wx.Frame):
    def _init_ctrls(self, prnt):
        # generated method, don't edit
        wx.Frame.__init__(self, id=wxID_FRAME1, name='', parent=prnt,
              pos=wx.Point(300, 243), size=wx.Size(400, 449),
              style=wx.DEFAULT_FRAME_STYLE, title='Send pages to CDU')
        self.SetClientSize(wx.Size(392, 200))
        self.Bind(wx.EVT_CLOSE, self.OnClose)

        self.panel1 = wx.Panel(id=wxID_FRAME1PANEL1, name='panel1', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(392, 200),
              style=wx.TAB_TRAVERSAL)

        self.button1 = wx.Button(id=wxID_FRAME1BUTTON1, label='BROWSE',
              name='button1', parent=self.panel1, pos=wx.Point(284, 76),
              size=wx.Size(75, 23), style=0)
        self.button1.Bind(wx.EVT_BUTTON, self.OnButton1Button,
              id=wxID_FRAME1BUTTON1)

        self.button2 = wx.Button(id=wxID_FRAME1BUTTON2, label='OK',
              name='button2', parent=self.panel1, pos=wx.Point(50, 120),
              size=wx.Size(75, 23), style=0)
        self.button2.Bind(wx.EVT_BUTTON, self.OnOK_click,
              id=wxID_FRAME1BUTTON2)
              
        self.button3 = wx.Button(id=wxID_FRAME1BUTTON3, label='Cancel',
              name='button3', parent=self.panel1, pos=wx.Point(140, 120),
              size=wx.Size(75, 23), style=0)
              
        self.button3.Bind(wx.EVT_BUTTON, self.OnButton3Button,
              id=wxID_FRAME1BUTTON3)

        self.staticText1 = wx.StaticText(id=wxID_FRAME1STATICTEXT1,
              label='Please select the .xls sheet', name='staticText1',
              parent=self.panel1, pos=wx.Point(36, 42), size=wx.Size(151, 13),
              style=0)
              
        self.staticText1.SetFont(wx.Font(10, wx.SWISS, wx.NORMAL, wx.BOLD, False,'Tahoma'))

        self.textCtrl1 = wx.TextCtrl(id=wxID_FRAME1TEXTCTRL1, name='textCtrl1',
              parent=self.panel1, pos=wx.Point(36, 78), size=wx.Size(240, 21),
              style=0, value='')
        self.connect_object=''
        self.check_pageselected=0
    def OnButton3Button(self,event):
        self.Destroy()
        event.Skip()
    def OnButton1Button(self,event):
        
        dlg = wx.FileDialog(self, "Choose a file", ".", "", "*.xls", wx.OPEN)
        try:
           if dlg.ShowModal() == wx.ID_OK:
               self.textCtrl1.Value = dlg.GetPath()
               self.filename_xls=self.textCtrl1.Value
        finally:
           dlg.Destroy()          
        event.Skip()
    def OnOK_click(self, event):
        global manager
        self.list4=[]
        self.list5=[]
        self.list_homeval=[]
        self.key_page_detl=[]
        ret_val=CDU_TestRig_MainWindow.class_var3.xlsvalidate()
        if self.textCtrl1.Value=='SELECT XLS':
            m1 = wx.MessageDialog(self, "NO XLS SELECTED",\
                " ", style = wx.OK | wx.ICON_INFORMATION|wx.STAY_ON_TOP)
            if m1.ShowModal() == wx.ID_OK:
                m1.Destroy()
##                self.Destroy()
        
        elif(ret_val==1):
            m1 = wx.MessageDialog(self, "NO HOTKEYS CONFIGURATION PAGE PRESENT",\
                " ", style = wx.OK | wx.ICON_INFORMATION|wx.STAY_ON_TOP)
            if m1.ShowModal() == wx.ID_OK:
                m1.Destroy()
                manager=TestThread()
                self.Hide()
        else:         
            filenm_xls=self.filename_xls
            head=os.path.split(filenm_xls)
            pathnfile=os.path.join(head[0],"CDUHOTKEY.xls")
            rb = xlrd.open_workbook(pathnfile, formatting_info=True)
            w=copy(rb)
            sheet=rb.sheet_by_index(0)
            rows, cols = sheet.nrows, sheet.ncols
            for i in range(rows):
                read_row=sheet.row_values(i)
                if read_row[0]==head[1]:
                    self.key_page_detl.append(read_row) 
                    self.list5=self.key_page_detl[0]
    ##                self.list4.append(read_row[0])
            for k in range(1,8):
                 self.list4.append(self.list5[k])
            self.list_homeval=self.homeconvert()
            self.check_pageselected=1  
            CDU_TestRig_MainWindow.CDUsend_flag=1         
##            print "self.key_page_detl",self.key_page_detl,self.list_homeval
    ##        print  pathnfile       
    ##        self.sendpacket()
    ##        self.connect_object = serial.Serial(0,baudrate=115200)
            manager=TestThread()
            self.Hide()
##        event.Skip()
        
    def OnClose(self,event):
        global flag
        CDU_TestRig_MainWindow.KEYreadnsend_flag=0
        
        '''Function to close the connection to the com port'''
##        if CDU_TestRig_MainWindow.class_var3.connect_object_CDU_receiver != '' :
        CDU_TestRig_MainWindow.flag=0 
##        CDU_TestRig_MainWindow.class_var3.connect_object_CDU_receiver.close()
##        CDU_TestRig_MainWindow.connect_object_CDU_receiver=''
               
##        time.sleep(1)   
        self.Destroy()
        event.Skip()      
    def OnCancel(self):
        global flag
        CDU_TestRig_MainWindow.KEYreadnsend_flag=0
        CDU_TestRig_MainWindow.flag=0    
        self.Destroy()
        
        
            
    def __init__(self, parent):
        self._init_ctrls(parent)
        
            
    def ConnectClose(self):
        
            '''Function to close the connection to the com port''' 
            CDU_TestRig_MainWindow.class_var3.connect_object_flag.close()

    def SendInitPacket(self,final_packet):
        '''Function to send the information packet to the com port''' 
        if ((CDU_TestRig_MainWindow.class_var3.connect_object_CDU_receiver!='') and \
            (CDU_TestRig_MainWindow.class_var3.connect_object_CDU_transmitter=='')):
            try:
                CDU_TestRig_MainWindow.class_var3.connect_object_CDU_receiver.write(final_packet)
                Timestamp=manager.Time_stamp()
                temp_text=" CDU INPUT Message sent at  "+ str(Timestamp)+"\n"
                CDU_TestRig_MainWindow.class_var3.textCtrl1.WriteText(temp_text)
            except:
                pass
        else:
            try:
                CDU_TestRig_MainWindow.class_var3.connect_object_CDU_transmitter.write(final_packet)
                
                Timestamp=manager.Time_stamp()
                temp_text=" CDU INPUT Message sent at  "+ str(Timestamp)+"\n"
                CDU_TestRig_MainWindow.class_var3.textCtrl1.WriteText(temp_text)
            except:
                pass    
    def Calculate_checksum(self,final_packet,byte_count):
        checksum=0
        data=struct.unpack_from('>%db'%byte_count,final_packet)
        for i in range(0,byte_count):
            checksum=checksum^data[i]
        checksum=checksum & 0xFF
        return checksum
    def homeconvert(self):
        list_ddd=[]
##        list_check=['Home2','Home1','Home1-cl1','Home1-cl2']
        for i in range(len(self.list4)):
            if len(self.list4[i])==5:
                list2=self.list4[i].split('Home')
                list3=list2[1]+'000'
                list_ddd.append(list3)
            elif(len(self.list4[i])==6):
                 list_ddd.append('0000')   
            else:
                list2=self.list4[i].split('-')
                list3=list2[0].split('Home')
                val2=list2[1].startswith('CR',0,3)
                if val2 == True:
                    list4=list2[1].split('CR')
##                    print 'list4',list4
                    list6=str(int(list4[1])+4)
                    list5=list3[1]+list6+'00'
                    list_ddd.append(list5)       
                else:
                    list4=list2[1].split('CL')
                    list5=list3[1]+list4[1]+'00' 
                
                    list_ddd.append(list5)                
##                    list4=list2[1].split('CL')
##                    list5=list3[1]+list4[1]+'00'
##                    list_ddd.append(list5)
                    
##            if list_ddd[i] in page_dict1:
                       
##        print list_ddd 
        return list_ddd
    
      
class TestThread(Thread):
        def __init__(self):
            Thread.__init__(self)
            self.start()    # start the thread
            self.list_alpha=[]
        def run(self):
            global data_packet,flag_data,data_packet_ibit,ibit_flag,ibitfinal_flag
##            ibitfinal_flag=0
##        self.Hide()
##            class_var.Hide()
            global page_details
            global page_list
            global counter
            counter=0
            final_file=xlrd.open_workbook(class_var.filename_xls, formatting_info=1)
            sheet=final_file.sheet_by_index(0)
            rows, cols = sheet.nrows, sheet.ncols
            page_details=[]
            page_list=[]
##            print rows
            page=((rows+1)/11)
##            print page
##            print "Classvar3", CDU_TestRig_MainWindow.class_var3.connect_object_page
            count=0
            page_dict={}
            page_dict1={}
            for i in range(0,rows,11):
                read_row=sheet.row_values(i)
##                print read_row
                list_hex=(str(hex(int(read_row[1]))))[2:]
                page_details.append(list_hex)
                
            for i in range(len(page_details)):
##                print page_details
                page_dict[i]=page_details[i]  
                page_dict1[page_details[i]]=i
##            print "page_dict" ,page_dict
##            print "page_dict1" ,page_dict1
            #To create page#      
            for i in range(page):
                read_line=[]
                if (i==(page-1)):
                    for a in range(count,count+10):
                       read_row=sheet.row_values(a)
                       read_line.append(read_row)
                      
                else:
                    for a in range(count,count+11):
                       read_row=sheet.row_values(a)
                       read_line.append(read_row)
                count=count+11    
                page_list.append(read_line)
                 
            '''Function to connect to the com port'''
             
            page_count=0

            #To send Homepage1 
        
            key=0
            
##            final_packet=self.SendHomepacket(key)
##            class_var.SendInitPacket(final_packet)
            validate_instance=CDU_output.validate()
            ibit_class_instance=ibit_out.ibit_class()
           
##            print final_packet
##            print "hello"
            ####shall be removed
            send = 0
            key_list=[]
            key_list1=[]
            list_key=[]
            home_list=[]
            home_list.append(0)
            home=0
##            print home_list
            n_try=0
            no_ibit=1
            no=1
            flag_data=0
            flag_process=1
            
          
            while(1):
                final_list=[]
                val=[]
                val1=[]
##                print "flag", CDU_TestRig_MainWindow.flag
                keystatus = 0
                final_packet=''
                data=[]
                if (CDU_TestRig_MainWindow.flag==0):
##                    print "flag", CDU_TestRig_MainWindow.flag
                    return 
                if CDU_TestRig_MainWindow.class_var3.connect_object_CDU_receiver.inWaiting() > 0:
##                     print "data >0"
                     if CDU_TestRig_MainWindow.class_var3.connect_object_CDU_receiver.inWaiting() < 2:
                        flag_process=0
                        rem_data=struct.unpack(">%dB"%(CDU_TestRig_MainWindow.class_var3.connect_object_CDU_receiver.inWaiting()),CDU_TestRig_MainWindow.class_var3.connect_object_CDU_receiver.read((CDU_TestRig_MainWindow.class_var3.connect_object_CDU_receiver.inWaiting()) ))
                        print rem_data
                     else:
                        
                        val=struct.unpack(">2B",CDU_TestRig_MainWindow.class_var3.connect_object_CDU_receiver.read(2))
##                        print "val", val
                        data.append(val[0])
                        data.append(val[1])
                        if (val[0]==0xAC)  : 
                            if(val[1]==0xA1):  
                                val1 = struct.unpack(">14B",CDU_TestRig_MainWindow.class_var3.connect_object_CDU_receiver.read(14))
##                            g=struct.unpack(">14B",class_var3.connect_object_CDU_receiver.read(14))
                                print "g", val1
##                                flag_process=1  # if it can read 14 byte means full msg than read 2 byte new msg
                                for i in range (14):
                                    data.append(val1[i])
                                                                      
                                Checksum=self.Calculate_Checksum(data,len(data)-2)
                                print " checksum",Checksum
                                print "last",data[len(data)-1]
##                                os.seek()
                                if( Checksum == data[len(data)-1] ):
##                                    CDU_output.msg_packect=data
                                    flag_data=1
                                    data_packet=data
                                    data=[]
                                    print "in thread A1----->data_packet",data_packet
                                    validate_instance.initialisation(data_packet)
                                    print "check sum is correct.................",no
                                    display.Write_xls(no)
                                    no=no+1
                                    temp_text="Status Message received from CDU\n"
                                    CDU_TestRig_MainWindow.class_var3.textCtrl1.WriteText(temp_text)
                                else:
                                    flag_data=0
                                    Timestamp=self.Time_stamp()
                                    CDU_TestRig_MainWindow.class_var3.textCtrl1.SetForegroundColour(wx.Colour(255, 0, 0))
                                    temp_text=" CDU output Message received at  "+ str(Timestamp)+"  instance is invalid " +"\n"
                                    CDU_TestRig_MainWindow.class_var3.textCtrl1.WriteText(temp_text) 
                                
                                    print "data",data
##                                    print "msg",CDU_output.msg_packect
                                   
                                if val1[0]!=0x5B and val1[0]!=0x5C:           
                                    if val1[0] == 0x01: 
                                        print "1"
                                        home_sent=home_list[len(home_list)-1]
                                        home_sent1=str(int(page_dict[home])+100)
                                        
                                        if home_sent1 in page_dict1:
                                            key = page_dict1[home_sent1]
                                            keystatus = 1 
                                        else:
                                            key = home_sent 
                                            keystatus = 1    
                                        n_try=0
                                        list_key=[]         
                                    elif val1[0] == 0x02:
                                        home_sent=home_list[len(home_list)-1]
                                        home_sent1=str(int(page_dict[home])+200)
                                        
                                        if home_sent1 in page_dict1:
                                            key = page_dict1[home_sent1] 
                                            keystatus = 1 
                                        else:
                                            key = home_sent 
                                            keystatus = 1 
                                        n_try=0
                                        list_key=[]                 
                                    elif val1[0] == 0x03:
                                        home_sent=home_list[len(home_list)-1]
                                        home_sent1=str(int(page_dict[home])+300)
                                       
                                        if home_sent1 in page_dict1:
                                            key = page_dict1[home_sent1] 
                                            keystatus = 1 
                                        else:
                                            key = home_sent 
                                            keystatus = 1 
                                        n_try=0
                                        list_key=[] 
                                              
                                    elif val1[0] == 0x04:
                                        home_sent=home_list[len(home_list)-1]
                                        home_sent1=str(int(page_dict[home])+400)
                                        if home_sent1 in page_dict1:
                                            
                                            key = page_dict1[home_sent1] 
                                            print key
                                            keystatus = 1 
                                        else:
                                            key = home_sent 
                                            keystatus = 1 
                                        n_try=0
                                        list_key=[]   

                                    elif val1[0] == 0x05:
                                        home_sent=home_list[len(home_list)-1]
                                        home_sent1=str(int(page_dict[home])+500)
                                        if home_sent1 in page_dict1:
                                            key = page_dict1[home_sent1] 
                                            keystatus = 1 
                                        else:
                                            key = home_sent 
                                            keystatus = 1 
                                        n_try=0
                                        list_key=[]                          
                                    elif val1[0] == 0x06:
                                        home_sent=home_list[len(home_list)-1]
                                        home_sent1=str(int(page_dict[home])+600)
                                        if home_sent1 in page_dict1:
                                            key = page_dict1[home_sent1] 
                                            keystatus = 1 
                                        else:
                                            key = home_sent 
                                            keystatus = 1 
                                        n_try=0
                                        list_key=[]                  
                                    elif val1[0] == 0x07: 
                                        home_sent=home_list[len(home_list)-1]
                                        home_sent1=str(int(page_dict[home])+700)
                                        if home_sent1 in page_dict1:
                                            key = page_dict1[home_sent1] 
                                            keystatus = 1 
                                        else:
                                            key = home_sent 
                                            keystatus = 1
                                        n_try=0
                                        list_key=[]                                         
                                    elif val1[0] == 0x08: 
                                        home_sent=home_list[len(home_list)-1]
                                        home_sent1=str(int(page_dict[home])+800)
                                        if home_sent1 in page_dict1:
                                            key = page_dict1[home_sent1] 
                                            keystatus = 1 
                                        else:
                                            key = home_sent 
                                            keystatus = 1  
                                        n_try=0
                                        list_key=[]                                               
                                    elif val1[0] == 0x1A:
                                        key = 0
                                        keystatus = 1
                                        home=key 
                                    elif val1[0] == 0x99:
                                        if (counter==0):
                                            key = 0
                                            keystatus = 1
                                            counter=1 
                                        else:
                                            key=(home_list[len(home_list)-1])
                                            keystatus=1
                                    elif (val1[0] in list2):
                                        var=val1[0]
                                        var1=list2.index(var)
                                        var2=class_var.list_homeval[var1]
                                        if var2 in page_dict1: 
                                            key = page_dict1[var2]
                                            keystatus = 1
                                            counter=1 
                                        else:
                                            key=(home_list[len(home_list)-1])
                                            keystatus=1        
##                                    elif (val1[0] >=0x41 and val1[0] <= 0x5A):
                                    elif (val1[0] in list1):
                                          home_sent=home_list[len(home_list)-1]
                                          list_val=[]
                                          color=0x1
                                          if (home_sent ==1):
                                                list_val=page_list[1]
                                                print "home ",(home_list[len(home_list)-1])
                                                self.list_alpha.append(int(val1[0]))
                                                if ((len(self.list_alpha))<=12):
                                                    for i in range(len(self.list_alpha)):
    ##                                                    cursor_position=9+len(list_key)
                                                        charcode_bin=str('{0:07b}'.format(self.list_alpha[i]))
                                                        charcode_bin=charcode_bin+'0'
                                                        charcode_bin1='00000101'+charcode_bin
                                                        print  charcode_bin,int(charcode_bin1,2)
                                                        pos=10+i
                                                        list_val[9][pos]= int(charcode_bin1,2) 
                                                    print "list_val" ,list_val
                                                    print  "page_list[1]",page_list[1]
                                                else:
                                                    self.list_alpha=[]
                                                key = (home_list[len(home_list)-1])
                                                keystatus = 1
                                                Alpha_numdict={}
                                                Alpha_numlist=[]
                                                Alpha_numdict[key]=Alpha_numlist
                                          else:
                                              key = home_sent 
                                              keystatus = 1 
                                    else:
                                        key = (home_list[len(home_list)-1])
                                        keystatus = 1                           
                                    home_list=[] 
                                    home_list.append(key)
                                elif val1[0] == 0x5B:
##                                    page_value=page_dict[(home_list[len(home_list)-1])]
                                    page_value=page_dict[home]
                                    page_value1= str(int(page_value)-1000)
                                    if(page_value1 in page_dict1):
                                        key=page_dict1[page_value1]
                                        keystatus=1
                                        home=key
                                    else :   
                                       key=(home_list[len(home_list)-1])
                                       keystatus=1   
                                    home_list=[]                      
                                    home_list.append(key)  

                                elif val1[0] == 0x5C:
##                                    page_value=page_dict[(home_list[len(home_list)-1])]
                                    page_value=page_dict[home]
                                    page_value1= str(int(page_value)+1000)
                                    if(page_value1 in page_dict1):
                                        key=page_dict1[page_value1]
                                        keystatus=1
                                        home=key
                                    else :   
                                       key=(home_list[len(home_list)-1])
                                       keystatus=1
                                    home_list=[]                         
                                    home_list.append(key)
                                    
                            elif(data[1]==0xE1):   #Acknowlegement message from CDU
                                print "Acknowlegement message from CDU"
                                flag_process=1
                                
                                g=struct.unpack(">2B",CDU_TestRig_MainWindow.class_var3.connect_object_CDU_receiver.read(2))
                                data.append(g[0])    # acceptance bit
                                data.append(g[1])    # checksum bit
                                
                                print "Acknowlegement message from CDU----->",data
                                
                                Checksum=self.Calculate_Checksum(data,len(data)-1)
                                print "checksum-------->",Checksum
                                print "last bit-------->",data[3]
                                if( Checksum == data[len(data)-1] ):
                                    ibit_flag=1
                                    if(data[2]==0):
                                        ibit_flag=0
                                        i=0
                                        Timestamp=self.Time_stamp()
                                        CDU_TestRig_MainWindow.class_var3.textCtrl1.SetForegroundColour(wx.Colour(255, 0, 0))
                                        temp_text="Invalid IBIT Acknowlegement Message received from CDU at "+ str(Timestamp)+"\n"
                                        CDU_TestRig_MainWindow.class_var3.textCtrl1.WriteText(temp_text)
                                        
                                        while(1):
                                            print "inside while loop"
                                            if(ibit_flag==0 and i<4):
                                                display.Ibit_msg()
                                                print "i=",i
                                                i=i+1
                                                time.sleep(1)
                                            else:
                                                 break
                                    else:  
                                        print "data is 1" 
                                        data=[]
                                        Timestamp=self.Time_stamp()
                                        CDU_TestRig_MainWindow.class_var3.textCtrl1.SetForegroundColour(wx.Colour(0, 0, 255))
                                        temp_text="IBIT Acknowlegement Message received from CDU at "+ str(Timestamp)+"\n"
                                        CDU_TestRig_MainWindow.class_var3.textCtrl1.WriteText(temp_text)
                                else:
                                    Timestamp=self.Time_stamp()
                                    CDU_TestRig_MainWindow.class_var3.textCtrl1.SetForegroundColour(wx.Colour(255, 0, 0))
                                    temp_text="Invalid IBIT Acknowlegement Message received from CDU at "+ str(Timestamp)+"\n"
                                    CDU_TestRig_MainWindow.class_var3.textCtrl1.WriteText(temp_text)
                            
                            elif(data[1]==0xE2):    #final data from CDU
                                flag_process=1
                                if(ibit_flag==1):
                                    g=struct.unpack(">2B",CDU_TestRig_MainWindow.class_var3.connect_object_CDU_receiver.read(2))
                                    data.append(g[0]) 
                                    data.append(g[1])
                                    print "data at A3 ibit----->",data
                                    
                                    Checksum=self.Calculate_Checksum(data,len(data)-1)
                                    print "checksum-------->",Checksum
                                    print "last bit-------->",data[3]
                                    if( Checksum == data[len(data)-1] ):
        ##                                Ibit_output.ibit_data=data
                                        data_packet_ibit=data
                                        ibit_flag=1
                                        ibitfinal_flag=1
##                                        ibit_class_instance.Setgrid_values(data_packet_ibit)
                                        display.logging_ibit(no_ibit)
                                        no_ibit=no_ibit+1
                                        
                                        Timestamp=self.Time_stamp()                                    
                                        temp_text="IBIT final Message received from CDU at "+ str(Timestamp)+"\n"
                                        CDU_TestRig_MainWindow.class_var3.textCtrl1.WriteText(temp_text)
                                        
                                        CDU_TestRig_MainWindow.class_var3.ibit_results.Show()
                                        ibit_class_instance.Setgrid_values(data_packet_ibit)
    ##                                    
                                    else:
                                        Timestamp=self.Time_stamp()
                                        temp_text="Invalid IBIT final Message received from CDU at "+ str(Timestamp)+"\n"
                                        CDU_TestRig_MainWindow.class_var3.textCtrl1.WriteText(temp_text)
                                        
                                else:
                                    Timestamp=self.Time_stamp()
                                    temp_text="IBIT Acknowlegement Message not received from CDU at "+ str(Timestamp)+"\n"
                                    CDU_TestRig_MainWindow.class_var3.textCtrl1.WriteText(temp_text)

                            else:
                                print "Invalid......>"
                                flag_process=0
                                data[0]=data[1]
                                (value,)=struct.unpack(">B",CDU_TestRig_MainWindow.class_var3.connect_object_CDU_receiver.read(1))
                                data[1]=(value)
                        if val[0]!=0xAC:
                            flag_process=0
                            data[0]=data[1]
                            (value,)=struct.unpack(">B",CDU_TestRig_MainWindow.class_var3.connect_object_CDU_receiver.read(1))
                            data[1]=(value)
                                         
                        if(keystatus == 1) or (keystatus == 2):
                            keystatus = 0
                            final_packet=self.SendHomepacket(key)
                            class_var.SendInitPacket(final_packet) 
                              
        def SendHomepacket(self,key):
            print key
            global page_info
            final_packet=''
            byte_count=0
            cursor_position=0x0
            read_line=page_list[key]
            page_info=key     
            for l in range(1,10):
                read_data=read_line[l]
                char_pack=''
                read_data1=[]
                for j in range(1,22):
                    b=str(int(read_data[j]))
                    read_data1.append(b)                                
                    var2=str('{0:04b}'.format(l-1))
                    var2=var2+'0000'
                    preamble_pack=struct.pack('>BB',Header,Packet_ID)
                    Row_packet=struct.pack('>BB',int(var2,2),cursor_position)
                    Finalrow_packet=preamble_pack+Row_packet               
      
                for index in range(1,22):
                    char_code=int(read_data[index])
                    char_pack=char_pack+struct.pack('>H',char_code)          
                final_packet=final_packet+Finalrow_packet+char_pack
                byte_count=len(final_packet)
                checksum_computed = class_var.Calculate_checksum(final_packet,byte_count)
                checksum_pack=struct.pack('>B',checksum_computed)   
                final_packet=final_packet+checksum_pack                 
            return final_packet 
        
        def Calculate_Checksum(self,data,bytecount):
            checksum=0
            for i in range(0,bytecount):
               var1=data[i]
               checksum = checksum ^ (var1)
            checksum = checksum & 0xFF
            return checksum                                            
        
        def Time_stamp(self):
            # To get the local time of system
            self.now=time.localtime(time.time())
            print "self.now", self.now
            year, month, day, hour, minute, second, weekday, yearday, daylight =self.now
            self.a=str(hour)
            self.b=str(minute)
            self.c=str(second)
            if len(self.a)==1:
                self.a='0'+self.a
            if len(self.b)==1:
                self.b='0'+self.b
            if len( self.c)==1:
                self.c='0'+self.c
            self.Timestamp=self.a+":"+self.b+":"+self.c
            print "Timestamp", self.Timestamp
            return self.Timestamp

