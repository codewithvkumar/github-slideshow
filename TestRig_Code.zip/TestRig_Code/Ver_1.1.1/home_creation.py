#Boa:Frame:Frame6

import wx
import page_creation
import GNSS_OutputWindow
import CDU_TestRig_MainWindow

def create(parent):
    instance_Frame6=home_creation(parent)
    return instance_Frame6

##    return home_creation(parent)

global home_no,flag_page_creation,home_flag

flag_page_creation=0
home_flag=0
[wxID_FRAME6, wxID_FRAME6BUTTON1, wxID_FRAME6BUTTON2, wxID_FRAME6PANEL1, 
 wxID_FRAME6STATICTEXT1, wxID_FRAME6TEXTCTRL1, 
] = [wx.NewId() for _init_ctrls in range(6)]

class home_creation(wx.Frame):
    def _init_ctrls(self, prnt):
        # generated method, don't edit
        wx.Frame.__init__(self, id=wxID_FRAME6, name='', parent=prnt,
              pos=wx.Point(320, 138), size=wx.Size(414, 131),
              style=wx.DEFAULT_FRAME_STYLE, title='Home Page Details')
        self.SetClientSize(wx.Size(406, 97))
        self.Center()
        self.Bind(wx.EVT_CLOSE, self.On_Close)
        self.panel1 = wx.Panel(id=wxID_FRAME6PANEL1, name='panel1', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(406, 97),
              style=wx.TAB_TRAVERSAL)

        self.staticText1 = wx.StaticText(id=wxID_FRAME6STATICTEXT1,
              label='Enter number of home pages :', name='staticText1',
              parent=self.panel1, pos=wx.Point(24, 24), size=wx.Size(146, 13),
              style=0)

        self.textCtrl1 = wx.TextCtrl(id=wxID_FRAME6TEXTCTRL1, name='textCtrl1',
              parent=self.panel1, pos=wx.Point(176, 24), size=wx.Size(160, 21),
              style=0, value='')

        self.button1 = wx.Button(id=wxID_FRAME6BUTTON1, label='OK',
              name='button1', parent=self.panel1, pos=wx.Point(176, 64),
              size=wx.Size(75, 23), style=0)
        self.button1.Bind(wx.EVT_BUTTON, self.OnOK, id=wxID_FRAME6BUTTON1)

        self.button2 = wx.Button(id=wxID_FRAME6BUTTON2, label='Cancel',
              name='button2', parent=self.panel1, pos=wx.Point(264, 64),
              size=wx.Size(80, 23), style=0)
        self.button2.Bind(wx.EVT_BUTTON, self.OnCancel, id=wxID_FRAME6BUTTON2)

    def __init__(self, parent):
        self._init_ctrls(parent)
        
    def On_Close(self,event):
        CDU_TestRig_MainWindow.flag_home_creation=0
        flag_page_creation=0
        self.Destroy() 
        event.Skip()

    def OnCancel(self, event):
        CDU_TestRig_MainWindow.flag_home_creation=0
        flag_page_creation=0
        self.Destroy() 
        event.Skip()

    def OnOK(self, event):
        global home_no,main8,flag_page_creation
        global home_flag
        home_flag=1
        home_no=self.textCtrl1.GetValue()
        flag=0
        if(home_no!=''):
            flag=1
        try:
            if(flag==1):
                home_no =int(home_no)
                if((home_no)>0 and home_no<=16):
                    print CDU_TestRig_MainWindow.flag_home_creation
                    if(flag_page_creation==0):
                        main8 = page_creation.create(None)
                        main8.Show()
                        flag_page_creation=1
                        CDU_TestRig_MainWindow.flag_home_creation=0
                        self.Destroy()
##                    else:
##                        self.main8.SetFocus()
##                        flag_page_creation=1
##                        self.main8.Show()
                    
                else:
                    dial = wx.MessageDialog(None, "Number of home pages ranges from 1 to 16",\
                    'Error !!!', wx.OK|wx.STAY_ON_TOP)
                    dial.ShowModal()   
             
            elif(flag==0):
                 dial = wx.MessageDialog(None, "Enter number of home pages",\
                'Error !!!', wx.OK|wx.STAY_ON_TOP)
                 dial.ShowModal()  
        except ValueError:
            dial = wx.MessageDialog(None, "Enter integer value",\
            'Error !!!', wx.OK|wx.STAY_ON_TOP)
            dial.ShowModal()  
        
        
##        event.Skip()
