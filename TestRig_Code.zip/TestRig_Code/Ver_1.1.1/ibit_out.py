#Boa:Frame:Frame5

import wx
import wx.grid
import CDU_TestRig_MainWindow
import KEYreadnsend
import os
##
##ibit_class_instance=ibit_class()
global ibit_status,ibit_result
ibit_status=''
ibit_result=''
def create(parent):
    return ibit_out(parent)

[wxID_FRAME5, wxID_FRAME5GRID1,wxID_FRAME5STATICTEXT1, wxID_FRAME5PANEL1, 
] = [wx.NewId() for _init_ctrls in range(4)]

class ibit_out(wx.Frame):
    def _init_ctrls(self, prnt):
        # generated method, don't edit
        wx.Frame.__init__(self, id=wxID_FRAME5, name='', parent=prnt,
              pos=wx.Point(315, 119), size=wx.Size(400, 257),
              style=wx.DEFAULT_FRAME_STYLE, title='IBIT Command')
        self.SetClientSize(wx.Size(392, 210))

        self.panel1 = wx.Panel(id=wxID_FRAME5PANEL1, name='panel1', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(322, 210),
              style=wx.TAB_TRAVERSAL)

        self.grid1 = wx.grid.Grid(id=wxID_FRAME5GRID1, name='grid1',
              parent=self.panel1, pos=wx.Point(48, 52), size=wx.Size(270, 90),
              style=0)
              
        self.staticText1 = wx.StaticText(id=wxID_FRAME5STATICTEXT1,
              label='IBIT Result from CDU    ', name='staticText1', parent=self.panel1,
              pos=wx.Point(120, 8), size=wx.Size(200, 20), style=0)
              
        self.staticText1.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD, False,'Tahoma'))
              
        self.Ibit_grid()
        self.grid1.SetCellValue(0,1,'   - ')
        self.grid1.SetCellValue(1,1,'   - ')
        
        self.timer=wx.Timer(self)
        self.Bind(wx.EVT_TIMER,self.refresh1)
        self.timer.Start(1000) 
        
    def __init__(self, parent):
        self._init_ctrls(parent)
        
    def refresh1(self,event):
        ibit_class_instance=ibit_class()
        print "ibit pass data......>",KEYreadnsend.data_packet_ibit
        
        if(KEYreadnsend.ibit_flag==1):
            print "ibit pass data......>",KEYreadnsend.data_packet_ibit
            ibit_class_instance.Setgrid_values(KEYreadnsend.data_packet_ibit)
            self.set_value()
        else:
            print "------- ibit failed"
        
    def Ibit_grid(self):             # To create key status grid
##        global ibit_data
        print"grid creation"
        self.grid1.CreateGrid(2,2) 
        self.grid1.DisableDragGridSize()
        self.grid1.DisableDragColSize()
        self.grid1.DisableDragRowSize()
        self.grid1.SetColLabelValue(0,'Field Name')
        self.grid1.SetColLabelValue(1,'Value')
        
        for i in range (2):
             for j in range (2):
                self.grid1.SetReadOnly(i,j)
                self.grid1.SetRowSize( i, 30 ) 
                self.grid1.SetCellFont(i,j,wx.Font(8, wx.SWISS, wx.NORMAL, wx.NORMAL))
        self.grid1.SetColSize( 0, 100 ) 
        self.grid1.SetColSize( 1, 140 )
        self.grid1.SetRowLabelSize(25)
        self.grid1.SetColLabelSize(25)
        
        self.grid1.SetCellValue(0,0,'IBIT Status')
        self.grid1.SetCellValue(1,0,'IBIT Result')
        print "end of grid"
##        os.seek()
        
    def set_value(self):
        global ibit_status,ibit_result
        
        if(KEYreadnsend.data_packet_ibit!=''):
##            ibit_status='IBIT test complete'
##            ibit_result='IBIT test complete'
            self.grid1.SetCellValue(1,1,ibit_status)
            self.grid1.SetCellValue(0,1,ibit_result)
            print"packet_data set value..........>"
##            os.seek()
        else:
            self.grid1.SetCellValue(0,1,' - ')
            self.grid1.SetCellValue(1,1,' - ')
        
        
class ibit_class:
##    self.ibit_status=''
##    self.ibit_result=''
    def Setgrid_values(self,packet_data):
        global ibit_status,ibit_result
        print"packet_data..........>",packet_data
##        print "ibit data",ibit_data
##        self.ibit_status=''
##        self.ibit_result=''
        
        if(len(packet_data)!=0):       
            temp1=packet_data[2]
            temp2=temp1&0x80
            #temp3=temp2%2
            if(temp2==0x80):
                  ibit_status='IBIT test complete'
            else:
                ibit_status='IBIT test not progress'
                
            temp1=packet_data[2]
            temp2=temp1&0x40
            if(temp2==0x40):
                ibit_result='IBIT test passed'

            else:
                ibit_result='IBIT test failed'        
