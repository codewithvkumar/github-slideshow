#Boa:Frame:Frame2

import wx
import wx.grid
import xlrd
import xlwt
import string
from xlutils.copy import copy
import CDU_TestRig_MainWindow
import GNSS_OutputWindow
##import Frame5
import Update_home
import page_creation
import home_creation
import Hotkey
import os

global list,x,y,p,page,prev,t,store_main,store_sub,store,store_main1,flag,cursor_col,cursor_row,frequency,repeat,\
filename_xls,q,counter,page_list,index,check_sub,check,page_info,page_num,h,s,g,btn_cl1,btn_cl2,btn_cl3,\
btn_cl4,btn_cr1,btn_cr2,btn_cr3,btn_cr4,page_txt,er_flag,xls_rows,delete_flag
list=['',' ', '!' , '"' , '#' ,'$', '%' ,'&', '\'' , '(' , ')' ,'*', '+' , ',' , '-' , '.' , '/' , '0' , '1' ,\
'2' , '3' , '4' , '5' , '6' , '7' , '8' , '9' , ':' , '~' , '<' , '=' , '>' , '?' ,'@', 'A' , 'B' ,\
'C' , 'D' , 'E' , 'F' , 'G' , 'H' , 'I' , 'J' ,'K','L' , 'M' , 'N' , 'O', 'P' , 'Q' , 'R' , 'S' , \
'T' ,'U' , 'V' , 'W' , 'X' , 'Y' , 'Z','[', '\'', ']','^','_']

dict={0:'',32:' ',33:'!' , 34:'"' , 35:'#' ,36:'$',37:'%' ,38:'&', 39:'\'' ,40:'(' ,41:')' ,42:'*',43:'+' ,44:',' ,45:'-' ,46:'.' ,47:'/' ,48:'0' ,49:'1' ,\
50:'2' ,51:'3' ,52:'4' ,53:'5' ,54:'6' ,55:'7' ,56:'8' ,57:'9' ,58:':' ,126:'~' ,60:'<' ,61:'=' ,62:'>' ,63:'?' ,64:'@',65:'A' ,66:'B' ,\
67:'C' ,68:'D' ,69:'E' ,70:'F' ,71:'G' ,72:'H' ,73:'I' ,74:'J' ,75:'K',76:'L' ,77:'M' ,78:'N' ,79:'O',80:'P' ,81:'Q' ,82:'R' ,83:'S' , \
84:'T' ,85:'U' ,86:'V' ,87:'W' ,88:'X' ,89:'Y' ,90:'Z',91:'[',92:'\'',93:']',94:'^',95:'_'}

DEBUG_MODE = 1
RELEASE_MODE = 0

Mode = DEBUG_MODE

x=-1
y=-1
t=0
prev=0
page=1
flag=0
er_flag=0
q=0

counter=0
index=0
page_num=1
s=0
g=0
h=1
delete_flag=0
##flag_save=0
btn_cl1=0
btn_cl2=0
btn_cl3=0
btn_cl4=0
btn_cr1=0
btn_cr2=0
btn_cr3=0
btn_cr4=0
store_main=[[]]
store_main1=[[]]
store_sub=[]
store=[]
page_list=[]
cursor_col=[]
cursor_row=[]
frequency=[]
repeat=[]
check_sub=[]
check=[]
page_info=[]
page_txt=[]
def create(parent):
    global my_instance1
    my_instance1=Update_page(parent)
    return my_instance1

[wxID_FRAME2,wxID_FRAME2BUTTON1,wxID_FRAME2BUTTON2,wxID_FRAME2BUTTON3, 
 wxID_FRAME2BUTTON4,wxID_FRAME2BUTTON5,wxID_FRAME2BUTTON6,wxID_FRAME2BUTTON7,
 wxID_FRAME2BUTTON8,wxID_FRAME2BUTTON9,wxID_FRAME2BUTTON10,wxID_FRAME2BUTTON11,
 wxID_FRAME2BUTTON12,wxID_FRAME2BUTTON13,wxID_FRAME2BUTTON14,wxID_FRAME2BUTTON15,
 wxID_FRAME2GRID1,wxID_FRAME2GRID2,wxID_FRAME2GRID3, wxID_FRAME2PANEL1, wxID_FRAME2STATICTEXT1, 
 wxID_FRAME2STATICTEXT2,wxID_FRAME2STATICTEXT3,wxID_FRAME2STATICTEXT4,
 wxID_FRAME2STATICTEXT5,wxID_FRAME2STATICTEXT6,wxID_FRAME2TEXTCTRL1,wxID_FRAME2TEXTCTRL2, 
 wxID_FRAME2TEXTCTRL3,wxID_FRAME2TEXTCTRL6,wxID_FRAME2USBTBSTATICBOX1,wxID_FRAME2USBTBSTATICBOX2,
 wxID_FRAME2USBTBSTATICBOX3,wxID_FRAME2USBTBSTATICBOX4,
] = [wx.NewId() for _init_ctrls in range(34)]


def print_data(data):
    """Alterative print function"""
    if Mode == DEBUG_MODE:
        print data
          
class Update_page(wx.Frame):
    count=0
    flag_save=0
##    flag_change=0
    def _init_ctrls(self, prnt):
        # generated method, don't edit
    
        wx.Frame.__init__(self, id=wxID_FRAME2, name='', parent=prnt,
              pos=wx.Point(161, 128), size=wx.Size(678, 399),
              style=wx.SYSTEM_MENU | wx.CAPTION | wx.MINIMIZE_BOX|wx.CLOSE_BOX, title='Page Update')
        self.SetClientSize(wx.Size(657, 420))
        self.Center()
        self.panel1 = wx.Panel(id=wxID_FRAME2PANEL1, name='panel1', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(657, 420),
              style=wx.TAB_TRAVERSAL)

        self.grid1 = wx.grid.Grid(id=wxID_FRAME2GRID1, name='grid1',
              parent=self.panel1, pos=wx.Point(52, 0), size=wx.Size(550, 257),
              style=0)
        self.grid1.Bind(wx.grid.EVT_GRID_CELL_LEFT_CLICK, self.Event_handler)
					
        self.StaticBox1 = wx.StaticBox(id=wxID_FRAME2USBTBSTATICBOX1,           #staticbox 1
             label='', name='StaticBox1', parent=self.panel1,
             pos=wx.Point(4,258),
             size=wx.Size(305,103), style=0)

        self.grid2 = wx.grid.Grid(id=wxID_FRAME2GRID2, name='grid2',
              parent=self.panel1, pos=wx.Point(125, 270), size=wx.Size(180, 30),
              style=0)
              
        self.grid2.Bind(wx.grid.EVT_GRID_CELL_LEFT_CLICK, self.Event_handler_bkpaint)
        
        self.button7 = wx.Button(id=wxID_FRAME2BUTTON7, label='CL1',
              name='button7', parent=self.panel1, pos=wx.Point(9,32),
              size=wx.Size(33, 22), style=0)
        self.button7.Bind(wx.EVT_BUTTON, self.OnCL1, id=wxID_FRAME2BUTTON7)
        
        self.button8 = wx.Button(id=wxID_FRAME2BUTTON8, label='CL2',
              name='button8', parent=self.panel1, pos=wx.Point(8, 81),
              size=wx.Size(33, 22), style=0)
        self.button8.Bind(wx.EVT_BUTTON, self.OnCL2, id=wxID_FRAME2BUTTON8)
              
        self.button9 = wx.Button(id=wxID_FRAME2BUTTON9, label='CL3',
              name='button9', parent=self.panel1, pos=wx.Point(8, 130),
              size=wx.Size(33, 22), style=0)
        self.button9.Bind(wx.EVT_BUTTON, self.OnCL3, id=wxID_FRAME2BUTTON9)
                    
        self.button10 = wx.Button(id=wxID_FRAME2BUTTON10, label='CL4',
              name='button10', parent=self.panel1, pos=wx.Point(8, 180),
              size=wx.Size(33, 22), style=0)
        self.button10.Bind(wx.EVT_BUTTON, self.OnCL4, id=wxID_FRAME2BUTTON10)
        
        self.button11 = wx.Button(id=wxID_FRAME2BUTTON11, label='CR1',
              name='button11', parent=self.panel1, pos=wx.Point(612, 32),
              size=wx.Size(33, 22), style=0)
        self.button11.Bind(wx.EVT_BUTTON, self.OnCR1, id=wxID_FRAME2BUTTON11)
              
        self.button12 = wx.Button(id=wxID_FRAME2BUTTON12, label='CR2',
              name='button12', parent=self.panel1, pos=wx.Point(612, 81),
              size=wx.Size(33, 22), style=0)
        self.button12.Bind(wx.EVT_BUTTON, self.OnCR2, id=wxID_FRAME2BUTTON12)
              
        self.button13 = wx.Button(id=wxID_FRAME2BUTTON13, label='CR3',
              name='button13', parent=self.panel1, pos=wx.Point(612, 130),
              size=wx.Size(33, 22), style=0)
        self.button13.Bind(wx.EVT_BUTTON, self.OnCR3, id=wxID_FRAME2BUTTON13)         

        self.button14 = wx.Button(id=wxID_FRAME2BUTTON14, label='CR4',
              name='button14', parent=self.panel1, pos=wx.Point(612, 180),
              size=wx.Size(33, 22), style=0)
        self.button14.Bind(wx.EVT_BUTTON, self.OnCR4, id=wxID_FRAME2BUTTON14)
        
        self.staticText1 = wx.StaticText(id=wxID_FRAME2STATICTEXT1,
              label='Background Colour :', name='staticText1',
              parent=self.panel1, pos=wx.Point(10,270), size=wx.Size(97, 13),
              style=0)
        self.staticText1.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD, False,'Tahoma'))

        self.staticText2 = wx.StaticText(id=wxID_FRAME2STATICTEXT2,
              label='Text Colour :', name='staticText2', parent=self.panel1,
              pos=wx.Point(48, 305), size=wx.Size(63, 13), style=0)
        self.staticText2.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD, False,'Tahoma'))
		

        self.grid3 = wx.grid.Grid(id=wxID_FRAME2GRID3, name='grid3',
              parent=self.panel1, pos=wx.Point(125, 305), size=wx.Size(180, 30),
              style=0)
              
        self.grid3.Bind(wx.grid.EVT_GRID_CELL_LEFT_CLICK, self.Event_handler_txpaint)
        
        self.StaticBox2 = wx.StaticBox(id=wxID_FRAME2USBTBSTATICBOX2,        #staticbox 2
             label='', name='StaticBox2', parent=self.panel1,
             pos=wx.Point(4,365),
             size=wx.Size(645,45), style=0)
             
        self.staticText3 = wx.StaticText(id=wxID_FRAME2STATICTEXT3,
              label='Page No:', name='staticText3', parent=self.panel1,
              pos=wx.Point(318, 382), size=wx.Size(44, 13), style=0)
        self.staticText3.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD, False,'Tahoma'))
              
		
        self.textCtrl1 = wx.TextCtrl(id=wxID_FRAME2TEXTCTRL1, name='textCtrl1',
              parent=self.panel1, pos=wx.Point(372, 380), size=wx.Size(78, 21),
              style=0, value='')
        self.textCtrl1. SetEditable(0)
              
##        self.button6 = wx.Button(id=wxID_FRAME2BUTTON6, label='Go',
##              name='button4', parent=self.panel1, pos=wx.Point(452, 380),
##              size=wx.Size(40, 22), style=0)
##        self.button6.Bind(wx.EVT_BUTTON, self.OnGoto, id=wxID_FRAME2BUTTON6)
              
        self.staticText4 = wx.StaticText(id=wxID_FRAME2STATICTEXT4,
              label='Frequency :', name='staticText4', parent=self.panel1,
              pos=wx.Point(372, 330), size=wx.Size(58, 13), style=0)
        self.staticText4.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD, False,'Tahoma'))
		
            
        self.textCtrl2 = wx.TextCtrl(id=wxID_FRAME2TEXTCTRL2, name='textCtrl2',
              parent=self.panel1, pos=wx.Point(440, 328), size=wx.Size(38, 21),
              style=0, value='')
              
        self.staticText5 = wx.StaticText(id=wxID_FRAME2STATICTEXT5,
              label='Repeat :', name='staticText5', parent=self.panel1,
              pos=wx.Point(494, 330), size=wx.Size(42, 13), style=0)
        self.staticText5.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD, False,'Tahoma'))
		
              
        self.textCtrl3 = wx.TextCtrl(id=wxID_FRAME2TEXTCTRL3, name='textCtrl3',
              parent=self.panel1, pos=wx.Point(544, 328), size=wx.Size(38, 21),
              style=0, value='')
              
        self.StaticBox3 = wx.StaticBox(id=wxID_FRAME2USBTBSTATICBOX3,        #staticbox 3
             label='', name='StaticBox3', parent=self.panel1,
             pos=wx.Point(320,258),
             size=wx.Size(330,47), style=0)
             
        self.StaticBox4 = wx.StaticBox(id=wxID_FRAME2USBTBSTATICBOX4,        #staticbox 4
             label='', name='StaticBox4', parent=self.panel1,
             pos=wx.Point(320,313),
             size=wx.Size(330,47), style=0)
        self.button1 = wx.Button(id=wxID_FRAME2BUTTON1, label=' Previous ',
              name='button1', parent=self.panel1, pos=wx.Point(342, 273),
              size=wx.Size(60, 23), style=0)
        self.button1.Bind(wx.EVT_BUTTON, self.OnPreviousPage,
              id=wxID_FRAME2BUTTON1)
              
        self.button2 = wx.Button(id=wxID_FRAME2BUTTON2, label=' Next ',
              name='button2', parent=self.panel1, pos=wx.Point(415, 273),
              size=wx.Size(60, 23), style=0)
        self.button2.Bind(wx.EVT_BUTTON, self.OnNextPage, id=wxID_FRAME2BUTTON2)

        self.button3 = wx.Button(id=wxID_FRAME2BUTTON3, label=' Save ',
              name='button3', parent=self.panel1, pos=wx.Point(488, 273),
              size=wx.Size(65, 23), style=0)
        self.button3.Bind(wx.EVT_BUTTON, self.OnSave, id=wxID_FRAME2BUTTON3)

        self.button4 = wx.Button(id=wxID_FRAME2BUTTON4, label='Cancel',
              name='button4', parent=self.panel1, pos=wx.Point(565, 273),
              size=wx.Size(65, 23), style=0)
        self.button4.Bind(wx.EVT_BUTTON, self.OnCancel, id=wxID_FRAME2BUTTON4)
        
        self.button5 = wx.Button(id=wxID_FRAME2BUTTON5, label='Blink',
              name='button5', parent=self.panel1, pos=wx.Point(115, 335),
              size=wx.Size(44, 23), style=0)
        self.button5.Bind(wx.EVT_BUTTON, self.OnBlink, id=wxID_FRAME2BUTTON5)
        
        self.staticText6 = wx.StaticText(id=wxID_FRAME2STATICTEXT6,
              label='File name :', name='staticText1', parent=self.panel1,
              pos=wx.Point(14, 380), size=wx.Size(52, 13), style=0)
        self.staticText6.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD, False,'Tahoma'))
		
              
        self.textCtrl6 = wx.TextCtrl(id=wxID_FRAME2TEXTCTRL6, name='textCtrl6',
              parent=self.panel1, pos=wx.Point(76, 380), size=wx.Size(225, 21),
              style=0, value='')
        self.textCtrl6.SetEditable(0)
              
		
		
        self.button15 = wx.Button(id=wxID_FRAME2BUTTON15, label='Configure Hotkeys',
              name='button15', parent=self.panel1, pos=wx.Point(470, 380),
              size=wx.Size(120, 22), style=0)
        self.button15.Bind(wx.EVT_BUTTON, self.Hotkey, id=wxID_FRAME2BUTTON15)      
        self.Bind(wx.EVT_CLOSE, self.On_Close)
        
##        self.button16 = wx.Button(id=wxID_FRAME3BUTTON16, label='Reset',
##              name='button16', parent=self.panel1, pos=wx.Point(165, 335),
##              size=wx.Size(44, 23), style=0)
##        self.button16.Bind(wx.EVT_BUTTON, self.OnReset, id=wxID_FRAME3BUTTON16)
        
        self.Create_grids()             # Function calls
        self.Create_grids_bkpaint()
        self.Create_grids_txpaint()
        self.button1.Disable()

        file_name=CDU_TestRig_MainWindow.filename_xls 
        
##        self.wtbook = xlwt.Workbook()           # xls file to write into it
##        self.wtsheet = self.wtbook.add_sheet('Sheet 1') 
##        self.wtbook.save('filename_xls')
        self.rb = xlrd.open_workbook(file_name, formatting_info=True)
        self.w=copy(self.rb)
        
        self.textCtrl1.SetValue(str("Home1"))
        self.textCtrl2.SetValue(str(80))
        self.textCtrl3.SetValue(str(1))
        CDU_TestRig_MainWindow.update_select=1
        
                
        file_name=CDU_TestRig_MainWindow.filename_xls 
        wb = xlrd.open_workbook(file_name)        # xls file to read from
        sh1 = wb.sheet_by_index(0)                # first sheet in workbook
        sh2 = wb.sheet_by_name('Sheet 1') 
        rows=sh1.nrows
       
        num_page=(rows+1)/11
##        print rows,num_page
            
        for page_no in range(1,num_page+1):
            for i in range(0,page_no):
                next=(page_no)+10*i
##            print_data(next)
            self.xls_lists(next)
##        print_data(store_main)
        print_data(check)
        print_data(page_info)
        print "page_info",page_info
        
        self.display(1)
        for i in range(9):
            for j in range(21):
##                self.grid1.SetCellTextColour( i,j,"red");
                self.grid1.SetCellBackgroundColour( i,j,"black");
##        self.w.get_sheet(0).Clear()
        
        for i in range(xls_rows):
            for j in range(23):
                self.w.get_sheet(0).write(i,j,'')
        self.textCtrl6.SetValue(CDU_TestRig_MainWindow.filename_xls)
                      
    def __init__(self, parent):
        self._init_ctrls(parent)
                  
    def global_initialisation(self):        # Global variable initialisation
        global list,x,y,p,page,prev,t,store_main,store_sub,store,store_main1,flag,cursor_col,cursor_row,frequency,\
        repeat,filename_xls,q,counter,page_list,index,check_sub,check,page_info,page_num,h,s,g,btn_cl1,btn_cl2,\
        btn_cl3,btn_cl4,btn_cr1,btn_cr2,btn_cr3,btn_cr4,er_flag
        x=-1
        y=-1
        t=0
        prev=0
        page=1
        flag=0
        er_flag=0
        q=0
        h=1
        s=0
        g=0
        counter=0
        index=0
        page_num=1
        btn_cl1=0
        btn_cl2=0
        btn_cl3=0
        btn_cl4=0
        btn_cr1=0
        btn_cr2=0
        btn_cr3=0
        btn_cr4=0
##        flag_save=0
        store_main=[[]]
        store_main1=[[]]
        store_sub=[]
        store=[]
        page_list=[]
        cursor_col=[]
        cursor_row=[]
        frequency=[]
        repeat=[]
        check_sub=[]
        check=[]
        page_info=[]
     
    def Create_grids(self):			# To create grid1
        self.grid1.CreateGrid(9,21) 
        self.grid1.DisableDragGridSize()
        self.grid1.DisableDragColSize()
        self.grid1.DisableDragRowSize()
        for i in range (21):
            self.grid1.SetColLabelValue(i,str(i+1))
        for i in range (9):
             for j in range (21):
                self.grid1.SetRowSize( i, 25 );   
                self.grid1.SetColSize( j, 25 ); 
                self.grid1.SetCellAlignment(i,j,wx.ALIGN_CENTRE,wx.ALIGN_CENTRE)
                self.grid1.SetCellFont(i,j,wx.Font(15, wx.SWISS, wx.NORMAL, wx.BOLD))
        self.grid1.SetRowLabelSize(25)
        self.grid1.SetColLabelSize(30)
        self.grid1.SetRowSize(i,1)
        
        
    def Create_grids_bkpaint(self):        #To create background_colour grid
        self.grid2.CreateGrid(1,9)
        self.grid2.DisableDragGridSize()
        self.grid2.DisableDragColSize()
        self.grid2.DisableDragRowSize()
        self.grid2.SetCellBackgroundColour( 0,0,"white");
        self.grid2.SetCellBackgroundColour( 0,1,"green");
        self.grid2.SetCellBackgroundColour( 0,2,"gray");
        self.grid2.SetCellBackgroundColour( 0,3,(255, 170, 0));
        self.grid2.SetCellBackgroundColour( 0,4,"cyan");
        self.grid2.SetCellBackgroundColour( 0,5,"magenta");
        self.grid2.SetCellBackgroundColour( 0,6,"yellow");
        self.grid2.SetCellBackgroundColour( 0,7,"red");
        self.grid2.SetCellBackgroundColour( 0,8,"black");
        for k in range (9):
            self.grid2.SetColSize( k, 20);
            self.grid2.SetReadOnly(0,k);
        self.grid2.SetRowSize( 0, 20 );
        self.grid2.SetRowLabelSize(0)
        self.grid2.SetColLabelSize(0)
                    
    def Create_grids_txpaint(self):     #To create text_colour grid
        self.grid3.CreateGrid(1,8)
        self.grid3.DisableDragGridSize()
        self.grid3.DisableDragColSize()
        self.grid3.DisableDragRowSize()
        self.grid3.SetCellBackgroundColour( 0,0,"white");
        self.grid3.SetCellBackgroundColour( 0,1,"green");
        self.grid3.SetCellBackgroundColour( 0,2,"gray");
        self.grid3.SetCellBackgroundColour( 0,3,(255, 170, 0));
        self.grid3.SetCellBackgroundColour( 0,4,"cyan");
        self.grid3.SetCellBackgroundColour( 0,5,"magenta");
        self.grid3.SetCellBackgroundColour( 0,6,"yellow");
        self.grid3.SetCellBackgroundColour( 0,7,"red");
        for k in range (8):
            self.grid3.SetColSize( k, 22 ); 
            self.grid3.SetReadOnly(0,k);
        self.grid3.SetRowSize( 0, 20 );
        self.grid3.SetRowLabelSize(0)
        self.grid3.SetColLabelSize(0)
        
    def OnReset(self,event):
        self.grid1.SetCellBackgroundColour(x,y,"black")
        self.grid1.SetGridCursor(x,y)
           
    def Event_handler(self,evt):    # Event to get x,y co-ordinate of the grid
        global x,y
        x=evt.GetRow()
        y=evt.GetCol() 
        self.flag_save=0      
        evt.Skip()
        
    def Event_handler_bkpaint(self,evt):    # To get background colour
        global x,y

        m=evt.GetRow()
        n=evt.GetCol()

        bkColour=self.grid2.GetCellBackgroundColour(m,n)
        if(x!=-1 and y!=-1):
            self.grid1.SetCellBackgroundColour(x,y,bkColour)
            self.grid1.SetGridCursor(x,y)
        
        evt.Skip()
               
    def Event_handler_txpaint(self,evt):       # To get text colour
        global x,y
        a=evt.GetRow()
        b=evt.GetCol()
        
        bkColour=self.grid2.GetCellBackgroundColour(a,b)
        if(x!=-1 and y!=-1):
            self.grid1.SetCellTextColour(x,y,bkColour)
            self.grid1.SetGridCursor(x,y)
                  
        evt.Skip()
        
    def OnBlink(self, event):       # To apply blink to grid content
        a=self.grid1.GetCellFont(x,y)
        font_style=a.GetStyle()
        if(x!=-1 and y!=-1):
            if(font_style==90):
                self.grid1.SetCellFont(x,y,wx.Font(15, wx.SWISS, wx.ITALIC, wx.NORMAL))
            else:
                self.grid1.SetCellFont(x,y,wx.Font(15, wx.SWISS, wx.NORMAL, wx.BOLD))
            self.grid1.SetGridCursor(x,y)
           
        event.Skip()
        
    def OnPreviousPage(self, event):
        global list,store,store_sub,store_main,page,store_main1,flag
        y=0
        
        self.create_list(y)   # To store grid content into list
                            
        page_no=page
        
        for i in range(9):     # Displays list content into grid
            for j in range(21):
                value=store_main[page_no-1][i][j]
                blink=value%2
                if(blink==0):
                    self.grid1.SetCellFont(i,j,wx.Font(15, wx.SWISS, wx.NORMAL, wx.BOLD))
                elif(blink==1):
                    self.grid1.SetCellFont(i,j,wx.Font(15, wx.SWISS, wx.ITALIC, wx.NORMAL))
                else:
                    print "a"
                temp1=value/2
                temp2=temp1%128
                self.grid1.SetCellValue(i,j,dict[temp2])
                temp3=temp1/128
                temp4=temp3%16
              
                if(temp4==15):                                                   
                    self.grid1.SetCellTextColour( i,j,"black");
                elif(temp4==8):
                    self.grid1.SetCellTextColour( i,j,"red");
                elif(temp4==7):
                    self.grid1.SetCellTextColour( i,j,"yellow");
                elif(temp4==6):
                    self.grid1.SetCellTextColour( i,j,"magenta");
                elif(temp4==5):
                    self.grid1.SetCellTextColour( i,j,"cyan");
                elif(temp4==4):
                    self.grid1.SetCellTextColour( i,j,(255, 170, 0));
                elif(temp4==2):
                    self.grid1.SetCellTextColour( i,j,"gray");
                elif(temp4==1):
                    self.grid1.SetCellTextColour( i,j,"green");
                else:
                    self.grid1.SetCellTextColour( i,j,"white");
            
                temp4=temp3/16
                temp5=temp4%16
                if(temp5==15):
                    self.grid1.SetCellBackgroundColour( i,j,"black")
                elif(temp5==8):
                    self.grid1.SetCellBackgroundColour( i,j,"red")
                elif(temp5==7):
                    self.grid1.SetCellBackgroundColour( i,j,"yellow")
                elif(temp5==6):
                    self.grid1.SetCellBackgroundColour( i,j,"magenta")
                elif(temp5==5):
                    self.grid1.SetCellBackgroundColour( i,j,"cyan")
                elif(temp5==4):
                    self.grid1.SetCellBackgroundColour( i,j,(255, 170, 0))
                elif(temp5==2):
                    self.grid1.SetCellBackgroundColour( i,j,"gray")
                elif(temp5==1):
                    self.grid1.SetCellBackgroundColour( i,j,"green")
                else:
                    self.grid1.SetCellBackgroundColour( i,j,"white")
   
        event.Skip()
        
    def OnNextPage(self, event):  
        global list,store,store_sub,store_main,page,flag,counter,index
        y=1  
        
        self.create_list(y)   # To store grid containt into list
                
        page_no=page
        number=Update_home.uphome_no
##        print "h-",h
##        print "number",number
####        print store_main
        if(len(store_main)>=page_no):
            print "next page"
##            print store_main  
            if(store_main[page-1]!=[]): 
                for i in range(9):                 # Displays list content into grid
                    for j in range(21):
                        value=store_main[page-1][i][j]
                        blink=value%2
                        if(blink==0):
                            self.grid1.SetCellFont(i,j,wx.Font(15, wx.SWISS, wx.NORMAL, wx.BOLD))
                        elif(blink==1):
                            self.grid1.SetCellFont(i,j,wx.Font(15, wx.SWISS, wx.ITALIC, wx.NORMAL))
                        else:
                            print "b"
                        temp1=value/2
                        temp2=temp1%128
                        self.grid1.SetCellValue(i,j,dict[temp2])
                        temp3=temp1/128
                        temp4=temp3%16
                        
                        if(temp4==8):
                            self.grid1.SetCellTextColour( i,j,"red");
                        elif(temp4==7):
                            self.grid1.SetCellTextColour( i,j,"yellow");
                        elif(temp4==6):
                            self.grid1.SetCellTextColour( i,j,"magenta");
                        elif(temp4==5):
                            self.grid1.SetCellTextColour( i,j,"cyan");
                        elif(temp4==4):
                            self.grid1.SetCellTextColour( i,j,(255, 170, 0));
                        elif(temp4==2):
                            self.grid1.SetCellTextColour( i,j,"gray");
                        elif(temp4==1):
                            self.grid1.SetCellTextColour( i,j,"green");
                        elif(temp4==0):
                            self.grid1.SetCellTextColour( i,j,"white");
                        else:
                            self.grid1.SetCellTextColour( i,j,"black");
                
                        temp4=temp3/16
                        temp5=temp4%16
                        if(temp5==8):
                            self.grid1.SetCellBackgroundColour( i,j,"red");
                        elif(temp5==7):
                            self.grid1.SetCellBackgroundColour( i,j,"yellow");
                        elif(temp5==6):
                            self.grid1.SetCellBackgroundColour( i,j,"magenta");
                        elif(temp5==5):
                            self.grid1.SetCellBackgroundColour( i,j,"cyan");
                        elif(temp5==4):
                            self.grid1.SetCellBackgroundColour( i,j,(255, 170, 0));
                        elif(temp5==2):
                            self.grid1.SetCellBackgroundColour( i,j,"gray");
                        elif(temp5==1):
                            self.grid1.SetCellBackgroundColour( i,j,"green");
                        elif(temp5==0):
                            self.grid1.SetCellBackgroundColour( i,j,"white");
                        else:
                            self.grid1.SetCellBackgroundColour( i,j,"black");
        event.Skip()
    
    def OnSave(self, event):
        global list,store,store_sub,store_main,page,cursor_col,cursor_row,frequency,repeat,\
        check,page_info,h,filename_xls,er_flag
        list_check=[0,0,0,0,0,0,0,0]
        t=0
        s=0
        count=0
        y=2
        q=1
        f=0
        
        for i in range (9):
            for j in range (21):
                self.grid1.SetCellBackgroundColour( i,j,"black")
        
        self.create_list(y)
      
##        if(self.flag_save==0 & er_flag==0):                    # To display browser window
##            dlg = wx.FileDialog(self, "Choose a file", ".", "", "*.xls", wx.SAVE)
##            if dlg.ShowModal() == wx.ID_OK:
##                global browse
##                browse=1
##                filename_xls = dlg.GetPath()
##                self.flag_save=1
##                
##        if(self.flag_save==1):                   # Once file is selected,next time onwards it saves to same file
        self.flag_save=1
        filename_xls=CDU_TestRig_MainWindow.filename_xls
              
       # self.create_list(y)
        number=Update_home.uphome_no
        print "h---->",h-1,
        print "number---->",Update_home.uphome_no
        
        print "check",check
        print "frequency",frequency
        print "page_info",page_info
        print "store_main",store_main
        
        cur_home=int(h)-1
        if(CDU_TestRig_MainWindow.prev_page<number):
            cur_home=int(h)-1
            if(page==1):
                if(h == number+1):
                    cur_home=int(h)-2
                           
        if(cur_home ==int(number)):           # if all pages are created as per total no of home pages
            print "equal both"
            self.w.get_sheet(0).write(0,0,'Page')
            self.w.get_sheet(0).write(0,1,page_info[0])
            self.w.get_sheet(0).write(0,2,'Frequency')
            self.w.get_sheet(0).write(0,3,frequency[0])
            self.w.get_sheet(0).write(0,4,'Repeat')
            self.w.get_sheet(0).write(0,5,repeat[0]) 
            self.w.get_sheet(0).write(0,6,'Cursor Position')
            self.w.get_sheet(0).write(0,7,cursor_row[0])
            self.w.get_sheet(0).write(0,8,cursor_col[0])
##            print"len(store_main).....>",len(store_main)
##            print "len store_main[len(store_main)-1]",len(store_main[len(store_main)-1])
            if(len(store_main[len(store_main)-1])==0):
##                print "empty,,,,,,,,,,>"
                lenght=len(store_main)-1
            else:
##                print "not empty.......>"
                lenght=len(store_main)
                
            print "page_info",page_info
            
            for i in range(lenght):
                for j in range(9):
                    for k in range(21): 
                        self.w.get_sheet(0).write(j+1+t,k+1,store_main[i][j][k])
                if(q<len(frequency) and q<lenght):
                    self.w.get_sheet(0).write(((i+1)+(10*(i+1))),0,'Page')
                    self.w.get_sheet(0).write(((i+1)+(10*(i+1))),1,page_info[q])
                    self.w.get_sheet(0).write(((i+1)+(10*(i+1))),2,'Frequency')
                    self.w.get_sheet(0).write(((i+1)+(10*(i+1))),3,frequency[q])
                    self.w.get_sheet(0).write(((i+1)+(10*(i+1))),4,'Repeat')
                    self.w.get_sheet(0).write(((i+1)+(10*(i+1))),5,repeat[q]) 
                    self.w.get_sheet(0).write(((i+1)+(10*(i+1))),6,'Cursor Position') 
                    self.w.get_sheet(0).write(((i+1)+(10*(i+1))),7,cursor_row[q])
                    self.w.get_sheet(0).write(((i+1)+(10*(i+1))),8,cursor_col[q])   
                self.w.get_sheet(0).write((t+1),0,check[s][0])
                self.w.get_sheet(0).write((t+3),0,check[s][1])
                self.w.get_sheet(0).write((t+5),0,check[s][2])
                self.w.get_sheet(0).write((t+7),0,check[s][3])
                self.w.get_sheet(0).write((t+1),22,check[s][4])
                self.w.get_sheet(0).write((t+3),22,check[s][5])
                self.w.get_sheet(0).write((t+5),22,check[s][6])
                self.w.get_sheet(0).write((t+7),22,check[s][7])
                s=s+1
                t=t+11
                q=q+1
            print "page_info",page_info
        else:    
            print "both r not equal"                        # if all pages are not created as per total no of home pages
            for i in range(9):
                for j in range(21):
                    store.append(63488)
                store_sub.append(store)
                store=[]
     
            for h1 in range(int(h),int(number)+1): # To generate not created page number info
                x=(h1)
                x=x*4096
                page_info.append(x)

##            print "page_info",page_info
##            print "On save :frequency",frequency
##            
##            print "len(frequency)",len(frequency)
##            print "len(page_info)",len(page_info)
            print "frequency",frequency
            print "check",check
                
            for h1 in range(len(frequency),len(page_info)):  # To generate not created page frequency,
                print "less than created values"
                frequency.append(80)                        # repeat,cursor_row,cursor_col,check
                repeat.append(1)                            # and empty page content
                cursor_row.append(0)
                cursor_col.append(0)
                check.append(list_check)
                store_main.insert((page+f),store_sub)
                f=f+1
       
##            print "check",check
            
            self.w.get_sheet(0).write(0,0,'Page')           # write into xls sheet
            self.w.get_sheet(0).write(0,1,page_info[0])
            self.w.get_sheet(0).write(0,2,'Frequency')
            self.w.get_sheet(0).write(0,3,frequency[0])
            self.w.get_sheet(0).write(0,4,'Repeat')
            self.w.get_sheet(0).write(0,5,repeat[0]) 
            self.w.get_sheet(0).write(0,6,'Cursor Position')
            self.w.get_sheet(0).write(0,7,cursor_row[0])
            self.w.get_sheet(0).write(0,8,cursor_col[0])
            
            if(len(store_main[len(store_main)-1])==0):
##                print "empty........>"
                lenght=len(store_main)-1
            else:
##                print "not empty.......>"
                lenght=len(store_main)
            
            for i in range(lenght):
                for j in range(9):
                    for k in range(21): 
                        self.w.get_sheet(0).write(j+1+t,k+1,store_main[i][j][k])
                if(q<len(frequency) and q<lenght and q<len(page_info) ):
                    self.w.get_sheet(0).write(((i+1)+(10*(i+1))),0,'Page')
                    self.w.get_sheet(0).write(((i+1)+(10*(i+1))),1,page_info[q])
                    self.w.get_sheet(0).write(((i+1)+(10*(i+1))),2,'Frequency')
                    self.w.get_sheet(0).write(((i+1)+(10*(i+1))),3,frequency[q])
                    self.w.get_sheet(0).write(((i+1)+(10*(i+1))),4,'Repeat')
                    self.w.get_sheet(0).write(((i+1)+(10*(i+1))),5,repeat[q]) 
                    self.w.get_sheet(0).write(((i+1)+(10*(i+1))),6,'Cursor Position') 
                    self.w.get_sheet(0).write(((i+1)+(10*(i+1))),7,cursor_row[q])
                    self.w.get_sheet(0).write(((i+1)+(10*(i+1))),8,cursor_col[q])
                
                self.w.get_sheet(0).write((t+1),0,check[s][0])
                self.w.get_sheet(0).write((t+3),0,check[s][1])
                self.w.get_sheet(0).write((t+5),0,check[s][2])
                self.w.get_sheet(0).write((t+7),0,check[s][3])
                self.w.get_sheet(0).write((t+1),22,check[s][4])
                self.w.get_sheet(0).write((t+3),22,check[s][5])
                self.w.get_sheet(0).write((t+5),22,check[s][6])
                self.w.get_sheet(0).write((t+7),22,check[s][7])
                s=s+1
                t=t+11
                q=q+1
##        print "updated store_main",store_main
        self.w.save(filename_xls)
        self.textCtrl6.SetValue(filename_xls)
        
        head=os.path.split(filename_xls)
        pathnfile=os.path.join(head[0],"CDUHOTKEY.xls")
##        print "pathnfile",pathnfile
        if os.path.exists(pathnfile)==True:
            self.var=0
            self.writetoxls(pathnfile,head)
        else:
            wtbook = xlwt.Workbook()           # xls file to write into it 
            wtsheet = wtbook.add_sheet(u'First')
            wtbook.save(pathnfile)
            self.var=1
            self.writetoxls(pathnfile,head) 
      
        event.Skip()
        
    def writetoxls(self,pathnfile,head):
        global page_txt
        list4=['Nopage','Nopage','Nopage','Nopage','Nopage','Nopage','Nopage','Nopage']
        xls_list=[] 
        valtohome=[]
        list1=[]
        list1.append(head[1])
##        print page_info,"page_info"
##        if (len(Hotkey.configkey)==0):
        for i in range(len(page_info)):
            val=hex(page_info[i])
            val1=val.split('0x')
            val4=int(val1[1])
##            print " vvvval-------->",val,val1,val4
            if (val4%1000==0): 
                val2=val4/1000
                valtohome.append("Home{0}".format(val2))
            else:
                val2=val4/1000
                val3=(val4%1000)/100
                if val3<=4:
                   valtohome.append('Home{0}-CL{1}'.format(val2,val3))  
                else:
                   
                   valtohome.append('Home{0}-CR{1}'.format(val2,val3-4))  
        Hotkey.configkey=valtohome                
        rb = xlrd.open_workbook(pathnfile, formatting_info=True)
##        print "head" ,head[1],Hotkey.hot_list,Hotkey.configkey
        w=copy(rb)
        sheet=rb.sheet_by_index(0)
        rows, cols = sheet.nrows, sheet.ncols
        if (self.var==1):  
            for index in range(rows,rows+1):
                for index1 in range(1):
                    w.get_sheet(0).write(rows,index1,head[1])
##                    print "head[1]",head[1]
                for index1 in range(1,8):
                    if len(Hotkey.hot_list)==0:
                        Hotkey.hot_list=list4
                        w.get_sheet(0).write(rows,index1,Hotkey.hot_list[index1-1])
                    else: 
                        w.get_sheet(0).write(rows,index1,Hotkey.hot_list[index1-1])
                for index2 in range(8,len(Hotkey.configkey)+8):
                    w.get_sheet(0).write(rows,index2,Hotkey.configkey[index2-8])
            w.save(pathnfile)        
        elif(self.var==0):            
            for i in range(rows):
                read_row=sheet.row_values(i)
##                print read_row,read_row[0],head[1],str(head[1])
                xls_list.append(read_row[0])
##            print xls_list
##            print list
            if list1[0] in xls_list:
                var=xls_list.index(list1[0])
##                print var
                list1=[]
                
##            if read_row[0]==str(head[1]):
                i=rows
##                print "hhhhhhhhhhhhhhhhh"
                for i in range(len(read_row)):
                    w.get_sheet(0).write(var,i+1,'')
                for index1 in range(1,8):
                    if len(Hotkey.hot_list)==0:
                        Hotkey.hot_list=list4
                        w.get_sheet(0).write(var,index1,Hotkey.hot_list[index1-1])
                    else: 
                        w.get_sheet(0).write(var,index1,Hotkey.hot_list[index1-1])
                for index2 in range(8,len(Hotkey.configkey)+8):
                    w.get_sheet(0).write(var,index2,Hotkey.configkey[index2-8]) 
##                print len(Hotkey.configkey)      
            else:
                list1=[]
                
##                print "jjjjjjjjjeeeeeeeeeeee"
                for index in range(rows,rows+1):
                    for index1 in range(1):
                        w.get_sheet(0).write(rows,index1,head[1])
##                        print "head[1]",head[1]
                    for index1 in range(1,8):
                        if len(Hotkey.hot_list)==0:
                              Hotkey.hot_list=list4
                              w.get_sheet(0).write(rows,index1,Hotkey.hot_list[index1-1])
                        else:      
                            w.get_sheet(0).write(rows,index1,Hotkey.hot_list[index1-1])
                    for index2 in range(8,len(Hotkey.configkey)+8):
                         w.get_sheet(0).write(rows,index2,Hotkey.configkey[index2-8])                             
            w.save(pathnfile)    
        
    def create_list(self,y):
        global list,store,store_sub,store_main,page,store_main1,store1,cursor_col,cursor_row,frequency,repeat,q,\
        check,page_info,h,btn_cl1,btn_cl2,btn_cl3,btn_cl4,btn_cr1,btn_cr2,btn_cr3,btn_cr4,page_txt,er_flag,delete_flag
        k=0
        flag=0
        flag_check=0
        flag_error=0
        er_flag=0
        store1=[]
        store_c=[]
        store_subc=[]
        grid_colour=bin(0)
        page_creation.new_confirm=1
        CDU_TestRig_MainWindow.update_select=1
        self.button1.Enable()
        self.button2.Enable()
        
        self.check_box()          # Call to checkbox function to get check clicks
        
        change_checki=[]
        change_checkd=[]
        temp_page_info=[]
        print "page_info before assignment.........>",page_info
        temp_page_info=page_info
        page_info=[]
        page_txt=[]                        
        counter=0
        h=1
        p=0
        page_no=page
        page_txt.append("Home{0}".format(h))    # To store page sequence in list
        x=(h)
        x=x*4096
##        x=int(x,16)
        page_info.append(x)
        h=h+1 

        for i in range(len(check)):
            for j in range(8):
                if(check[i][j]==1):
                    if(j<4):
                        page_txt.append("Home{0}-CL{1}".format(h-1,(j+1)))
                    else:
                        temp=(j+1)-4
                        page_txt.append("Home{0}-CR{1}".format(h-1,(temp)))
                    counter=counter+1
                    x=(h-1)
                    x=x*4096
                    z=(j+1)
                    z=z*256
                    x=x+z
                    page_info.append(x)  # To page no in 16 bit format
                           
            if(i==(counter+p)):
                p=p+1
                number=Update_home.uphome_no
##                print "h-{0} home-{1} y-{2} ".format(h,Update_home.uphome_no,y)
                if(int(h) <= int(number)):      # To check pages are within no of home pages
                    page_txt.append("Home{0}".format(h))
                    x=(h)
                    x=x*4096
                    page_info.append(x)     # To page no in 16 bit format  
                    h=h+1 
                else:
                    pg=page
##                    print "else part........>"
##                    print page,len(check)
##                    if(y==0 and pg-1==len(check)):       # On previous page click
##                        flag_error=1
##                        dial = wx.MessageDialog(None, "Next page is not present",\
##                        'Error !!!', wx.OK|wx.STAY_ON_TOP)
##                        dial.ShowModal() 
##                    print "pg",pg
##                    print "len(check)",len(check)
                    if(y==1 and pg==len(check)):        # on next page click
                        flag_error=1
                        self.button2.Disable()
                        dial = wx.MessageDialog(None, "Next page is not present",\
                        'Error !!!', wx.OK|wx.STAY_ON_TOP)
                        dial.ShowModal() 
                    break
##        print "h-{0} home-{1} y-{2} ".format(h,Update_home.uphome_no,y)        
        print page_info
        print page_txt  
        page_text=str(self.textCtrl1.GetValue())
        
        if(len(page_info)>len(temp_page_info) and len(page_text)<7 and len(temp_page_info)!=0 ):     # insertion subpages
            for i in range(len(page_info)):
                if(k<len(temp_page_info) and page_info[i]==temp_page_info[k]):
                    k=k+1
                else:
                    change_checki.append(page_info[i])              # position is stored
                    flag_check=1 
                    print "change_checki{0}".format(change_checki)  # mismatch check list is added for insertion
            
        if(len(page_info)<len(temp_page_info) and len(page_text)<7):     # deletion subpages
##            print "temp_page_info{0}".format(temp_page_info) 
##            print "page_info{0}".format(page_info)      
            for i in range(len(temp_page_info)):
                if(k<len(page_info) and temp_page_info[i]==page_info[k]):
                    k=k+1
                else:
                    change_checkd.append(temp_page_info[i])    # mismatch check list is added for deletion
                    flag_check=2 
##            print "change_checkd{0}".format(change_checkd) 
            
        if(flag_check==1):         # To insert empty page at specific position (for check buttons)
            store_subc=[] 
            for i in range(9):
                for j in range(21):
                    store_c.append(63488)
                store_subc.append(store_c)
                store_c=[]     
            m=0   
            for i in range(len(page_info)):
                if(m<len(change_checki) and change_checki[m]==page_info[i]):
                    print "insert at..........>"
                    frequency.insert(i,80)
                    check.insert(i,[0,0,0,0,0,0,0,0])
                    repeat.insert(i,1)
                    cursor_col.insert(i,0)
                    cursor_row.insert(i,0)
                    store_main.insert(i,store_subc)  
                    m=m+1
                else:
                    print "aaaa"  
            
        if(flag_check==2):      # Delete page at specific postion (for check buttons)
            m=0  
            k=0    
            print "change_checkd{0}".format(change_checkd) 
            print "temp_page_info{0}".format(temp_page_info)        
            for i in range(len(temp_page_info)):
                if(m<len(change_checkd) and change_checkd[m]==temp_page_info[i]):
                    if page_creation.new_confirm==1:
                        del store_main[i-k] 
                        del frequency[i-k]
                        del repeat[i-k]
                        del cursor_col[i-k]
                        del cursor_row[i-k]
                        m=m+1
                        k=k+1
                else:
                    print "bbbb"                  
##        print store_main 
        n=0
        length=len(store_main)
##        print "main len-",len(store_main)
##        print "page_info-",len(page_info)
##        print "prev",CDU_TestRig_MainWindow.prev_page
##        print "number",number
        number=Update_home.uphome_no
        if( page==1 and CDU_TestRig_MainWindow.prev_page>number and flag_error==0 and delete_flag==0 and len(page_info)!=0):  # deletion of pages(if less than currect page)
##            print "page==1............>"
##            if page_creation.new_confirm==0:
            for i in range(len(page_info),length):
                del store_main[len(page_info)] 
                
                if(len(check)>=len(page_info)):
                    del check[len(page_info)] 
                    del frequency[len(page_info)] 
                    del repeat[len(page_info)] 
                    del cursor_col[len(page_info)] 
                    del cursor_row[len(page_info)] 
            delete_flag=1
##            print "aft check",check
##            print " aft store_main",store_main
##            print "aft cursor_col",cursor_col

        for i in range(9):      # Read grid content and checks valid/invalid
            flag=0
            for j in range(21):
                flag=0
                value=str(self.grid1.GetCellValue(i, j))
                k=0
                while(flag!=1 and k<len(list)):
                    if(value==list[k]):     # check grid value is valid
                        flag=1  
                        bkColour=self.grid1.GetCellBackgroundColour(i,j)
                        txcolour=self.grid1.GetCellTextColour(i,j)
                        a=self.grid1.GetCellFont(i,j)
                        font_style=a.GetStyle()
                        if(bkColour[0]== 255 and bkColour[1]==255 and bkColour[2]==255 ):
                            grid_colour='0000'
                        elif(bkColour[0]== 0 and bkColour[1]==255 and bkColour[2]==0):
                            grid_colour='0001'
                        elif(bkColour[0]== 128 and bkColour[1]==128 and bkColour[2]==128):
                            grid_colour='0010'
                        elif(bkColour[0]== 255 and bkColour[1]==170 and bkColour[2]==0):
                            grid_colour='0100'
                        elif(bkColour[0]== 0 and bkColour[1]==255 and bkColour[2]==255 ):
                            grid_colour='0101'
                        elif(bkColour[0]== 255 and bkColour[1]==0 and bkColour[2]==255):
                            grid_colour='0110'
                        elif(bkColour[0]==255 and bkColour[1]==255 and bkColour[2]==0 ):
                            grid_colour='0111'
                        elif(bkColour[0]==255 and bkColour[1]==0 and bkColour[2]==0 ):
                            grid_colour='1000'
                        else:
                            grid_colour='1111'
                            
                        if(txcolour[0]==255 and txcolour[1]==255 and txcolour[2]==255 ):
                            grid_colour=grid_colour+'0000'
                        elif(txcolour[0]==0 and txcolour[1]==255 and txcolour[2]==0 ):
                            grid_colour=grid_colour+'0001'
                        elif(txcolour[0]==128 and txcolour[1]==128 and txcolour[2]==128 ):
                            grid_colour=grid_colour+'0010'
                        elif(txcolour[0]==255 and txcolour[1]==170 and txcolour[2]==0 ):
                            grid_colour=grid_colour+'0100'
                        elif(txcolour[0]==0 and txcolour[1]==255 and txcolour[2]==255 ):
                            grid_colour=grid_colour+'0101'
                        elif(txcolour[0]==255 and txcolour[1]==0 and txcolour[2]==255 ):
                            grid_colour=grid_colour+'0110'
                        elif(txcolour[0]==255 and txcolour[1]==255 and txcolour[2]==0 ):
                            grid_colour=grid_colour+'0111'
                        elif(txcolour[0]==255 and txcolour[1]==0 and txcolour[2]==0 ):
##                            print "red",i,j
                            grid_colour=grid_colour+'1000'
                        else:
                            grid_colour=grid_colour+'1111'
                            
                        if(value!=''):
                            ascii=ord(value)        # Convertion to its ascii value
                            ascii_bin=bin(ascii)
                            if(len(ascii_bin)==8):
                                ascii=ascii_bin.replace('0b','0')
                            else:
                                ascii=ascii_bin.replace('0b','')
                        else:
                            ascii='0000000'
                            
                        grid_colour=grid_colour+ascii
                        
                        if(font_style==90):  
                            grid_colour=grid_colour+'0'  #font_style=90 NO Blink
                        else: 
                            grid_colour=grid_colour+'1'  #font_style=93 Blink
                            
                        value=int(grid_colour,2)                           
                        
                        store.append(value)
                        store[j]=value
                        store1=[] 
                        value=''              
                        break
                    else:
                        store1.append(value)           
                    k=k+1                                   
                if(flag==0):
                    er_flag=1
                    dial = wx.MessageDialog(None, "Input value '{0}' at row {1} and column {2} is invalid!!".format(value,i+1,j+1),\
                    'Error !!!', wx.OK|wx.STAY_ON_TOP)
                    dial.ShowModal()  
                    break                     
            if(flag==0):
                break  
            store_sub.append(store)
            store=[]
  
        page_no=page-1
##        print store_main
##        print "IN create"
##        print page_no+1,len(store_main)
        if(page_no+1==len(store_main)):      # extend list when new page is created
            store_main[page_no]=store_sub
            store_main.extend(store_main1)
        elif(page_no+1<len(store_main)):     
            store_main[page_no]=store_sub
        store_sub=[]  
##        store_main[page_no]=store_sub
##        store_sub=[] 
##        print page_no
        print "y-------------->",y
        print "update"
##        print store_main
        b=[]
        c=[]
        d=[]
        e=[]
        if(page_no<=len(frequency)): 
            try:
##                print "freq at create list.......>"
##                print "frequency",frequency
                b.append(int(str(self.textCtrl2.GetValue())))
                if(page_no>=len(frequency)):
                    frequency.extend(b)
                frequency[page_no]=b[0]             # To store frequency of every page
##                er_flag=0
            except ValueError:
                flag_error=1
                er_flag=1
                dial = wx.MessageDialog(None, "Frequency should be integer value",\
                'Error !!!', wx.OK|wx.STAY_ON_TOP)
                dial.ShowModal()
                
            try:             
                c.append(int(str(self.textCtrl3.GetValue())))
                if(page_no>=len(repeat)):
                    repeat.extend(c)
                repeat[page_no]=c[0]                # To store repeat of every page
##                er_flag=0
            except ValueError:
                flag_error=1
                er_flag=1
                dial = wx.MessageDialog(None, "Repeat should be integer value",\
                'Error !!!', wx.OK|wx.STAY_ON_TOP)
                dial.ShowModal()
          
            d.append(int(self.grid1.GetGridCursorRow()))
            if(page_no>=len(cursor_row)):
                cursor_row.extend(d)
            cursor_row[page_no]=d[0]            # To store cursor_row of every page
            print "cursor_row",cursor_row
       
            e.append(int(self.grid1.GetGridCursorCol()))
            if(page_no>=len(cursor_col)):
                cursor_col.extend(e)
            cursor_col[page_no]=e[0]            # To store cursor_col of every page
            print "cursor_col",cursor_col
##        print "y-{0}".format(y)   
                  
        if(len(store1)<59):              # if page has valid content
            if(y==0 and flag_error==0):                          
                if(page==1):  
                    self.button1.Disable()      
                    dial = wx.MessageDialog(None, "Previous page is not present",\
                    'Error !!!', wx.OK|wx.STAY_ON_TOP)
                    dial.ShowModal()          
                elif(page>1):
                    page=page-1
                    q=q-1
                    self.grid1.SetFocus()
                    self.grid1.SetGridCursor(cursor_row[page-1],cursor_col[page-1])
                    if(q<len(page_txt)):
                        self.textCtrl1.SetValue(str(page_txt[q]))
                    if(page<=len(check)):
                        for j in range(8):
                            if(check[page-1][j]==1):  
                                if(j==0):
                                    btn_cl1=1
                                    self.button7.SetBackgroundColour('gray')
                                if(j==1):
                                    btn_cl2=1
                                    self.button8.SetBackgroundColour('gray')
                                if(j==2):
                                    btn_cl3=1
                                    self.button9.SetBackgroundColour('gray')
                                if(j==3):
                                    btn_cl4=1
                                    self.button10.SetBackgroundColour('gray')
                                if(j==4):
                                    btn_cr1=1
                                    self.button11.SetBackgroundColour('gray')
                                if(j==5): 
                                    btn_cr2=1
                                    self.button12.SetBackgroundColour('gray')
                                if(j==6):
                                    btn_cr3=1
                                    self.button13.SetBackgroundColour('gray')
                                if(j==7): 
                                    btn_cr4=1
                                    self.button14.SetBackgroundColour('gray')
                            elif(check[page-1][j]==0):
                                if(j==0):
                                    btn_cl1=0
                                    self.button7.SetBackgroundColour('white')
                                if(j==1):
                                    btn_cl2=0
                                    self.button8.SetBackgroundColour('white')
                                if(j==2):
                                    btn_cl3=0
                                    self.button9.SetBackgroundColour('white')
                                if(j==3):
                                    btn_cl4=0
                                    self.button10.SetBackgroundColour('white')
                                if(j==4):
                                    btn_cr1=0
                                    self.button11.SetBackgroundColour('white')
                                if(j==5): 
                                    btn_cr2=0
                                    self.button12.SetBackgroundColour('white')
                                if(j==6):
                                    btn_cr3=0
                                    self.button13.SetBackgroundColour('white')
                                if(j==7): 
                                    btn_cr4=0
                                    self.button14.SetBackgroundColour('white')
                    if(q<len(page_txt) and len(page_txt[q])>6):
                        self.button7.Disable()
                        self.button8.Disable()
                        self.button9.Disable()
                        self.button10.Disable()
                        self.button11.Disable()
                        self.button12.Disable()
                        self.button13.Disable()
                        self.button14.Disable()   
                    else:
                        self.button7.Enable()
                        self.button8.Enable()
                        self.button9.Enable()
                        self.button10.Enable()
                        self.button11.Enable()
                        self.button12.Enable()
                        self.button13.Enable()
                        self.button14.Enable()     
                        self.grid1.ClearGrid()           # clear grid on every previous btn click
                    for i in range (9):
                        for j in range (21):
                            print " setting black on previous..............>",i,j
                            self.grid1.SetCellBackgroundColour( i,j,"black")
                            self.grid1.SetCellTextColour( i,j,"red");
                            self.grid1.SetCellFont(i,j,wx.Font(15, wx.SWISS, wx.NORMAL, wx.BOLD))
                if(q<len(frequency)):
                    self.textCtrl2.SetValue(str(frequency[q]))
                if(q<len(repeat)):
                    self.textCtrl3.SetValue(str(repeat[q]))
               
            elif(y==1 and flag_error==0 and page<=len(page_info)-1):           # On next btn click
                page=page+1
                q=q+1
                if(page-1<len(cursor_row)):
                    self.grid1.SetFocus()
                    self.grid1.SetGridCursor(cursor_row[page-1],cursor_col[page-1])
                if(q<len(page_txt)):
                    self.textCtrl1.SetValue(str(page_txt[q]))
                if(q<len(page_txt) and len(page_txt[q])>6):
                    btn_cl1=0
                    btn_cl2=0
                    btn_cl3=0
                    btn_cl4=0
                    btn_cr1=0
                    btn_cr2=0
                    btn_cr3=0
                    btn_cr4=0
                    self.button7.Disable()
                    self.button8.Disable()
                    self.button9.Disable()
                    self.button10.Disable()
                    self.button11.Disable()
                    self.button12.Disable()
                    self.button13.Disable()
                    self.button14.Disable()  
                else:
                    self.button7.Enable()
                    self.button8.Enable()
                    self.button9.Enable()
                    self.button10.Enable()
                    self.button11.Enable()
                    self.button12.Enable()
                    self.button13.Enable()
                    self.button14.Enable()       
                 
                if(page<=len(check)):
                    for j in range(8):
                        if(check[page-1][j]==1):
                            self.button7.Enable()
                            self.button8.Enable()
                            self.button9.Enable()
                            self.button10.Enable()
                            self.button11.Enable()
                            self.button12.Enable()
                            self.button13.Enable()
                            self.button14.Enable()  
                            if(j==0):
                                btn_cl1=1
                                self.button7.SetBackgroundColour('gray')
                            if(j==1):
                                btn_cl2=1
                                self.button8.SetBackgroundColour('gray')
                            if(j==2):
                                btn_cl3=1
                                self.button9.SetBackgroundColour('gray')
                            if(j==3):
                                btn_cl4=1
                                self.button10.SetBackgroundColour('gray')
                            if(j==4):
                                btn_cr1=1
                                self.button11.SetBackgroundColour('gray')
                            if(j==5): 
                                btn_cr2=1
                                self.button12.SetBackgroundColour('gray')
                            if(j==6):
                                btn_cr3=1
                                self.button13.SetBackgroundColour('gray')
                            if(j==7): 
                                btn_cr4=1
                                self.button14.SetBackgroundColour('gray')
                        elif(check[page-1][j]==0):
                            if(j==0):
                                btn_cl1=0
                                self.button7.SetBackgroundColour('white')
                            if(j==1):
                                btn_cl2=0
                                self.button8.SetBackgroundColour('white')
                            if(j==2):
                                btn_cl3=0
                                self.button9.SetBackgroundColour('white')
                            if(j==3):
                                btn_cl4=0
                                self.button10.SetBackgroundColour('white')
                            if(j==4):
                                btn_cr1=0
                                self.button11.SetBackgroundColour('white')
                            if(j==5):
                                btn_cr2=0 
                                self.button12.SetBackgroundColour('white')
                            if(j==6):
                                btn_cr3=0
                                self.button13.SetBackgroundColour('white')
                            if(j==7): 
                                btn_cr4=0
                                self.button14.SetBackgroundColour('white')
                if(page>=len(check)):
                    btn_cl1=0
                    btn_cl2=0
                    btn_cl3=0
                    btn_cl4=0
                    btn_cr1=0
                    btn_cr2=0
                    btn_cr3=0
                    btn_cr4=0
                    self.button7.SetBackgroundColour('white')
                    self.button8.SetBackgroundColour('white')
                    self.button9.SetBackgroundColour('white')
                    self.button10.SetBackgroundColour('white')
                    self.button11.SetBackgroundColour('white')
                    self.button12.SetBackgroundColour('white')
                    self.button13.SetBackgroundColour('white')
                    self.button14.SetBackgroundColour('white')               
                self.grid1.ClearGrid()          # clear grid on every next btn click
                for i in range (9):
                    for j in range (21):
                        self.grid1.SetCellBackgroundColour( i,j,"black")
                        self.grid1.SetCellTextColour( i,j,"red");
                        self.grid1.SetCellFont(i,j,wx.Font(15, wx.SWISS, wx.NORMAL, wx.BOLD))
                if(q<len(frequency)):
                    self.textCtrl2.SetValue(str(frequency[q]))
                if(q<len(repeat)):
                    self.textCtrl3.SetValue(str(repeat[q]))
##                self.grid1.SetGridCursor(5,5)
            else:                       # On save btn click
                print "On save"
                flag_error=0
        else:                   # if value is invalid
            print "a"
            
            
    def check_box(self):
        global check,btn_cl1,btn_cl2,btn_cl3,btn_cl4,btn_cr1,btn_cr2,btn_cr3,btn_cr4
        list_check=[0, 0, 0, 0, 0, 0, 0, 0]
        store=[]
        store_sub=[]
        index=[]
        flag=0
        count=0
        count_old=0
        check_sub=[]
        
        check_sub.append(btn_cl1)
        check_sub.append(btn_cl2)
        check_sub.append(btn_cl3)
        check_sub.append(btn_cl4)
        check_sub.append(btn_cr1)
        check_sub.append(btn_cr2)
        check_sub.append(btn_cr3)
        check_sub.append(btn_cr4)
                 
        page_no=page-1 
        print_data(page_no)
##        print page_no
        print "check_sub{0}".format(check_sub)
##        print "page_info-{0} len(check)-{1}".format(len(page_info),len(check))
        
        page_text=str(self.textCtrl1.GetValue())
        if(len(page_text)<7):               #append check value for only home no's
            flag=1       
        if(flag==1):
            for i in range(8):
                if(check_sub[i]==1):
                    count=count+1                      #count of new checkbox
            if(page_no<len(check)):  
                for i in range(8):
                    if(check[page_no][i]==1):
                        count_old=count_old+1           #count of old checkbox
                for i in range(8):
                    if(check[page_no][i]!=check_sub[i]):
                        index.append(i)   
                print "index{0}".format(index)     
            if(len(page_info)==0 and len(check)==0):   # this apply for 1st page
                if(page_no+1>=len(check)):
                    check.extend([1])
                check[page_no]=check_sub
            number=Update_home.uphome_no
            if((len(page_info)>=len(check) and len(page_info)!=0 and len(check)!=0) or ((h-1)<=number)): 
                if(page_no+1>len(check)):
                    check.extend([1])
                check[page_no]=check_sub
            k=1           
            if(count>count_old):             # addition of check box clicks                
                for j in range(count-count_old):
                    check.insert((page_no+k),list_check)   
                    k=k+1            
            else:                           # deletion of check box clicks
                for m in range(len(index)):
                    del check[(page_no)+1]
                                 
        check_sub=[]
        store_sub=[]
        print "check{0}".format(check)
##        print "index{0}".format(index)
    def xls_lists(self,page_number):
        global list,store,store_sub,store_main,page,store_main1,store1,cursor_col,cursor_row,frequency,repeat,q,\
        check,page_info,flag_error,xls_rows
        check_sub=['','','','','','','','']
        
        file_name=CDU_TestRig_MainWindow.filename_xls 
        wb = xlrd.open_workbook(file_name)        # xls file to read from
        sh1 = wb.sheet_by_index(0)                # first sheet in workbook
        sh2 = wb.sheet_by_name('Sheet 1') 
        
        xls_rows=sh1.nrows

        value_grid1=(sh1.row_values(page_number-1))
##        print value_grid1
        page_info.append(int((value_grid1[1])))
        frequency.append(int((value_grid1[3])))
##        print_data("frequency{0}".format(frequency))
           
        repeat.append(int(value_grid1[5]))
##        print_data("repeat{0}".format(repeat))

        cursor_row.append(int(value_grid1[7]))
##        print_data("cursor_row{0}".format(cursor_row))

        cursor_col.append(int(value_grid1[8]))
##        print_data("cursor_col{0}".format(cursor_col))

        for i in range(page_number,page_number+9):
            value_grid=(sh1.row_values(i))
            if(i==page_number):
                check_sub[0]=int(value_grid[0])
                check_sub[4]=int(value_grid[22])
            if(i==page_number+2):
                check_sub[1]=int(value_grid[0])
                check_sub[5]=int(value_grid[22])
            if(i==page_number+4):
                check_sub[2]=int(value_grid[0])
                check_sub[6]=int(value_grid[22])
            if(i==page_number+6):
                check_sub[3]=int(value_grid[0])
                check_sub[7]=int(value_grid[22])   
            for j in range(1,22):
                value1=value_grid[j]
                store.append(int(value1))
##            print_data(store)
            store_sub.append(store)
            store=[]
            
        check.append(check_sub)
        if(page_number==1):
            store_main[0]=store_sub
        else:
            store_main.append(store_sub)
        store_sub=[]
        
    
    def display(self,page_number):
        global list,store,store_sub,store_main,page,store_main1,store1,cursor_col,cursor_row,frequency,repeat,q,\
        check,page_info,flag_error,btn_cl1,btn_cl2,btn_cl3,btn_cl4,btn_cr1,btn_cr2,btn_cr3,btn_cr4
        t=0
        check_sub=['','','','','','','','']
        file_name=CDU_TestRig_MainWindow.filename_xls 
        wb = xlrd.open_workbook(file_name)        # xls file to read from
        sh1 = wb.sheet_by_index(0)                # first sheet in workbook
        sh2 = wb.sheet_by_name('Sheet 1') 
        b=[]
        c=[]
        d=[]
        e=[]
        number=Update_home.uphome_no
##        print "rows-{0},page_number-{1}".format(rows,page_number)
##        print "h-{0},number-{1}".format(h,number)
##        if(rows>page_number and (int(h)-1) <= int(number) and flag_error==0):
##        value_grid1=(sh1.row_values(page_number-1))
##        b.append(int((value_grid1[3])))
##        print "frequency..........>",frequency
####        frequency.extend(b)
##        print "page_number",page_number,b[0]
##        frequency[page_number-1]=b[0]
##        
##        print" in display frequency......>",frequency,b[0]
##           
##        c.append(int(value_grid1[5]))
##        repeat.extend(c)
##        repeat[page_number-1]=c[0]
##
##        d.append(int(value_grid1[7]))
##        cursor_row.extend(d)
##        cursor_row[page_number-1]=d[0]
##
##        e.append(int(value_grid1[8]))
##        cursor_col.extend(e)
##        cursor_col[page_number-1]=e[0]
        print "frequency",frequency
        print "repeat",repeat
        print "cursor_row",cursor_row
        print "cursor_col",cursor_col
        self.grid1.SetFocus()
        self.grid1.SetGridCursor(cursor_row[0],cursor_col[0])
   
        for i in range(page_number,page_number+9):
            value_grid=(sh1.row_values(i))
            if(i==page_number):
                check_sub[0]=int(value_grid[0])
                check_sub[4]=int(value_grid[22])
            if(i==page_number+2):
                check_sub[1]=int(value_grid[0])
                check_sub[5]=int(value_grid[22])
            if(i==page_number+4):
                check_sub[2]=int(value_grid[0])
                check_sub[6]=int(value_grid[22])
            if(i==page_number+6):
                check_sub[3]=int(value_grid[0])
                check_sub[7]=int(value_grid[22])   
            for j in range(1,22):
                value1=value_grid[j]
                value=int(value1)
                store.append(value) 
                blink=value%2
                if(blink==0):
                    self.grid1.SetCellFont(t,j-1,wx.Font(15, wx.SWISS, wx.NORMAL, wx.BOLD))
                elif(blink==1):
                    self.grid1.SetCellFont(t,j-1,wx.Font(15, wx.SWISS, wx.ITALIC, wx.NORMAL))
                else:
                    print "b"
                temp1=value/2
                temp2=temp1%128
                self.grid1.SetCellValue(t,j-1,dict[temp2])
                temp3=temp1/128
                temp4=temp3%16
                
                if(temp4==15):                                                   
                    self.grid1.SetCellTextColour( t,j-1,"black");
                elif(temp4==8):
                    self.grid1.SetCellTextColour( t,j-1,"red");
                elif(temp4==7):
                    self.grid1.SetCellTextColour( t,j-1,"yellow");
                elif(temp4==6):
                    self.grid1.SetCellTextColour( t,j-1,"magenta");
                elif(temp4==5):
                    self.grid1.SetCellTextColour( t,j-1,"cyan");
                elif(temp4==4):
                    self.grid1.SetCellTextColour( t,j-1,(255, 170, 0));
                elif(temp4==2):
                    self.grid1.SetCellTextColour( t,j-1,"gray");
                elif(temp4==1):
                    self.grid1.SetCellTextColour( t,j-1,"green");
                else:
                    self.grid1.SetCellTextColour( t,j-1,"white");

                temp4=temp3/16
                temp5=temp4%16
                if(temp5==15):
##                    print "setting black to cell.....>",t,j-1
                    self.grid1.SetCellBackgroundColour( t,j-1,"black")
                if(temp5==8):
                    self.grid1.SetCellBackgroundColour( t,j-1,"red");
                elif(temp5==7):
                    self.grid1.SetCellBackgroundColour( t,j-1,"yellow");
                elif(temp5==6):
                    self.grid1.SetCellBackgroundColour( t,j-1,"magenta");
                elif(temp5==5):
                    self.grid1.SetCellBackgroundColour( t,j-1,"cyan");
                elif(temp5==4):
                    self.grid1.SetCellBackgroundColour( t,j-1,(255, 170, 0));
                elif(temp5==2):
                    self.grid1.SetCellBackgroundColour( t,j-1,"gray");
                elif(temp5==1):
                    self.grid1.SetCellBackgroundColour( t,j-1,"green");
                else:
                    self.grid1.SetCellBackgroundColour( t,j-1,"white");
            store_sub.append(store)
            store=[]
            t=t+1 
        page_no=page-1   
        if(page_no+1>len(check)):
            check.extend([1])
        check[page_no]=check_sub
        
        if(page_no+1==len(store_main)):
            store_main[page_no]=store_sub
            store_main.extend(store_main1)
        elif(page_no+1<len(store_main)):
            store_main[page_no]=store_sub
   
        store_sub=[]
        for j in range(8):
            if(check[page-1][j]==1):
                if(j==0):
                    btn_cl1=1
                    self.button7.SetBackgroundColour('gray')
                if(j==1):
                    btn_cl2=1
                    self.button8.SetBackgroundColour('gray')
                if(j==2):
                    btn_cl3=1
                    self.button9.SetBackgroundColour('gray')
                if(j==3):
                    btn_cl4=1
                    self.button10.SetBackgroundColour('gray')
                if(j==4):
                    btn_cr1=1
                    self.button11.SetBackgroundColour('gray')
                if(j==5): 
                    btn_cr2=1
                    self.button12.SetBackgroundColour('gray')
                if(j==6):
                    btn_cr3=1
                    self.button13.SetBackgroundColour('gray')
                if(j==7): 
                    btn_cr4=1
                    self.button14.SetBackgroundColour('gray')                
##        else:
##            flag_error=1
##            dial = wx.MessageDialog(None, "Next page is not present",\
##            'Error !!!', wx.OK|wx.STAY_ON_TOP)
##            dial.ShowModal() 
##            print "in end page in xls-flag_error-{0}".format(flag_error)
        
##        print store_main
         
    def OnGoto(self, event):
        global page

        page_no=str(self.textCtrl1.GetValue())
        page_no=int(page_no) 
        page=page_no
##        print len(store_main)
##        print page_no

        if(len(store_main)>page_no):
            print "page found"
            for i in range(9):      ## to display grid contents 
                for j in range(21):
                    value=store_main[page_no-1][i][j]
##                    print value
##                    print page,i,j
##                    print store_main[page_no-1][i][j]
                    blink=value%2
                    if(blink==0):
##                      print value
                        self.grid1.SetCellFont(i,j,wx.Font(15, wx.SWISS, wx.NORMAL, wx.BOLD))
                    elif(blink==1):
##                      print value
                        self.grid1.SetCellFont(i,j,wx.Font(15, wx.SWISS, wx.ITALIC, wx.NORMAL))
                    else:
                        print "b"
                    temp1=value/2
                    temp2=temp1%128
                    self.grid1.SetCellValue(i,j,dict[temp2])
                    temp3=temp1/128
                    temp4=temp3%16
                    if(temp4==8):
                        self.grid1.SetCellTextColour( i,j,"red");
                    elif(temp4==7):
                        self.grid1.SetCellTextColour( i,j,"yellow");
                    elif(temp4==6):
                        self.grid1.SetCellTextColour( i,j,"magenta");
                    elif(temp4==5):
                        self.grid1.SetCellTextColour( i,j,"cyan");
                    elif(temp4==4):
                        self.grid1.SetCellTextColour( i,j,(255, 170, 0));
                    elif(temp4==2):
                        self.grid1.SetCellTextColour( i,j,"gray");
                    elif(temp4==1):
                        self.grid1.SetCellTextColour( i,j,"green");
                    else:
                        self.grid1.SetCellTextColour( i,j,"white");
            
                    temp4=temp3/16
                    temp5=temp4%16
                    if(temp5==8):
                        self.grid1.SetCellBackgroundColour( i,j,"red");
                    elif(temp5==7):
                        self.grid1.SetCellBackgroundColour( i,j,"yellow");
                    elif(temp5==6):
                        self.grid1.SetCellBackgroundColour( i,j,"magenta");
                    elif(temp5==5):
                        self.grid1.SetCellBackgroundColour( i,j,"cyan");
                    elif(temp5==4):
                        self.grid1.SetCellBackgroundColour( i,j,(255, 170, 0));
                    elif(temp5==2):
                        self.grid1.SetCellBackgroundColour( i,j,"gray");
                    elif(temp5==1):
                        self.grid1.SetCellBackgroundColour( i,j,"green");
                    else:
                        self.grid1.SetCellBackgroundColour( i,j,"white");
        else:
            print "no page"
            dial = wx.MessageDialog(None, 'Page not found.....!!', 'Error!!!', wx.OK|wx.STAY_ON_TOP)
            dial.ShowModal()   
            
    def Savexls(self):
        global list,store,store_sub,store_main,page,cursor_col,cursor_row,frequency,repeat,\
        check,page_info,h,filename_xls,er_flag,btn_cl1,btn_cl2,btn_cl3,btn_cl4,btn_cr1,\
        btn_cr2,btn_cr3,btn_cr4
        list_check=[0,0,0,0,0,0,0,0]
        t=0
        s=0
        count=0
        y=2
        q=1
        f=0
        
        self.create_list(y)
        
        number=Update_home.uphome_no
        print "h---->",h-1,
        print "number---->",Update_home.uphome_no
        
        cur_home=int(h)-1
        if(CDU_TestRig_MainWindow.prev_page<number):
            cur_home=int(h)-1
            if(page==1):
                if(h == number+1):
                    cur_home=int(h)-2
                           
        if(cur_home ==int(number)):           # if all pages are created as per total no of home pages
            print "equal both"
            self.w.get_sheet(0).write(0,0,'Page')
            self.w.get_sheet(0).write(0,1,page_info[0])
            self.w.get_sheet(0).write(0,2,'Frequency')
            self.w.get_sheet(0).write(0,3,frequency[0])
            self.w.get_sheet(0).write(0,4,'Repeat')
            self.w.get_sheet(0).write(0,5,repeat[0]) 
            self.w.get_sheet(0).write(0,6,'Cursor Position')
            self.w.get_sheet(0).write(0,7,cursor_row[0])
            self.w.get_sheet(0).write(0,8,cursor_col[0])
##            print"len(store_main).....>",len(store_main)
##            print "len store_main[len(store_main)-1]",len(store_main[len(store_main)-1])
            if(len(store_main[len(store_main)-1])==0):
                print "empty,,,,,,,,,,>"
                lenght=len(store_main)-1
            else:
                print "not empty.......>"
                lenght=len(store_main)
            
            for i in range(lenght):
                for j in range(9):
                    for k in range(21): 
                        self.w.get_sheet(0).write(j+1+t,k+1,store_main[i][j][k])
                if(q<len(frequency) and q<lenght):
                    self.w.get_sheet(0).write(((i+1)+(10*(i+1))),0,'Page')
                    self.w.get_sheet(0).write(((i+1)+(10*(i+1))),1,page_info[q])
                    self.w.get_sheet(0).write(((i+1)+(10*(i+1))),2,'Frequency')
                    self.w.get_sheet(0).write(((i+1)+(10*(i+1))),3,frequency[q])
                    self.w.get_sheet(0).write(((i+1)+(10*(i+1))),4,'Repeat')
                    self.w.get_sheet(0).write(((i+1)+(10*(i+1))),5,repeat[q]) 
                    self.w.get_sheet(0).write(((i+1)+(10*(i+1))),6,'Cursor Position') 
                    self.w.get_sheet(0).write(((i+1)+(10*(i+1))),7,cursor_row[q])
                    self.w.get_sheet(0).write(((i+1)+(10*(i+1))),8,cursor_col[q])   
                self.w.get_sheet(0).write((t+1),0,check[s][0])
                self.w.get_sheet(0).write((t+3),0,check[s][1])
                self.w.get_sheet(0).write((t+5),0,check[s][2])
                self.w.get_sheet(0).write((t+7),0,check[s][3])
                self.w.get_sheet(0).write((t+1),22,check[s][4])
                self.w.get_sheet(0).write((t+3),22,check[s][5])
                self.w.get_sheet(0).write((t+5),22,check[s][6])
                self.w.get_sheet(0).write((t+7),22,check[s][7])
                s=s+1
                t=t+11
                q=q+1
        else:    
            print "both r not equal"                        # if all pages are not created as per total no of home pages
            for i in range(9):
                for j in range(21):
                    store.append(2048)
                store_sub.append(store)
                store=[]
     
            for h1 in range(int(h),int(number)+1): #To generate not created page number info
                x=(h1)
                x=x*4096
                page_info.append(x)

##            print "page_info",page_info
##            print "On save :frequency",frequency
##            
##            print "len(frequency)",len(frequency)
##            print "len(page_info)",len(page_info)
                
            for h1 in range(len(frequency),len(page_info)):  # To generate not created page frequency,
                print "less than created values"
                frequency.append(80)                        # repeat,cursor_row,cursor_col,check
                repeat.append(1)                            # and empty page content
                cursor_row.append(0)
                cursor_col.append(0)
                check.append(list_check)
                store_main.insert((page+f),store_sub)
                f=f+1
       
            print "check",check
            
            self.w.get_sheet(0).write(0,0,'Page')           # write into xls sheet
            self.w.get_sheet(0).write(0,1,page_info[0])
            self.w.get_sheet(0).write(0,2,'Frequency')
            self.w.get_sheet(0).write(0,3,frequency[0])
            self.w.get_sheet(0).write(0,4,'Repeat')
            self.w.get_sheet(0).write(0,5,repeat[0]) 
            self.w.get_sheet(0).write(0,6,'Cursor Position')
            self.w.get_sheet(0).write(0,7,cursor_row[0])
            self.w.get_sheet(0).write(0,8,cursor_col[0])
            
            if(len(store_main[len(store_main)-1])==0):
                print "empty........>"
                lenght=len(store_main)-1
            else:
                print "not empty.......>"
                lenght=len(store_main)
            
            for i in range(lenght):
                for j in range(9):
                    for k in range(21): 
                        self.w.get_sheet(0).write(j+1+t,k+1,store_main[i][j][k])
                if(q<len(frequency) and q<lenght and q<len(page_info) ):
                    self.w.get_sheet(0).write(((i+1)+(10*(i+1))),0,'Page')
                    self.w.get_sheet(0).write(((i+1)+(10*(i+1))),1,page_info[q])
                    self.w.get_sheet(0).write(((i+1)+(10*(i+1))),2,'Frequency')
                    self.w.get_sheet(0).write(((i+1)+(10*(i+1))),3,frequency[q])
                    self.w.get_sheet(0).write(((i+1)+(10*(i+1))),4,'Repeat')
                    self.w.get_sheet(0).write(((i+1)+(10*(i+1))),5,repeat[q]) 
                    self.w.get_sheet(0).write(((i+1)+(10*(i+1))),6,'Cursor Position') 
                    self.w.get_sheet(0).write(((i+1)+(10*(i+1))),7,cursor_row[q])
                    self.w.get_sheet(0).write(((i+1)+(10*(i+1))),8,cursor_col[q])
                
                self.w.get_sheet(0).write((t+1),0,check[s][0])
                self.w.get_sheet(0).write((t+3),0,check[s][1])
                self.w.get_sheet(0).write((t+5),0,check[s][2])
                self.w.get_sheet(0).write((t+7),0,check[s][3])
                self.w.get_sheet(0).write((t+1),22,check[s][4])
                self.w.get_sheet(0).write((t+3),22,check[s][5])
                self.w.get_sheet(0).write((t+5),22,check[s][6])
                self.w.get_sheet(0).write((t+7),22,check[s][7])
                s=s+1
                t=t+11
                q=q+1
##        print "updated store_main",store_main
        self.w.save(filename_xls)
        self.textCtrl6.SetValue(filename_xls)
        
        head=os.path.split(filename_xls)
        pathnfile=os.path.join(head[0],"CDUHOTKEY.xls")
##        print "pathnfile",pathnfile
        if os.path.exists(pathnfile)==True:
            self.var=0
            self.writetoxls(pathnfile,head)
        else:
            wtbook = xlwt.Workbook()           # xls file to write into it 
            wtsheet = wtbook.add_sheet(u'First')
            wtbook.save(pathnfile)
            self.var=1
            self.writetoxls(pathnfile,head)
                  
       
        
    def OnCancel(self, event):
        global filename_xls,er_flag
        
        self.global_initialisation()
        
        CDU_TestRig_MainWindow.update_select=0
        Update_home.flag_Update_page=0
        
        if(self.flag_save==0 & er_flag==0):                    # To display browser window
            dial = wx.MessageDialog(None, 'Do you want to save?', 'Message', wx.STAY_ON_TOP|wx.YES_NO )
            if dial.ShowModal()==wx.ID_YES:
                filename_xls=CDU_TestRig_MainWindow.filename_xls
                self.flag_save=1
                self.Savexls()
                self.Destroy()
            else:
                self.Destroy()
        elif(self.flag_save==1):                   # Once file is selected,next time onwards it saves to same file
            filename_xls=CDU_TestRig_MainWindow.filename_xls
            self.Destroy() 
            event.Skip()
        
    def On_Close(self,event):
        global filename_xls,er_flag
        
        Update_home.flag_Update_page=0
        CDU_TestRig_MainWindow.update_select=0
        CDU_TestRig_MainWindow.flag_Update_home=0
        
        self.global_initialisation()
        
        if(self.flag_save==0 & er_flag==0): # To display browser window
            dial = wx.MessageDialog(None, 'Do you want to save?', 'Message', wx.STAY_ON_TOP|wx.YES_NO )
            if dial.ShowModal()==wx.ID_YES:
                filename_xls=CDU_TestRig_MainWindow.filename_xls
                self.flag_save=1
                self.Savexls()
                self.Destroy()
            else:
                self.Destroy()
        elif(self.flag_save==1):                   # Once file is selected,next time onwards it saves to same file
            filename_xls=CDU_TestRig_MainWindow.filename_xls
            self.Destroy() 
           

    def OnCL1(self, event):
        global btn_cl1
        self.flag_save=0
        if(btn_cl1==0):
            btn_cl1=1
            self.List_page()
            self.button7.SetBackgroundColour('gray')
        else:
            btn_cl1=0
            self.List_page()
            self.button7.SetBackgroundColour('white')
        event.Skip()
        
    def OnCL2(self, event):
        global btn_cl2
        self.flag_save=0
        if(btn_cl2==0):
            btn_cl2=1
            self.List_page()
            self.button8.SetBackgroundColour('gray')
        else:
            btn_cl2=0
            self.List_page()
            self.button8.SetBackgroundColour('white')
        event.Skip()
        
    def OnCL3(self, event):
        global btn_cl3
        self.flag_save=0
        if(btn_cl3==0):
            btn_cl3=1
            self.List_page()
            self.button9.SetBackgroundColour('gray')
        else:
            btn_cl3=0
            self.List_page()
            self.button9.SetBackgroundColour('white')
        event.Skip()
        
    def OnCL4(self, event):
        global btn_cl4
        self.flag_save=0
        if(btn_cl4==0):
            btn_cl4=1
            self.List_page()
            self.button10.SetBackgroundColour('gray')
        else:
            btn_cl4=0
            self.List_page()
            self.button10.SetBackgroundColour('white')
        event.Skip()
        
    def OnCR1(self, event):
        global btn_cr1
        self.flag_save=0
        if(btn_cr1==0):
            btn_cr1=1
            self.List_page()
            self.button11.SetBackgroundColour('gray')
        else:
            btn_cr1=0
            self.List_page()
            self.button11.SetBackgroundColour('white')
        event.Skip()
        
    def OnCR2(self, event):
        global btn_cr2
        self.flag_save=0
        if(btn_cr2==0):
            btn_cr2=1
            self.List_page()
            self.button12.SetBackgroundColour('gray')
        else:
            btn_cr2=0
            self.List_page()
            self.button12.SetBackgroundColour('white')
        event.Skip()
        
    def OnCR3(self, event):
        global btn_cr3
        self.flag_save=0
        if(btn_cr3==0):
            btn_cr3=1
            self.List_page()
            self.button13.SetBackgroundColour('gray')
        else:
            btn_cr3=0
            self.List_page()
            self.button13.SetBackgroundColour('white')
        event.Skip()
          
    def OnCR4(self, event):
        global btn_cr4
        self.flag_save=0
        if(btn_cr4==0):
            btn_cr4=1
            self.List_page()
            self.button14.SetBackgroundColour('gray')
        else:
            btn_cr4=0
            self.List_page()
            self.button14.SetBackgroundColour('white')
        event.Skip()
        
    def Hotkey(self, event):
        global hotkey_configdetail
##        global new_confirm
        page_creation.new_confirm=1
        CDU_TestRig_MainWindow.page_var==1
        
##        hotkey_configdetail=self.page_txt
        self.main12 = Hotkey.create(None)
        self.main12.Show()
        event.Skip()
        
    def List_page(self):
        global List_page
        global new_confirm
        CDU_TestRig_MainWindow.update_select=1
        new_confirm=1
        var=0     
        
        
        
        
