#Boa:Frame:COMConfig_Window

import wx
import CDU_TestRig_MainWindow
import GNSS_OutputWindow
import os
import display

import _winreg as winreg    # To get com port
import itertools            # To get com port
from ctypes import *
import threading
from threading import Thread
import time
from ctypes import *
import serial
import string
from serial import  *
import win32api
import xlrd
import xlwt
from xlutils.copy import copy
import sys
from ctypes import *
global flag_ok,class_var3,class_var4,w,w_ibit
global filename_GNSS_position_data,path_name,filename_GNSS_health_data,filename_GNSS_version_data
global instance_comport_receiver,instance_comport_transmitter
global com_port,com_port1,com_port2,com_port3,com_port4,com_port5,com_port6,com_port7
##filename_GNSS_version_data
flag_ok=0
com_port=0
com_port1=0
com_port2=0
com_port3=0
com_port4=0
com_port5=0
com_port6=0
com_port7=0
def create(parent):
    global class_var4
    class_var4= COMConfig_Window(parent)
    return class_var4


[wxID_COMConfig_Window, wxID_COMConfig_WindowBUTTON1, wxID_COMConfig_WindowBUTTON2, wxID_COMConfig_WindowBUTTON3, 
 wxID_COMConfig_WindowRADIOBOX4, wxID_COMConfig_WindowPANEL1, wxID_COMConfig_WindowRADIOBOX1, 
 wxID_COMConfig_WindowRADIOBOX2, wxID_COMConfig_WindowRADIOBOX3,wxID_COMConfig_WindowRADIOBOX5,
 wxID_COMConfig_WindowRADIOBOX6,wxID_COMConfig_WindowRADIOBOX7,wxID_COMConfig_WindowSTATICBOX1, 
 wxID_COMConfig_WindowSTATICBOX2, wxID_COMConfig_WindowSTATICBOX3,wxID_COMConfig_WindowSTATICTEXT1, 
 wxID_COMConfig_WindowRADIOBOX8,wxID_COMConfig_WindowSTATICTEXT2, wxID_COMConfig_WindowTEXTCTRL1, 
 wxID_FRAME1COMBOBOX1,wxID_FRAME1COMBOBOX2,
] = [wx.NewId() for _init_ctrls in range(21)]

class COMConfig_Window(wx.Frame):
##    com_port=0
##    com_port1=0
##    com_port2=0
##    com_port3=0
##    com_port4=0
##    com_port5=0
##    com_port6=0
##    com_port7=0
    def _init_ctrls(self, prnt):
        port=[]
       
        # generated method, don't edit
        pixel4=wx.GetDisplaySize() 
        print pixel4
     
        ##Length and width of Main Window
        self.Main_window_Length4=pixel4[0]/1.0058
        self.Main_window_Width4=pixel4[1]/1.266
        self.Main_window_Start_y4=pixel4[1]/5.92
        self.Main_window_Start_x4=pixel4[0]/3.12
        if(CDU_TestRig_MainWindow.flag_com==1):
            title_Output='Comport Configuration to GNSS'
        else:
            title_Output='Comport Configuration to CDU'
        wx.Frame.__init__(self, id=wxID_COMConfig_Window, name='', parent=prnt,
              pos=wx.Point( self.Main_window_Start_x4, self.Main_window_Start_y4), size=wx.Size(419, 330),
              style=wx.SYSTEM_MENU | wx.CAPTION | wx.MINIMIZE_BOX|wx.CLOSE_BOX, title=title_Output)
        self.SetClientSize(wx.Size(460, 316))
        self.Center()
        self.panel1 = wx.Panel(id=wxID_COMConfig_WindowPANEL1, name='panel1', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(460, 316),
              style=wx.ALWAYS_SHOW_SB | wx.TAB_TRAVERSAL)
              
        self.Bind(wx.EVT_CLOSE, self.On_Close)
        
        self.radioBox1 = wx.RadioBox(choices=["9600", "19200", "38400", "57600",
              "115200"], id=wxID_COMConfig_WindowRADIOBOX1, label='Baud Rate',
              majorDimension=1, name='radioBox1', parent=self.panel1,
              pos=wx.Point( 22, 32), size=wx.Size(65, 120),
              style=wx.RA_USE_CHECKBOX)
        self.radioBox1.SetSelection(4)
   

        self.radioBox2 = wx.RadioBox(choices=["1", "2"],
              id=wxID_COMConfig_WindowRADIOBOX2, label='Stop Bits', majorDimension=1,
              name='radioBox2', parent=self.panel1, pos=wx.Point(100, 32),
              size=wx.Size(44, 120), style=wx.RA_SPECIFY_COLS)

        self.radioBox3 = wx.RadioBox(choices=["None", "Odd", "Even"],
              id=wxID_COMConfig_WindowRADIOBOX3, label='Parity', majorDimension=1,
              name='radioBox3', parent=self.panel1, pos=wx.Point(158, 32),
              size=wx.Size(52, 120), style=wx.RA_SPECIFY_COLS)

        self.staticBox1 = wx.StaticBox(id=wxID_COMConfig_WindowSTATICBOX1,   #Receiving
              label='Reception Port', name='staticBox1', parent=self.panel1,
              pos=wx.Point(8, 8), size=wx.Size(215, 185), style=0)

        self.staticBox2 = wx.StaticBox(id=wxID_COMConfig_WindowSTATICBOX2,  #Receiving
              label='Path for Logging', name='staticBox2', parent=self.panel1,
              pos=wx.Point(8, 206), size=wx.Size(392, 72), style=0)

        self.textCtrl1 = wx.TextCtrl(id=wxID_COMConfig_WindowTEXTCTRL1, name='textCtrl1',
              parent=self.panel1, pos=wx.Point(80, 225), size=wx.Size(232, 37),
              style=0, value="")
              
        self.dirpath=os.getcwd()
        self.textCtrl1.SetValue(self.dirpath)
        self.textCtrl1. SetEditable(0)
        
        self.staticText2 = wx.StaticText(id=wxID_COMConfig_WindowSTATICTEXT2,
              label='Log Folder', name='staticText2', parent=self.panel1,
              pos=wx.Point(24, 228), size=wx.Size(54, 13), style=0)

        self.Browse = wx.Button(id=wxID_COMConfig_WindowBUTTON1, label='Browse',
              name='button1', parent=self.panel1, pos=wx.Point(320, 230),
              size=wx.Size(64, 23), style=0)
        self.Browse.Bind(wx.EVT_BUTTON, self.OnBrowse, id=wxID_COMConfig_WindowBUTTON1)
        
        self.ok_button = wx.Button(id=wxID_COMConfig_WindowBUTTON2, label='OK',
              name='ok_button', parent=self.panel1, pos=wx.Point(120, 284),
              size=wx.Size(75, 23), style=0)
        self.ok_button .Bind(wx.EVT_BUTTON, self.OnOK_button,
              id=wxID_COMConfig_WindowBUTTON2)
              
        self.cancel_button = wx.Button(id=wxID_COMConfig_WindowBUTTON3, label='Cancel',
              name='cancel_button', parent=self.panel1, pos=wx.Point(216, 284),
              size=wx.Size(75, 23), style=0)
              
        self.cancel_button.Bind(wx.EVT_BUTTON, self.OnCancel_button,
              id=wxID_COMConfig_WindowBUTTON3)
                           
##        self.radioBox4 = wx.RadioBox(choices=["COM1","COM2","COM3","COM4","COM5"], id=wxID_COMConfig_WindowRADIOBOX4,
##              label='Comport', majorDimension=1, name='radioBox4',
##              parent=self.panel1, pos=wx.Point(304, 32), size=wx.Size(68, 120),
##              style=wx.RA_SPECIFY_COLS)
##        self.CDU_LOG_xls=''
                
        self.staticBox3 = wx.StaticBox(id=wxID_COMConfig_WindowSTATICBOX3,   #Transmitting
              label='Transmission Port', name='staticBox3', parent=self.panel1,
              pos=wx.Point(235, 8), size=wx.Size(215,185), style=0)
              
        self.radioBox5 = wx.RadioBox(choices=["9600", "19200", "38400", "57600",    #Transmitting
              "115200"], id=wxID_COMConfig_WindowRADIOBOX5, label='Baud Rate',
              majorDimension=1, name='radioBox5', parent=self.panel1,
              pos=wx.Point(249, 32), size=wx.Size(65, 120),
              style=wx.RA_USE_CHECKBOX)
        self.radioBox5.SetSelection(4)
              
        self.radioBox6 = wx.RadioBox(choices=["1", "2"],                #Transmitting
              id=wxID_COMConfig_WindowRADIOBOX6, label='Stop Bits', majorDimension=1,
              name='radioBox2', parent=self.panel1, pos=wx.Point(327, 32),
              size=wx.Size(44, 120), style=wx.RA_SPECIFY_COLS)
        

        self.radioBox7 = wx.RadioBox(choices=["None", "Odd", "Even"],           #Transmitting
              id=wxID_COMConfig_WindowRADIOBOX7, label='Parity', majorDimension=1,
              name='radioBox3', parent=self.panel1, pos=wx.Point(383, 32),
              size=wx.Size(52, 120), style=wx.RA_SPECIFY_COLS)
              
##        self.radioBox8 = wx.RadioBox(choices=["COM1","COM2","COM3","COM4","COM5"], id=wxID_COMConfig_WindowRADIOBOX8,
##              label='Comport', majorDimension=1, name='radioBox8',
##              parent=self.panel1, pos=wx.Point(712, 32), size=wx.Size(68, 120),
##              style=wx.RA_SPECIFY_COLS)

        # To get opened com ports

        path = 'HARDWARE\\DEVICEMAP\\SERIALCOMM'
        try:
            key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, path)
               
        except WindowsError:
            raise IterationError

        for i in itertools.count():
            try:
                val = winreg.EnumValue(key, i)
                print "val[1]",val[1]
                port.append(val[1])

            except EnvironmentError:
                break
            
        print "port........>",port
        self.comboBox1 = wx.ComboBox(choices=port,
              id=wxID_FRAME1COMBOBOX1, name='comboBox1', parent=self.panel1,
              pos=wx.Point(25, 165), size=wx.Size(120, 21), style=0,
              value='Select COM port')
        self.comboBox1.SetEditable(0)
              
        self.comboBox2 = wx.ComboBox(choices=port,
              id=wxID_FRAME1COMBOBOX2, name='comboBox2', parent=self.panel1,
              pos=wx.Point(252, 165), size=wx.Size(120, 21), style=0,
              value='Select COM port')
        self.comboBox2.SetEditable(0)
              
              
##        self.CDU_LOG_xls=''
##        self.IBIT_log_xls=''
        
        self.global_intialisation()

    def __init__(self, parent):
        self._init_ctrls(parent)
        
    def global_intialisation(self):
        global path_name,com_port,com_port1,com_port2,com_port3,com_port4,com_port5,com_port6,com_port7
        self.radioBox1.SetSelection(4)  #fixed baud rate for 115200
        self.radioBox5.SetSelection(4)
        
        self.comboBox1.SetSelection(instance_comport_receiver.Comport_select)   # To have previous value of com port
        self.comboBox2.SetSelection(instance_comport_transmitter.Comport_select)
        
        self.radioBox2.SetSelection(com_port1) # To have previous value of stop bit
        self.radioBox6.SetSelection(com_port5)
        
        self.radioBox3.SetSelection(com_port2) # To have previous value of parity
        self.radioBox7.SetSelection(com_port6)
##        self.textCtrl1.SetValue(self.path_name)
        
        
    def OnOK_button(self, event):
        global flag_ok,w,w_ibit, com_port,com_port1,com_port2,com_port3,com_port4,com_port5,com_port6,com_port7
        flag_ok=1
        com_port =self.radioBox1.GetSelection()    #Receiver
        com_port1 =self.radioBox2.GetSelection()
        com_port2 =self.radioBox3.GetSelection()
        com_port3=self.comboBox1.GetValue()
        print "com_port3........>",com_port3
        com1=com_port3.split('COM')
        instance_comport_receiver.Comport_select=int(com1[1])-1

        com_port4 =self.radioBox5.GetSelection()   #Transmitter
        com_port5 =self.radioBox6.GetSelection()
        com_port6 =self.radioBox7.GetSelection()
        com_port7=self.comboBox2.GetValue()
        com1=com_port7.split('COM')
        instance_comport_transmitter.Comport_select=int(com1[1])-1
        
        print "Comport_select----------->",instance_comport_transmitter.Comport_select
        if(com_port==0):                           #Receiver
            instance_comport_receiver.Baud_Rate="9600"
        elif(com_port==1):
            instance_comport_receiver.Baud_Rate="19200"
        elif(com_port==2):
            instance_comport_receiver.Baud_Rate="38400"
        elif(com_port==3):
            instance_comport_receiver.Baud_Rate="57600" 
        elif(com_port==4):
            instance_comport_receiver.Baud_Rate="115200" 
            
        if(com_port1==0):                              #Receiver
            instance_comport_receiver.Stop_Bits=STOPBITS_ONE
        elif(com_port1==1):
            instance_comport_receiver.Stop_Bits=STOPBITS_TWO
            
        if(com_port2==0):                          #Receiver
            instance_comport_receiver.Parity=PARITY_NONE
        elif(com_port2==1):
            instance_comport_receiver.Parity=PARITY_ODD
        elif(com_port2==2):
            instance_comport_receiver.Parity=PARITY_EVEN
            
        if(com_port4==0):                           #Transmitter
            instance_comport_transmitter.Baud_Rate="9600"
        elif(com_port4==1):
            instance_comport_transmitter.Baud_Rate="19200"
        elif(com_port4==2):
            instance_comport_transmitter.Baud_Rate="38400"
        elif(com_port4==3):
            instance_comport_transmitter.Baud_Rate="57600" 
        elif(com_port4==4):
            instance_comport_transmitter.Baud_Rate="115200" 
            
        if(com_port5==0):                                  #Transmitter
            instance_comport_transmitter.Stop_Bits=STOPBITS_ONE
        elif(com_port5==1):
            instance_comport_transmitter.Stop_Bits=STOPBITS_TWO
            
        if(com_port6==0):                               #Transmitter
            instance_comport_transmitter.Parity=PARITY_NONE
        elif(com_port6==1):
            instance_comport_transmitter.Parity=PARITY_ODD
        elif(com_port6==2):
            instance_comport_transmitter.Parity=PARITY_EVEN
            
         
            
        if(CDU_TestRig_MainWindow.GNSS_flag==1):
            self.path_name= self.textCtrl1.GetValue()
            CDU_TestRig_MainWindow.class_var3.filename_GNSS_position_data=self.path_name+'/Obtained_GNSS_position_data.csv'
            CDU_TestRig_MainWindow.class_var3.filename_GNSS_health_data=self.path_name+'/Obtained_GNSS_health_data.csv'
            CDU_TestRig_MainWindow.class_var3.filename_GNSS_version_data=self.path_name+'/Obtained_GNSS_version_data.csv'
            CDU_TestRig_MainWindow.class_var3.create_file_GNSS_Data()
            CDU_TestRig_MainWindow.class_var3.connection()
        else:
            self.path_name= self.textCtrl1.GetValue()
            CDU_TestRig_MainWindow.CDU_LOG_xls=self.path_name+'\CDU_LOG_file.xls'
            print "path_name.............>", CDU_TestRig_MainWindow.CDU_LOG_xls
            wtbook = xlwt.Workbook()           # xls file to write CDU status message
            wtsheet =wtbook.add_sheet('Sheet 1') 
            wtbook.save(CDU_TestRig_MainWindow.CDU_LOG_xls)
            rb = xlrd.open_workbook(CDU_TestRig_MainWindow.CDU_LOG_xls, formatting_info=True)
            w=copy(rb)

            display.Log_Heading(w)
          
            CDU_TestRig_MainWindow.IBIT_log_xls=self.path_name+'\log_ibit.xls'
            wtbook = xlwt.Workbook()           # xls file to write IBIT log
            wtsheet = wtbook.add_sheet('Sheet 1') 
            wtbook.save(CDU_TestRig_MainWindow.IBIT_log_xls)
            rb = xlrd.open_workbook(CDU_TestRig_MainWindow.IBIT_log_xls, formatting_info=True)
            w_ibit=copy(rb)
            print "call connnection1......>"
            CDU_TestRig_MainWindow.class_var3.connnection1()
        if(instance_comport_receiver.Comport_select==instance_comport_transmitter.Comport_select):
            if((CDU_TestRig_MainWindow.class_var3.connect_object_GNSS_receiver!='') or \
            (CDU_TestRig_MainWindow.class_var3.connect_object_CDU_receiver!='')):
                self.Close()
        else:
            if((CDU_TestRig_MainWindow.class_var3.connect_object_GNSS_receiver!='' and \
            CDU_TestRig_MainWindow.class_var3.connect_object_GNSS_transmitter!='') or \
            (CDU_TestRig_MainWindow.class_var3.connect_object_CDU_receiver!='' and \
            CDU_TestRig_MainWindow.class_var3.connect_object_CDU_transmitter!='')):
                self.Close()
            

    def OnBrowse(self,event):
        # Create the dialog
##        global path_name
        global filename_GNSS_position_data,filename_GNSS_health_data,filename_GNSS_version_data
        dialog = wx.DirDialog (self,message="Pick a directory...")
        self.path_name=os.getcwd()
        
        dialog.SetPath(self.path_name)
        if dialog.ShowModal() == wx.ID_OK:
            self.path_name=dialog.GetPath()
            self.textCtrl1.SetValue(self.path_name)
##        CDU_TestRig_MainWindow.class_var3.filename_GNSS_position_data=self.path_name+'/Obtained_GNSS_position_data.csv'
##        CDU_TestRig_MainWindow.class_var3.filename_GNSS_health_data=self.path_name+'/Obtained_GNSS_health_data.csv'
##        CDU_TestRig_MainWindow.class_var3.filename_GNSS_version_data=self.path_name+'/Obtained_GNSS_version_data.csv'
##        CDU_TestRig_MainWindow.class_var3.create_file_GNSS_Data()
        event.Skip()
        
        
    def On_Close(self,event):
        CDU_TestRig_MainWindow.COMConfig_Window_flag=0
        self.global_intialisation()
        self.Destroy() 
        event.Skip()

    def OnCancel_button(self, event):
        CDU_TestRig_MainWindow.COMConfig_Window_flag=0
        self.global_intialisation()
        self.Destroy() 
        event.Skip()
        
class Comport_set_receiver(Structure):
	_fields_ = [
	            ("Baud_Rate",c_char_p),
	            ("Stop_Bits", c_uint),          
                ("Parity",c_char_p),          
                ("Data_Bits", c_char_p), 
                ("Comport_select",c_uint ),  
               ]
instance_comport_receiver=Comport_set_receiver()

class Comport_set_transmitter(Structure):
	_fields_ = [
	            ("Baud_Rate",c_char_p),
	            ("Stop_Bits", c_uint),          
                ("Parity",c_char_p),          
                ("Data_Bits", c_char_p), 
                ("Comport_select",c_uint ),  
               ]
instance_comport_transmitter=Comport_set_transmitter()