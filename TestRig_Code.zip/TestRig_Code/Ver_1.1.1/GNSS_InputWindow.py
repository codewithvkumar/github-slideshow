#Boa:Frame:GNSS_InputWindow

import wx
import CDU_TestRig_MainWindow
import GNSS_OutputWindow
import COMConfig_Window
import struct
import serial
import threading
import win32api
from threading import Thread
from serial import  SerialException
from struct import *
from ctypes import *
global constellation_selection
global Receive_message_instance
global temp_GNSS_command_message,flag_transmit
global class_var2  
flag_transmit=0
                                           
def create(parent):
    global class_var2
    class_var2= GNSS_InputWindow(parent)
    return class_var2
[wxID_FRAME5, wxID_FRAME1GNSS_input, wxID_FRAME1GNSS_input_Command,wxID_FRAME5PANEL1,wxID_FRAME1GNSS_input_Control,\
 wxID_OK_button,wxID_Cancel_button,wxID_Position_Latitude,wxID_Position_Longitude,wxID_Position_Altitude,\
 wxID_textCtrl_latitude,wxID_textCtrl_longitude,wxID_textCtrl_Altitude,wxID_FRAME5COMBOBOX1,\
 wxID_FRAME5STATICTEXT1,wxID_FRAME5STATICTEXT4,wxID_FRAME5BUTTON1,wxID_FRAME5BUTTON2
] = [wx.NewId() for _init_ctrls in range(18)]

class GNSS_InputWindow(wx.Frame):
    def _init_ctrls(self, prnt):
        #For getting pixel's value of the display window
        pixel_value=wx.GetDisplaySize()
        
        ##GNSS_input Window Size
        self.GNSS_input_window_Length=pixel_value[0]/2.67
        self.GNSS_input_window_Width=pixel_value[1]/2.95
        self.GNSS_input_Start_x=pixel_value[0]/3.12
        self.GNSS_input_Start_y=pixel_value[1]/5.95
        
        ##GNSS_input notebook Size
        self.notebook_length=pixel_value[0]/2.47##575
        self.notebook_width=pixel_value[1]/2.95##529.6
        
        ##GNSS_Position Buttons Size
        self.OKbutton_start_x=pixel_value[0]/10.6
        self.OKbutton_start_y=pixel_value[1]/4.8
        self.button_length=pixel_value[0]/13.65
        self.button_width=pixel_value[1]/33.39
        
        self.Cancelbutton_start_x=pixel_value[0]/5.02
        self.Cancelbutton_start_y=pixel_value[1]/4.8
        ## GNSS static text Size
        self.statictext_start_x=pixel_value[0]/12.82
        self.statictext_latitude_start_y=pixel_value[1]/18.9
        self.statictext_longitude_start_y=pixel_value[1]/9.92
        self.statictext_altitude_start_y=pixel_value[1]/6.8
        self.statictext_length=pixel_value[0]/18.96
        self.statictext_width=pixel_value[1]/59.08
        ## GNSS static text control box Size
        self.textctrl_start_x=pixel_value[0]/6.50
        self.textctrl_latitude_start_y=pixel_value[1]/19.2
        self.textctrl_longitude_start_y=pixel_value[1]/10.00
        self.textctrl_altitude_start_y=pixel_value[1]/7.00
        self.textctrl_length=pixel_value[0]/7.24
        self.textctrl_width=pixel_value[1]/36.57
        ## combobox Size
        self.combobx_start_x=pixel_value[0]/6.40
        self.combobx_start_y=pixel_value[1]/10.67
        self.combobox_length=pixel_value[0]/5.22
        self.combobox_width=pixel_value[1]/36.57
        
        self.statictext_constellatn_start_x=pixel_value[0]/50
        self.statictext_constellatn_start_y=pixel_value[1]/10.44
        self.statictext_constellatn_length=pixel_value[0]/14.22
        self.statictext_constellatn_width=pixel_value[1]/48
        
        wx.Frame.__init__(self, id=wxID_FRAME5, name='', parent=prnt,
              pos=wx.Point(self.GNSS_input_Start_x, self.GNSS_input_Start_y), size=wx.Size(self.GNSS_input_window_Length,\
               self.GNSS_input_window_Width),
              style=wx.SYSTEM_MENU | wx.CAPTION | wx.MINIMIZE_BOX|wx.CLOSE_BOX, title='CDU::ATE GNSS-Input Window')
        self.SetClientSize(wx.Size(self.GNSS_input_window_Length, self.GNSS_input_window_Width))
        self.Center()
        self.Bind(wx.EVT_CLOSE, self.OnGNSS_InputWindowClose)
        self.panel1 = wx.Panel(id=wxID_FRAME5PANEL1, name='panel1', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(self.GNSS_input_window_Length, self.GNSS_input_window_Width),
              style=wx.TAB_TRAVERSAL)
        self.GNSS_input_notebook = wx.Notebook(id=wxID_FRAME1GNSS_input,
              name='GNSS_input_notebook', parent=self.panel1, pos=wx.Point(0,0),
              size=wx.Size(self.notebook_length,self.notebook_width), style=wx.EXPAND)  
        self.GNSS_input_Command = wx.Panel(id=wxID_FRAME1GNSS_input_Command,
              name='GNSS_input_Command', parent=self.GNSS_input_notebook,pos=wx.Point(0,0),
              size=wx.Size(self.notebook_length, self.notebook_width),
              style=wx.TAB_TRAVERSAL|wx.EXPAND)
        self.GNSS_input_Control = wx.Panel(id=wxID_FRAME1GNSS_input_Control,
              name='GNSS_input_Control', parent=self.GNSS_input_notebook,
              pos=wx.Point(0,0), size=wx.Size(self.notebook_length, self.notebook_width),
              style=wx.TAB_TRAVERSAL|wx.EXPAND)
        self.OK_button = wx.Button(id=wxID_OK_button, label='OK',
              name='OK_button', parent=self.GNSS_input_Command, pos=wx.Point(self.OKbutton_start_x, self.OKbutton_start_y),
              size=wx.Size(self.button_length, self.button_width), style=0)
        self.OK_button .Bind(wx.EVT_BUTTON, self.OnOK_button,
              id=wxID_OK_button)
        self.Cancel_button = wx.Button(id=wxID_Cancel_button, label='Cancel',
              name='Cancel_button', parent=self.GNSS_input_Command, pos=wx.Point(self.Cancelbutton_start_x, self.Cancelbutton_start_y),
              size=wx.Size(self.button_length, self.button_width), style=0)
        self.Cancel_button.Bind(wx.EVT_BUTTON, self.OnCancel_button,
              id=wxID_Cancel_button)
        
        self.Position_Latitude = wx.StaticText(id=wxID_Position_Latitude,
              label='Latitude ', name='Position_Latitude',
              parent=self.GNSS_input_Command, pos=wx.Point( self.statictext_start_x,self.statictext_latitude_start_y),\
               size=wx.Size(self.statictext_length,self.statictext_width), style=0)
        self.Position_Latitude.SetFont(wx.Font(9, wx.SWISS, wx.NORMAL, wx.NORMAL, False, 
              'Tahoma'))

        self.Position_Longitude = wx.StaticText(id=wxID_Position_Altitude,
              label='Longitude', name='Position_Longitude',  
              parent=self.GNSS_input_Command, pos=wx.Point(self.statictext_start_x,self.statictext_longitude_start_y), size=wx.Size(self.statictext_length,
              self.statictext_width), style=0)                              
        self.Position_Longitude.SetFont(wx.Font(9, wx.SWISS, wx.NORMAL, wx.NORMAL, False,
              'Tahoma'))

        self.Position_altitude = wx.StaticText(id=wxID_Position_Longitude,
              label='Altitude', name='Position_altitude',
              parent=self.GNSS_input_Command, pos=wx.Point(self.statictext_start_x, self.statictext_altitude_start_y), \
              size=wx.Size(self.statictext_length,self.statictext_width), style=0)
        self.Position_altitude.SetFont(wx.Font(9, wx.SWISS, wx.NORMAL, wx.NORMAL, False,
              'Tahoma'))

        self.textCtrl_latitude = wx.TextCtrl(id=wxID_textCtrl_latitude, name='textCtrl_latitude',
              parent=self.GNSS_input_Command, pos=wx.Point(self.textctrl_start_x, self.textctrl_latitude_start_y), size=wx.Size(self.textctrl_length,
            self.textctrl_width), style=0, value="") 

        self.textCtrl_longitude = wx.TextCtrl(id=wxID_textCtrl_longitude, name='textCtrl_longitude',
              parent=self.GNSS_input_Command, pos=wx.Point(self.textctrl_start_x, self.textctrl_longitude_start_y), size=wx.Size(self.textctrl_length,               
            self.textctrl_width), style=0, value="")

        self.textCtrl_Altitude = wx.TextCtrl(id=wxID_textCtrl_Altitude, name='textCtrl_Altitude',
              parent=self.GNSS_input_Command, pos=wx.Point(self.textctrl_start_x, self.textctrl_altitude_start_y), size=wx.Size(self.textctrl_length,
            self.textctrl_width), style=0, value="")

        self.comboBox1 = wx.ComboBox(choices=["SGPS (GPS+SBAS)","GPS Only","GLONASS Only","SGNSS (GPS + SBAS + GLONASS)"], id=wxID_FRAME5COMBOBOX1,
              name='comboBox1', parent=self.GNSS_input_Control, pos=wx.Point(self.combobx_start_x, self.combobx_start_y),
              size=wx.Size(self.combobox_length, self.combobox_width), style=wx.CB_DROPDOWN , value="Select One")
        self.staticText1 = wx.StaticText(id=wxID_FRAME5STATICTEXT1,
              label='Constellation Selection', name='staticText1',
              parent=self.GNSS_input_Control, pos=wx.Point(self.statictext_constellatn_start_x, self.statictext_constellatn_start_y), \
              size=wx.Size(self.statictext_constellatn_length,self.statictext_constellatn_width), style=0)
        self.staticText1.SetFont(wx.Font(10, wx.SWISS, wx.NORMAL, wx.NORMAL,
              False, 'Tahoma'))                    
        self.OK_control_message = wx.Button(id=wxID_FRAME5BUTTON1, label='OK',
              name='OK_control_message', parent=self.GNSS_input_Control, pos=wx.Point(self.OKbutton_start_x, self.OKbutton_start_y),\
              size=wx.Size(self.button_length, self.button_width), style=0)
        self.OK_control_message.Bind(wx.EVT_BUTTON, self.OnOK_control_message,
              id=wxID_FRAME5BUTTON1)
        self.Cancel_control_message = wx.Button(id=wxID_FRAME5BUTTON2, label='Cancel',
              name='Cancel_control_message', parent=self.GNSS_input_Control,pos= wx.Point(self.Cancelbutton_start_x, self.Cancelbutton_start_y),\
              size=wx.Size(self.button_length, self.button_width), style=0)
        self.Cancel_control_message.Bind(wx.EVT_BUTTON, self.OnCancel_control_message,
              id=wxID_FRAME5BUTTON2)
        self._init_coll_GNSS_input_Pages(self.GNSS_input_notebook) 
  
    def _init_coll_GNSS_input_Pages(self, parent):
        # generated method, don't edit
        parent.AddPage(imageId=-1, page=self.GNSS_input_Command, select=True,
              text='Position Estimation')
        parent.AddPage(imageId=-1, page=self.GNSS_input_Control,
              select=False, text='GNSS Constellation Selection')
    
    def OnOK_button(self, event):
        CDU_TestRig_MainWindow.class_var3.textCtrl1.Clear()
        ##Checking Whether text control is empty or not
        if((self.textCtrl_latitude.IsEmpty())or(self.textCtrl_longitude.IsEmpty())|(self.textCtrl_Altitude.IsEmpty())):
            CDU_TestRig_MainWindow.class_var3.textCtrl1.SetForegroundColour(wx.Colour(255, 0, 0))
            CDU_TestRig_MainWindow.class_var3.textCtrl1.WriteText("Enter all the fields\n")
            dial = wx.MessageDialog(None, 'Enter all the fields.....!!',
            'Error!!!', wx.OK|wx.STAY_ON_TOP)
            dial.ShowModal()
        else:
            Position=[]
            Position_Update=[]
            Position_Latitude=str(self.textCtrl_latitude.GetValue())
            Position_Longitude=str(self.textCtrl_longitude.GetValue())
            Position_Altitude=str(self.textCtrl_Altitude.GetValue())
            Position.append(Position_Latitude)
            Position.append(Position_Longitude)
            Position.append(Position_Altitude)
##            print Position
            try:
                ##Appending the accepted position values into the list
                for i in range (len(Position)):
                  Position_Update.append(float(Position[i]))
                self.validate_input(Position_Update) 
            except ValueError:
                CDU_TestRig_MainWindow.class_var3.textCtrl1.SetForegroundColour(wx.Colour(255, 0, 0))
                CDU_TestRig_MainWindow.class_var3.textCtrl1.WriteText("Input Value must be a float\n")
                dial = wx.MessageDialog(None, 'Input Value must be a float.....!!',
                'Error!!!', wx.OK|wx.STAY_ON_TOP)
                dial.ShowModal()
    def validate_input(self,Position_Update):
        global temp_GNSS_command_message
        flag_lati=0
        flag_longi=0
        flag_alti=0
        flag_error=0
        flag_error1=0
        temp_GNSS_command_message=GNSS_command_message()  
        ## Checking whether the accepted position values are within the range  
        if(((Position_Update[0])>=-90)and ((Position_Update[0])<=90)):
            flag_lati=1
            temp_GNSS_command_message.Position_Update_latitude=Position_Update[0]
        else:
             CDU_TestRig_MainWindow.class_var3.textCtrl1.SetForegroundColour(wx.Colour(255, 0, 0))
             flag_error=1
             CDU_TestRig_MainWindow.class_var3.textCtrl1.WriteText("Enter the Latitude within the range(-90,90)")
        if(flag_error==0):
            if(((Position_Update[1])>=-180) and ((Position_Update[1])<=180)):
                flag_longi=1
                temp_GNSS_command_message.Position_Update_longitude =Position_Update[1]
            else:
                CDU_TestRig_MainWindow.class_var3.textCtrl1.SetForegroundColour(wx.Colour(255, 0, 0))
                CDU_TestRig_MainWindow.class_var3.textCtrl1.WriteText("Enter the Longitude within the range(-90,90)")
                flag_error1=1
        if((flag_error==0)and(flag_error1==0)):
            if(((Position_Update[2])>=-1000) and ((Position_Update[2])<=18000)):
                flag_alti=1
                temp_GNSS_command_message.Position_Update_altitude =Position_Update[2]
            else:
                 CDU_TestRig_MainWindow.class_var3.textCtrl1.SetForegroundColour(wx.Colour(255, 0, 0))
                 CDU_TestRig_MainWindow.class_var3.textCtrl1.WriteText( "Enter the Position Altitude within the range(-1000,18000)")
        if(flag_alti==1 and flag_lati==1 and flag_longi==1):
            Gnss_command_temp=pack_GNSS_command_message()
            Gnss_command_temp.process_input(Position_Update)
              
    def OnCancel_button(self, event):
         CDU_TestRig_MainWindow.class_var3.textCtrl1.Clear()   
         self.Close()
    def OnCancel_control_message(self, event):
         CDU_TestRig_MainWindow.class_var3.textCtrl1.Clear()
         self.Close()
    def OnOK_control_message(self, event):
        CDU_TestRig_MainWindow.class_var3.textCtrl1.Clear()
        global class_var2 ,constellation_selection
##        print "combo selection"
        constellation_selection=class_var2.comboBox1.GetValue()
##        print "constellation_selection",constellation_selection
        if(constellation_selection=="Select One"):
            CDU_TestRig_MainWindow.class_var3.textCtrl1.SetForegroundColour(wx.Colour(255, 0, 0))
            CDU_TestRig_MainWindow.class_var3.textCtrl1.WriteText("Select one Constellation") 
        else:
            pack_GNSS_control_message_temp=pack_GNSS_control_message()
            pack_GNSS_control_message_temp.process_input_control()
    def  OnGNSS_InputWindowClose(self,event):
        CDU_TestRig_MainWindow.flag_frame2=0
        CDU_TestRig_MainWindow.class_var3.textCtrl1.Clear()
        self.Destroy()
    def __init__(self, parent):
        self._init_ctrls(parent)
    
class GNSS_command_message(Structure):
    _fields_=[
            ("Position_Update_latitude",c_double),
            ("Position_Update_longitude",c_double),
            ("Position_Update_altitude",c_float),
            ]
class pack_GNSS_command_message:
    global temp_GNSS_command_message,flag_transmit
    def process_input(self,Position_Update):
        global flag_transmit
        GNSS_list=[63,63,175,0,temp_GNSS_command_message.Position_Update_latitude,
        temp_GNSS_command_message.Position_Update_longitude,temp_GNSS_command_message.Position_Update_altitude,
            175,0,10]
        check_position=Calculate_Checksum(GNSS_list,10)
        ##Packing the GNSS command message
        GNSS_input_message=struct.pack('<4B2dfI2B',\
                                    63,63,175,0,temp_GNSS_command_message.Position_Update_latitude,\
                                     temp_GNSS_command_message.Position_Update_longitude,\
                                     temp_GNSS_command_message.Position_Update_altitude,\
                                    0,check_position,10)
                                      
        Receive_message_instance=Receive_message()
        ##Calling the thread to send the packed GNSS command message
        threading.Thread(target=Receive_message_instance.start_thread,args=(GNSS_input_message,)).start()
        CDU_TestRig_MainWindow.class_var3.textCtrl1.SetForegroundColour(wx.Colour(0, 0, 0))
        if (flag_transmit==0):
            CDU_TestRig_MainWindow.class_var3.textCtrl1.WriteText("GNSS Command Message Block is Transmitted") 
        
class pack_GNSS_control_message:
   def process_input_control(self):
        global flag_transmit, Receive_message_instance,constellation_selection
        ## Getting the selected constellation
        if(constellation_selection=="SGPS (GPS+SBAS)"):
            var_pos=0
        elif(constellation_selection=="GPS Only"):
             var_pos=1
        elif(constellation_selection=="GLONASS Only"):
             var_pos=2
        elif(constellation_selection=="SGNSS (GPS + SBAS + GLONASS)"):
            var_pos=3        
        GNSS_input_checksum=[63,63,175,1,var_pos,0]
        Checksum=Calculate_Checksum(GNSS_input_checksum,6)
        print "check..........",Checksum
        GNSS_input_message_control=struct.pack('<8B',\
                                    63,63,175,1,var_pos,0,Checksum,10)
     
        Payload_for_checksum1=struct.unpack_from('<8B',GNSS_input_message_control[0:8])
        print "GNSS_input_message",Payload_for_checksum1
        Receive_message_instance=Receive_message()
        threading.Thread(target=Receive_message_instance.start_thread,args=(GNSS_input_message_control,)).start()
        CDU_TestRig_MainWindow.class_var3.textCtrl1.SetForegroundColour(wx.Colour(0, 0, 0))
        if (flag_transmit==0):
            CDU_TestRig_MainWindow.class_var3.textCtrl1.WriteText("GNSS Control Message Block is Transmitted")
class Receive_message():
    ## Thread to send the GNSS input message
  def start_thread(self,GNSS_input_message):
        global flag_transmit
        if(COMConfig_Window.instance_comport_receiver.Comport_select==COMConfig_Window.instance_comport_transmitter.Comport_select):
            if(CDU_TestRig_MainWindow.class_var3.connect_object_GNSS_receiver!=''):
                CDU_TestRig_MainWindow.class_var3.connect_object_GNSS_receiver.write(GNSS_input_message)
            else:
                flag_transmit=1
                win32api.MessageBox(0, 'COM Port is not Available !', 'Error!!!' )
        else:
            if(CDU_TestRig_MainWindow.class_var3.connect_object_GNSS_transmitter!=''):
                CDU_TestRig_MainWindow.class_var3.connect_object_GNSS_transmitter.write(GNSS_input_message)
            
            else:
                flag_transmit=1
                win32api.MessageBox(0, 'COM Port is not Available !', 'Error!!!' )
## Function to calculate checksum
def Calculate_Checksum(data,bytecount):
    checksum=0
    print "data",data
    for i in range(0,bytecount):
       var1=int(data[i])
       checksum=checksum ^ (var1)
    checksum=checksum&0xFFFFFFFF
    print "checksum",checksum
    return checksum   