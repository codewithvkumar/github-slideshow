#-----------------------------------------------------------------------------
# Name:        Frame3.py
# Purpose:     
#
# Author:      <your name>
#
# Created:     2013/02/28
# RCS-ID:      $Id: Frame3.py $
# Copyright:   (c) 2006
# Licence:     <your licence>
#-----------------------------------------------------------------------------
#Boa:Frame:CDU_TestRig_MainWindow

import wx
import GNSS_OutputWindow
import GNSS_InputWindow
import COMConfig_Window
import home_creation
import CDU_output
import Update_home
import KEYreadnsend
import display
import ibit_out
import page_creation
import Hotkey
import Frame2
import struct
import os
import time
from ctypes import *
import threading
from threading import Thread
import time
from ctypes import *
import serial
import string
from serial import  *
import win32api
from xlutils.copy import copy
import sys
import xlrd
import xlwt

global flag_frame1,flag_frame2,flag_mainframe,main1,main2,class_var,flag_display1,flag_display2,flag_display3,main3
global GNSS_version_temp ,GNSS_output_temp,GNSS_health_temp,file1,flag_com,COMConfig_Window_flag
global class_var3,temp_message,flag_save,flag_save1,flag_save2,val_latitude,GNSS_decoded_output_temp,GNSS_decoded_version_temp,\
GNSS_decoded_health_temp,flag_ok,GNSS_flag
global class_var4,KEYreadnsend_flag,update_select
global filename_GNSS_position_data,filename_GNSS_health_data,filename_GNSS_version_data,flag_connection
##global data_packet,ibit_flag,data_packet_ibit
global data_packet_ibit,IBIT_log_xls,CDUsend_flag
##data_packet=[]
IBIT_log_xls=''
CDU_LOG_xls=''
data_packet_ibit=[]
flag=0
KEYreadnsend_flag=0
COMConfig_Window_flag=0
flag_display1=0
flag_display2=0
flag_display3=0
flag_frame1=0
flag_frame2=0 
CDUsend_flag=0
##flag_page_creation=0
##flag_Update_page=0
flag_home_creation=0
flag_Update_home=0
flag_CDU_output=0
update_select=0
page_var=0
COMConfig_Window_flag=0
##ibit_flag=0
##ibit_packet=[]



def create(parent):
     global class_var3
     class_var3=CDU_TestRig_MainWindow(parent)
     return class_var3

[wxID_CDU_TestRig_MainWindow, wxID_CDU_TestRig_MainWindowPANEL3, wxID_CDU_TestRig_MainWindow_GNSS_STATICBOX, wxID_CDU_TestRig_MainWindow_GNSS_status, 
 wxID_CDU_TestRig_MainWindow_CDU_STATICBOX,wxID_CDU_TestRig_MainWindow_CDU_status,
 wxID_CDU_TestRig_MainWindow_STATICBOX3,wxID_CDU_TestRig_MainWindowTEXTCTRL3,
] = [wx.NewId() for _init_ctrls in range(8)]

class CDU_TestRig_MainWindow(wx.Frame):
    def _init_ctrls(self, prnt):
        # generated method, don't edit
        ##Length and width of Main Window
        pixel=wx.GetDisplaySize() 
        global class_var4

        self.Main_window_Length=pixel[0]
        self.Main_window_Width=pixel[1]-50
        self.panel1_Length=pixel[0]
        self.panel1_Width=pixel[1]/9.5
        
        ##Main Frame
        wx.Frame.__init__(self, id=wxID_CDU_TestRig_MainWindow, name='', parent=prnt,
              pos=wx.Point(0, 0), size=wx.Size(self.Main_window_Length, self.Main_window_Width),
              style=wx.SYSTEM_MENU | wx.CAPTION | wx.MINIMIZE_BOX|wx.CLOSE_BOX    , title='CDU TestRig')
        self.SetClientSize(wx.Size(self.Main_window_Length, self.Main_window_Width))
##        self.Center()
        self.Bind(wx.EVT_CLOSE, self.OnMainFrameClose)
        self.panel1 = wx.Panel(id=wxID_CDU_TestRig_MainWindowPANEL3, name='panel1', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(self.panel1_Length, self.panel1_Width),
              style=wx.TAB_TRAVERSAL)
        self.panel2 = wx.Panel(id=wxID_CDU_TestRig_MainWindowPANEL3, name='panel1', parent=self,
              pos=wx.Point(0, self.panel1_Width), size=wx.Size(self.panel1_Length, self.Main_window_Width-self.panel1_Length),
              style=wx.TAB_TRAVERSAL)
        self.CreateMenu()
        #position for labels
        self.static_box_Start_x=(pixel[0]/136.6)
        self.static_box_Start_y=(pixel[1]/76.8)
        self.static_box_Length=(pixel[0]/24)
        self.static_box_Width=(pixel[1]/15)
        
        #positions for bitmap labels
        self.bmp_Start_x=(pixel[0]/35.62)
        self.bmp_Start_y=(pixel[1]/25.6)
        self.bmp_Length=pixel[0]/60
        self.bmp_Width=pixel[1]/30
        self.bmp_gap=(pixel[0]/16.00) ##60
       
        #Color for bmp 
        self.default_color=[236,233,216]
        #Position for "message log"
        self.static_box1_Start_x=(pixel[0]/4.65)
        self.static_box1_Start_y=(pixel[1]/192)
        self.static_box1_Length=(pixel[0]/4.129)
        self.static_box1_Width=(pixel[1]/13.71)
        self.txtctrl_Start_x=(pixel[0]/4.53)
        self.txtctrl_Start_y=(pixel[1]/34.9)
        self.txtctrl_Length=(pixel[0]/4.41)
        self.txtctrl_Width=(pixel[1]/32)
        
        #Position for text control
        self.TextCtrl_Start_x=(pixel[0]/2.34)
        self.TextCtrl_Start_y=(pixel[1]/54.86)
        self.TextCtrl_Length=(pixel[0]/1.79)
        self.TextCtrl_Width=(pixel[1]/14.40)
        
        #Position for staticBox3
        self.staticBox3_Start_x=(pixel[0]/2.38)
        self.staticBox3_Start_y=(pixel[1]/768)
        self.staticBox3_Length=(pixel[0]/1.75)
        self.staticBox3_Width=(pixel[1]/10.67)
        
        ##CDU-Connection
        self.CDU = wx.StaticBox(id=wxID_CDU_TestRig_MainWindow_CDU_STATICBOX,
              label='CDU', name='RS232', parent=self.panel1,
              pos=wx.Point((2*self.static_box_Start_x),self.static_box_Start_y), size=wx.Size(self.static_box_Length,self.static_box_Width), style=0)
        self.CDU_status =  wx.StaticBitmap(bitmap=wx.Bitmap(u'red_light.bmp',
              wx.BITMAP_TYPE_BMP), id=wxID_CDU_TestRig_MainWindow_CDU_status,
              name='USB', parent=self, pos=wx.Point(self.bmp_Start_x,self.bmp_Start_y),
              size=wx.Size(self.bmp_Length+3,self.bmp_Width), style=0)
        self.CDU_status.SetBackgroundColour(self.default_color)
       
        ##GNSS-Connection
        self.GNSS = wx.StaticBox(id=wxID_CDU_TestRig_MainWindow_GNSS_STATICBOX,
              label='GNSS', name='WIFI', parent=self.panel1,
              pos=wx.Point((5*self.static_box_Start_x)+self.static_box_Length,self.static_box_Start_y), size=wx.Size(self.static_box_Length,self.static_box_Width), style=0)        
        self.GNSS_status =  wx.StaticBitmap(bitmap=wx.Bitmap(u'red_light.bmp',      
              wx.BITMAP_TYPE_BMP), id=wxID_CDU_TestRig_MainWindow_GNSS_status,
              name='USB-TB', parent=self, pos=wx.Point(self.bmp_Start_x+self.bmp_gap,self.bmp_Start_y),
              size=wx.Size(self.bmp_Length+3,self.bmp_Width), style=0)    
        self.GNSS_status.SetBackgroundColour(self.default_color)     
        
        ##Message Log
        self.textCtrl1 = wx.TextCtrl(id=wxID_CDU_TestRig_MainWindowTEXTCTRL3, name='textCtrl1',
              parent=self.panel1, pos=wx.Point(self.TextCtrl_Start_x, self.TextCtrl_Start_y), size=wx.Size(self.TextCtrl_Length, self.TextCtrl_Width),
              style=wx.TE_MULTILINE , value="")
        self.textCtrl1. SetEditable(0)
##        self.textCtrl1.SetForegroundColour(wx.Colour(255, 0, 0))
        self.staticBox3 = wx.StaticBox(id=wxID_CDU_TestRig_MainWindow_STATICBOX3,
              label='Message Log', name='staticBox3', parent=self.panel1,
              pos=wx.Point(self.staticBox3_Start_x, self.staticBox3_Start_y), size=wx.Size( self.staticBox3_Length, self.staticBox3_Width), style=0)   
        self.connect_object_GNSS_receiver=''  
        self.connect_object_GNSS_transmitter=''
        self.connect_object_CDU_receiver=''
        self.connect_object_CDU_transmitter=''
        self.filename_GNSS_position_data=''
        self.filename_GNSS_health_data=''
        self.filename_GNSS_version_data=''
        
        self.wtbook = xlwt.Workbook()           # xls file to write into it
        self.wtsheet = self.wtbook.add_sheet('Sheet 1') 
        self.wtbook.save('CDU_LOG.xls')
        self.rb = xlrd.open_workbook('CDU_LOG.xls', formatting_info=True)
        self.w=copy(self.rb)

                
    def __init__(self, parent):
        self._init_ctrls(parent)
        
    def OnMainFrameClose(self, event):    
        global flag_connection,flag
        flag=0
        flag_connection=0
        if(COMConfig_Window.instance_comport_receiver.Comport_select==COMConfig_Window.instance_comport_transmitter.Comport_select):
            if (self.connect_object_GNSS_receiver!='' ):
                flag_connection=0
                time.sleep(1)
                self.connect_object_GNSS_receiver.close()
                self.connect_object_GNSS_receiver='' 
                
            if(self.connect_object_CDU_receiver!=''):  
                time.sleep(1)
                self.connect_object_CDU_receiver.close()
                self.connect_object_CDU_receiver='' 
        else:
            if(self.connect_object_GNSS_receiver!='' and self.connect_object_GNSS_transmitter!=''):
                flag_connection=0
                time.sleep(1)
                self.connect_object_GNSS_receiver.close()
                self.connect_object_GNSS_transmitter.close()
                self.connect_object_GNSS_receiver=''
                self.connect_object_GNSS_transmitter=''
                
                
            if(self.connect_object_CDU_receiver!='' and self.connect_object_CDU_transmitter!=''):
                time.sleep(1)
                self.connect_object_CDU_receiver.close()
                self.connect_object_CDU_receiver='' 
                self.connect_object_CDU_transmitter.close()
                self.connect_object_CDU_transmitter=''
                
                
##        if(page_creation.my_instance.flag_save==0 ): # To display browser window
##            dial = wx.MessageDialog(None, 'Do you want to save?', 'Message', wx.STAY_ON_TOP|wx.YES_NO )
##            if dial.ShowModal()==wx.ID_YES:
##                dlg = wx.FileDialog(self, "Choose a file", ".", "", "*.xls", wx.SAVE)
##                if dlg.ShowModal() == wx.ID_OK:
##                    global browse
##                    browse=1
##                    page_creation.filename_xls = dlg.GetPath()
##                    page_creation.my_instance.flag_save=1
##                    page_creation.my_instance.Savexls()
##        elif(page_creation.my_instance.flag_save==1):                   # Once file is selected,next time onwards it saves to same file
##            page_creation.filename_xls=filename_xls 
##                
##        if(Update_page.my_instance1.flag_save==0):                    # To display browser window
##            dial = wx.MessageDialog(None, 'Do you want to save?', 'Message', wx.STAY_ON_TOP|wx.YES_NO )
##            if dial.ShowModal()==wx.ID_YES:
##                Update_page.my_instance1.flag_save=1
##                Update_page.my_instance1.Savexls()
##        elif(self.flag_save==1):                   # Once file is selected,next time onwards it saves to same file
##            Update_page.filename_xls=CDU_TestRig_MainWindow.filename_xls
            

        if(flag_frame1==1):
            self.main1.Destroy() 
        if(flag_frame2==1):
            self.main2.Destroy()   
        if(COMConfig_Window_flag==1):
            self.main3.Destroy() 
        if(KEYreadnsend_flag==1):
            self.main6.Destroy()  
        if(flag_home_creation==1): # home_creation dialog Destroy
            self.main4.Destroy()
        if(flag_Update_home==1): # Update_homedialog Destroy
            self.main5.Destroy() 
        if(home_creation.flag_page_creation==1): # page_creation  Destroy
            home_creation.main8.Destroy()
        if(Update_home.flag_Update_page==1): # Update_page  Destroy
            Update_home.main9.Destroy() 
        if(flag_CDU_output==1):      # CDU_output  Destroy
            self.main7.Destroy() 
        
                 
        self.Destroy()  
        print "close"
        
    def BuildSubmenu(self, subMenu):
        subMenuObject = wx.Menu()
        for item in subMenu:
            if not item: #allow now to add separators
                subMenuObject.AppendSeparator()
                continue
            if len(item) == 2:
                title, action = item 
            elif len(item) == 3:
                title,id,action = item 
            if type(action) is list:
                _id = wx.NewId()
                subMenuObject.AppendMenu(_id, title, self.BuildSubmenu(action))
            else:
                _id = id ##wx.NewId()
                subMenuObject.Append(_id, title)
                wx.EVT_MENU(self, _id, action)
        return subMenuObject
     
    def BuildMenu(self, menu):
        mainMenu = wx.MenuBar()
        for title, subMenu in menu:
            mainMenu.Append(self.BuildSubmenu(subMenu), title)
        return mainMenu
       
    def CreateMenu(self):
        menu = [
                ('&Configure',
                    [
                    ('&Connect to GNSS ', 1,self.connect_port),
                    ('&Connect to CDU', 2,self.Connect_CDU),
                    ('&Close connection  ', 14,
                        [
                            ('&GNSS connection', 15,self.close_GNSS),
                            ('&CDU connection ', 16,self.close_CDU),
                        ]
                    ),
                    ]
                ),
                ('&CDU',
                    [
                    ('&Create Page ', 3,self.Create_Page),
                    ('&Update Page', 4,self.Update_Pagefn),
                    ('&Send pages to CDU', 5,self.Send_CDU),
                    ('&Output Message from CDU', 6,self.Output_CDU),
					('&Configure the HotKeys', 7,self.Hotkeys_CDU),
                    ('&IBIT Command   ', 8,
                        [
                            ('&IBIT Command Input', 9,self.Ibit_command),
                            ('&IBIT Command Output ', 10,self.Ibit_results),
                        ]
                    ),
                    ]
                ),
                ('&GNSS Messages ',
                   [
                    ('&GNSS Input Message ', 11,self.GNSS_input),
                    ('&GNSS Output Message ', 12,self.GNSS_output1),
                    ]              
                ),  
                ('&Help ',
                   [
                    ('&About CDU-TestRig', 13,self.about_CDU),                    ]              
                ),              
               ]
               
        self.Menu_created=self.BuildMenu(menu)
        self.SetMenuBar(self.Menu_created)
        
    def about_CDU(self,event):
       self.main18 = Frame2.create(None)
       self.main18.Show()
##       event.skip()

    def close_GNSS(self,event):
        global flag_connection,flag
        flag=0
        flag_connection=0
        self.GNSS_status.SetBitmap(wx.Bitmap(u'red_light.bmp'))
        if(COMConfig_Window.instance_comport_receiver.Comport_select==COMConfig_Window.instance_comport_transmitter.Comport_select):
            if (self.connect_object_GNSS_receiver!='' ):
                flag_connection=0
                time.sleep(1)
                self.connect_object_GNSS_receiver.close()
                self.connect_object_GNSS_receiver='' 
        else:
            if(self.connect_object_GNSS_receiver!='' and self.connect_object_GNSS_transmitter!=''):
                flag_connection=0
                time.sleep(1)
                self.connect_object_GNSS_receiver.close()
                self.connect_object_GNSS_transmitter.close()
                self.connect_object_GNSS_receiver=''
                self.connect_object_GNSS_transmitter=''
         
                
##        event.skip()
        
    def close_CDU(self,event):
        global flag_connection,flag
        flag=0
        flag_connection=0
        self.CDU_status.SetBitmap(wx.Bitmap(u'red_light.bmp'))
        if(COMConfig_Window.instance_comport_receiver.Comport_select==COMConfig_Window.instance_comport_transmitter.Comport_select):
            if(self.connect_object_CDU_receiver!=''):  
                time.sleep(1)
                self.connect_object_CDU_receiver.close()
                self.connect_object_CDU_receiver=''
        else:
            if(self.connect_object_CDU_receiver!='' and self.connect_object_CDU_transmitter!=''):
                time.sleep(1)
                self.connect_object_CDU_receiver.close()
                self.connect_object_CDU_receiver='' 
                self.connect_object_CDU_transmitter.close()
                self.connect_object_CDU_transmitter=''
        
           
##        event.skip()
        
        
    def Hotkeys_CDU(self,event):
	    global page_var,flag 
	    val=0
##            page_creation.new_confirm=0
##            page_var=1
##            home_creation.home_flag=0
##            self.main11 = Hotkey.create(None)
##            self.main11.Show()
##            if KEYreadnsend.class_var.check_pageselected==1:
##                flag=0
            head=os.getcwd()
            print head
            file="CDUHOTKEY.xls"
            pathnfile=os.path.join(head,"CDUHOTKEY.xls") 
            print pathnfile   
            for subdir,dirs,files in os.walk(head):
                for a in files:
                    fullpath=os.path.join(head,a)
                    if(fullpath!=pathnfile):
                        val=1
                    else:
                        val=0
                        break
                break     
            if val==1:
                 m1 = wx.MessageDialog(self, "NO HOTKEYS CONFIGURATION PAGE PRESENT!!!Please create or update page!!!",\
                    " ", style = wx.OK | wx.ICON_INFORMATION|wx.STAY_ON_TOP)
                 if m1.ShowModal() == wx.ID_OK:
                    m1.Destroy()           
                
            else: 
                print "llllllllllllllllllll"
                page_creation.new_confirm=0
                page_var=1
                home_creation.home_flag=0
                self.main11 = Hotkey.create(None)
                self.main11.Show()
##                self.main11.MakeModal(True) 

##            event.skip()    
    def Ibit_results(self,event):
        if(self.connect_object_CDU_receiver!='' or self.connect_object_CDU_transmitter!=''):
            self.ibit_results = ibit_out.create(None)
            self.ibit_results.Show()
        else:
            dial = wx.MessageDialog(None, 'COM port is not connected.....!!',
            'Error!!!', wx.OK|wx.STAY_ON_TOP)
            dial.ShowModal()

    def Ibit_command(self,event):
        global CDUsend_flag
        i=0
        KEYreadnsend.ibit_flag=0
        self.ibit_results = ibit_out.create(None)
##        print "receiver------>",self.connect_object_CDU_receiver
        if(self.connect_object_CDU_receiver!='' or self.connect_object_CDU_transmitter!=''):
            if(CDUsend_flag==1):
                while(1):
                    if(KEYreadnsend.ibit_flag==0 and i<4):
                        display.Ibit_msg()
                        print "i=",i
                        i=i+1
                        time.sleep(1)
    ##                if KEYreadnsend.ibitfinal_flag==1:
    ##                    self.ibit_results = sample.create(None)
    ##                    print "open ibit_out.........>"
    ##                    self.ibit_results.Show()
    ##                    break 
                    else:
                         break
            else:
                dial = wx.MessageDialog(None, 'Pages not sent to CDU.....!!',
                'Error!!!', wx.OK|wx.STAY_ON_TOP)
                dial.ShowModal()
                      
        else:
            dial = wx.MessageDialog(None, 'COM port is not connected.....!!',
            'Error!!!', wx.OK|wx.STAY_ON_TOP)
            dial.ShowModal() 
          
##       event.Skip()
                  
    def GNSS_output1(self,event):
            global flag_frame1,main1
##        if(self.connect_object_GNSS_receiver!='' or self.connect_object_GNSS_transmitter!=''):
            if(flag_frame1==0):
                self.main1 = GNSS_OutputWindow.create(None)
                self.main1.Show()
                flag_frame1=1
            else:
                self.main1.SetFocus()
                self.main1.Show() 
##        else:
##            dial = wx.MessageDialog(None, 'COM port is not connected.....!!',
##            'Error!!!', wx.OK|wx.STAY_ON_TOP)
##            dial.ShowModal()  
   
    def GNSS_input(self,event):
        global flag_frame2,main2
        if(self.connect_object_GNSS_receiver!='' or self.connect_object_GNSS_transmitter!=''):
            if(flag_frame2==0):
                self.main2 = GNSS_InputWindow.create(None)
                self.main2.Show()
                flag_frame2=1
            else:
                self.main2.SetFocus()
                self.main2.Show() 
        else:
            dial = wx.MessageDialog(None, 'COM port is not connected.....!!',
            'Error!!!', wx.OK|wx.STAY_ON_TOP)
            dial.ShowModal()
               
        
    def connect_port(self,evt):
        global main3,GNSS_flag,flag_com,COMConfig_Window_flag
        GNSS_flag=1
        flag_com=1
        if(COMConfig_Window_flag==0):
            self.main3 = COMConfig_Window.create(None)
            self.main3.Show()
            COMConfig_Window_flag=1
        else:
            self.main3.SetFocus()
            self.main3.Show() 
            

    def create_file_GNSS_Data(self):   ##CSV file.
        print "self",self
        fd=open(self.filename_GNSS_position_data,'w')
        fd.write("Message,")
        fd.write("Position Availability,")
        fd.write("Receiver_latitude,") 
        fd.write("Receiver_longitude,")
        fd.write("Receiver_altitude,")
        fd.write("Ground_Speed,")
        fd.write("Heading,")
        fd.write("Receiver_North_Velocity,")
        fd.write("Receiver_east_velocity,")
        fd.write("Receiver_vertical_velocity,")
        fd.write("UTC Date,")
        fd.write("UTC Time,")
        fd.write("HPL,")
        fd.write("HFOM,")
        fd.write("VPL,")
        fd.write("VFOM,")
        fd.write("PPS Status,")
        fd.write("Position Computation by,") 
        fd.close()
        
        fd1=open(self.filename_GNSS_health_data,'w')
        fd1.write("Message,")
        fd1.write("GPS Start Mode," ) 
##            fd1.write("GNSS Mode,")           
        fd1.write("Navigation with GAGAN Corrections,") 
        fd1.write("Navigation with Integrity,")        
        fd1.write("2D Navigation with Altitude Aid,")      
        fd1.write("3D Navigation,")                   
        fd1.write("Fault Integrity Fails During Navigation,")
        fd1.write("Phase of Flight,") 
        fd1.write("Number of Tracking GPS Satellites,")
        fd1.write("Number of Tracking GLONASS Satellites,")
        fd1.write("Number of Tracking GAGAN Satellites,")
##            fd1.write("Fault Status,")
        fd1.write("Antenna Connected,")
        fd1.write("Antenna State,")    
        fd1.write("RF1 (GPS + GAGAN RF) PLL Locked,")     
        fd1.write("RF2 (GLONASS) PLL Locked,")      
        fd1.write("CPU1(GPS +GLONASS processor,")    
        fd1.write("CPU2 (GAGAN),")     
        fd1.write("Satellites Availability,") 
        fd1.write("PDOP Value,") 
        fd1.write("GAGAN Satellites are Used for Position Computation,") 
        fd1.write("GNSS System Failure,")  
        fd1.write("GNSS Mode,")  
        fd1.write("PDOP Value,") 
        fd1.write("HDOP Value,")     
        fd1.write("VDOP Value,")    
        fd1.write("TDOP Value,")      
        fd1.close()
        
        fd2=open(self.filename_GNSS_version_data,'w')
        fd2.write("Message,")
        fd2.write("Hardware Version number,")
        fd2.write("Software Version number ,")
        fd2.write("Software Release Date ,")
        fd2.close()
##        evt.Skip()    
    
    def Save_GNSS_fields(self,list1):
##        print "SAving"
        list_str=''
        list3=[]
        for i in range((len(list1))-2):
            list3.append((hex(list1[i])))
            if((len(list3[i]))==3):
                  temp5=string.split(list3[i],'0x')
                  list3[i]='0x'+'0'+temp5[1]
            list3[i]=list3[i].replace("0x",'')
            list_str=list_str+list3[i]
        list_str='0x'+list_str
##        print list_str 
        global flag_position
##        print "self",self
##        print self.filename_GNSS_position_data
        fd=open(self.filename_GNSS_position_data,'a')
        fd.write("\n"+list_str +",")
        fd.write(str(GNSS_OutputWindow.GNSS_decoded_output_temp.Position_availability) +",")
        fd.write(str(GNSS_OutputWindow.GNSS_decoded_output_temp.Receiver_latitude)+",")
        fd.write(str(GNSS_OutputWindow.GNSS_decoded_output_temp.Receiver_longitude)+",")
        fd.write(str(GNSS_OutputWindow.GNSS_decoded_output_temp.Receiver_altitude)+",")
        fd.write(str(GNSS_OutputWindow.GNSS_decoded_output_temp.Ground_Speed)+",")
        fd.write(str(GNSS_OutputWindow.GNSS_decoded_output_temp.Heading)+",")
        fd.write(str(GNSS_OutputWindow.GNSS_decoded_output_temp.Receiver_North_Velocity)+",")
        fd.write(str(GNSS_OutputWindow.GNSS_decoded_output_temp.Receiver_east_velocity)+",")
        fd.write(str(GNSS_OutputWindow.GNSS_decoded_output_temp.Receiver_vertical_velocity)+",")
        fd.write(str(GNSS_OutputWindow.GNSS_decoded_output_temp.UTC_date)+",")
        fd.write(str(GNSS_OutputWindow.GNSS_decoded_output_temp.UTC_time)+",")
        fd.write(str(GNSS_OutputWindow.GNSS_decoded_output_temp.HPL)+",")
        fd.write(str(GNSS_OutputWindow.GNSS_decoded_output_temp.HFOM)+",")
        fd.write(str(GNSS_OutputWindow.GNSS_decoded_output_temp.VPL)+",")
        fd.write(str(GNSS_OutputWindow.GNSS_decoded_output_temp.VFOM)+",")
        fd.write(str(GNSS_OutputWindow.GNSS_decoded_output_temp.PPS)+",")
        fd.write(str(GNSS_OutputWindow.GNSS_decoded_output_temp.Position_Computation)+",")
        fd.close()

    def Save_GNSS_health_fields(self,health_list):
##        print "SAving1"
        global filename_GNSS_health_data
##        global filename_GNSS_position_data,filename_GNSS_health_data,filename_GNSS_version_data,flag_position
        list_str2=''
        list_health=[]
##        print health_list
        for i in range((len(health_list))-2):
            list_health.append((hex(health_list[i])))
            if((len(list_health[i]))==3):
                  temp5=string.split(list_health[i],'0x')
                  list_health[i]='0x'+'0'+temp5[1]
            list_health[i]=list_health[i].replace("0x",'')
            list_str2=list_str2+list_health[i]
        list_str2='0x'+list_str2
##        print list_str2
        fd1=open(self.filename_GNSS_health_data,'a')
        fd1.write("\n"+list_str2+",")
        fd1.write( GNSS_OutputWindow.GNSS_decoded_health_temp.GNSS_Start_Mode+",")              
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.Navigation_with_GAGAN+",")
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.Navigation_with_Integrity+",")
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.Navigation_2D+",")
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.Navigation_3D+",")  
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.FaultIntegrity+",")
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.Phase_of_Flight+",")
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.GPS_Satellites+",")
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.GLONASS_Satellites+",")
        fd1.write( GNSS_OutputWindow.GNSS_decoded_health_temp.GAGAN_Satellites+",")
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.Antenna+",")
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.Antenna_state+",")
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.RF1+",")
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.RF2+",") 
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.CPU1+",")   
        fd1.write( GNSS_OutputWindow.GNSS_decoded_health_temp.CPU2+",")
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.Satellites_avail+",")
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.PDOP1+",")
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.GAGAN_position+",")
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.GNSS_system_failure+",")    
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.GNSS_mode+",")
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.PDOP_value+",")
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.HDOP+",")
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.VDOP+",") 
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.TDOP+",")       
        fd1.close()
        
    def Save_GNSS_version_fields(self,version_list):
##        print "SAving2"
        global filename_GNSS_version_data
##        global filename_GNSS_position_data,filename_GNSS_health_data,filename_GNSS_version_data,flag_position
        list_str3=''
        list_version=[]
        for i in range((len(version_list))-2):
            list_version.append((hex(version_list[i])))
            if((len(list_version[i]))==3):
                  temp5=string.split(list_version[i],'0x')
                  list_version[i]='0x'+'0'+temp5[1]
            list_version[i]=list_version[i].replace("0x",'')
            list_str3=list_str3+list_version[i]
        list_str3='0x'+list_str3
##        print list_str3
        fd2=open(self.filename_GNSS_version_data,'a')
        fd2.write("\n"+list_str3+",")
        fd2.write(GNSS_OutputWindow.GNSS_decoded_version_temp.Hardware_version_number+",")
        fd2.write(GNSS_OutputWindow.GNSS_decoded_version_temp.Software_version+",")
        fd2.write(GNSS_OutputWindow.GNSS_decoded_version_temp.Software_release_date+",")
        fd2.close()
        
    def connection(self):
            global flag_connection
            try:
                flag_connection=1
##                instance_comport_receiver=Comport_set_receiver()
##                instance_comport_transmitter=Comport_set_transmitter()
                print"GNSS---------->"
                if(COMConfig_Window.instance_comport_receiver.Comport_select==COMConfig_Window.instance_comport_transmitter.Comport_select):
                    self.connect_object_GNSS_receiver = serial.Serial(int(COMConfig_Window.instance_comport_receiver.Comport_select),baudrate=int(COMConfig_Window.instance_comport_receiver.Baud_Rate),timeout=None,bytesize=8, parity=COMConfig_Window.instance_comport_receiver.Parity, stopbits=COMConfig_Window.instance_comport_receiver.Stop_Bits)
                    self.GNSS_status.SetBitmap(wx.Bitmap(u'green_light.bmp')) 
                    print"GNSS---------->EQUAL"
                else:
                    self.connect_object_GNSS_receiver = serial.Serial(int(COMConfig_Window.instance_comport_receiver.Comport_select),baudrate=int(COMConfig_Window.instance_comport_receiver.Baud_Rate),timeout=None,bytesize=8, parity=COMConfig_Window.instance_comport_receiver.Parity, stopbits=COMConfig_Window.instance_comport_receiver.Stop_Bits)
                    self.connect_object_GNSS_transmitter = serial.Serial(int(COMConfig_Window.instance_comport_transmitter.Comport_select),baudrate=int(COMConfig_Window.instance_comport_transmitter.Baud_Rate),timeout=None,bytesize=8, parity=COMConfig_Window.instance_comport_transmitter.Parity, stopbits=COMConfig_Window.instance_comport_transmitter.Stop_Bits)
                    self.GNSS_status.SetBitmap(wx.Bitmap(u'green_light.bmp'))
                    print"GNSS---------->DIFFERENT"
                TestThread()
            except SerialException:
                win32api.MessageBox(0, 'COM Port is not Available !', 'Error!!!')  
                    
    def Create_Page(self,event): 
        global flag_home_creation
##        print" global main4",main4
        update_select=0
       
##        print"flag_home_creation",flag_home_creation
##        print"home_creation.flag_page_creation",home_creation.flag_page_creation
        
        if(flag_home_creation==0 and home_creation.flag_page_creation==0):
            self.main4 = home_creation.create(None)
            self.main4.Show()
            flag_home_creation=1
        elif(flag_home_creation==1 and home_creation.flag_page_creation==0):
            self.main4.SetFocus()
            flag_home_creation=1
            self.main4.Show() 
        elif(flag_home_creation==0 and home_creation.flag_page_creation==1):
            home_creation.main8.SetFocus()
            home_creation.flag_page_creation=1
            home_creation.main8.Show()
        else:
            print "aaaaaaaa"
               
    def Update_Pagefn(self,event):
        global filename_xls,prev_page,flag_Update_home,update_select
		
        page_creation.new_confirm=2
        update_select=1
        t=0
##        try:
        if(flag_Update_home==0 and Update_home.flag_Update_page==0):
            dlg = wx.FileDialog(self, "Choose a file", ".", "", "*.xls", wx.OPEN)
            if dlg.ShowModal() == wx.ID_OK:
                global browse
                browse=1
                filename_xls = dlg.GetPath()
                
                wb=xlrd.open_workbook(filename_xls, formatting_info=1)
                sh1=wb.sheet_by_index(0)
                rows=sh1.nrows 
##                    print "rows",rows
##                    temp=(sh1.row_values(rows-10))  
##                    temp1=temp[1]
##                    print "temp[1]",temp
##                    prev_page=int(temp1/4096)
                row_no=(rows+1)/11
##                print "rows",rows
##                print "row_no",row_no
                for i in range(row_no):
                    temp=(sh1.row_values(t)) 
##                    print "temp",temp[1]
 
                    if(temp[1]!=''): 
##                        temp=(sh1.row_values(t-11)) 
##                        print "inside if--->temp",temp
                        prev_page=int(temp[1]/4096)
##                        print "prev_page",prev_page
                    else:
                        break
                    t=t+11
                        
                self.main5 = Update_home.create(None)
                flag_Update_home=1
                self.main5.Show()
        elif(flag_Update_home==1 and Update_home.flag_Update_page==0):
            self.main5.SetFocus()
            flag_Update_home=1
            self.main5.Show() 
        elif(flag_Update_home==0 and Update_home.flag_Update_page==1): 
            Update_home.main9.SetFocus()
            Update_home.flag_Update_page=1
            Update_home.main9.Show()
                
##        except:
##            dial = wx.MessageDialog(None, 'Format not supported.....!!',
##            'Error!!!', wx.OK|wx.STAY_ON_TOP)
##            dial.ShowModal()  
 
           
        
##        event.Skip()

    def Output_CDU(self,event): 
        global flag_CDU_output
        print "Output_CDU"
        if(self.connect_object_CDU_receiver!=''):
            if(flag_CDU_output==0):
                self.main7 = CDU_output.create(None)
                self.main7.Show()
##                CDU_output.instance_Frame8.Log_Heading()
##                display.Log_Heading()
            else:
                self.main7.SetFocus()
                self.main7.Show()
        else:
            dial = wx.MessageDialog(None, 'COM port is not connected cdu o/p.....!!',
            'Error!!!', wx.OK|wx.STAY_ON_TOP)
            dial.ShowModal()
            

    def Connect_CDU(self,event): 
        global flag,GNSS_flag,flag_com,COMConfig_Window_flag
        GNSS_flag=0
        flag_com=2
        if(COMConfig_Window_flag==0):
            self.main3 = COMConfig_Window.create(None)
            self.main3.Show()
            COMConfig_Window_flag=1
##            display.Log_Heading()
        else:
            self.main3.SetFocus()
            self.main3.Show()
            
            
    def connnection1(self):
        global flag
        try:
            flag=1
            # 1st position is 4 means com port-4 acts data sends from.
            
            if(COMConfig_Window.instance_comport_receiver.Comport_select==COMConfig_Window.instance_comport_transmitter.Comport_select):
                self.connect_object_CDU_receiver = serial.Serial(int(COMConfig_Window.instance_comport_receiver.Comport_select),baudrate=int(COMConfig_Window.instance_comport_receiver.Baud_Rate),timeout=None,bytesize=8, parity=COMConfig_Window.instance_comport_receiver.Parity, stopbits=COMConfig_Window.instance_comport_receiver.Stop_Bits)
                self.CDU_status.SetBitmap(wx.Bitmap(u'green_light.bmp')) 
            else:
                self.connect_object_CDU_receiver = serial.Serial(int(COMConfig_Window.instance_comport_receiver.Comport_select),baudrate=int(COMConfig_Window.instance_comport_receiver.Baud_Rate),timeout=None,bytesize=8, parity=COMConfig_Window.instance_comport_receiver.Parity, stopbits=COMConfig_Window.instance_comport_receiver.Stop_Bits)
                self.connect_object_CDU_transmitter = serial.Serial(int(COMConfig_Window.instance_comport_transmitter.Comport_select),baudrate=int(COMConfig_Window.instance_comport_transmitter.Baud_Rate),timeout=None,bytesize=8, parity=COMConfig_Window.instance_comport_transmitter.Parity, stopbits=COMConfig_Window.instance_comport_transmitter.Stop_Bits)
                self.CDU_status.SetBitmap(wx.Bitmap(u'green_light.bmp')) 
##            TestThread_Ibit()
        except SerialException:
            win32api.MessageBox(0, 'COM Port is not Available !', 'Error!!!')  
            
    def Send_CDU(self,event):   
        global KEYreadnsend_flag,flag
##        KEYreadnsend_flag=0
        print "self.connect_object_CDU_receiver",self.connect_object_CDU_receiver
        if (self.connect_object_CDU_receiver==''):
            m1 = wx.MessageDialog(self, "NO CONNECTION ESTABLISHED!!! PLEASE CONFIGURE",\
                    " ", style = wx.OK | wx.ICON_INFORMATION|wx.STAY_ON_TOP)
            if m1.ShowModal() == wx.ID_OK:
                m1.Destroy()
        else:
                    
            if(KEYreadnsend_flag==0):
                flag=1     
                self.main6 = KEYreadnsend.create(None)
                self.main6.Show()
                KEYreadnsend_flag=1
##                KEYreadnsend.class_var.ShowModal(False)
            else:
                KEYreadnsend.class_var.OnCancel()
                flag=1     
                self.main6 = KEYreadnsend.create(None)
                self.main6.Show()
                KEYreadnsend_flag=1     
    def xlsvalidate(self):
        val=0
        head=os.getcwd()
        print head
        file="CDUHOTKEY.xls"
        pathnfile=os.path.join(head,"CDUHOTKEY.xls") 
        print pathnfile   
        for subdir,dirs,files in os.walk(head):
            for a in files:
                fullpath=os.path.join(head,a)
                if(fullpath!=pathnfile):
                    val=1
                else:
                    val=0
                    break
            break
        return val 
##        event.Skip()      
    
class TestThread(Thread):       # GNSS 
    def __init__(self):
        Thread.__init__(self)
        self.start()    # start the thread
 
    def run(self):
            global main1,flag_display1,flag_display2,flag_display3,temp_message,flag_connection
            process_flag=0
            i=0
            list=[]
            list1=[] 
            temp_message=GNSS_OutputWindow.message()
            while(1):
##                print "read"
##                print class_var3.connect_object
##                ser.read(ser.inWaiting())
##                list=[]   
                if flag_connection==0:
                    return
                elif class_var3.connect_object_GNSS_receiver.inWaiting() > 0:
##                    print "**************************************************"
##                    print "**************************************************"
##                    print "message"
##                    a=class_var3.connect_object.read(1)
                    if(process_flag==0):
                        list=[]
                        list1=[]
                        if class_var3.connect_object_GNSS_receiver.inWaiting() < 3:
                            flag_process=0
                            rem_data=struct.unpack("%dB"%(class_var3.connect_object_GNSS_receiver.inWaiting()),class_var3.connect_object_GNSS_receiver.read((class_var3.connect_object_GNSS_receiver.inWaiting()) ))
                            print rem_data
                        else:
                            b=struct.unpack(">3B",class_var3.connect_object_GNSS_receiver.read(3))
                            flag_process=1
##                    (b,)=struct.unpack('>B',class_var3.connect_object_GNSS_receiver.read(1))
                            print "b value"
                            print hex(b[0])
                        
                            list.append(hex(b[0]))
                            list.append(hex(b[1]))
                            list.append(hex(b[2]))
##                            print (b[2])
##                    print list
##                    f=(hex(b[0]))
##                    print f
                    if(flag_process==1):
                        if (list[0]=='0x3f'): 
                            print "First byte"    
                            if(list[1]=='0x3f'):
                                print "Second byte"
                                if(list[2]=='0xaf'):
                                    process_flag=0
                                    if class_var3.connect_object_GNSS_receiver.inWaiting() >0:
                                        (e,)=struct.unpack(">B",class_var3.connect_object_GNSS_receiver.read(1))
                                        if(e==0x02):
                                            try:
                                                print "message id 1"
                                                g=struct.unpack(">66B",class_var3.connect_object_GNSS_receiver.read(66))
                                                print g 
                                                list1=[] 
                                                list1=g
                                                print "LIst1.........>",list1
                                                list2=[]
                                                list2[0:4]=['0x3f','0x3f','0xaf','0x02']
                                                for i in range (0,66):
                                                    list2.append(hex(list1[i]))
            ##                                    print list2
                                                ##For converting from hex value to float suffixing with '0'
                                                for i in range (0,(len(list2))):
                                                    if((len(list2[i]))==3):
                                                          temp4=string.split(list2[i],'0x')
                                                          list2[i]='0x'+'0'+temp4[1]
            ##                                              print temp4
            ##                                          print val[i]
                                                print list2
            ##                                    print list1
            ##                                    print hex(list1[0])
            ##                                    self.main1 = GNSS_OutputWindow.create(None,list2)
                                                print "list2........" ,list2
                                                #Function to store the data into Structure                                   
                                                temp_message.process_msg(list2)
                                                if(GNSS_OutputWindow.flag_save==1):
                                                  # Function to validate the input values
                                                    temp_message.display_validate()
                                                  # Function to save the data into xl file
                                                    class_var3.Save_GNSS_fields(list1)
    ##                                            else:
                                            except:
                                                print " GNSS Output (Position,Velocity and Time)data is less than 66 bytes\n"
                                                temp_text=" GNSS Output (Position,Velocity and Time)data is less than 66 bytes\n"
                                                class_var3.textCtrl1.SetValue(temp_text)
                                                
                                        elif(e==0x03):
                                                try:
                                                    print "message id2"
                                                    g=struct.unpack(">13B",class_var3.connect_object_GNSS_receiver.read(13))              
                                                    print g 
                                                    health_list=[]
                                                    health_list1=[]
                                                    health_list =g
                                                    health_list1[0:4]=['0x3f','0x3f','0xaf','0x03']
                                                    for i in range (0,13):
                                                        health_list1.append(hex(health_list[i]))
                ##                                    print list2
                                                    for i in range (0,(len(health_list1))):
                                                        if((len(health_list1[i]))==3):
                                                              temp4=string.split(health_list1[i],'0x')
                                                              health_list1[i]='0x'+'0'+temp4[1]
                ##                                              print temp4
                ##                                          print val[i]
                                                    print health_list1
                ##                                    print list1
                ##                                    print hex(list1[0])
                ##                                    self.main1 = GNSS_OutputWindow.create(None,list2)
                ##                                    print "list2........" ,list2
                                                    flag_display2=1
                                                    temp_message.process_msg1(health_list1)
                                                    temp_message.display_health_validate()
                                                    if(GNSS_OutputWindow.flag_save1==1):
                                                        class_var3.Save_GNSS_health_fields(health_list)
                ##                                    flag_display2=1
                                                except:
                                                    temp_text="Insufficient GNSS Output(Health Message)data\n"
                                                    class_var3.textCtrl1.WriteText(temp_text)
                                            
                                        elif(e==0x04):
                                            try:
                                                print "message id3"
                                                g=struct.unpack(">16B",class_var3.connect_object_GNSS_receiver.read(16))    
                                                print g 
                                                version_list=[]
                                                version_list1=[]
                                                version_list =g
                                                version_list1[0:4]=['0x3f','0x3f','0xaf','0x04']
                                                for i in range (0,16):
                                                    version_list1.append(hex(version_list[i]))
            ##                                    print list2
                                                for i in range (0,(len(version_list1))):
                                                    if((len(version_list1[i]))==3):
                                                          temp4=string.split(version_list1[i],'0x')
                                                          version_list1[i]='0x'+'0'+temp4[1]
     
                                                print "list2........" ,version_list1
                                                temp_message.process_msg2(version_list1)
                                                temp_message.display_version_validate()
                                                if(GNSS_OutputWindow.flag_save2==1):
                                                    print "Message 3"
                                                    class_var3.Save_GNSS_version_fields(version_list)
                                                flag_display3=1
                                            except:
                                                temp_text="Insufficient GNSS Output(Version Message)data\n"
                                                class_var3.textCtrl1.WriteText(temp_text)
                                else:
                                    
                                    process_flag=1
                                    list[0]=list[1]
                                    list[1]=list[2]
##                                    print list[0],list[1]
                                    if class_var3.connect_object_GNSS_receiver.inWaiting() >0:
                                        (c,)=struct.unpack(">B",class_var3.connect_object_GNSS_receiver.read(1))
                                        list[2]=hex(c)
                            else:
                                    process_flag=1
                                    list[0]=list[1]
                                    list[1]=list[2]
##                                    print list[0],list[1]
                                    if class_var3.connect_object_GNSS_receiver.inWaiting() >0:
                                        (c,)=struct.unpack(">B",class_var3.connect_object_GNSS_receiver.read(1))
                                        list[2]=hex(c)
                        else:
                                    process_flag=1
##                                    print "else"
                                    list[0]=list[1]
                                    list[1]=list[2]
##                                    print list[0],list[1]
                                    if class_var3.connect_object_GNSS_receiver.inWaiting() >0:
                                        (c,)=struct.unpack(">B",class_var3.connect_object_GNSS_receiver.read(1))
                                        list[2]=hex(c)
                        
##                GNSS_OutputWindow.class_var.refresh()        
                                    
##        except:
##           print  "Reading RS-232 Exception"

##class TestThread_page(Thread):    #CDU   
##    def __init__(self):
##        Thread.__init__(self)
##        self.start()         # start the thread
##  
##    def run(self):
####        global data_packet,flag_data,data_packet_ibit,ibit_flag
##        print "---------------Thread"
##        data=[]
##        no=1
##        flag_data=0
##        flag_process=1
##        validate_instance=CDU_output.validate()
##        ibit_class_instance=ibit_out.ibit_class()
##        while(1):
##            if flag==0:         # without connection it can't read data
##                return
##            
##            elif class_var3.connect_object_page.inWaiting() > 0:
##                print "data >0 "
##               
##                if class_var3.connect_object_page.inWaiting() < 2:
##                    flag_process=0
##                    rem_data=struct.unpack(">%dB"%(class_var3.connect_object_page.inWaiting()),class_var3.connect_object_page.read((class_var3.connect_object_page.inWaiting()) ))
##                    print "DATA is less than 2 byte"
##                else:
##                    if(flag_process==1):
##                        print "reads 2 byte data"
##                        b=struct.unpack(">2B",class_var3.connect_object_page.read(2))
##                        print b
##                        data.append(b[0])
##                        data.append(b[1])
##         
##                    if(data[0]==0xAC): 
##                        if(data[1]==0xA1): 
##                            g=struct.unpack(">14B",class_var3.connect_object_page.read(14))
##                            print g
##                            flag_process=1  # if it can read 14 byte means full msg than read 2 byte new msg
##                            for i in range (14):
##                                data.append(g[i])
##                            
####                            for i in range(len(data)):
####                                if(data[i]==3):
####                                    data[i]='0x0'+data[i][2:]
##                                    
##                            Checksum=self.Calculate_Checksum(data,len(data)-2)
##                            print " checksum",Checksum
##                            print "last",data
##                            if( Checksum == data[len(data)-1] ):
##                                flag_data=1
##                                data_packet=data
##                                data=[]
##                                print "in thread A1----->data_packet",data_packet
##                                validate_instance.initialisation(data_packet)
##                                print "check sum is correct.................",no
##                                display.Write_xls(no)
##                                no=no+1
##                            else:
##                                flag_data=0
##                                Timestamp=self.Time_stamp()
##                                temp_text=" CDU output Message received at  "+ str(Timestamp)+"  instance is invalid " +"\n"
##                                class_var3.textCtrl1.WriteText(temp_text)                               
##
##                        elif(data[1]==0xA2):   #Acknowlegement message from CDU
##                            flag_process=1
##                            g=struct.unpack(">2B",class_var3.connect_object_page.read(2))
##                            data.append(g[0])    # acceptance bit
##                            data.append(g[1])    # checksum bit
##                            
##                            print "data at A2 ibit----->",data
##                            
##                            Checksum=self.Calculate_Checksum(data,len(data)-1)
##                            print "checksum-------->",Checksum
##                            print "last bit-------->",data[3]
##                            if( Checksum == data[len(data)-1] ):
##                                ibit_flag=1
####                                if(data[2]==0):
####                                    display.Ibit_msg()
##                                data=[]
####                                else:
####                                    break
##                        elif(data[1]==0xA3):
##                            flag_process=1
##                            g=struct.unpack(">2B",class_var3.connect_object_page.read(2))
##                            data.append(g[0]) 
##                            data.append(g[1])
##                            print "data at A3 ibit----->",data
##                            
##                            Checksum=self.Calculate_Checksum(data,len(data)-1)
##                            print "checksum-------->",Checksum
##                            print "last bit-------->",data[3]
##                            if( Checksum == data[len(data)-1] ):
####                                Ibit_output.ibit_data=data
##                                data_packet_ibit=data
##                                ibit_class_instance.Setgrid_values(data_packet_ibit)
####                                self.ibit = ibit_out.create(None)
####                                self.ibit.Show()
####                                data=[]
##                        else:
##                            flag_process=0
##                            data[0]=data[1]
##                            (value,)=struct.unpack(">B",class_var3.connect_object_page.read(1))
##                            data[1]=(value)
##                    else:
##                        flag_process=0
##                        data[0]=data[1]
##                        (value,)=struct.unpack(">B",class_var3.connect_object_page.read(1))
##                        data[1]=(value)
##            else:  
##               flag_process=1
                    
    def Calculate_Checksum(self,data,bytecount):
        checksum=0
        for i in range(0,bytecount):
           var1=data[i]
           checksum = checksum ^ (var1)
        checksum = checksum & 0xFF
        return checksum  
    
    
    def Time_stamp(self):
        # To get the local time of system
        self.now=time.localtime(time.time())
        print "self.now", self.now
        year, month, day, hour, minute, second, weekday, yearday, daylight =self.now
        self.a=str(hour)
        self.b=str(minute)
        self.c=str(second)
        if len(self.a)==1:
            self.a='0'+self.a
        if len(self.b)==1:
            self.b='0'+self.b
        if len( self.c)==1:
            self.c='0'+self.c
        self.Timestamp=self.a+":"+self.b+":"+self.c
        print "Timestamp", self.Timestamp
        return self.Timestamp

    
            
        
          
     