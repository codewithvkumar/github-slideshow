#Boa:Frame:Frame1

import wx
import struct
import win32api
import time
import CDU_TestRig_MainWindow
import os
import pdb
import request_packet
import xlwt
import xlrd
import Progress_download
from xlutils.copy import copy
import com_connection
class Errorlog():
   
    def Errorlog_data(self):
        global open_frame,flag_resend
        global pathnfile
           
##        print self.upgrade,self.header
        no_try_packet_correct1=0
        no_try_packet_correct=0
        Try_req_send=0 
        ack_count=0
        no_try=0
        j=0
        flag_resend=0
        flag_response_true=0
        flag_packet_ack=0
        percent=0
        percent1=0
        self.packet=request_packet.Error_Log_Packet()

        while(True):
            if Try_req_send==3:
                Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
                CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("No Acknowledgement received " +str(Timestamp) +"\n")
                
                break
            elif flag_resend==1:
##                print "heellllllllll"
                break
            else:
                self.Req_data_transfer(self.packet)

##                Timestamp=self.Time_stamp()
                Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
                CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Request for Error Log sent"+str(Timestamp) +"\n")
                self.req_response_cdu=self.Response_data_transfer()
                Try_req_send=Try_req_send+1
##                if self.req_response_cdu!=0:
##                    self.prog_dwnload=Progress_download.Create(None) 
##                    self.prog_dwnload.Show()
        if flag_resend==1: 
            print "heellllllllll"       
            while(True):
    ##            self.req_response_cdu3=[]
                if no_try==3:
                   Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
                   CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("No Acknowledgement Received  "+str(Timestamp) +"\n")
                   break
                elif flag_resend==0:
                    self.req_response_cdu=self.Response_data_transfer()
                else:
                     flag_resend==0   
                self.req_response_cdu3=list(self.req_response_cdu)
                if self.req_response_cdu[3]==0 :
                    Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Acknowledgement Received with incorrect checksum status "+str(Timestamp) +"\n")
                    
                    self.Req_data_transfer(self.packet)
                    no_try=no_try+1

                elif self.req_response_cdu[3]==2: 
                     self.Req_data_transfer(self.packet)
                     no_try=no_try+1
                elif self.req_response_cdu[3]==1:
                     flag_response_true=1
                     break
                if self.req_response_cdu==0:
                    break
                if flag_response_true==0: 
                     break       
        if flag_response_true==1: 
                 self.ret_ack=0
                 while (True):
##                     pdb.Settrace()
                     if no_try_packet_correct==3:
                         break   
                     self.ret_ack=self.Ack_Response_data_transfer(self.req_response_cdu)
                     if self.ret_ack==1:
                         self.response_cdu1=[]
                         self.response_cdu2=[172,195]
                         i=1
                         no_try_packet_correct=0
                         ack_count=4
                         flag_packet_ack=1
                         break
                     else:
                         
                         self.req_response_cdu=self.Response_data_transfer()
                         
                         print "Control heeeeeeeeeeeeeeeerrrrrrrrreeeeeeee",ack_count
                         ack_count=ack_count+1
                         no_try_packet_correct=no_try_packet_correct+1
##                         if ack_count==4:
                     if self.req_response_cdu==0:
                             break
        
        if flag_packet_ack==1: 
             no_try_packet_correct=1  
             count=0            
             while(True):
                 if i<self.req_response_cdu3[0] and no_try_packet_correct<=2:
                     
                     print "lok heeeere------------>",i,self.req_response_cdu3[0],no_try_packet_correct
##                     time.sleep(2)
                     self.response_cdu1=self.Response_data_transfer()
                     if self.response_cdu1!=0:
                         self.response_cdu2=[172,195]
                         self.response_cdu3=list(self.response_cdu1)
                         
                         for k in range(len(self.response_cdu1)):
                            self.response_cdu2.append(self.response_cdu3[k])
                         status_to_improve=(100/self.req_response_cdu[0])
                         
                         byte_count=len(self.response_cdu2)-1
                         self.cal_crc=self.Calculate_Checksum1(self.response_cdu2,byte_count)
                         print "kkkkk------------->",self.req_response_cdu[0]
                         print self.response_cdu2[len(self.response_cdu2)-1],self.cal_crc,self.response_cdu2
                         
                         if self.response_cdu2[len(self.response_cdu2)-1]== self.cal_crc:
                            checksum_stat=0x1
##                            pathnfile=os.getcwd()+'\Errorlog.xls'
##                            wtbook = xlwt.Workbook()
##                            wtsheet = wtbook.add_sheet(u'First')
##                            wtbook.save(pathnfile)
                            rb = xlrd.open_workbook(pathnfile, formatting_info=True)

                            w=copy(rb)
                            sheet=rb.sheet_by_index(0)
                            rows, cols = sheet.nrows, sheet.ncols
                            for i in range(rows,rows+1):
                                for k in range(len(self.response_cdu2)):
                                      w.get_sheet(0).write(rows,k,hex(self.response_cdu2[k]))
                            w.save(pathnfile)
##                            file_object=open(os.getcwd()+'\Errorlog_old.xls','a')
##                            file_object.write(str(self.response_cdu2))
                            i=i+1
                            j=j+1
                            percent=percent+status_to_improve
                            percent1=str(percent)
                            Progress_download.instance_dwnld.sta_dwld_percent.SetLabel(percent1)
                            Progress_download.instance_dwnld.guage_progressbar.SetValue(percent)
##                            if percent1==str(100):
##                               self.prog_dwnload.show() 
##                               time.sleep(5)
##                               self.prog_dwnload.Destroy()  
##                            count=count+status_to_improve
##                            self.gauge1.SetValue(count)
##                            Timestamp=self.Time_stamp()
                            Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
                            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Packet Received"+str(Timestamp) +"\n")

##                            status_to_improve=0
                            print "i m where----------->"
                         else:
                            checksum_stat=0x0
                            no_try_packet_correct=no_try_packet_correct+1 
        ##                        self.req_response_cdu3[0]=0
##                            Timestamp=self.Time_stamp()
                            Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()

                            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Incorrect Packet Received"+str(Timestamp) +"\n")
                            print "i m here----------------->",self.req_response_cdu3[0]
                            
                         packet_ack=struct.pack('<BBBBB',0xac,0xc3,self.response_cdu1[0],self.response_cdu1[1],checksum_stat)
        ##                     print "self.response_cdu",self.response_cdu
                         checksum_cal=self.Calculate_Checksum(packet_ack,5) 
                         Checksumcal_pack=struct.pack('<B',checksum_cal)
                         packet_ack=packet_ack+Checksumcal_pack
                         self.Req_data_transfer(packet_ack) 
                 else:
                    
                    break
                 if self.response_cdu1==0:
                    break                      

	

    def Req_data_transfer(self,Final_packet):    
        if( CDU_TestRig_MainWindow.class_var3.maintenance_object_receiver!='' or CDU_TestRig_MainWindow.class_var3.maintenance_object_transmitter!=''): 
            CDU_TestRig_MainWindow.class_var3.maintenance_object_receiver.write(Final_packet)
        else:
            CDU_TestRig_MainWindow.class_var3.maintenance_object_transmitter.write(Final_packet)
##        CDU_TestRig_MainWindow.class_var3.Com_maintenance.connect_object.write(Final_packet)
        
    def Ack_Response_data_transfer(self,response_cdu):
        
        self.response_cdu1=[172,194]
##        self.response_cdu1=list(response_cdu)
        for k in range(len(response_cdu)):
            self.response_cdu1.append(response_cdu[k])
        self.acceptance_code=0
        self.Ack_packet=[0xAC,0xC2,self.acceptance_code]
        print "response_cdu",response_cdu
        self.val_temp=self.response_cdu1[6]
        print "self.respense_cdu1",self.response_cdu1[4]
        byte_count=len(self.response_cdu1)-1
        Checksumcal=self.Calculate_Checksum1(self.response_cdu1,byte_count)
        if Checksumcal==self.val_temp:
            self.acceptance_code=0x1
            
            print "yes        ----------------->"
        else:
            self.acceptance_code=0x0
            print "No --------------------->" ,Checksumcal,self.val_temp
            
        Checksumret=self.Calculate_Checksum1(self.Ack_packet,3)
        data_pack=struct.pack('<BBB',0xAC,0xC2,self.acceptance_code)
        
        Checksumcal_pack=struct.pack('<B',Checksumret)
        Final_packet=data_pack+Checksumcal_pack 
        self.Req_data_transfer(Final_packet)
##        CDU_TestRig_MainWindow.class_var3.Com_maintenance.connect_object.write(Final_packet)
##        Timestamp=self.Time_stamp()
        Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
        CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Acknowledgement for Packet Info Command sent"+str(Timestamp) +"\n")

        if Checksumcal==self.val_temp:
            return 1   
        else:
            return 0     
    
    def Calculate_Checksum1(self,data,byte_count):
        checksum=0
        for i in range(0,byte_count):
            checksum=checksum^data[i]
        checksum=checksum & 0xFF
        return checksum     
    def Calculate_Checksum(self,data,byte_count):
        checksum=0
##        print "pkt,byte_count------>",pkt
##        packet=[0xAC,0xC1,0x0,0x0] 
##        data=struct.pack('<BBBB',0xAC,0xC1,0,0)
        data1=struct.unpack_from('<%dB'%byte_count,data)
        for i in range(0,byte_count):
            checksum=checksum^data1[i]
        checksum=checksum & 0xFF
        return checksum  
    
       
    def Response_data_transfer(self):
        global flag_resend
        ret_value = 0
        self.byte_count=0
        self.read_char1=[]
        self.read_char=[]
        self.read_char2=[]
##        self.data_recvd=[]
        timeout = 20
        flag_timeout=0
        start = time.time()
        flag=0 
        end = start + timeout
        while time.time() < end:
##        time.sleep(1)
##            print "hellooooooooooooo"
            if CDU_TestRig_MainWindow.class_var3.maintenance_object_receiver.inWaiting() > 0:
                flag=1
                
##                print "hellooooooooooooo"
                self.read_char = struct.unpack('>BB',CDU_TestRig_MainWindow.class_var3.maintenance_object_receiver.read(2))
                print "read_char",self.read_char
                if self.read_char[0] == 0xAC :
                    if self.read_char[1] == 0xC2:
                        flag_resend=1
                        print "vvvvvvvvvvvvvvvvvvv"
                        self.read_char1 = struct.unpack('>HHIBB',CDU_TestRig_MainWindow.class_var3.maintenance_object_receiver.read(10))
    ##                    data1=struct.unpack('>BHHIBB',self.read_char1)
                        self.data_recvd=self.read_char1
                        print "Data received---->",self.read_char1
                        flag_timeout=1
##                        Timestamp=self.Time_stamp()
                        Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
                        CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Response for Data transfer received"+str(Timestamp) +"\n")

                        return self.read_char1
                          
                    elif self.read_char[1] == 0xC3:
                         print "self.data_recvd at first", self.data_recvd
                         
                         data=CDU_TestRig_MainWindow.class_var3.maintenance_object_receiver.read(self.data_recvd[1]+3)
 
##                         data=MainFrame_CDU.my_instance.Com_maintenance.connect_object.read(MainFrame_CDU.my_instance.Com_maintenance.connect_object.inWaiting())
                         size=len(data)
                         self.read_char2 = struct.unpack('>%dB'%size,data)
                         print "self.read_char2",self.read_char2
                         flag_timeout=1
                         return self.read_char2          
                            
                break
        if flag_timeout==0:
            return 0   
##    def Packet_data_receive(self):
##        global flag_resend
##        ret_value = 0
##        self.byte_count=0
##        self.read_char1=[]
##        self.read_char=[]
##        self.read_char2=[]
##        timeout = 60
##        start = time.time()
##        flag=0 
##        end = start + timeout
##        while time.time() < end:
####        time.sleep(1)
####            print "hellooooooooooooo"
##            if MainFrame_CDU.my_instance.Com_maintenance.connect_object.inWaiting() > 0:
##                flag=1
##                
####                print "hellooooooooooooo"
##                self.read_char = struct.unpack('>BB',MainFrame_CDU.my_instance.Com_maintenance.connect_object.read(2))
##                print "read_char",self.read_char
##                if self.read_char[0] == 0xAC :
##                    if self.read_char[1] == 0xC3:
##                         print "self.read_char2", self.data_recvd  
##                         data=MainFrame_CDU.my_instance.Com_maintenance.connect_object.read(self.data_recvd[1]+3)
####                         data=MainFrame_CDU.my_instance.Com_maintenance.connect_object.read(MainFrame_CDU.my_instance.Com_maintenance.connect_object.inWaiting())
##                         size=len(data)
##                         self.read_char2 = struct.unpack('>%dB'%size,data)
##                         print "self.read_char2",self.read_char2
##                         
##                         return self.read_char2          
##                            
##                break 
##                  
##        if flag_timeout==0:
##            return 0  
##   
##    def Time_stamp(self):
##        # To get the local time of system
##        self.now=time.localtime(time.time())
##        print "self.now", self.now
##        year, month, day, hour, minute, second, weekday, yearday, daylight =self.now
##        self.a=str(hour)
##        self.b=str(minute)
##        self.c=str(second)
##        if len(self.a)==1:
##            self.a='0'+self.a
##        if len(self.b)==1:
##            self.b='0'+self.b
##        if len( self.c)==1:
##            self.c='0'+self.c
##        self.Timestamp=self.a+":"+self.b+":"+self.c
##        print "Timestamp", self.Timestamp
##        return self.Timestamp                
    
    def dialog_browse(self):
        global pathnfile
        dialog = wx.DirDialog(None, "Choose a directory:", style=wx.DD_DEFAULT_STYLE | wx.DD_NEW_DIR_BUTTON) 
        if dialog.ShowModal() == wx.ID_OK: 
            self.folder_name= dialog.GetPath()
            pathnfile=self.folder_name+'\Errorlog.xls'
            wtbook = xlwt.Workbook()
            wtsheet = wtbook.add_sheet(u'First')
            wtbook.save(pathnfile) 
            CDU_TestRig_MainWindow.class_var3.maintenece_flag=1
            self.prog_dwnload=Progress_download.create(None) 
            self.prog_dwnload.Show()
        dialog.Hide()     