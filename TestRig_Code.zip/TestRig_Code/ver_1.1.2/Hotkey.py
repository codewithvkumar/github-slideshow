#Boa:Frame:Hotkey_config

import wx
import page_creation
import home_creation
import Update_page
import Update_home
import KEYreadnsend
import CDU_TestRig_MainWindow
import xlwt
import xlrd
import os
from xlutils.copy import copy
import page_creation as page_creation222
##import TEStmodule
global configkey,var
##global check
configkey=[]
hot_list=[]
##global list_home1
global list1
list1=[]
global pagevar
pagevar=1
var=0
##var_status=0
open_status=0
def create(parent):
    return Hotkey_config(parent)

[wxID_FRAME1, wxID_FRAME1BUTTON1, wxID_FRAME1BUTTON2, wxID_FRAME1COMBOBOX1, 
 wxID_FRAME1COMBOBOX2, wxID_FRAME1COMBOBOX3, wxID_FRAME1COMBOBOX4,wxID_FRAME1COMBOBOX8, 
 wxID_FRAME1COMBOBOX5, wxID_FRAME1COMBOBOX6, wxID_FRAME1COMBOBOX7,wxID_FRAME1PANEL1, 
 wxID_FRAME1STATICTEXT1, wxID_FRAME1STATICTEXT2, wxID_FRAME1STATICTEXT3,wxID_FRAME1STATICTEXT9, 
 wxID_FRAME1STATICTEXT4, wxID_FRAME1STATICTEXT5, wxID_FRAME1STATICTEXT6, 
 wxID_FRAME1STATICTEXT7, wxID_FRAME1STATICTEXT8, wxID_FRAME1TEXTCTRL1, 
] = [wx.NewId() for _init_ctrls in range(22)]

class Hotkey_config(wx.Frame):
    def _init_ctrls(self, prnt):
        # generated method, don't edit
        
        self.hotlist=[]
        self.list_created=[]
        self.var_status=0
        global x
        global configkey
        global open_status
        open_status=1
        x=2
        listondisplay=['Nopage','Nopage','Nopage','Nopage','Nopage','Nopage','Nopage']
##        var_status=0
        print 'page_txt44444',page_creation.page_txt
        if (page_creation.new_confirm==1):
            if (CDU_TestRig_MainWindow.update_select==1):
                self.var_status=1
                var2=self.Create_list()
                print "var222222",var2,CDU_TestRig_MainWindow.filename_xls
                var3=os.path.split(CDU_TestRig_MainWindow.filename_xls)
                
                if var3[1] not in var2:
                   listondisplay=listondisplay
                else:
                    var4=var2.index(var3[1])
                    var5=key_home_detl[var4]
                    listondisplay=var5[1:8]
                Update_page.my_instance1.create_list(x)
                var=Update_page.page_txt[len(Update_page.page_txt)-1]
                var1=var.split('Home')
##                self.hotlist=Update_page.page_txt
                if str(Update_home.uphome_no)==var1[1]: 
                    self.hotlist=Update_page.page_txt
##                 self.hotlist=self.update_list()
##                 self.hotlist=['Home','Home','Home']
                    print "yahoooooo"
                else:
                    var2=var1[1].split('-') 
                    var3=int(var2[0])
                    var4=Update_home.uphome_no
                    print var3,var4
                    self.hotlist=Update_page.page_txt
                    for i in range(var3,var4):
                        self.hotlist.append('Home'+str(i+1))
                        print "noooo",self.hotlist
                configkey=self.hotlist        
            else:    
                page_creation.my_instance.create_hotlist()
                   
    ##            print 'page_txt44444',page_creation.page_txt
    ##            self.hotlist=page_creation.page_txt 
    ##            configkey=self.hotlist
    ##            page_creation.page_txt.append('Home1')   
                var=page_creation.page_txt1[len(page_creation.page_txt1)-1]
                var1=var.split('Home')
                print 'yas',var1,var,str(home_creation.home_no)
                if str(home_creation.home_no)==var1[1]: 
                    self.hotlist=page_creation.page_txt1
                    print 'yepppppppeeeee'
                else:
                    var2=var1[1].split('-') 
                    var3=int(var2[0])
                    var4=home_creation.home_no
                    print var3,var4
                    self.hotlist=page_creation.page_txt1
                    for i in range(var3,var4):
                        self.hotlist.append('Home'+str(i+1))
                        print "noooo",self.hotlist
    ##                 
                configkey=self.hotlist
##            page_creation.new_confirm=0
        if (page_creation.new_confirm==0):
            if  (CDU_TestRig_MainWindow.page_var==0):
                page_creation.my_instance.create_hotlist()
                self.hotlist=page_creation.page_txt1 
                print "hello888888"
##            else:
##                self.var_status=1
##                self.list_created=self.Create_list()
##                print "hello999999999"

                   
        if(home_creation.home_flag==1):
            print "hello444444"
            for i in range(home_creation.home_no):
                var1='Home'+str(i+1)
                if var1 in self.hotlist:
                   self.hotlist=self.hotlist
                else:    
                    self.hotlist.append(var1)
            configkey=self.hotlist
        if(CDU_TestRig_MainWindow.page_var==1):
            print "hello666666666"
            self.var_status=1         
            self.list_created=self.Create_list()
        if (page_creation.new_confirm==2):
            self.hotlist=self.update_list()
            print "hello997777777777777555555555555" 
        wx.Frame.__init__(self, id=wxID_FRAME1, name='', parent=prnt,
              pos=wx.Point(497, 114), size=wx.Size(340, 449),
              style=wx.DEFAULT_FRAME_STYLE, title='Configure Hotkeys')
        self.SetClientSize(wx.Size(300, 485))
        self.Bind(wx.EVT_CLOSE, self.btn_onclose)
        self.panel1 = wx.Panel(id=wxID_FRAME1PANEL1, name='panel1', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(343, 415),
              style=wx.TAB_TRAVERSAL)

        self.sta_label_hotkey = wx.StaticText(id=wxID_FRAME1STATICTEXT1,
              label='Please select the XLS for the Hotkey', name='sta_label_hotkey',
              parent=self.panel1, pos=wx.Point(24, 16), size=wx.Size(174, 13),
              style=0)

        self.btn_confirm = wx.Button(id=wxID_FRAME1BUTTON2, label='CONFIRM',
              name='btn_confirm', parent=self.panel1, pos=wx.Point(96, 395),
              size=wx.Size(75, 23), style=0)
        self.btn_confirm.Bind(wx.EVT_BUTTON, self.btn_onconfirm,
              id=wxID_FRAME1BUTTON2)       
        self.cbx_selectxls = wx.ComboBox(choices=self.list_created,
                id=wxID_FRAME1COMBOBOX7, name='cbx_selectxls', parent=self.panel1,
                pos=wx.Point(24, 40), size=wx.Size(100, 21), value='Select XLS',style=0)
                
        self.cbx_selectxls.Bind(wx.EVT_COMBOBOX, self.Oncomboselect)
        self.cbx_selectxls.SetEditable(False)
        self.cbx_sys = wx.ComboBox(choices=self.hotlist,
              id=wxID_FRAME1COMBOBOX1, name='cbx_sys', parent=self.panel1,
              pos=wx.Point(80, 120), size=wx.Size(130, 21), value=listondisplay[0], style=0)
        self.cbx_sys.SetEditable(False) 
        self.cbx_dat = wx.ComboBox(choices=self.hotlist,
              id=wxID_FRAME1COMBOBOX2, name='cbx_dat', parent=self.panel1,
              pos=wx.Point(80, 160), size=wx.Size(130, 21),value=listondisplay[1], style=0)
              
        self.cbx_dat.SetEditable(False)
        self.cbx_nav = wx.ComboBox(choices=self.hotlist,
              id=wxID_FRAME1COMBOBOX3, name='cbx_nav', parent=self.panel1,
              pos=wx.Point(80, 200), size=wx.Size(130, 21),value=listondisplay[2] ,style=0)

        self.cbx_nav.SetEditable(False)
        self.cbx_mnt = wx.ComboBox(choices=self.hotlist,
              id=wxID_FRAME1COMBOBOX4, name='cbx_mnt', parent=self.panel1,
              pos=wx.Point(80, 240), size=wx.Size(130, 21),value=listondisplay[3], style=0)
              
        self.cbx_mnt.SetEditable(False)
        self.cbx_per = wx.ComboBox(choices=self.hotlist ,
              id=wxID_FRAME1COMBOBOX5, name='cbx_per', parent=self.panel1,
              pos=wx.Point(80, 280), size=wx.Size(130, 21), value=listondisplay[4],style=0)
 
        self.cbx_per.SetEditable(False)
        self.cbx_wpn = wx.ComboBox(choices=self.hotlist,
              id=wxID_FRAME1COMBOBOX6, name='cbx_wpn', parent=self.panel1,
              pos=wx.Point(80, 320), size=wx.Size(130, 21), value=listondisplay[5],style=0)
        self.cbx_wpn.SetEditable(False)
        self.cbx_set = wx.ComboBox(choices=self.hotlist ,
              id=wxID_FRAME1COMBOBOX8, name='cbx_set', parent=self.panel1,
              pos=wx.Point(80, 360), size=wx.Size(130, 21), value=listondisplay[6],style=0)
        self.cbx_set.SetEditable(False)   
        self.sta_txt_sys = wx.StaticText(id=wxID_FRAME1STATICTEXT2, label='SYS',
              name='sta_txt_sys', parent=self.panel1, pos=wx.Point(24, 120),
              size=wx.Size(21, 13), style=0)
        self.sta_txt_sys.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD, False,
              'Tahoma'))

        self.sta_txt_dat = wx.StaticText(id=wxID_FRAME1STATICTEXT3, label='DAT',
              name='sta_txt_dat', parent=self.panel1, pos=wx.Point(24, 160),
              size=wx.Size(22, 13), style=0)
        self.sta_txt_dat.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD, False,
              'Tahoma'))

        self.sta_txt_nav = wx.StaticText(id=wxID_FRAME1STATICTEXT4, label='NAV',
              name='sta_txt_nav', parent=self.panel1, pos=wx.Point(24, 200),
              size=wx.Size(23, 13), style=0)
        self.sta_txt_nav.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD, False,
              'Tahoma'))

        self.sta_txt_mnt = wx.StaticText(id=wxID_FRAME1STATICTEXT5, label='MNT',
              name='sta_txt_mnt', parent=self.panel1, pos=wx.Point(24, 240),
              size=wx.Size(24, 13), style=0)
        self.sta_txt_mnt.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD, False,
              'Tahoma'))

        self.sta_txt_per = wx.StaticText(id=wxID_FRAME1STATICTEXT6, label='PER',
              name='sta_txt_per', parent=self.panel1, pos=wx.Point(24, 280),
              size=wx.Size(26, 13), style=0)
        self.sta_txt_per.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD, False,
              'Tahoma'))

        self.sta_txt_wpn = wx.StaticText(id=wxID_FRAME1STATICTEXT7, label='WPN',
              name='sta_txt_wpn', parent=self.panel1, pos=wx.Point(24, 320),
              size=wx.Size(20, 13), style=0)
        self.sta_txt_wpn.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD, False,
              'Tahoma'))
        self.sta_txt_set = wx.StaticText(id=wxID_FRAME1STATICTEXT9, label='SET',
              name='sta_txt_set', parent=self.panel1, pos=wx.Point(24, 360),
              size=wx.Size(20, 13), style=0)
        self.sta_txt_set.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD, False,
              'Tahoma'))
        self.sta_txt_config_hotkey = wx.StaticText(id=wxID_FRAME1STATICTEXT8,
              label='CONFIGURE HOTKEYS', name='sta_txt_config_hotkey', parent=self.panel1,
              pos=wx.Point(24, 80), size=wx.Size(109, 13), style=0)
        self.sta_txt_config_hotkey.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD, False,
              'Tahoma'))

        if (page_creation.new_confirm==1):
            self.cbx_selectxls.Disable()
            self.hotlist=[]
            print "zeroooo"
##            page_creation.new_confirm=0
            page_creation.list_page=[]
        if(home_creation.home_flag==1):
            self.cbx_selectxls.Disable()
            self.hotlist=[]
            print "zer22222"   
##            home_creation.home_flag=0
        if (page_creation.new_confirm==0):
            if (CDU_TestRig_MainWindow.page_var==0):
                self.cbx_selectxls.Disable()
                self.hotlist=[]
                print "zer33333"
        if (CDU_TestRig_MainWindow.update_select==1):
            if (page_creation.new_confirm==0):
                self.cbx_selectxls.Disable()
                self.hotlist=[]
        self.MakeModal(True)         
        print "zer44444444"
    def __init__(self, parent):
        self._init_ctrls(parent)
        
    def Oncomboselect(self,event):
        val=self.Create_list()
        for i in range(val.count('')):
            val.remove('')
        val1=self.cbx_selectxls.GetValue()
        val3=list1.index(val1)
        val4=key_home_detl[val3]
        for i in range(val4.count('')):
            val4.remove('')
        self.hotlist=val4
        self.hotlist.append('Nopage')
        self.cbx_sys.Destroy()
        self.cbx_sys = wx.ComboBox(choices=val4[8:],
              id=wxID_FRAME1COMBOBOX1, name='cbx_sys', parent=self.panel1,
              pos=wx.Point(80, 120), size=wx.Size(130, 21), style=0,
              value=val4[1])
        self.cbx_sys.SetEditable(False)              
        self.cbx_dat.Destroy()
        self.cbx_dat = wx.ComboBox(choices=val4[8:],
              id=wxID_FRAME1COMBOBOX2, name='cbx_dat', parent=self.panel1,
              pos=wx.Point(80, 160), size=wx.Size(130, 21), style=0,
              value=val4[2]) 
        self.cbx_dat.SetEditable(False)           
        self.cbx_nav.Destroy()
        self.cbx_nav = wx.ComboBox(choices=val4[8:],
              id=wxID_FRAME1COMBOBOX3, name='cbx_nav', parent=self.panel1,
              pos=wx.Point(80, 200), size=wx.Size(130, 21), style=0,
              value=val4[3])
        self.cbx_nav.SetEditable(False)      
        self.cbx_mnt.Destroy()
        self.cbx_mnt = wx.ComboBox(choices=val4[8:],
              id=wxID_FRAME1COMBOBOX4, name='cbx_mnt', parent=self.panel1,
              pos=wx.Point(80, 240), size=wx.Size(130, 21), style=0,
              value=val4[4])
        self.cbx_mnt.SetEditable(False)      
        self.cbx_per.Destroy()
        self.cbx_per = wx.ComboBox(choices=val4[8:],
              id=wxID_FRAME1COMBOBOX5, name='cbx_per', parent=self.panel1,
              pos=wx.Point(80, 280), size=wx.Size(130, 21), style=0,
              value=val4[5])
        self.cbx_per.SetEditable(False)      
        self.cbx_wpn.Destroy()
        self.cbx_wpn = wx.ComboBox(choices=val4[8:],
              id=wxID_FRAME1COMBOBOX6, name='cbx_wpn', parent=self.panel1,
              pos=wx.Point(80, 320), size=wx.Size(130, 21), style=0,
              value=val4[6])
        self.cbx_wpn.SetEditable(False)      
        self.cbx_set.Destroy()
        self.cbx_set = wx.ComboBox(choices=val4[8:],
              id=wxID_FRAME1COMBOBOX6, name='cbx_set', parent=self.panel1,
              pos=wx.Point(80, 360), size=wx.Size(130, 21), style=0,
              value=val4[7])
        self.cbx_set.SetEditable(False)            
        print key_home_detl[val3]
        print 'val1',val1
        event.Skip()
    def btn_onconfirm(self,event):
        global hot_list
##        f=open('D:\CDU-Test_Rig\CDUINtegrated\CDUINtegrated.xls','a')
##        f.write('CDUINtegrated.xls\t')
##        self.wtbook = xlwt.Workbook()           # xls file to write into it 
##        self.wtbook.save('filename_xls')
##        final_file=xlrd.open_workbook(filename_xls, formatting_info=1)
        hot_list=[]
##        val_select_xls=self.cbx_selectxls.GetValue()
##        if (val_select_xls=='Select XLS'):
##           dial = wx.MessageDialog(None, "NO PAGE SELECTED",\
##                        'Error !!!', wx.OK|wx.STAY_ON_TOP)
##           dial.ShowModal()
        var=self.cbx_sys.GetValue()
        if (var=='' or var=='page select'):
           dial = wx.MessageDialog(None, "Please Configure the SYS key",\
                        'Error !!!', wx.OK|wx.STAY_ON_TOP)
           dial.ShowModal()
        else:    
            hot_list.append(var)
##            f.write(str(var))
##            f.write('\t')
        var1=self.cbx_dat.GetValue()
        if (var1=='' or var1=='page select'):
           dial = wx.MessageDialog(None, "Please Configure the DAT key",\
                        'Error !!!', wx.OK|wx.STAY_ON_TOP)
           dial.ShowModal()
        else:    
            hot_list.append(var1)
##            f.write(str(var1))
##            f.write('\t')
        var2=self.cbx_nav.GetValue() 
        if (var2=='' or var2=='page select'):
           dial = wx.MessageDialog(None, "Please Configure the NAV key",\
                        'Error !!!', wx.OK|wx.STAY_ON_TOP)
           dial.ShowModal()
        else:    
            hot_list.append(var2)
##            f.write(str(var2))
##            f.write('\t')
        var3=self.cbx_mnt.GetValue()
        if (var3=='' or var3=='page select'):
           dial = wx.MessageDialog(None, "Please Configure the WPN key",\
                        'Error !!!', wx.OK|wx.STAY_ON_TOP)
           dial.ShowModal()
        else:    
            hot_list.append(var3)
##            f.write(str(var3))
##            f.write('\t')
        var4=self.cbx_per.GetValue()
        if (var4=='' or var4=='page select'):
           dial = wx.MessageDialog(None, "Please Configure the SYS key",\
                        'Error !!!', wx.OK|wx.STAY_ON_TOP)
           dial.ShowModal()
        else:    
            hot_list.append(var4)

        var5=self.cbx_wpn.GetValue()
        if (var5=='' or var5=='page select'):
           dial = wx.MessageDialog(None, "wrong page or no input",\
                        'Error !!!', wx.OK|wx.STAY_ON_TOP)
           dial.ShowModal()
        else:    
            hot_list.append(var5)
            
        var6=self.cbx_set.GetValue()
        if (var6=='' or var6=='page select'):
           dial = wx.MessageDialog(None, "wrong page or no input",\
                        'Error !!!', wx.OK|wx.STAY_ON_TOP)
           dial.ShowModal()
        else:    
            hot_list.append(var6)            
##        if (CDU_TestRig_MainWindow.page_var==1): 
        self.var_status=0   
        self.Create_list()
##        if KEYreadnsend.class_var.check_pageselected==1:
##            KEYreadnsend.class_var.list4=hot_list
##            KEYreadnsend.class_var.list_homeval=KEYreadnsend.class_var.homeconvert()
##            CDU_TestRig_MainWindow.flag=1
##            KEYreadnsend.TestThread()
##            print "hot_list",hot_list
        self.MakeModal(False)
        self.Destroy()
            
##        event.Skip()
    
    def Create_list(self):
        global list1
        global key_home_detl
 
        
        head=os.getcwd()
        pathnfile=os.path.join(head,"CDUHOTKEY.xls") 
        if os.path.isfile(pathnfile)==False:
            print 'True'
            list1=[]
        else:       
            rb = xlrd.open_workbook(pathnfile, formatting_info=True)
            
    ##        print "head" ,head[1],Hotkey.hot_list
            w=copy(rb)
            sheet=rb.sheet_by_index(0)
            rows, cols = sheet.nrows, sheet.ncols
            if (self.var_status==1):
                list1=[]
                key_home_detl=[]
                for i in range(rows):
                    read_row=sheet.row_values(i)
                    key_home_detl.append(read_row) 
                    list1.append(read_row[0])
            elif(self.var_status==0):            
                var1=self.cbx_selectxls.GetValue()
                if var1 in list1:
                    var=list1.index(var1)
                    print var,list1

                    print "hhhhhhhhhhhhhhhhh"
                    for index1 in range(1,8):
                        w.get_sheet(0).write(var,index1,hot_list[index1-1])
        ##            for index2 in range(8,len(configkey)+8):
        ##                w.get_sheet(0).write(var,index2,configkey[index2-8]) 
                    print len(configkey)
                                     
            w.save(pathnfile)
        for i in range(list1.count('')):
            list1.remove('')    
        return list1    
    def update_list(self):
        check1=[]
        page_txt1=[]
        h=2
        counter=0
        p=0
        check1=Update_page.check
        print "ckeck1",check1
        page_txt1.append("Home1")
        for i in range(len(check1)):
            print "helllllllo"
            for j in range(8):
                print "bbbbelllllllo"
                if(check1[i][j]==1): 
                    if(j<4):
                        page_txt1.append("Home{0}-CL{1}".format(h-1,(j+1)))
                    else:
                        temp=(j+1)-4
                        page_txt1.append("Home{0}-CR{1}".format(h-1,(temp)))
                    counter=counter+1
                           
            if(i==(counter+p)):
                print i,(counter+p)
                p=p+1
                number=Update_home.uphome_no
                if(int(h) <= int(number)):
                    print "h",h
                    # To check pages are within no of home pages
                    page_txt1.append("Home{0}".format(h))  
                    h=h+1
        number=Update_home.uphome_no
        print "h",h            
        for k in range(number+1,h,-1):
              page_txt1.append("Home{0}".format(h))
              h=h+1           
##                else:
##                    pg=page
####                    print page,len(check)
##                    if(y==0 and pg-1==len(check)):       # On previous page click
##                        flag_error=1
##                        dial = wx.MessageDialog(None, "Next page is not present",\
##                        'Error !!!', wx.OK|wx.STAY_ON_TOP)
##                        dial.ShowModal() 
##                    if(y==1 and pg==len(check)):        # on next page click
##                        flag_error=1
##                        dial = wx.MessageDialog(None, "Next page is not present",\
##                        'Error !!!', wx.OK|wx.STAY_ON_TOP)
##                        dial.ShowModal() 
##                    break
##        print "h-{0} home-{1} y-{2} ".format(h,Update_home.uphome_no,y)        
##        print page_info
##        print page_txt  
##        page_text=str(self.textCtrl1.GetValue())
        print "page_txt1",page_txt1                
        return  page_txt1 
    def btn_onclose(self, event):
        global open_status
        open_status=0
        self.hotlist=[]
        page_creation.new_confirm=0
        self.MakeModal(False)
##        CDU_TestRig_MainWindow.update_select=0
##        page_creation.list_page=[]
        self.Destroy() 
        event.Skip()    