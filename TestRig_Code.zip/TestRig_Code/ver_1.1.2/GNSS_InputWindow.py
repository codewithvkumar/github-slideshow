#Boa:Frame:GNSS_InputWindow

import wx
import CDU_TestRig_MainWindow
import GNSS_OutputWindow
import COMConfig_GNSS_Window
import struct
import serial
import threading
import win32api
from threading import Thread
from serial import  SerialException
from struct import *
from ctypes import *
global constellation_selection
global Receive_message_instance
global temp_GNSS_command_message,flag_transmit
global class_var2  
flag_transmit=0
                                           
def create(parent):
    global class_var2
    class_var2= GNSS_InputWindow(parent)
    return class_var2
[wxID_FRAME5, wxID_FRAME1GNSS_input, wxID_FRAME1GNSS_input_Command,wxID_GNSS_Input_Window_Panel,wxID_FRAME1GNSS_input_Control,\
 wxID_btn_OK,wxID_Cancel_button,wxID_Position_Latitude,wxID_Position_Longitude,wxID_Position_Altitude,\
 wxID_textCtrl_latitude,wxID_textCtrl_longitude,wxID_textCtrl_Altitude,wxID_cmb_constellation,\
 wxID_FRAME5STATICTEXT1,wxID_FRAME5STATICTEXT4,wxID_FRAME5BUTTON1,wxID_FRAME5BUTTON2
] = [wx.NewId() for _init_ctrls in range(18)]

class GNSS_InputWindow(wx.Frame):
    def _init_ctrls(self, prnt):
        #For getting pixel's value of the display window
        pixel_value=wx.GetDisplaySize()
        
        ##GNSS_input Window Size
        self.GNSS_input_window_Length=pixel_value[0]/2.67
        self.GNSS_input_window_Width=pixel_value[1]/2.95
        self.GNSS_input_Start_x=pixel_value[0]/3.12
        self.GNSS_input_Start_y=pixel_value[1]/5.95
        
        ##GNSS_input notebook Size
        self.notebook_length=pixel_value[0]/2.47##575
        self.notebook_width=pixel_value[1]/2.95##529.6
        
        ##GNSS_Position Buttons Size
        self.OKbutton_start_x=pixel_value[0]/10.6
        self.OKbutton_start_y=pixel_value[1]/4.8
        self.button_length=pixel_value[0]/13.65
        self.button_width=pixel_value[1]/33.39
        
        self.Cancelbutton_start_x=pixel_value[0]/5.02
        self.Cancelbutton_start_y=pixel_value[1]/4.8
        ## GNSS static text Size
        self.statictext_start_x=pixel_value[0]/12.82
        self.statictext_latitude_start_y=pixel_value[1]/18.9
        self.statictext_longitude_start_y=pixel_value[1]/9.92
        self.statictext_altitude_start_y=pixel_value[1]/6.8
        self.statictext_length=pixel_value[0]/18.96
        self.statictext_width=pixel_value[1]/59.08
        ## GNSS static text control box Size
        self.textctrl_start_x=pixel_value[0]/6.50
        self.textctrl_latitude_start_y=pixel_value[1]/19.2
        self.textctrl_longitude_start_y=pixel_value[1]/10.00
        self.textctrl_altitude_start_y=pixel_value[1]/7.00
        self.textctrl_length=pixel_value[0]/7.24
        self.textctrl_width=pixel_value[1]/36.57
        ## combobox Size
        self.combobx_start_x=pixel_value[0]/6.40
        self.combobx_start_y=pixel_value[1]/10.67
        self.combobox_length=pixel_value[0]/5.22
        self.combobox_width=pixel_value[1]/36.57
        
        self.statictext_constellatn_start_x=pixel_value[0]/50
        self.statictext_constellatn_start_y=pixel_value[1]/10.44
        self.statictext_constellatn_length=pixel_value[0]/14.22
        self.statictext_constellatn_width=pixel_value[1]/48
        
        wx.Frame.__init__(self, id=wxID_FRAME5, name='', parent=prnt,
              pos=wx.Point(self.GNSS_input_Start_x, self.GNSS_input_Start_y), size=wx.Size(self.GNSS_input_window_Length,\
               self.GNSS_input_window_Width),
              style=wx.SYSTEM_MENU | wx.CAPTION | wx.MINIMIZE_BOX|wx.CLOSE_BOX, title='CDU TestRig:: GNSS-Input Window')
        self.SetClientSize(wx.Size(self.GNSS_input_window_Length, self.GNSS_input_window_Width))
        self.Center()
        self.Bind(wx.EVT_CLOSE, self.OnGNSS_InputWindowClose)
        self.GNSS_Input_Window_Panel = wx.Panel(id=wxID_GNSS_Input_Window_Panel, name='GNSS_Input_Window_Panel', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(self.GNSS_input_window_Length, self.GNSS_input_window_Width),
              style=wx.TAB_TRAVERSAL)
        self.GNSS_input_notebook = wx.Notebook(id=wxID_FRAME1GNSS_input,
              name='GNSS_input_notebook', parent=self.GNSS_Input_Window_Panel, pos=wx.Point(0,0),
              size=wx.Size(self.notebook_length,self.notebook_width), style=wx.EXPAND)  
        self.GNSS_input_Command = wx.Panel(id=wxID_FRAME1GNSS_input_Command,
              name='GNSS_input_Command', parent=self.GNSS_input_notebook,pos=wx.Point(0,0),
              size=wx.Size(self.notebook_length, self.notebook_width),
              style=wx.TAB_TRAVERSAL|wx.EXPAND)
        self.GNSS_input_Control = wx.Panel(id=wxID_FRAME1GNSS_input_Control,
              name='GNSS_input_Control', parent=self.GNSS_input_notebook,
              pos=wx.Point(0,0), size=wx.Size(self.notebook_length, self.notebook_width),
              style=wx.TAB_TRAVERSAL|wx.EXPAND)
        self.btn_OK = wx.Button(id=wxID_btn_OK, label='OK',
              name='btn_OK', parent=self.GNSS_input_Command, pos=wx.Point(self.OKbutton_start_x, self.OKbutton_start_y),
              size=wx.Size(self.button_length, self.button_width), style=0)
        self.btn_OK .Bind(wx.EVT_BUTTON, self.Onbtn_OK,
              id=wxID_btn_OK)
        self.btn_Cancel = wx.Button(id=wxID_Cancel_button, label='Cancel',
              name='Cancel_button', parent=self.GNSS_input_Command, pos=wx.Point(self.Cancelbutton_start_x, self.Cancelbutton_start_y),
              size=wx.Size(self.button_length, self.button_width), style=0)
        self.btn_Cancel.Bind(wx.EVT_BUTTON, self.OnCancel_button,
              id=wxID_Cancel_button)
        
        self.sta_Position_Latitude = wx.StaticText(id=wxID_Position_Latitude,
              label='Latitude ', name='Position_Latitude',
              parent=self.GNSS_input_Command, pos=wx.Point( self.statictext_start_x,self.statictext_latitude_start_y),\
               size=wx.Size(self.statictext_length,self.statictext_width), style=0)
        self.sta_Position_Latitude.SetFont(wx.Font(9, wx.SWISS, wx.NORMAL, wx.NORMAL, False, 
              'Tahoma'))

        self.sta_Position_Longitude = wx.StaticText(id=wxID_Position_Altitude,
              label='Longitude', name='Position_Longitude',  
              parent=self.GNSS_input_Command, pos=wx.Point(self.statictext_start_x,self.statictext_longitude_start_y), size=wx.Size(self.statictext_length,
              self.statictext_width), style=0)                              
        self.sta_Position_Longitude.SetFont(wx.Font(9, wx.SWISS, wx.NORMAL, wx.NORMAL, False,
              'Tahoma'))

        self.sta_Position_altitude = wx.StaticText(id=wxID_Position_Longitude,
              label='Altitude', name='Position_altitude',
              parent=self.GNSS_input_Command, pos=wx.Point(self.statictext_start_x, self.statictext_altitude_start_y), \
              size=wx.Size(self.statictext_length,self.statictext_width), style=0)
        self.sta_Position_altitude.SetFont(wx.Font(9, wx.SWISS, wx.NORMAL, wx.NORMAL, False,
              'Tahoma'))

        self.txt_latitude = wx.TextCtrl(id=wxID_textCtrl_latitude, name='textCtrl_latitude',
              parent=self.GNSS_input_Command, pos=wx.Point(self.textctrl_start_x, self.textctrl_latitude_start_y), size=wx.Size(self.textctrl_length,
            self.textctrl_width), style=0, value="") 

        self.txt_longitude = wx.TextCtrl(id=wxID_textCtrl_longitude, name='textCtrl_longitude',
              parent=self.GNSS_input_Command, pos=wx.Point(self.textctrl_start_x, self.textctrl_longitude_start_y), size=wx.Size(self.textctrl_length,               
            self.textctrl_width), style=0, value="")

        self.txt_altitude = wx.TextCtrl(id=wxID_textCtrl_Altitude, name='textCtrl_Altitude',
              parent=self.GNSS_input_Command, pos=wx.Point(self.textctrl_start_x, self.textctrl_altitude_start_y), size=wx.Size(self.textctrl_length,
            self.textctrl_width), style=0, value="")

        self.cmb_constellation = wx.ComboBox(choices=["SGPS (GPS+SBAS)","GPS Only","GLONASS Only","SGNSS (GPS + SBAS + GLONASS)"], id=wxID_cmb_constellation,
              name='cmb_constellation', parent=self.GNSS_input_Control, pos=wx.Point(self.combobx_start_x, self.combobx_start_y),
              size=wx.Size(self.combobox_length, self.combobox_width), style=wx.CB_DROPDOWN , value="SGPS (GPS+SBAS)")
        self.sta_selection = wx.StaticText(id=wxID_FRAME5STATICTEXT1,
              label='Constellation Selection', name='staticText1',
              parent=self.GNSS_input_Control, pos=wx.Point(self.statictext_constellatn_start_x, self.statictext_constellatn_start_y), \
              size=wx.Size(self.statictext_constellatn_length,self.statictext_constellatn_width), style=0)
        self.sta_selection.SetFont(wx.Font(10, wx.SWISS, wx.NORMAL, wx.NORMAL,
              False, 'Tahoma'))                    
        self.btn_OK_control_message = wx.Button(id=wxID_FRAME5BUTTON1, label='OK',
              name='OK_control_message', parent=self.GNSS_input_Control, pos=wx.Point(self.OKbutton_start_x, self.OKbutton_start_y),\
              size=wx.Size(self.button_length, self.button_width), style=0)
        self.btn_OK_control_message.Bind(wx.EVT_BUTTON, self.OnOK_control_message,
              id=wxID_FRAME5BUTTON1)
        self.btn_Cancel_control_message = wx.Button(id=wxID_FRAME5BUTTON2, label='Cancel',
              name='Cancel_control_message', parent=self.GNSS_input_Control,pos= wx.Point(self.Cancelbutton_start_x, self.Cancelbutton_start_y),\
              size=wx.Size(self.button_length, self.button_width), style=0)
        self.btn_Cancel_control_message.Bind(wx.EVT_BUTTON, self.OnCancel_control_message,
              id=wxID_FRAME5BUTTON2)
        self._init_coll_GNSS_input_Pages(self.GNSS_input_notebook) 
  
    def _init_coll_GNSS_input_Pages(self, parent):
        # generated method, don't edit
        parent.AddPage(imageId=-1, page=self.GNSS_input_Command, select=True,
              text='Position Estimation')
        parent.AddPage(imageId=-1, page=self.GNSS_input_Control,
              select=False, text='GNSS Constellation Selection')
    
    def Onbtn_OK(self, event):
##        CDU_TestRig_MainWindow.class_var3.txt_statuswindow.Clear()
        #Checking Whether text control is empty or not
        if((self.txt_latitude.IsEmpty())or(self.txt_longitude.IsEmpty())|(self.txt_altitude.IsEmpty())):
            dial = wx.MessageDialog(None, 'Enter all the fields.....! !',
                'Error!!!', wx.OK)
            dial.ShowModal()
                     
        else:
            Position=[]
            Position_Update=[]
            Position_Latitude=str(self.txt_latitude.GetValue())
            Position_Longitude=str(self.txt_longitude.GetValue())
            Position_Altitude=str(self.txt_altitude.GetValue())
            Position.append(Position_Latitude)
            Position.append(Position_Longitude)
            Position.append(Position_Altitude)

            try:
                ##Appending the accepted position values into the list
                for i in range (len(Position)):
                  Position_Update.append(float(Position[i]))
                self.validate_input(Position_Update) 
            except ValueError:
                dial = wx.MessageDialog(None, 'Input Value must be a float.....!',
                'Error!!!', wx.OK)
                dial.ShowModal()
           
    def validate_input(self,Position_Update):
        global temp_GNSS_command_message
        flag_lati=0
        flag_longi=0
        flag_alti=0
        flag_error=0
        flag_error1=0
        temp_GNSS_command_message=GNSS_command_message()  
        # Checking whether the accepted position values are within the range  
        if(((Position_Update[0])>=-90)and ((Position_Update[0])<=90)):
            flag_lati=1
            temp_GNSS_command_message.Position_Update_latitude=Position_Update[0]
        else:
             flag_error=1
             dial = wx.MessageDialog(None, 'Enter the Latitude within the range(-90,90)',
                'Error!!!', wx.OK)
             dial.ShowModal()
        if(flag_error==0):
            if(((Position_Update[1])>=-180) and ((Position_Update[1])<=180)):
                flag_longi=1
                temp_GNSS_command_message.Position_Update_longitude =Position_Update[1]
            else:
                dial = wx.MessageDialog(None, 'Enter the Longitude within the range(-180,180)',
                'Error!!!', wx.OK)
                dial.ShowModal()
                flag_error1=1 
        if((flag_error==0)and(flag_error1==0)):
            if(((Position_Update[2])>=-1000) and ((Position_Update[2])<=18000)):
                flag_alti=1
                temp_GNSS_command_message.Position_Update_altitude =Position_Update[2]
            else:
                 dial = wx.MessageDialog(None, 'Enter the Altitude within the range(-1000,18000)',
                'Error!!!', wx.OK)
                 dial.ShowModal()
        if(flag_alti==1 and flag_lati==1 and flag_longi==1):
            Gnss_command_temp=pack_GNSS_command_message()
            Gnss_command_temp.process_input(Position_Update)
              
    def OnCancel_button(self, event):
##         CDU_TestRig_MainWindow.class_var3.txt_statuswindow.Clear()   
         self.Close()
    def OnCancel_control_message(self, event):
##         CDU_TestRig_MainWindow.class_var3.txt_statuswindow.Clear()
         self.Close()
    def OnOK_control_message(self, event):
##        CDU_TestRig_MainWindow.class_var3.txt_statuswindow.Clear()
        global class_var2 ,constellation_selection
        constellation_selection=class_var2.cmb_constellation.GetValue()
        pack_GNSS_control_message_temp=pack_GNSS_control_message()
        pack_GNSS_control_message_temp.process_input_control()
    def  OnGNSS_InputWindowClose(self,event):
        CDU_TestRig_MainWindow.flag_frame2=0
        self.Destroy()
    def __init__(self, parent):
        self._init_ctrls(parent)
    
class GNSS_command_message(Structure):
    _fields_=[
            ("Position_Update_latitude",c_double),
            ("Position_Update_longitude",c_double),
            ("Position_Update_altitude",c_float),
            ]
class pack_GNSS_command_message:
    global temp_GNSS_command_message,flag_transmit
    def process_input(self,Position_Update):
        global flag_transmit
        GNSS_list=[63,63,175,0,temp_GNSS_command_message.Position_Update_latitude,
        temp_GNSS_command_message.Position_Update_longitude,temp_GNSS_command_message.Position_Update_altitude,
            175,0,10]
        
        #Packing the GNSS command message
        GNSS_input_message_for_checksum=struct.pack('<4B2dfI',\
                                    63,63,175,0,temp_GNSS_command_message.Position_Update_latitude,\
                                     temp_GNSS_command_message.Position_Update_longitude,\
                                     temp_GNSS_command_message.Position_Update_altitude,\
                                    0)
        check_position=Calculate_Checksum(GNSS_input_message_for_checksum,28)
        GNSS_input_message=GNSS_input_message_for_checksum+struct.pack('>2B',check_position,10)
        Receive_message_instance=Receive_message()
        #Calling the thread to send the packed GNSS command message
        threading.Thread(target=Receive_message_instance.start_thread,args=(GNSS_input_message,)).start()
        if (flag_transmit==0):
            time_now=CDU_TestRig_MainWindow.class_var3.local_time()
            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("\nGNSS Command Message Block is Transmitted at " +str(time_now)+" instance") 
        
class pack_GNSS_control_message:
   def process_input_control(self):
        global flag_transmit, Receive_message_instance,constellation_selection
        # Getting the selected constellation
        if(constellation_selection=="SGPS (GPS+SBAS)"):
            var_pos=0
        elif(constellation_selection=="GPS Only"):
             var_pos=1
        elif(constellation_selection=="GLONASS Only"):
             var_pos=2
        elif(constellation_selection=="SGNSS (GPS + SBAS + GLONASS)"):
            var_pos=3        
        GNSS_input_checksum=[63,63,175,1,var_pos,0]
      ##        print "check..........",Checksum
        GNSS_input_message_control_for_checksum=struct.pack('<6B',\
                                    63,63,175,1,var_pos,0)
        Checksum=Calculate_Checksum(GNSS_input_message_control_for_checksum,6)
        GNSS_input_message_control=GNSS_input_message_control_for_checksum+struct.pack('>2B',Checksum,10)
        Receive_message_instance=Receive_message()
        threading.Thread(target=Receive_message_instance.start_thread,args=(GNSS_input_message_control,)).start()
        if (flag_transmit==0):
            time_now=CDU_TestRig_MainWindow.class_var3.local_time()
            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("\nGNSS Control Message Block is Transmitted at " +str(time_now)+" instance")
class Receive_message():
    # Thread to send the GNSS input messages
  def start_thread(self,GNSS_input_message):
        global flag_transmit
        
        if(COMConfig_GNSS_Window.instance_comport_receiver.Comport_select==COMConfig_GNSS_Window.instance_comport_transmitter.Comport_select):
            if(CDU_TestRig_MainWindow.class_var3.connect_object_GNSS_receiver!=''):
                CDU_TestRig_MainWindow.class_var3.connect_object_GNSS_receiver.write(GNSS_input_message)
                
            else:
                flag_transmit=1
                dial = wx.MessageDialog(None, 'COM Port is not Available.....!!',
                'Error!!!', wx.OK|wx.STAY_ON_TOP)
                dial.ShowModal()
               
        else:
            if(CDU_TestRig_MainWindow.class_var3.connect_object_GNSS_transmitter!=''):
                CDU_TestRig_MainWindow.class_var3.connect_object_GNSS_transmitter.write(GNSS_input_message)
            
            else:
                flag_transmit=1
                dial = wx.MessageDialog(None, 'COM Port is not Available.....!!',
                 'Error!!!', wx.OK|wx.STAY_ON_TOP)
                dial.ShowModal()
# Function to calculate checksum
def Calculate_Checksum(pkt,bytecount):
        checksum=0
        data=struct.unpack_from('<%dB'%bytecount,pkt)
##        print data
        for i in range(0,bytecount):
            checksum=checksum^data[i]
        checksum=checksum & 0xFF
        return checksum