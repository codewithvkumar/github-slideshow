#Boa:Frame:Frame6

import wx
import page_creation
import GNSS_OutputWindow
import CDU_TestRig_MainWindow

def create(parent):
    instance_Frame6=home_creation(parent)
    return instance_Frame6

##    return home_creation(parent)

global home_no,flag_page_creation,home_flag

flag_page_creation=0
home_flag=0
[wxID_FRAME6, wxID_FRAME6BUTTON1, wxID_FRAME6BUTTON2, wxID_FRAME6PANEL1, 
 wxID_FRAME6STATICTEXT1, wxID_FRAME6TEXTCTRL1, 
] = [wx.NewId() for _init_ctrls in range(6)]

class home_creation(wx.Frame):
    def _init_ctrls(self, prnt):
        # generated method, don't edit
        wx.Frame.__init__(self, id=wxID_FRAME6, name='', parent=prnt,
              pos=wx.Point(320, 138), size=wx.Size(414, 131),
              style=wx.DEFAULT_FRAME_STYLE, title='Home Page Details')
        self.SetClientSize(wx.Size(406, 97))
        self.Center()
        self.Bind(wx.EVT_CLOSE, self.On_Close)
        self.home_creation_panel = wx.Panel(id=wxID_FRAME6PANEL1, name='home_creation_panel', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(406, 97),
              style=wx.TAB_TRAVERSAL)

        self.sta_no_page = wx.StaticText(id=wxID_FRAME6STATICTEXT1,
              label='Enter number of home pages :', name='sta_no_page',
              parent=self.home_creation_panel, pos=wx.Point(24, 24), size=wx.Size(146, 13),
              style=0)

        self.txt_no_page = wx.TextCtrl(id=wxID_FRAME6TEXTCTRL1, name='txt_no_page',
              parent=self.home_creation_panel, pos=wx.Point(176, 24), size=wx.Size(160, 21),
              style=0, value='')

        self.btn_ok= wx.Button(id=wxID_FRAME6BUTTON1, label='OK',
              name='btn_ok', parent=self.home_creation_panel, pos=wx.Point(176, 64),
              size=wx.Size(75, 23), style=0)
        self.btn_ok.Bind(wx.EVT_BUTTON, self.OnOK, id=wxID_FRAME6BUTTON1)

        self.btn_cancel = wx.Button(id=wxID_FRAME6BUTTON2, label='Cancel',
              name='btn_cancel', parent=self.home_creation_panel, pos=wx.Point(264, 64),
              size=wx.Size(80, 23), style=0)
        self.btn_cancel.Bind(wx.EVT_BUTTON, self.OnCancel, id=wxID_FRAME6BUTTON2)

    def __init__(self, parent):
        self._init_ctrls(parent)
    
    # Description:
    # Function parameters:
    # Global variables:
            
    def On_Close(self,event):
        CDU_TestRig_MainWindow.flag_home_creation=0
        flag_page_creation=0
        self.Destroy() 
        event.Skip()

    # Description:
    # Function parameters:
    # Global variables:
        
    def OnCancel(self, event):
        CDU_TestRig_MainWindow.flag_home_creation=0
        flag_page_creation=0
        self.Destroy() 
        event.Skip()
    
    # Description:
    # Function parameters:
    # Global variables:
        
    def OnOK(self, event):
        global home_no,main8,flag_page_creation
        global home_flag
        home_flag=1
        home_no=self.txt_no_page.GetValue()
        flag=0
        if(home_no!=''):
            flag=1
        try:
            if(flag==1):
                home_no =int(home_no)
                if((home_no)>0 and home_no<=16):
                    print CDU_TestRig_MainWindow.flag_home_creation
                    if(flag_page_creation==0):
                        main8 = page_creation.create(None)
                        main8.Show()
                        flag_page_creation=1
                        CDU_TestRig_MainWindow.flag_home_creation=0
                        self.Destroy()
##                    else:
##                        self.main8.SetFocus()
##                        flag_page_creation=1
##                        self.main8.Show()
                    
                else:
                    dial = wx.MessageDialog(None, "Number of home pages ranges from 1 to 16",\
                    'Error !!!', wx.OK|wx.STAY_ON_TOP)
                    dial.ShowModal()   
             
            elif(flag==0):
                 dial = wx.MessageDialog(None, "Enter number of home pages",\
                'Error !!!', wx.OK|wx.STAY_ON_TOP)
                 dial.ShowModal()  
        except ValueError:
            dial = wx.MessageDialog(None, "Enter integer value",\
            'Error !!!', wx.OK|wx.STAY_ON_TOP)
            dial.ShowModal()  
        
        
##        event.Skip()
