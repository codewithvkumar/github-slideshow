##import os
##bin_sub=[]
##bin_main=[[]]
##bin_main1=[[]]
##f=open('data3.bin','rb')
##
##size_file=os.path.getsize('data3.bin')
##print size_file
##no_pck=float(size_file)/50
##                            
##
##no_pck=int(no_pck)+1
##
##t=0
##print "no_pck",no_pck
##for i in range(no_pck):
##    for j in range(t,t+50):
##        bin_sub.append(f.read(1))
##        f.seek(j,0)
##                    
##    f.seek(t+50,0)
##    t=t+50
##    bin_main[i]=bin_sub
##    bin_main.extend(bin_main1)
##    print "bin_sub",bin_sub
##    bin_sub=[]
##
##a=size_file%50
##print "a",a
##for i in range(a+1,50):
##    bin_main[no_pck][i]='00'
####    bin_main.extend(bin_main1)
##print "bin_main[no_pck]",bin_main[no_pck]


binn=0x05&0x40
print binn
    
