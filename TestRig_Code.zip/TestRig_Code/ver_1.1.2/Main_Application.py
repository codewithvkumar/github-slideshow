#!/usr/bin/env python
#Boa:App:BoaApp

import wx

import GNSS_OutputWindow
import CDU_TestRig_MainWindow
modules ={u'CDU_TestRig_MainWindow': [0, '', u'CDU_TestRig_MainWindow.py'],
 'Dialog1': [0, '', 'none://Dialog1.py'],
 'GNSS_OutputWindow': [1,
                       'Main frame of Application',
                       u'../CDU_TestRig on Shrividyar3/Frame3.py']}

class BoaApp(wx.App):
    def OnInit(self):
        self.main = CDU_TestRig_MainWindow.create(None)
        self.main.Show()
        self.SetTopWindow(self.main)
        return True

def main():
    application = BoaApp(0)
    application.MainLoop()

if __name__ == '__main__':
     main()
