#Boa:Frame:COMConfig_Window

import wx
import CDU_TestRig_MainWindow
import GNSS_OutputWindow
import os
import display

import _winreg as winreg    # To get com port
import itertools            # To get com port
from ctypes import *
import threading
from threading import Thread
import time 
from ctypes import *
import serial
import string
from serial import  *
import win32api
import xlrd
import xlwt
from xlutils.copy import copy
import sys
from ctypes import *
global flag_ok,class_var3,class_var4,w,w_ibit
global filename_GNSS_position_data,path_name,filename_GNSS_health_data,filename_GNSS_version_data
global instance_comport_receiver_CDU1,instance_comport_transmitter_CDU1
global com_port,com_port1,com_port2,com_port3,com_port4,com_port5,com_port6,com_port7,master
##filename_GNSS_version_data
flag_ok=0
com_port=0
com_port1=0
com_port2=0
com_port3=0
com_port4=0
com_port5=0
com_port6=0
com_port7=0
def create(parent):
    global class_var4
    class_var4= COMConfig_Window(parent)
    return class_var4


[wxID_COMConfig_Window, wxID_COMConfig_WindowBUTTON1, wxID_COMConfig_WindowBUTTON2, wxID_COMConfig_WindowBUTTON3, 
 wxID_COMConfig_WindowRADIOBOX4, wxID_COMConfig_WindowPANEL1, wxID_COMConfig_WindowRADIOBOX1, 
 wxID_COMConfig_WindowRADIOBOX2, wxID_COMConfig_WindowRADIOBOX3,wxID_COMConfig_WindowRADIOBOX5,
 wxID_COMConfig_WindowRADIOBOX6,wxID_COMConfig_WindowRADIOBOX7,wxID_COMConfig_WindowSTATICBOX1, 
 wxID_COMConfig_WindowSTATICBOX2, wxID_COMConfig_WindowSTATICBOX3,wxID_COMConfig_WindowSTATICTEXT1, 
 wxID_COMConfig_WindowRADIOBOX8,wxID_COMConfig_WindowSTATICTEXT2, wxID_COMConfig_Windowtxt_log, 
 wxID_FRAME1COMBOBOX1,wxID_FRAME1COMBOBOX2,wxID_COMConfig_WindowRADIOBOX9,wxID_COMConfig_WindowRADIOBOX10,
 wxID_COMConfig_WindowRADIOBOX12,wxID_COMConfig_WindowRADIOBOX13,wxID_COMConfig_WindowRADIOBOX11,
 wxID_COMConfig_WindowSTATICBOX5,wxID_COMConfig_WindowSTATICBOX4,wxID_FRAME1COMBOBOX3,wxID_FRAME1COMBOBOX4,
 wxID_FRAME1COMBOBOX5,wxID_COMConfig_WindowSTATICTEXT3,wxID_COMConfig_WindowSTATICBOX6,wxID_COMConfig_WindowSTATICBOX7
] = [wx.NewId() for _init_ctrls in range(34)]

class COMConfig_Window(wx.Frame):
##    com_port=0
##    com_port1=0
##    com_port2=0
##    com_port3=0
##    com_port4=0
##    com_port5=0
##    com_port6=0
##    com_port7=0
    def _init_ctrls(self, prnt):
        port=[]
       
        # generated method, don't edit
        pixel4=wx.GetDisplaySize() 
##        print pixel4
     
        ##Length and width of Main Window
        self.Main_window_Length4=pixel4[0]/1
        self.Main_window_Width4=pixel4[1]/1.266
        self.Main_window_Start_y4=pixel4[1]/7.77
##        self.var_display
        self.Main_window_Start_x4=pixel4[0]/3.12
##        if(CDU_TestRig_MainWindow.flag_com==1):
##            title_Output='Comport Configuration to GNSS'
##        else:
##            title_Output='Comport Configuration to CDU'
        wx.Frame.__init__(self, id=wxID_COMConfig_Window, name='', parent=prnt,
              pos=wx.Point( self.Main_window_Start_x4, self.Main_window_Start_y4), size=wx.Size(460, 546),
              style=wx.SYSTEM_MENU | wx.CAPTION | wx.MINIMIZE_BOX|wx.CLOSE_BOX|wx.RESIZE_BORDER, title='Comport Configuration to CDU')
        self.SetClientSize(wx.Size(460, 546))
        self.Comconfig_panel = wx.Panel(id=wxID_COMConfig_WindowPANEL1, name='Comconfig_panel', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(459, 546),
              style=wx.ALWAYS_SHOW_SB | wx.TAB_TRAVERSAL)
              
        self.Bind(wx.EVT_CLOSE, self.On_Close)
        self.radioBox1 = wx.RadioBox(choices=["9600", "19200", "38400", "57600",    #CDU1 RECEIVER
              "115200"], id=wxID_COMConfig_WindowRADIOBOX1, label='Baud Rate',
              majorDimension=1, name='radioBox1', parent=self.Comconfig_panel,
              pos=wx.Point( 26, 40), size=wx.Size(65, 120),
              style=wx.RA_USE_CHECKBOX)
        self.radioBox1.SetSelection(4)
  
        self.radioBox2 = wx.RadioBox(choices=["1", "2"],
              id=wxID_COMConfig_WindowRADIOBOX2, label='Stop Bits', majorDimension=1,   #CDU1 RECEIVER
              name='radioBox2', parent=self.Comconfig_panel, pos=wx.Point(100, 40),
              size=wx.Size(44, 120), style=wx.RA_SPECIFY_COLS)

        self.radioBox3 = wx.RadioBox(choices=["None", "Odd", "Even"],
              id=wxID_COMConfig_WindowRADIOBOX3, label='Parity', majorDimension=1,
              name='radioBox3', parent=self.Comconfig_panel, pos=wx.Point(158, 40),
              size=wx.Size(52, 120), style=wx.RA_SPECIFY_COLS)

        self.sta_reception = wx.StaticBox(id=wxID_COMConfig_WindowSTATICBOX1,          #CDU1 RECEIVER
              label='Reception Port', name='sta_reception', parent=self.Comconfig_panel,
              pos=wx.Point(18, 23), size=wx.Size(200, 175), style=0)
        
        self.sta_connect = wx.StaticBox(id=wxID_COMConfig_WindowSTATICBOX6,          #CDU1 BOX
              label='Connect to CDU through Master DMC', name='staticBox6', parent=self.Comconfig_panel,
              pos=wx.Point(6, 4), size=wx.Size(440, 208), style=0)
              
        self.radioBox8 = wx.RadioBox(choices=["9600", "19200", "38400", "57600",     #CDU1 TRANSMITTER
              "115200"], id=wxID_COMConfig_WindowRADIOBOX8, label='Baud Rate',
              majorDimension=1, name='radioBox1', parent=self.Comconfig_panel,
              pos=wx.Point( 28, 260), size=wx.Size(65, 120),
              style=wx.RA_USE_CHECKBOX)
        self.radioBox8.SetSelection(4)
  
        self.radioBox9 = wx.RadioBox(choices=["1", "2"],
              id=wxID_COMConfig_WindowRADIOBOX9, label='Stop Bits', majorDimension=1,   #CDU1 TRANSMITTER
              name='radioBox2', parent=self.Comconfig_panel, pos=wx.Point(104, 260),
              size=wx.Size(44, 120), style=wx.RA_SPECIFY_COLS)

        self.radioBox10 = wx.RadioBox(choices=["None", "Odd", "Even"],
              id=wxID_COMConfig_WindowRADIOBOX10, label='Parity', majorDimension=1,     #CDU1 TRANSMITTER
              name='radioBox3', parent=self.Comconfig_panel, pos=wx.Point(158, 260),
              size=wx.Size(52, 120), style=wx.RA_SPECIFY_COLS)

        self.sta_reception2= wx.StaticBox(id=wxID_COMConfig_WindowSTATICBOX4,           #Receiving BOX cdu2
              label='Reception Port', name='staticBox4', parent=self.Comconfig_panel,
              pos=wx.Point(18, 240), size=wx.Size(200, 175), style=0)
              
        self.sta_connect2 = wx.StaticBox(id=wxID_COMConfig_WindowSTATICBOX7,             #CDU2 BOX
              label='Connect to CDU through DMC2', name='sta_connect2', parent=self.Comconfig_panel,
              pos=wx.Point(4, 220), size=wx.Size(440, 208), style=0)

        self.stabox_path = wx.StaticBox(id=wxID_COMConfig_WindowSTATICBOX2,  
              label='Path for Logging', name='sta_log', parent=self.Comconfig_panel,     #PATH
              pos=wx.Point(8, 464), size=wx.Size(440, 50), style=0)

        self.txt_log = wx.TextCtrl(id=wxID_COMConfig_Windowtxt_log, name='txt_log',       #LOG CNTRL
              parent=self.Comconfig_panel, pos=wx.Point(120, 484), size=wx.Size(200, 20),
              style=0, value="")
              
        self.dirpath=os.getcwd()
        self.txt_log.SetValue(self.dirpath)
        self.txt_log. SetEditable(0)
        
        self.sta_log= wx.StaticText(id=wxID_COMConfig_WindowSTATICTEXT2,
              label='Log Folder', name='sta_log', parent=self.Comconfig_panel,      #LOG
              pos=wx.Point(48, 486), size=wx.Size(64, 15), style=0)

        self.btn_Browse = wx.Button(id=wxID_COMConfig_WindowBUTTON1, label='Browse',                
              name='btn_Browse', parent=self.Comconfig_panel, pos=wx.Point(340, 482),
              size=wx.Size(74, 21), style=0)
        self.btn_Browse.Bind(wx.EVT_BUTTON, self.OnBrowse, id=wxID_COMConfig_WindowBUTTON1)
        
        self.btn_ok = wx.Button(id=wxID_COMConfig_WindowBUTTON2, label='OK',
              name='ok_button', parent=self.Comconfig_panel, pos=wx.Point(150, 523),
              size=wx.Size(64, 20), style=0)
        self.btn_ok .Bind(wx.EVT_BUTTON, self.OnOK_button,
              id=wxID_COMConfig_WindowBUTTON2)
              
        self.btn_cancel = wx.Button(id=wxID_COMConfig_WindowBUTTON3, label='Cancel',
              name='btn_cancel', parent=self.Comconfig_panel, pos=wx.Point(236, 523),
              size=wx.Size(64, 20), style=0)
              
        self.btn_cancel.Bind(wx.EVT_BUTTON, self.OnCancel_button,
              id=wxID_COMConfig_WindowBUTTON3)
                           
##        self.radioBox4 = wx.RadioBox(choices=["COM1","COM2","COM3","COM4","COM5"], id=wxID_COMConfig_WindowRADIOBOX4,
##              label='Comport', majorDimension=1, name='radioBox4',
##              parent=self.Comconfig_panel, pos=wx.Point(304, 32), size=wx.Size(68, 120),
##              style=wx.RA_SPECIFY_COLS)
##        self.CDU_LOG_xls=''
                
        self.sta_trans= wx.StaticBox(id=wxID_COMConfig_WindowSTATICBOX3,             #CDU1 Transmitting
              label='Transmission Port', name='staticBox3', parent=self.Comconfig_panel,
              pos=wx.Point(235, 23), size=wx.Size(200,175), style=0)
              
        self.radioBox5 = wx.RadioBox(choices=["9600", "19200", "38400", "57600",       #CDU1 Transmitting
              "115200"], id=wxID_COMConfig_WindowRADIOBOX5, label='Baud Rate',
              majorDimension=1, name='radioBox5', parent=self.Comconfig_panel,
              pos=wx.Point(243, 40), size=wx.Size(65, 120),
              style=wx.RA_USE_CHECKBOX)
        self.radioBox5.SetSelection(4)
              
        self.radioBox6 = wx.RadioBox(choices=["1", "2"],                                #CDU2 Transmitting
              id=wxID_COMConfig_WindowRADIOBOX6, label='Stop Bits', majorDimension=1,
              name='radioBox2', parent=self.Comconfig_panel, pos=wx.Point(319,  40),
              size=wx.Size(44, 120), style=wx.RA_SPECIFY_COLS)
        
        self.radioBox7 = wx.RadioBox(choices=["None", "Odd", "Even"],               #CDU2 Transmitting
              id=wxID_COMConfig_WindowRADIOBOX7, label='Parity', majorDimension=1,
              name='radioBox3', parent=self.Comconfig_panel, pos=wx.Point(375, 40),
              size=wx.Size(52, 120), style=wx.RA_SPECIFY_COLS)
                              
        self.sta_trans2 = wx.StaticBox(id=wxID_COMConfig_WindowSTATICBOX5,   #CDU2 Transmitting
              label='Transmission Port', name='staticBox5', parent=self.Comconfig_panel,
              pos=wx.Point(235, 240), size=wx.Size(200,175), style=0)
              
        self.radioBox11 = wx.RadioBox(choices=["9600", "19200", "38400", "57600",    #CDU2 Transmitting
              "115200"], id=wxID_COMConfig_WindowRADIOBOX11, label='Baud Rate',
              majorDimension=1, name='radioBox5', parent=self.Comconfig_panel,
              pos=wx.Point(245, 262), size=wx.Size(65, 120),
              style=wx.RA_USE_CHECKBOX)
        self.radioBox11.SetSelection(4)
        self.radioBox12 = wx.RadioBox(choices=["1", "2"],                #CDU2 Transmitting
              id=wxID_COMConfig_WindowRADIOBOX12, label='Stop Bits', majorDimension=1,
              name='radioBox2', parent=self.Comconfig_panel, pos=wx.Point(319, 262),
              size=wx.Size(44, 120), style=wx.RA_SPECIFY_COLS)
      
        self.radioBox13 = wx.RadioBox(choices=["None", "Odd", "Even"],           #CDU2 Transmitting
              id=wxID_COMConfig_WindowRADIOBOX13, label='Parity', majorDimension=1,
              name='radioBox3', parent=self.Comconfig_panel, pos=wx.Point(375, 262 ),
              size=wx.Size(52, 120), style=wx.RA_SPECIFY_COLS)      

##        self.radioBox8 = wx.RadioBox(choices=["COM1","COM2","COM3","COM4","COM5"], id=wxID_COMConfig_WindowRADIOBOX8,
##              label='Comport', majorDimension=1, name='radioBox8',
##              parent=self.Comconfig_panel, pos=wx.Point(712, 32), size=wx.Size(68, 120),
##              style=wx.RA_SPECIFY_COLS)

        # To get opened com ports

        path = 'HARDWARE\\DEVICEMAP\\SERIALCOMM'
        try:
            key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, path)
               
        except WindowsError:
            raise IterationError

        for i in itertools.count():
            try:
                val = winreg.EnumValue(key, i)
##                print "val[1]",val[1]
                port.append(val[1])

            except EnvironmentError:
                break
            
##        print "port........>",port
        self.cmb_r1 = wx.ComboBox(choices=port,     
              id=wxID_FRAME1COMBOBOX1, name='cmb_r1', parent=self.Comconfig_panel,  #CDU1 
              pos=wx.Point(25, 170), size=wx.Size(120, 21), style=0,
              value='Select COM port')
        self.cmb_r1.SetEditable(0)
              
        self.cmb_t1 = wx.ComboBox(choices=port,
              id=wxID_FRAME1COMBOBOX2, name='cmb_t1', parent=self.Comconfig_panel,  #CDU1 
              pos=wx.Point(252, 170), size=wx.Size(120, 21), style=0,
              value='Select COM port')
        self.cmb_t1.SetEditable(0)
        
        self.cmb_r2 = wx.ComboBox(choices=port,
              id=wxID_FRAME1COMBOBOX3, name='cmb_r2', parent=self.Comconfig_panel,  #CDU2
              pos=wx.Point(25, 388), size=wx.Size(120, 21), style=0,
              value='Select COM port')
        self.cmb_r2.SetEditable(0)
              
        self.cmb_t2 = wx.ComboBox(choices=port,
              id=wxID_FRAME1COMBOBOX4, name='cmb_t2', parent=self.Comconfig_panel,  #CDU2
              pos=wx.Point(252, 388), size=wx.Size(120, 21), style=0,
              value='Select COM port')
        self.cmb_t2.SetEditable(0)
        
        self.cmb_cdu = wx.ComboBox(choices=["DMC1","DMC2"],\
              id=wxID_FRAME1COMBOBOX5, name='cmb_cdu', parent=self.Comconfig_panel,
              pos=wx.Point(222, 440), size=wx.Size(100, 21), style=0,
              value='DMC1')
        self.cmb_cdu.SetEditable(0)
        
        self.sta_dmc= wx.StaticText(id=wxID_COMConfig_WindowSTATICTEXT3,
              label='Select Master DMC', name='sta_dmc', parent=self.Comconfig_panel,   
              pos=wx.Point(120, 443), size=wx.Size(94, 13), style=0)
              
##        self.CDU_LOG_xls=''
##        self.IBIT_log_xls=''
        
        self.global_intialisation()

    def __init__(self, parent):
        self._init_ctrls(parent)
        
    # Description:
    # Function parameters:
    # Global variables:
                
    def global_intialisation(self):
        global path_name,com_port,com_port1,com_port2,com_port3,com_port4,com_port5,com_port6,com_port7\
        
        self.radioBox1.SetSelection(4)  #fixed baud rate for 115200
        self.radioBox5.SetSelection(4)
        
        self.cmb_r1.SetSelection(instance_comport_receiver_CDU1.Comport_select)   # To have previous value of com port
        self.cmb_t1.SetSelection(instance_comport_transmitter_CDU1.Comport_select)
        
        self.radioBox2.SetSelection(com_port1) # To have previous value of stop bit
        self.radioBox6.SetSelection(com_port5)
        
        self.radioBox3.SetSelection(com_port2) # To have previous value of parity
        self.radioBox7.SetSelection(com_port6)
##        self.txt_log.SetValue(self.path_name)

        self.radioBox8.SetSelection(4)  #fixed baud rate for 115200
        self.radioBox11.SetSelection(4)
        
        self.cmb_r2.SetSelection(instance_comport_receiver_CDU2.Comport_select)   # To have previous value of com port
        self.cmb_t2.SetSelection(instance_comport_transmitter_CDU2.Comport_select)
        
    # Description:
    # Function parameters:
    # Global variables:
            
    def OnOK_button(self, event):
        global flag_ok,w,w_ibit, com_port,com_port1,com_port2,com_port3,com_port4,com_port5,com_port6,com_port7,\
        master
        flag_ok=1
        
        if(instance_comport_receiver_CDU1.Comport_select==instance_comport_transmitter_CDU1.Comport_select):
            if(CDU_TestRig_MainWindow.class_var3.connect_object_CDU1_receiver!=''):  
                time.sleep(1)
                CDU_TestRig_MainWindow.class_var3.connect_object_CDU1_receiver.close()
                CDU_TestRig_MainWindow.class_var3.connect_object_CDU1_receiver=''
        else:
            if(CDU_TestRig_MainWindow.class_var3.connect_object_CDU1_receiver!='' and CDU_TestRig_MainWindow.class_var3.connect_object_CDU1_transmitter!=''):
                time.sleep(1)
                CDU_TestRig_MainWindow.class_var3.connect_object_CDU1_receiver.close()
                CDU_TestRig_MainWindow.class_var3.connect_object_CDU1_receiver='' 
                CDU_TestRig_MainWindow.class_var3.connect_object_CDU1_transmitter.close()
                CDU_TestRig_MainWindow.class_var3.connect_object_CDU1_transmitter=''
                        
        
        
        com_port =self.radioBox1.GetSelection()    #CDU1 Receiver
        com_port1 =self.radioBox2.GetSelection()
        com_port2 =self.radioBox3.GetSelection()
        com_port3=self.cmb_r1.GetValue()
        com1=com_port3.split('COM')
        instance_comport_receiver_CDU1.Comport_select=int(com1[1])-1

        com_port4 =self.radioBox5.GetSelection()   #CDU1 Transmitter
        com_port5 =self.radioBox6.GetSelection()
        com_port6 =self.radioBox7.GetSelection()
        com_port7=self.cmb_t1.GetValue()
        com1=com_port7.split('COM')
        instance_comport_transmitter_CDU1.Comport_select=int(com1[1])-1
              
             
        if(com_port==0):                           #Receiver
            instance_comport_receiver_CDU1.Baud_Rate="9600"
        elif(com_port==1):
            instance_comport_receiver_CDU1.Baud_Rate="19200"
        elif(com_port==2):
            instance_comport_receiver_CDU1.Baud_Rate="38400"
        elif(com_port==3):
            instance_comport_receiver_CDU1.Baud_Rate="57600" 
        elif(com_port==4):
            instance_comport_receiver_CDU1.Baud_Rate="115200" 
            
        if(com_port1==0):                              #Receiver
            instance_comport_receiver_CDU1.Stop_Bits=STOPBITS_ONE
        elif(com_port1==1):
            instance_comport_receiver_CDU1.Stop_Bits=STOPBITS_TWO
            
        if(com_port2==0):                          #Receiver
            instance_comport_receiver_CDU1.Parity=PARITY_NONE
        elif(com_port2==1):
            instance_comport_receiver_CDU1.Parity=PARITY_ODD
        elif(com_port2==2):
            instance_comport_receiver_CDU1.Parity=PARITY_EVEN
            
        if(com_port4==0):                           #Transmitter
            instance_comport_transmitter_CDU1.Baud_Rate="9600"
        elif(com_port4==1):
            instance_comport_transmitter_CDU1.Baud_Rate="19200"
        elif(com_port4==2):
            instance_comport_transmitter_CDU1.Baud_Rate="38400"
        elif(com_port4==3):
            instance_comport_transmitter_CDU1.Baud_Rate="57600" 
        elif(com_port4==4):
            instance_comport_transmitter_CDU1.Baud_Rate="115200" 
            
        if(com_port5==0):                                  #Transmitter
            instance_comport_transmitter_CDU1.Stop_Bits=STOPBITS_ONE
        elif(com_port5==1):
            instance_comport_transmitter_CDU1.Stop_Bits=STOPBITS_TWO
            
        if(com_port6==0):                               #Transmitter
            instance_comport_transmitter_CDU1.Parity=PARITY_NONE
        elif(com_port6==1):
            instance_comport_transmitter_CDU1.Parity=PARITY_ODD
        elif(com_port6==2):
            instance_comport_transmitter_CDU1.Parity=PARITY_EVEN
            
#-------------------------------------------------------------------------------

        com_port8 =self.radioBox1.GetSelection()    #CDU2 Receiver
        com_port9 =self.radioBox2.GetSelection()
        com_port10 =self.radioBox3.GetSelection()
        try:
            com_port11=self.cmb_r2.GetValue()
            com1=com_port11.split('COM')
##            print "com1--------->",com1
            instance_comport_receiver_CDU2.Comport_select=int(com1[1])-1
    ##        print "cdu2 receiver------>",instance_comport_receiver_CDU2.Comport_select

            com_port12 =self.radioBox5.GetSelection()   #CDU2 Transmitter
            com_port13 =self.radioBox6.GetSelection()
            com_port14 =self.radioBox7.GetSelection()
            com_port15=self.cmb_t2.GetValue()
            com1=com_port15.split('COM')
            instance_comport_transmitter_CDU2.Comport_select=int(com1[1])-1
    ##        print "cdu2 trans------>",instance_comport_transmitter_CDU2.Comport_select
        except ValueError:
            dial = wx.MessageDialog(None, "Select COM Port",\
            'Error !!!', wx.OK|wx.STAY_ON_TOP)
            dial.ShowModal()
        
        if(com_port8==0):                           #Receiver
            instance_comport_receiver_CDU2.Baud_Rate="9600"
        elif(com_port8==1):
            instance_comport_receiver_CDU2.Baud_Rate="19200"
        elif(com_port8==2):
            instance_comport_receiver_CDU2.Baud_Rate="38400"
        elif(com_port8==3):
            instance_comport_receiver_CDU2.Baud_Rate="57600" 
        elif(com_port8==4):
            instance_comport_receiver_CDU2.Baud_Rate="115200" 
            
        if(com_port9==0):                              #Receiver
            instance_comport_receiver_CDU2.Stop_Bits=STOPBITS_ONE
        elif(com_port9==1):
            instance_comport_receiver_CDU2.Stop_Bits=STOPBITS_TWO
            
        if(com_port10==0):                          #Receiver
            instance_comport_receiver_CDU2.Parity=PARITY_NONE
        elif(com_port10==1):
            instance_comport_receiver_CDU2.Parity=PARITY_ODD
        elif(com_port10==2):
            instance_comport_receiver_CDU2.Parity=PARITY_EVEN
            
        if(com_port12==0):                           #Transmitter
            instance_comport_transmitter_CDU2.Baud_Rate="9600"
        elif(com_port12==1):
            instance_comport_transmitter_CDU2.Baud_Rate="19200"
        elif(com_port12==2):
            instance_comport_transmitter_CDU2.Baud_Rate="38400"
        elif(com_port12==3):
            instance_comport_transmitter_CDU2.Baud_Rate="57600" 
        elif(com_port12==4):
            instance_comport_transmitter_CDU2.Baud_Rate="115200" 
            
        if(com_port13==0):                                  #Transmitter
            instance_comport_transmitter_CDU2.Stop_Bits=STOPBITS_ONE
        elif(com_port13==1):
            instance_comport_transmitter_CDU2.Stop_Bits=STOPBITS_TWO
            
        if(com_port14==0):                               #Transmitter
            instance_comport_transmitter_CDU2.Parity=PARITY_NONE
        elif(com_port14==1):
            instance_comport_transmitter_CDU2.Parity=PARITY_ODD
        elif(com_port14==2):
            instance_comport_transmitter_CDU2.Parity=PARITY_EVEN
        
        master=self.cmb_cdu.GetValue()
        
        print "master----->",master
        value=master.split('DMC') 
##        print value
        CDU_TestRig_MainWindow.close_CDU_flag=int(value[1])
        
##        if(instance_comport_receiver_CDU1.Comport_select==instance_comport_receiver_CDU2.Comport_select):
##            dial = wx.MessageDialog(None, 'Choose different COM Ports for CDU1 and CDU2',
##            'Error!!!', wx.OK|wx.STAY_ON_TOP)
##            dial.ShowModal()
         
        self.path_name= self.txt_log.GetValue()
        CDU_TestRig_MainWindow.CDU_LOG_xls=self.path_name+'\CDU_LOG_file.xls'
##            print "path_name.............>", CDU_TestRig_MainWindow.CDU_LOG_xls
        wtbook = xlwt.Workbook()           # xls file to write CDU status message
        wtsheet =wtbook.add_sheet('Sheet 1') 
        wtbook.save(CDU_TestRig_MainWindow.CDU_LOG_xls)
        rb = xlrd.open_workbook(CDU_TestRig_MainWindow.CDU_LOG_xls, formatting_info=True)
        w=copy(rb)

        display.Log_Heading(w)
      
        CDU_TestRig_MainWindow.IBIT_log_xls=self.path_name+'\log_ibit.xls'
        wtbook = xlwt.Workbook()           # xls file to write IBIT log
        wtsheet = wtbook.add_sheet('Sheet 1') 
        wtbook.save(CDU_TestRig_MainWindow.IBIT_log_xls)
        rb = xlrd.open_workbook(CDU_TestRig_MainWindow.IBIT_log_xls, formatting_info=True)
        w_ibit=copy(rb)
##            print "call connnection1......>"
        CDU_TestRig_MainWindow.class_var3.connnection1()
##        if(CDU_TestRig_MainWindow.close_CDU_flag==1):
        if(instance_comport_receiver_CDU1.Comport_select==instance_comport_transmitter_CDU1.Comport_select):
            if((CDU_TestRig_MainWindow.class_var3.connect_object_GNSS_receiver!='') or \
            (CDU_TestRig_MainWindow.class_var3.connect_object_CDU1_receiver!='')):
                if(instance_comport_receiver_CDU2.Comport_select==instance_comport_transmitter_CDU2.Comport_select):
                    if((CDU_TestRig_MainWindow.class_var3.connect_object_GNSS_receiver!='') or \
                    (CDU_TestRig_MainWindow.class_var3.connect_object_CDU2_receiver!='')):
                        self.Close()
        else:
            if((CDU_TestRig_MainWindow.class_var3.connect_object_GNSS_receiver!='' and \
            CDU_TestRig_MainWindow.class_var3.connect_object_GNSS_transmitter!='') or \
            (CDU_TestRig_MainWindow.class_var3.connect_object_CDU1_receiver!='' and \
            CDU_TestRig_MainWindow.class_var3.connect_object_CDU1_transmitter!='')):
                print "cdu2 diff"
##                    self.Close()
##        elif(CDU_TestRig_MainWindow.close_CDU_flag==2):
        if(instance_comport_receiver_CDU2.Comport_select==instance_comport_transmitter_CDU2.Comport_select):
            if((CDU_TestRig_MainWindow.class_var3.connect_object_GNSS_receiver!='') or \
            (CDU_TestRig_MainWindow.class_var3.connect_object_CDU2_receiver!='')):
                self.Close()
        else:
            if((CDU_TestRig_MainWindow.class_var3.connect_object_GNSS_receiver!='' and \
            CDU_TestRig_MainWindow.class_var3.connect_object_GNSS_transmitter!='') or \
            (CDU_TestRig_MainWindow.class_var3.connect_object_CDU2_receiver!='' and \
            CDU_TestRig_MainWindow.class_var3.connect_object_CDU2_transmitter!='')):
                self.Close()
    
    # Description:
    # Function parameters:
    # Global variables:        

    def OnBrowse(self,event):
        # Create the dialog
##        global path_name
        global filename_GNSS_position_data,filename_GNSS_health_data,filename_GNSS_version_data
        dialog = wx.DirDialog (self,message="Pick a directory...")
        self.path_name=os.getcwd()
        
        dialog.SetPath(self.path_name)
        if dialog.ShowModal() == wx.ID_OK:
            self.path_name=dialog.GetPath()
            self.txt_log.SetValue(self.path_name)
##        CDU_TestRig_MainWindow.class_var3.filename_GNSS_position_data=self.path_name+'/Obtained_GNSS_position_data.csv'
##        CDU_TestRig_MainWindow.class_var3.filename_GNSS_health_data=self.path_name+'/Obtained_GNSS_health_data.csv'
##        CDU_TestRig_MainWindow.class_var3.filename_GNSS_version_data=self.path_name+'/Obtained_GNSS_version_data.csv'
##        CDU_TestRig_MainWindow.class_var3.create_file_GNSS_Data()
        event.Skip()
        
    # Description:
    # Function parameters:
    # Global variables:
            
    def On_Close(self,event):
        CDU_TestRig_MainWindow.COMConfig_Window_flag=0
        self.global_intialisation()
        self.Destroy() 
        event.Skip()

    # Description:
    # Function parameters:
    # Global variables:
        
    def OnCancel_button(self, event):
        CDU_TestRig_MainWindow.COMConfig_Window_flag=0
        self.global_intialisation()
        self.Destroy() 
        event.Skip()
                
class Comport_set_receiver_CDU1(Structure):
	_fields_ = [
	            ("Baud_Rate",c_char_p),
	            ("Stop_Bits", c_uint),          
                ("Parity",c_char_p),          
                ("Data_Bits", c_char_p), 
                ("Comport_select",c_uint ),  
               ]
instance_comport_receiver_CDU1=Comport_set_receiver_CDU1()

class Comport_set_transmitter_CDU1(Structure):
	_fields_ = [
	            ("Baud_Rate",c_char_p),
	            ("Stop_Bits", c_uint),          
                ("Parity",c_char_p),          
                ("Data_Bits", c_char_p), 
                ("Comport_select",c_uint ),  
               ]
instance_comport_transmitter_CDU1=Comport_set_transmitter_CDU1()
#-------------------------------------------------------------------------------

class Comport_set_receiver_CDU2(Structure):
	_fields_ = [
	            ("Baud_Rate",c_char_p),
	            ("Stop_Bits", c_uint),          
                ("Parity",c_char_p),          
                ("Data_Bits", c_char_p), 
                ("Comport_select",c_uint ),  
               ]
instance_comport_receiver_CDU2=Comport_set_receiver_CDU2()

class Comport_set_transmitter_CDU2(Structure):
	_fields_ = [
	            ("Baud_Rate",c_char_p),
	            ("Stop_Bits", c_uint),          
                ("Parity",c_char_p),          
                ("Data_Bits", c_char_p), 
                ("Comport_select",c_uint ),  
               ]
instance_comport_transmitter_CDU2=Comport_set_transmitter_CDU2()