#Boa:Frame:Update_home

import wx
import Update_page
import CDU_TestRig_MainWindow
##import Frame5
##import Frame4

global uphome_no,flag_Update_page

uphome_no=0
flag_Update_page=0

def create(parent):
    return Update_home(parent)

[wxID_FRAME4, wxID_FRAME4BUTTON1, wxID_FRAME4BUTTON2, wxID_FRAME4PANEL1, 
 wxID_FRAME4STATICTEXT1, wxID_FRAME4TEXTCTRL1, 
] = [wx.NewId() for _init_ctrls in range(6)]

class Update_home(wx.Frame):
    def _init_ctrls(self, prnt):
        # generated method, don't edit
        wx.Frame.__init__(self, id=wxID_FRAME4, name='', parent=prnt,
              pos=wx.Point(320, 138), size=wx.Size(414, 131),
              style=wx.DEFAULT_FRAME_STYLE, title='Home Page Details')
        self.SetClientSize(wx.Size(406, 97))
        self.Center()
        self.Bind(wx.EVT_CLOSE, self.On_Close)
        self.update_home_panel = wx.Panel(id=wxID_FRAME4PANEL1, name='update_home_panel', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(406, 97),
              style=wx.TAB_TRAVERSAL)

        self.sta_no_page = wx.StaticText(id=wxID_FRAME4STATICTEXT1,
              label='Enter number of home pages :', name='sta_no_page',
              parent=self.update_home_panel, pos=wx.Point(24, 24), size=wx.Size(146, 13),
              style=0)

        self.txt_no_page = wx.TextCtrl(id=wxID_FRAME4TEXTCTRL1, name='txt_no_page',
              parent=self.update_home_panel, pos=wx.Point(176, 24), size=wx.Size(160, 21),
              style=0, value='')

        self.btn_ok = wx.Button(id=wxID_FRAME4BUTTON1, label='OK',
              name='btn_ok', parent=self.update_home_panel, pos=wx.Point(176, 64),
              size=wx.Size(75, 23), style=0)
        self.btn_ok.Bind(wx.EVT_BUTTON, self.OnOK, id=wxID_FRAME4BUTTON1)

        self.btn_cancel = wx.Button(id=wxID_FRAME4BUTTON2, label='Cancel',
              name='btn_cancel', parent=self.update_home_panel, pos=wx.Point(264, 64),
              size=wx.Size(80, 23), style=0)
        self.btn_cancel.Bind(wx.EVT_BUTTON, self.OnCancel, id=wxID_FRAME4BUTTON2)
        
        self.txt_no_page.SetLabel(str(CDU_TestRig_MainWindow.prev_page))

    def __init__(self, parent):
        self._init_ctrls(parent)
        
    def On_Close(self,event):
        CDU_TestRig_MainWindow.flag_Update_home=0
        self.Destroy()
        CDU_TestRig_MainWindow.update_select=0  
        event.Skip()

    def OnCancel(self, event):
        CDU_TestRig_MainWindow.flag_Update_home=0
        self.Destroy()
        CDU_TestRig_MainWindow.update_select=0 
        event.Skip()

    def OnOK(self, event):
        global uphome_no,main9,flag_Update_page
        uphome_no=self.txt_no_page.GetValue()
        flag=0
        if(uphome_no!=''):
            flag=1
        try:
            if(flag==1):
                uphome_no =int(uphome_no)
                if((uphome_no)>0 and uphome_no<=16): 
                    if(flag_Update_page==0):
                        main9 = Update_page.create(None)
                        main9.Show()
                        flag_Update_page=1
                        CDU_TestRig_MainWindow.flag_Update_home=0
                        self.Destroy()
##                    else:
##                        self.main9.SetFocus()
##                        self.main9.Show()
##                        CDU_TestRig_MainWindow.flag_Update_page=1
                else:
                    dial = wx.MessageDialog(None, "Number of home pages ranges from 1 to 16",\
                    'Error !!!', wx.OK|wx.STAY_ON_TOP)
                    dial.ShowModal()   
             
            elif(flag==0):
                 dial = wx.MessageDialog(None, "Enter number of home pages",\
                'Error !!!', wx.OK|wx.STAY_ON_TOP)
                 dial.ShowModal()  
        except ValueError:
            dial = wx.MessageDialog(None, "Enter integer value",\
            'Error !!!', wx.OK|wx.STAY_ON_TOP)
            dial.ShowModal()  
       
         
        
##        event.Skip()
