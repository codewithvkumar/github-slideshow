#Boa:Frame:Frame3

import wx
import wx.grid
import os
import xlrd
import xlwt
import string
from xlutils.copy import copy
import home_creation
import CDU_TestRig_MainWindow
import Hotkey


global list,x,y,p,page,prev,t,store_main,store_sub,store,store_main1,flag,cursor_col,cursor_row,frequency,repeat,\
filename_xls,q,counter,page_list,index,check_sub,check,page_info,s,g,h,btn_cl1,btn_cl2,btn_cl3,\
btn_cl4,btn_cr1,btn_cr2,btn_cr3,btn_cr4,er_flag,page_txt,new_confirm,Listpage,list_home1,List_page,page_txt1,page_info1\


list=['', ' ', '!' , '"' , '#' ,'$', '%' ,'&', '\'' , '(' , ')' ,'*', '+' , ',' , '-' , '.' , '/' , '0' , '1' ,\
'2' , '3' , '4' , '5' , '6' , '7' , '8' , '9' , ':' , '~' , '<' , '=' , '>' , '?' ,'@', 'A' , 'B' ,\
'C' , 'D' , 'E' , 'F' , 'G' , 'H' , 'I' , 'J' ,'K','L' , 'M' , 'N' , 'O', 'P' , 'Q' , 'R' , 'S' , \
'T' ,'U' , 'V' , 'W' , 'X' , 'Y' , 'Z','[','\'', ']','^','_']

dict={0:'',32:' ',33:'!' , 34:'"' , 35:'#' ,36:'$',37:'%' ,38:'&', 39:'\'' ,40:'(' ,41:')' ,42:'*',43:'+' ,44:',' ,45:'-' ,46:'.' ,47:'/' ,48:'0' ,49:'1' ,\
50:'2' ,51:'3' ,52:'4' ,53:'5' ,54:'6' ,55:'7' ,56:'8' ,57:'9' ,58:':' ,126:'~' ,60:'<' ,61:'=' ,62:'>' ,63:'?' ,64:'@',65:'A' ,66:'B' ,\
67:'C' ,68:'D' ,69:'E' ,70:'F' ,71:'G' ,72:'H' ,73:'I' ,74:'J' ,75:'K',76:'L' ,77:'M' ,78:'N' ,79:'O',80:'P' ,81:'Q' ,82:'R' ,83:'S' , \
84:'T' ,85:'U' ,86:'V' ,87:'W' ,88:'X' ,89:'Y' ,90:'Z',91:'[',92:'\'',93:']',94:'^',95:'_'}

x=-1
y=-1
t=0
prev=0
page=1
flag=0
##flag_save=0
er_flag=0
##flag_error=0
q=0
counter=0
index=0
s=0
g=0
h=1
btn_cl1=0
btn_cl2=0
btn_cl3=0
btn_cl4=0
btn_cr1=0
btn_cr2=0
btn_cr3=0
btn_cr4=0
store_main=[[]]
store_main1=[[]]
store_sub=[]
store=[]
page_list=[]
cursor_col=[]
cursor_row=[]
frequency=[]
repeat=[]
check_sub=[]
check=[]
page_info=[]
page_txt=[]
page_txt1=[]
hotkey_configdetail=[]
new_confirm=0
Listpage=[]
List_page=[]
list_home1=[]
page_info1=[]
##print store_main

def create(parent):
    global my_instance
    my_instance=page_creation(parent)
    return my_instance

[wxID_FRAME3,wxID_FRAME3BUTTON1,wxID_FRAME3BUTTON2,wxID_FRAME3BUTTON3, 
 wxID_FRAME3BUTTON4,wxID_FRAME3BUTTON5,wxID_FRAME3BUTTON6,wxID_FRAME3BUTTON7,
 wxID_FRAME3BUTTON8,wxID_FRAME3BUTTON9,wxID_FRAME3BUTTON10,wxID_FRAME3BUTTON11,
 wxID_FRAME3BUTTON12,wxID_FRAME3BUTTON13,wxID_FRAME3BUTTON14,wxID_FRAME3BUTTON15,wxID_FRAME3BUTTON16,
 wxID_FRAME3GRID1,wxID_FRAME3GRID2,wxID_FRAME3GRID3, wxID_FRAME3PANEL1, wxID_FRAME3STATICTEXT1, 
 wxID_FRAME3STATICTEXT2,wxID_FRAME3STATICTEXT3,wxID_FRAME3STATICTEXT4,
 wxID_FRAME3STATICTEXT5,wxID_FRAME3STATICTEXT6,wxID_FRAME3TEXTCTRL1,wxID_FRAME3TEXTCTRL2, 
 wxID_FRAME3TEXTCTRL3,wxID_FRAME3TEXTCTRL6,wxID_FRAME3USBTBSTATICBOX1,wxID_FRAME3USBTBSTATICBOX2,
 wxID_FRAME3USBTBSTATICBOX3,wxID_FRAME3USBTBSTATICBOX4,
] = [wx.NewId() for _init_ctrls in range(35)]

class page_creation(wx.Frame):
    flag_save=0
    flag_change=0
    def _init_ctrls(self, prnt):
        # generated method, don't edit
##        wx.Frame.__init__(self, style=wx.SYSTEM_MENU | wx.CAPTION | wx.MINIMIZE_BOX|wx.CLOSE_BOX|wx.STAY_ON_TOP|wx.RESIZE_BORDER, name='', parent=prnt, title='Input Window',
##                          pos=wx.Point(self.UUT_input_window_start_x,self.UUT_input_window_start_y), id=wxID_FRAME1, size=wx.Size(self.UUT_input_window_Length, self.UUT_input_window_Width))
    
        wx.Frame.__init__(self, id=wxID_FRAME3, name='', parent=prnt,
              pos=wx.Point(161, 128), size=wx.Size(678, 399),
              style=wx.SYSTEM_MENU | wx.CAPTION | wx.MINIMIZE_BOX|wx.CLOSE_BOX, title='Page Creation')
        self.SetClientSize(wx.Size(657, 420))
##        self.Bind(wx.EVT_CLOSE, self.OnMainFrameClose)
        self.page_creation_panel = wx.Panel(id=wxID_FRAME3PANEL1, name='page_creation_panel', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(657, 420),
              style=wx.TAB_TRAVERSAL)
        self.Center()
        self.main_grid = wx.grid.Grid(id=wxID_FRAME3GRID1, name='main_grid',
              parent=self.page_creation_panel, pos=wx.Point(52, 0), size=wx.Size(550, 257),
              style=0)
        self.main_grid.Bind(wx.grid.EVT_GRID_CELL_LEFT_CLICK, self.Event_handler)
        
        self.sta_bx_color = wx.StaticBox(id=wxID_FRAME3USBTBSTATICBOX1,           # staticbox 1
             label='', name='sta_bx_color', parent=self.page_creation_panel,
             pos=wx.Point(4,258),
             size=wx.Size(305,103), style=0)

        self.bkcolor_grid = wx.grid.Grid(id=wxID_FRAME3GRID2, name='bkcolor_grid',
              parent=self.page_creation_panel, pos=wx.Point(125, 270), size=wx.Size(180, 30),
              style=0)
              
        self.bkcolor_grid.Bind(wx.grid.EVT_GRID_CELL_LEFT_CLICK, self.Event_handler_bkpaint)
        
        self.btn_CL1 = wx.Button(id=wxID_FRAME3BUTTON7, label='CL1',
              name='btn_CL1', parent=self.page_creation_panel, pos=wx.Point(9,32),
              size=wx.Size(33, 22), style=0)
        self.btn_CL1.Bind(wx.EVT_BUTTON, self.OnCL1, id=wxID_FRAME3BUTTON7)
        
        self.btn_CL2= wx.Button(id=wxID_FRAME3BUTTON8, label='CL2',
              name='btn_CL2', parent=self.page_creation_panel, pos=wx.Point(8, 81),
              size=wx.Size(33, 22), style=0)
        self.btn_CL2.Bind(wx.EVT_BUTTON, self.OnCL2, id=wxID_FRAME3BUTTON8)

        self.btn_CL3= wx.Button(id=wxID_FRAME3BUTTON9, label='CL3',
              name='btn_CL3', parent=self.page_creation_panel, pos=wx.Point(8, 130),
              size=wx.Size(33, 22), style=0)
        self.btn_CL3.Bind(wx.EVT_BUTTON, self.OnCL3, id=wxID_FRAME3BUTTON9)
  
        self.btn_CL4 = wx.Button(id=wxID_FRAME3BUTTON10, label='CL4',
              name='btn_CL4', parent=self.page_creation_panel, pos=wx.Point(8, 180),
              size=wx.Size(33, 22), style=0)
        self.btn_CL4.Bind(wx.EVT_BUTTON, self.OnCL4, id=wxID_FRAME3BUTTON10)

        self.btn_CR1 = wx.Button(id=wxID_FRAME3BUTTON11, label='CR1',
              name='btn_CR1', parent=self.page_creation_panel, pos=wx.Point(612, 32),
              size=wx.Size(33, 22), style=0)
        self.btn_CR1.Bind(wx.EVT_BUTTON, self.OnCR1, id=wxID_FRAME3BUTTON11)

        self.btn_CR2 = wx.Button(id=wxID_FRAME3BUTTON12, label='CR2',
              name='btn_CR2', parent=self.page_creation_panel, pos=wx.Point(612, 81),
              size=wx.Size(33, 22), style=0)
        self.btn_CR2.Bind(wx.EVT_BUTTON, self.OnCR2, id=wxID_FRAME3BUTTON12)

        self.btn_CR3 = wx.Button(id=wxID_FRAME3BUTTON13, label='CR3',
              name='btn_CR3', parent=self.page_creation_panel, pos=wx.Point(612, 130),
              size=wx.Size(33, 22), style=0)
        self.btn_CR3.Bind(wx.EVT_BUTTON, self.OnCR3, id=wxID_FRAME3BUTTON13)

        self.btn_CR4 = wx.Button(id=wxID_FRAME3BUTTON14, label='CR4',
              name='btn_CR4', parent=self.page_creation_panel, pos=wx.Point(612, 180),
              size=wx.Size(33, 22), style=0)
        self.btn_CR4.Bind(wx.EVT_BUTTON, self.OnCR4, id=wxID_FRAME3BUTTON14)

        self.sta_bkcolor = wx.StaticText(id=wxID_FRAME3STATICTEXT1,
              label='Background Colour :', name='sta_bkcolor',
              parent=self.page_creation_panel, pos=wx.Point(10,270), size=wx.Size(97, 13),
              style=0)
        self.sta_bkcolor.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD, False,'Tahoma'))

        self.sta_txcolor = wx.StaticText(id=wxID_FRAME3STATICTEXT2,
              label='Text Colour :', name='sta_txcolor', parent=self.page_creation_panel,
              pos=wx.Point(48, 305), size=wx.Size(63, 13), style=0)
              
        self.sta_txcolor.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD, False,'Tahoma'))

        self.txcolor_grid = wx.grid.Grid(id=wxID_FRAME3GRID3, name='txcolor_grid',
              parent=self.page_creation_panel, pos=wx.Point(125, 305), size=wx.Size(180, 30),
              style=0)
              
        self.txcolor_grid.Bind(wx.grid.EVT_GRID_CELL_LEFT_CLICK, self.Event_handler_txpaint)
        
        self.sta_bx_filename = wx.StaticBox(id=wxID_FRAME3USBTBSTATICBOX2,        # staticbox 2
             label='', name='sta_bx_filename', parent=self.page_creation_panel,
             pos=wx.Point(4,365),
             size=wx.Size(650,45), style=0)
             
        self.sta_pageno = wx.StaticText(id=wxID_FRAME3STATICTEXT3,
              label='Page No :', name='sta_pageno', parent=self.page_creation_panel,
              pos=wx.Point(318, 382), size=wx.Size(44, 13), style=0)
              
        self.sta_pageno.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD, False,'Tahoma'))
              
        self.txt_pageno = wx.TextCtrl(id=wxID_FRAME3TEXTCTRL1, name='txt_pageno',
              parent=self.page_creation_panel, pos=wx.Point(372, 380), size=wx.Size(78, 21),
              style=0, value='')
        self.txt_pageno. SetEditable(0)           
              
        self.sta_frequency = wx.StaticText(id=wxID_FRAME3STATICTEXT4,
              label='Frequency :', name='sta_frequency', parent=self.page_creation_panel,
              pos=wx.Point(372, 330), size=wx.Size(58, 13), style=0)
        self.sta_frequency.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD, False,'Tahoma'))
            
        self.txt_frequency = wx.TextCtrl(id=wxID_FRAME3TEXTCTRL2, name='txt_frequency',
              parent=self.page_creation_panel, pos=wx.Point(440, 328), size=wx.Size(38, 21),
              style=0, value='')
              
        self.sta_repeat = wx.StaticText(id=wxID_FRAME3STATICTEXT5,
              label='Repeat :', name='sta_repeat', parent=self.page_creation_panel,
              pos=wx.Point(494, 330), size=wx.Size(42, 13), style=0)
        self.sta_repeat.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD, False,'Tahoma'))
              
        self.txt_repeat = wx.TextCtrl(id=wxID_FRAME3TEXTCTRL3, name='txt_repeat',
              parent=self.page_creation_panel, pos=wx.Point(544, 328), size=wx.Size(38, 21),
              style=0, value='')
              
        self.sta_bx_btn = wx.StaticBox(id=wxID_FRAME3USBTBSTATICBOX3,        # staticbox 3
             label='', name='sta_bx_btn', parent=self.page_creation_panel,
             pos=wx.Point(320,258),
             size=wx.Size(330,47), style=0)
             
        self.sta_bx_freq = wx.StaticBox(id=wxID_FRAME3USBTBSTATICBOX4,        # staticbox 4
             label='', name='sta_bx_freq', parent=self.page_creation_panel,
             pos=wx.Point(320,313),
             size=wx.Size(330,47), style=0)
             
        self.btn_Previous = wx.Button(id=wxID_FRAME3BUTTON1, label='Previous',
              name='btn_Previous', parent=self.page_creation_panel, pos=wx.Point(342, 273),
              size=wx.Size(60, 23), style=0)
        self.btn_Previous.Bind(wx.EVT_BUTTON, self.OnPreviousPage,
              id=wxID_FRAME3BUTTON1)
              
        self.btn_Next = wx.Button(id=wxID_FRAME3BUTTON2, label='Next',
              name='btn_Next', parent=self.page_creation_panel, pos=wx.Point(415, 273),
              size=wx.Size(60, 23), style=0)
        self.btn_Next.Bind(wx.EVT_BUTTON, self.OnNextPage, id=wxID_FRAME3BUTTON2)

        self.btn_Save = wx.Button(id=wxID_FRAME3BUTTON3, label='Save',
              name='btn_Save', parent=self.page_creation_panel, pos=wx.Point(488, 273),
              size=wx.Size(65, 23), style=0)
        self.btn_Save.Bind(wx.EVT_BUTTON, self.OnSave, id=wxID_FRAME3BUTTON3)

        self.btn_Cancel = wx.Button(id=wxID_FRAME3BUTTON4, label='Cancel',
              name='btn_Cancel', parent=self.page_creation_panel, pos=wx.Point(565, 273),
              size=wx.Size(65, 23), style=0)
        self.btn_Cancel.Bind(wx.EVT_BUTTON, self.OnCancel, id=wxID_FRAME3BUTTON4)
        
        self.btn_Blink = wx.Button(id=wxID_FRAME3BUTTON5, label='Blink',
              name='btn_Blink', parent=self.page_creation_panel, pos=wx.Point(115, 335),
              size=wx.Size(44, 23), style=0)
        self.btn_Blink.Bind(wx.EVT_BUTTON, self.OnBlink, id=wxID_FRAME3BUTTON5)
        
        self.sta_Filename = wx.StaticText(id=wxID_FRAME3STATICTEXT6,
              label='File name :', name='sta_Filename', parent=self.page_creation_panel,
              pos=wx.Point(14, 380), size=wx.Size(52, 13), style=0)
        self.sta_Filename.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD, False,'Tahoma'))
              
        self.txt_Filename = wx.TextCtrl(id=wxID_FRAME3TEXTCTRL6, name='txt_Filename',
              parent=self.page_creation_panel, pos=wx.Point(75, 380), size=wx.Size(220, 21),
              style=0, value='')
        self.txt_Filename.SetEditable(0)
        
        self.btn_Hotkeys = wx.Button(id=wxID_FRAME3BUTTON15, label='Configure Hotkeys',
              name='btn_Hotkeys', parent=self.page_creation_panel, pos=wx.Point(470, 380),
              size=wx.Size(120, 22), style=0)
        self.btn_Hotkeys.Bind(wx.EVT_BUTTON, self.Hotkey, id=wxID_FRAME3BUTTON15)
##        self.txt_Filename.SetCellAlignment(wx.ALIGN_RIGHT,wx.ALIGN_RIGHT)
             
        self.Bind(wx.EVT_CLOSE, self.On_Close)
        
        self.Create_grids()             # Function calls
        self.Create_grids_bkpaint()
        self.Create_grids_txpaint()
        self.btn_Previous.Disable()
        
        self.writetobook  = xlwt.Workbook()           # xls file to write into it
        self.writetosheet= self.writetobook .add_sheet('Sheet 1') 
        self.writetobook .save('filename_xls')
        self.read_book  = xlrd.open_workbook('filename_xls', formatting_info=True)
        self.write_obj=copy(self.read_book )
        
        self.txt_pageno.SetValue(str("Home1"))   # To set initial values
        self.txt_frequency.SetValue(str(80))
        self.txt_repeat.SetValue(str(1))
        list_home1.append("Home1")
##        list_page.append("Home1")
##        self.page_txt=[]
        for i in range(9):
            for j in range(21):
                self.main_grid.SetCellTextColour( i,j,"red");
                self.main_grid.SetCellBackgroundColour( i,j,"black");
               
    def __init__(self, parent):
        self._init_ctrls(parent)
        
    # Description: This function will be called on close of this frame and on 
    #              click of cancel button, to restore all global variable defult values.
    # Function parameters: None
    # Global variables: list,x,y,p,page,prev,t,store_main,store_sub,store,store_main1,
    #                   flag,cursor_col,cursor_row,frequency,repeat,filename_xls,q,
    #                   counter,page_list,index,check_sub,check,page_info,s,g,h,btn_cl1,btn_cl2,
    #                   btn_cl3,btn_cl4,btn_cr1,btn_cr2,btn_cr3,btn_cr4,list_page,page_txt,er_flag
                        
    def global_initialisation(self):        
        global list,x,y,p,page,prev,t,store_main,store_sub,store,store_main1,flag,cursor_col,cursor_row,frequency,repeat,\
        filename_xls,q,counter,page_list,index,check_sub,check,page_info,s,g,h,btn_cl1,btn_cl2,btn_cl3,\
        btn_cl4,btn_cr1,btn_cr2,btn_cr3,btn_cr4,list_page,page_txt,er_flag
        x=-1
        y=-1
        t=0
        prev=0
        page=1
        flag=0
##        flag_error=0
        er_flag=0
        q=0
        counter=0
        index=0
        s=0
        g=0
        h=1
        btn_cl1=0
        btn_cl2=0
        btn_cl3=0
        btn_cl4=0
        btn_cr1=0
        btn_cr2=0
        btn_cr3=0
        btn_cr4=0
##        flag_save=0
        store_main=[[]]
        store_main1=[[]]
        store_sub=[]
        store=[]
        page_list=[]
        cursor_col=[]
        cursor_row=[]
        frequency=[]
        repeat=[]
        check_sub=[]
        check=[]
        page_info=[]
        page_txt=[]
        list_page=[]
        
    # Description: This function will be called to create grid of 9 rows and 21 columns.
    # Function parameters: None
    # Global variables: None
        
    def Create_grids(self):             # To create main_grid
        self.main_grid.CreateGrid(9,21) 
        self.main_grid.DisableDragGridSize()
        self.main_grid.DisableDragColSize()
        self.main_grid.DisableDragRowSize()
        for i in range (21):
            self.main_grid.SetColLabelValue(i,str(i+1))
        for i in range (9):
             for j in range (21):
                self.main_grid.SetRowSize( i, 25 );   
                self.main_grid.SetColSize( j, 25 ); 
                self.main_grid.SetCellAlignment(i,j,wx.ALIGN_CENTRE,wx.ALIGN_CENTRE)
                self.main_grid.SetCellFont(i,j,wx.Font(15, wx.SWISS, wx.NORMAL, wx.BOLD))
        self.main_grid.SetRowLabelSize(25)
        self.main_grid.SetColLabelSize(30)
        self.main_grid.SetRowSize(i,1)
        
    # Description: This function will be called to create grid of 1 rows and 9 columns.
    # Function parameters: None
    # Global variables: None
            
    def Create_grids_bkpaint(self):        #To create background_colour grid
        self.bkcolor_grid.CreateGrid(1,9)
        self.bkcolor_grid.DisableDragGridSize()
        self.bkcolor_grid.DisableDragColSize()
        self.bkcolor_grid.DisableDragRowSize()
        self.bkcolor_grid.SetCellBackgroundColour( 0,0,"white");
        self.bkcolor_grid.SetCellBackgroundColour( 0,1,"green");
        self.bkcolor_grid.SetCellBackgroundColour( 0,2,"gray");
        self.bkcolor_grid.SetCellBackgroundColour( 0,3,(255, 170, 0));
        self.bkcolor_grid.SetCellBackgroundColour( 0,4,"cyan");
        self.bkcolor_grid.SetCellBackgroundColour( 0,5,"magenta");
        self.bkcolor_grid.SetCellBackgroundColour( 0,6,"yellow");
        self.bkcolor_grid.SetCellBackgroundColour( 0,7,"red");
        self.bkcolor_grid.SetCellBackgroundColour( 0,8,"black");
        for k in range (9):
            self.bkcolor_grid.SetColSize( k, 20);
            self.bkcolor_grid.SetReadOnly(0,k);
        self.bkcolor_grid.SetRowSize( 0, 20 );
        self.bkcolor_grid.SetRowLabelSize(0)
        self.bkcolor_grid.SetColLabelSize(0)
    
    # Description: This function will be called to create grid of 1 rows and 8 columns.
    # Function parameters:
    # Global variables:
                       
    def Create_grids_txpaint(self):     #To create text_colour grid
        self.txcolor_grid.CreateGrid(1,8)
        self.txcolor_grid.DisableDragGridSize()
        self.txcolor_grid.DisableDragColSize()
        self.txcolor_grid.DisableDragRowSize()
        self.txcolor_grid.SetCellBackgroundColour( 0,0,"white");
        self.txcolor_grid.SetCellBackgroundColour( 0,1,"green");
        self.txcolor_grid.SetCellBackgroundColour( 0,2,"gray");
        self.txcolor_grid.SetCellBackgroundColour( 0,3,(255, 170, 0));
        self.txcolor_grid.SetCellBackgroundColour( 0,4,"cyan");
        self.txcolor_grid.SetCellBackgroundColour( 0,5,"magenta");
        self.txcolor_grid.SetCellBackgroundColour( 0,6,"yellow");
        self.txcolor_grid.SetCellBackgroundColour( 0,7,"red");
        for k in range (8):
            self.txcolor_grid.SetColSize( k, 22); 
            self.txcolor_grid.SetReadOnly(0,k);
        self.txcolor_grid.SetRowSize( 0, 20 );
        self.txcolor_grid.SetRowLabelSize(0)
        self.txcolor_grid.SetColLabelSize(0)
        
    # Description: This event handler function called
    # Function parameters:
    # Global variables:
               
    def Event_handler(self,evt):    # Event to get x,y co-ordinate of the grid
        global x,y
        x=evt.GetRow()
        y=evt.GetCol() 
        self.flag_change=0      
        evt.Skip()
    
    # Description:
    # Function parameters:
    # Global variables:
            
    def Event_handler_bkpaint(self,evt):    # To get background colour
        global x,y
##        print x,y
        m=evt.GetRow()
        n=evt.GetCol()
##        print m,n
        bkColour=self.bkcolor_grid.GetCellBackgroundColour(m,n)
##        print bkColour
        if(x!=-1 and y!=-1):
            self.main_grid.SetCellBackgroundColour( x,y,bkColour)
            self.main_grid.SetGridCursor(x,y)
        
        evt.Skip()
    
    # Description:
    # Function parameters:
    # Global variables:
                   
    def Event_handler_txpaint(self,evt):       # To get text colour
        global x,y
        a=evt.GetRow()
        b=evt.GetCol()
        
        bkColour=self.bkcolor_grid.GetCellBackgroundColour(a,b)
        if(x!=-1 and y!=-1):
            self.main_grid.SetCellTextColour(x,y,bkColour)
            self.main_grid.SetGridCursor(x,y)
                  
        evt.Skip()
    
    # Description:
    # Function parameters:
    # Global variables:
            
    def OnBlink(self, event):       # To apply blink to grid content
        a=self.main_grid.GetCellFont(x,y)
        font_style=a.GetStyle()
        if(x!=-1 and y!=-1):
            if(font_style==90):
                self.main_grid.SetCellFont(x,y,wx.Font(15, wx.SWISS, wx.ITALIC, wx.NORMAL))
            else:
                self.main_grid.SetCellFont(x,y,wx.Font(15, wx.SWISS, wx.NORMAL, wx.BOLD))
            self.main_grid.SetGridCursor(x,y)
        
        event.Skip()
    
    # Description:
    # Function parameters:
    # Global variables:
            
    def OnPreviousPage(self, event): 
        global list,store,store_sub,store_main,page,store_main1,flag,new_confirm
        y=0
        print "previous..........>"
        new_confirm=1
        CDU_TestRig_MainWindow.page_var=0
        
##        for i in range (9):
##            for j in range (21):
##                self.main_grid.SetCellBackgroundColour( i,j,"black")
        self.create_list(y)   # To store grid content into list
        self.create_hotlist()                    
        page_no=page
        
        for i in range(9):     # Displays list content into grid
            for j in range(21):
                value=store_main[page_no-1][i][j]
                blink=value%2
                if(blink==0):
                    self.main_grid.SetCellFont(i,j,wx.Font(15, wx.SWISS, wx.NORMAL, wx.BOLD))
                elif(blink==1):
                    self.main_grid.SetCellFont(i,j,wx.Font(15, wx.SWISS, wx.ITALIC, wx.NORMAL))
                else:
                    print "a"
                temp1=value/2
                temp2=temp1%128
                self.main_grid.SetCellValue(i,j,dict[temp2])
                temp3=temp1/128
                temp4=temp3%16
              
                if(temp4==15):                                                   
                    self.main_grid.SetCellTextColour( i,j,"black");
                elif(temp4==8):
                    self.main_grid.SetCellTextColour( i,j,"red");
                elif(temp4==7):
                    self.main_grid.SetCellTextColour( i,j,"yellow");
                elif(temp4==6):
                    self.main_grid.SetCellTextColour( i,j,"magenta");
                elif(temp4==5):
                    self.main_grid.SetCellTextColour( i,j,"cyan");
                elif(temp4==4):
                    self.main_grid.SetCellTextColour( i,j,(255, 170, 0));
                elif(temp4==2):
                    self.main_grid.SetCellTextColour( i,j,"gray");
                elif(temp4==1):
                    self.main_grid.SetCellTextColour( i,j,"green");
                else:
                    self.main_grid.SetCellTextColour( i,j,"white");
                
                temp4=temp3/16
                temp5=temp4%16
                if(temp5==15):
                    self.main_grid.SetCellBackgroundColour( i,j,"black")
                elif(temp5==8):
                    self.main_grid.SetCellBackgroundColour( i,j,"red")
                elif(temp5==7):
                    self.main_grid.SetCellBackgroundColour( i,j,"yellow")
                elif(temp5==6):
                    self.main_grid.SetCellBackgroundColour( i,j,"magenta")
                elif(temp5==5):
                    self.main_grid.SetCellBackgroundColour( i,j,"cyan")
                elif(temp5==4):
                    self.main_grid.SetCellBackgroundColour( i,j,(255, 170, 0))
                elif(temp5==2):
                    self.main_grid.SetCellBackgroundColour( i,j,"gray")
                elif(temp5==1):
                    self.main_grid.SetCellBackgroundColour( i,j,"green")
                else:
                    self.main_grid.SetCellBackgroundColour( i,j,"white")
   
        event.Skip()
    
    # Description:
    # Function parameters:
    # Global variables:
            
    def OnNextPage(self, event):  
        global list,store,store_sub,store_main,page,flag,\
        frequency1,counter,index,new_confirm,list_page
        y=1  
        new_confirm=1
##        for i in range (9):
##            for j in range (21):
##                self.main_grid.SetCellBackgroundColour( i,j,"black")
        self.create_list(y)   # To store grid containt into list
        self.create_hotlist()
        home_creation.home_flag=0         
        page_no=page
        if(len(store_main)>page_no):
            print "next page............>"
##            print store_main  
            if(store_main[page-1]!=[]): 
                for i in range(9):                 # Displays list content into grid
                    for j in range(21):
                        value=store_main[page-1][i][j]
                        blink=value%2
                        if(blink==0):
                            self.main_grid.SetCellFont(i,j,wx.Font(15, wx.SWISS, wx.NORMAL, wx.BOLD))
                        elif(blink==1):
                            self.main_grid.SetCellFont(i,j,wx.Font(15, wx.SWISS, wx.ITALIC, wx.NORMAL))
                        else:
                            print "b"
                        temp1=value/2
                        temp2=temp1%128
                        self.main_grid.SetCellValue(i,j,dict[temp2])
                        temp3=temp1/128
                        temp4=temp3%16
                        if(temp4==8):
                            self.main_grid.SetCellTextColour( i,j,"red");
                        elif(temp4==7):
                            self.main_grid.SetCellTextColour( i,j,"yellow");
                        elif(temp4==6):
                            self.main_grid.SetCellTextColour( i,j,"magenta");
                        elif(temp4==5):
                            self.main_grid.SetCellTextColour( i,j,"cyan");
                        elif(temp4==4):
                            self.main_grid.SetCellTextColour( i,j,(255, 170, 0));
                        elif(temp4==2):
                            self.main_grid.SetCellTextColour( i,j,"gray");
                        elif(temp4==1):
                            self.main_grid.SetCellTextColour( i,j,"green");
                        elif(temp4==0):
                            self.main_grid.SetCellTextColour( i,j,"white");
                        else:
                            self.main_grid.SetCellTextColour( i,j,"black");
                
                        temp4=temp3/16
                        temp5=temp4%16
                        if(temp5==8):
                            self.main_grid.SetCellBackgroundColour( i,j,"red");
                        elif(temp5==7):
                            self.main_grid.SetCellBackgroundColour( i,j,"yellow");
                        elif(temp5==6):
                            self.main_grid.SetCellBackgroundColour( i,j,"magenta");
                        elif(temp5==5):
                            self.main_grid.SetCellBackgroundColour( i,j,"cyan");
                        elif(temp5==4):
                            self.main_grid.SetCellBackgroundColour( i,j,(255, 170, 0));
                        elif(temp5==2):
                            self.main_grid.SetCellBackgroundColour( i,j,"gray");
                        elif(temp5==1):
                            self.main_grid.SetCellBackgroundColour( i,j,"green");
                        elif(temp5==0):
                            self.main_grid.SetCellBackgroundColour( i,j,"white");
                        else:
                            self.main_grid.SetCellBackgroundColour( i,j,"black");
        event.Skip()
    
    # Description:
    # Function parameters:
    # Global variables:
        
    def OnSave(self, event):
        global list,store,store_sub,store_main,page,cursor_col,cursor_row,frequency,repeat,\
        check,page_info,h,filename_xls,er_flag
        list_check=[0,0,0,0,0,0,0,0]
        t=0
        s=0
        y=2
        q=1
        f=0
        print "store_main",store_main
        for i in range (9):
            for j in range (21):
                self.main_grid.SetCellBackgroundColour( i,j,"black")
        
        self.create_list(y)
        self.create_hotlist()
        print "er_flag at save-------------->",er_flag
##        print "flag_error--------------->",flag_error
        print "cursor_col",cursor_col
        print "cursor_row",cursor_row
      
        if(self.flag_save==0 and er_flag==0):                    # To display browser window
            dlg = wx.FileDialog(self, "Choose a file", ".", "", "*.xls", wx.SAVE)
            if dlg.ShowModal() == wx.ID_OK:
                global browse
                browse=1
                filename_xls = dlg.GetPath()
                self.flag_save=1
                self.flag_change=1
                
        if(self.flag_save==1):                   # Once file is selected,next time onwards it saves to same file
            filename_xls=filename_xls
              
##        self.create_list(y)
            number=home_creation.home_no
            cur_home=int(h)-1
            if(number==2 and page==1):
                cur_home=int(h)-2
            if(cur_home==int(number)):           # if all pages are created as per total no of home pages
                self.write_obj.get_sheet(0).write(0,0,'Page')
                self.write_obj.get_sheet(0).write(0,1,page_info[0])
                self.write_obj.get_sheet(0).write(0,2,'Frequency')
                self.write_obj.get_sheet(0).write(0,3,frequency[0])
                self.write_obj.get_sheet(0).write(0,4,'Repeat')
                self.write_obj.get_sheet(0).write(0,5,repeat[0]) 
                self.write_obj.get_sheet(0).write(0,6,'Cursor Position')
                self.write_obj.get_sheet(0).write(0,7,cursor_row[0])
                self.write_obj.get_sheet(0).write(0,8,cursor_col[0])
                
                for i in range(len(store_main)-1):
                    for j in range(9):
                        for k in range(21): 
                            self.write_obj.get_sheet(0).write(j+1+t,k+1,store_main[i][j][k])
                    if(q<len(frequency) and q<len(store_main)-1):
                        self.write_obj.get_sheet(0).write(((i+1)+(10*(i+1))),0,'Page')
                        self.write_obj.get_sheet(0).write(((i+1)+(10*(i+1))),1,page_info[q])
                        self.write_obj.get_sheet(0).write(((i+1)+(10*(i+1))),2,'Frequency')
                        self.write_obj.get_sheet(0).write(((i+1)+(10*(i+1))),3,frequency[q])
                        self.write_obj.get_sheet(0).write(((i+1)+(10*(i+1))),4,'Repeat')
                        self.write_obj.get_sheet(0).write(((i+1)+(10*(i+1))),5,repeat[q]) 
                        self.write_obj.get_sheet(0).write(((i+1)+(10*(i+1))),6,'Cursor Position') 
                        self.write_obj.get_sheet(0).write(((i+1)+(10*(i+1))),7,cursor_row[q])
                        self.write_obj.get_sheet(0).write(((i+1)+(10*(i+1))),8,cursor_col[q])   
                    self.write_obj.get_sheet(0).write((t+1),0,check[s][0])
                    self.write_obj.get_sheet(0).write((t+3),0,check[s][1])
                    self.write_obj.get_sheet(0).write((t+5),0,check[s][2])
                    self.write_obj.get_sheet(0).write((t+7),0,check[s][3])
                    self.write_obj.get_sheet(0).write((t+1),22,check[s][4])
                    self.write_obj.get_sheet(0).write((t+3),22,check[s][5])
                    self.write_obj.get_sheet(0).write((t+5),22,check[s][6])
                    self.write_obj.get_sheet(0).write((t+7),22,check[s][7])
                    s=s+1
                    t=t+11
                    q=q+1
            else:                            # if all pages are not created as per total no of home pages
                for i in range(9):
                    for j in range(21):
                        store.append(63488)
                    store_sub.append(store)
                    store=[]
                    
                for h in range(int(h),int(number)+1): # To generate not created page number info
                    x=(h)
                    x=x*4096
                    page_info.append(x)
                    
                for h in range(len(frequency),len(page_info)):  # To generate not created page frequency,
                    frequency.append(80)                        # repeat,cursor_row,cursor_col,check
                    repeat.append(1)                            # and empty page content
                    cursor_row.append(0)
                    cursor_col.append(0)
                    check.append(list_check)
                    store_main.insert((page+f),store_sub)
                    f=f+1
                self.write_obj.get_sheet(0).write(0,0,'Page')           # write into xls sheet
                self.write_obj.get_sheet(0).write(0,1,page_info[0])
                self.write_obj.get_sheet(0).write(0,2,'Frequency')
                self.write_obj.get_sheet(0).write(0,3,frequency[0])
                self.write_obj.get_sheet(0).write(0,4,'Repeat')
                self.write_obj.get_sheet(0).write(0,5,repeat[0]) 
                self.write_obj.get_sheet(0).write(0,6,'Cursor Position')
                self.write_obj.get_sheet(0).write(0,7,cursor_row[0])
                self.write_obj.get_sheet(0).write(0,8,cursor_col[0])
                
                for i in range(len(store_main)-1):
                    for j in range(9):
                        for k in range(21): 
                            self.write_obj.get_sheet(0).write(j+1+t,k+1,store_main[i][j][k])
                    if(q<len(frequency) and q<len(store_main)-1 and q<len(page_info) ):
                        self.write_obj.get_sheet(0).write(((i+1)+(10*(i+1))),0,'Page')
                        self.write_obj.get_sheet(0).write(((i+1)+(10*(i+1))),1,page_info[q])
                        self.write_obj.get_sheet(0).write(((i+1)+(10*(i+1))),2,'Frequency')
                        self.write_obj.get_sheet(0).write(((i+1)+(10*(i+1))),3,frequency[q])
                        self.write_obj.get_sheet(0).write(((i+1)+(10*(i+1))),4,'Repeat')
                        self.write_obj.get_sheet(0).write(((i+1)+(10*(i+1))),5,repeat[q]) 
                        self.write_obj.get_sheet(0).write(((i+1)+(10*(i+1))),6,'Cursor Position') 
                        self.write_obj.get_sheet(0).write(((i+1)+(10*(i+1))),7,cursor_row[q])
                        self.write_obj.get_sheet(0).write(((i+1)+(10*(i+1))),8,cursor_col[q])
                    
                    self.write_obj.get_sheet(0).write((t+1),0,check[s][0])
                    self.write_obj.get_sheet(0).write((t+3),0,check[s][1])
                    self.write_obj.get_sheet(0).write((t+5),0,check[s][2])
                    self.write_obj.get_sheet(0).write((t+7),0,check[s][3])
                    self.write_obj.get_sheet(0).write((t+1),22,check[s][4])
                    self.write_obj.get_sheet(0).write((t+3),22,check[s][5])
                    self.write_obj.get_sheet(0).write((t+5),22,check[s][6])
                    self.write_obj.get_sheet(0).write((t+7),22,check[s][7])
                    s=s+1
                    t=t+11
                    q=q+1
        
            self.write_obj.save(filename_xls)
            self.txt_Filename.SetValue(filename_xls)
##        print page_txt 
            head=os.path.split(filename_xls)
            pathnfile=os.path.join(head[0],"CDUHOTKEY.xls")
            print "pathnfile",pathnfile
            if os.path.exists(pathnfile)==True:
                self.var_exist=0
                self.writetoxls(pathnfile,head)
            else:
                writetobook  = xlwt.Workbook()           # xls file to write into it 
                writetosheet= writetobook .add_sheet(u'First')
                writetobook.save(pathnfile)
                self.var_exist=1
                self.writetoxls(pathnfile,head) 
        event.Skip() 
    
    # Description:
    # Function parameters:
    # Global variables:
               
    def writetoxls(self,pathnfile,head):
        global page_txt
        list4=['Nopage','Nopage','Nopage','Nopage','Nopage','Nopage','Nopage','Nopage']
        xls_list=[] 
        valtohome=[]
        list1=[]
        list1.append(head[1])
##        print page_info,"page_info"
##        if (len(Hotkey.configkey)==0):
        for i in range(len(page_info)):
            val=hex(page_info[i])
            if val>'0x9000':
                val1=val.split('00')
                val6=str(int(val1[0],16))
                val7=val6+'000'
                
                print "va",val,val1
                val4=int(val7)
            else:    
                val1=val.split('0x')
                val4=int(val1[1])
##                print val,val1
                if (val4%1000==0): 
                    val2=val4/1000
                    valtohome.append("Home{0}".format(val2))
                else:
                    val2=val4/1000
                    val3=(val4%1000)/100
                    if val3<=4:
                       valtohome.append('Home{0}-CL{0}'.format(val2,val3))  
                    else:
                       valtohome.append('Home{0}-CR{0}'.format(val2,val3))  
            Hotkey.configkey=valtohome                
        read_book  = xlrd.open_workbook(pathnfile, formatting_info=True)
##        print "head" ,head[1],Hotkey.hot_list
        write_obj=copy(read_book )
        sheet=read_book .sheet_by_index(0)
        rows, cols = sheet.nrows, sheet.ncols
        if (self.var_exist==1):  
            for index in range(rows,rows+1):
                for index1 in range(1):
                    write_obj.get_sheet(0).write(rows,index1,head[1])
##                    print "head[1]",head[1]
                for index1 in range(1,8):
                    if len(Hotkey.hot_list)==0:
                        Hotkey.hot_list=list4
                        write_obj.get_sheet(0).write(rows,index1,Hotkey.hot_list[index1-1])
                    else: 
                        write_obj.get_sheet(0).write(rows,index1,Hotkey.hot_list[index1-1])
                for index2 in range(8,len(Hotkey.configkey)+8):
                    write_obj.get_sheet(0).write(rows,index2,Hotkey.configkey[index2-8])
            write_obj.save(pathnfile)        
        elif(self.var_exist==0):            
            for i in range(rows):
                read_row=sheet.row_values(i)
##                print read_row,read_row[0],head[1],str(head[1])
                xls_list.append(read_row[0])
##            print xls_list
##            print list
            if list1[0] in xls_list:
                var=xls_list.index(list1[0])
##                print var
                list1=[]
                
##            if read_row[0]==str(head[1]):
                i=rows
##                print "hhhhhhhhhhhhhhhhh"
                for i in range(len(read_row)):
                    write_obj.get_sheet(0).write(var,i+1,'')
                for index1 in range(1,8):
                    if len(Hotkey.hot_list)==0:
                        Hotkey.hot_list=list4
                        write_obj.get_sheet(0).write(var,index1,Hotkey.hot_list[index1-1])
                    else: 
                        write_obj.get_sheet(0).write(var,index1,Hotkey.hot_list[index1-1])
                for index2 in range(8,len(Hotkey.configkey)+8):
                    write_obj.get_sheet(0).write(var,index2,Hotkey.configkey[index2-8]) 
##                print len(Hotkey.configkey)      
            else:
                list1=[]
                
##                print "jjjjjjjjjeeeeeeeeeeee"
                for index in range(rows,rows+1):
                    for index1 in range(1):
                        write_obj.get_sheet(0).write(rows,index1,head[1])
##                        print "head[1]",head[1]
                    for index1 in range(1,8):
                        if len(Hotkey.hot_list)==0:
                            Hotkey.hot_list=list4
                            write_obj.get_sheet(0).write(rows,index1,Hotkey.hot_list[index1-1])
                        else:      
                            write_obj.get_sheet(0).write(rows,index1,Hotkey.hot_list[index1-1])
                    Hotkey.hot_list=[]
                    for index2 in range(8,len(Hotkey.configkey)+8):
                        write_obj.get_sheet(0).write(rows,index2,Hotkey.configkey[index2-8])                             
            write_obj.save(pathnfile)

    # Description:
    # Function parameters:
    # Global variables:
                        
    def create_list(self,y): 
        global list,store,store_sub,store_main,page,store_main1,store1,cursor_col,cursor_row,frequency,repeat,q,\
        check,page_info,h,btn_cl1,btn_cl2,btn_cl3,btn_cl4,btn_cr1,btn_cr2,btn_cr3,btn_cr4,er_flag,page_txt,\
        new_confirm
        k=0
        flag=0
        flag_check=0
        flag_error=0
        er_flag=0
        store1=[]
        store_c=[]
        store_subc=[]
        grid_colour=bin(0)
        
        self.btn_Previous.Enable()
        self.btn_Next.Enable()
        
        self.check_box()          # Call to checkbox function to get check clicks
        
        change_checki=[]
        change_checkd=[]
        temp_page_info=[]
        temp_page_info=page_info
        page_info=[]
        page_txt=[]                        
        counter=0
        frq_flag=0
        h=1
        p=0
        page_no=page
        page_txt.append("Home{0}".format(h))    # To store page sequence in list
        x=(h)
        x=x*4096
        page_info.append(x)
        h=h+1 
        print "check",check
        for i in range(len(check)):
            for j in range(8):
                if(check[i][j]==1):
                    if(j<4):
                        page_txt.append("Home{0}-CL{1}".format(h-1,(j+1)))
                    else:
                        temp=(j+1)-4
                        page_txt.append("Home{0}-CR{1}".format(h-1,(temp)))
                    counter=counter+1
                    x=(h-1)
                    x=x*4096
                    z=(j+1)
                    z=z*256
                    x=x+z
                    page_info.append(x)      # To page no in 16 bit format
                           
            if(i==(counter+p)):
                p=p+1
                number=home_creation.home_no
##                print "h-{0} home-{1} y-{2} ".format(h,home_creation.home_no,y)
                if(int(h) <= int(number)):      # To check pages are within no of home pages
                    page_txt.append("Home{0}".format(h))
                    x=(h)
                    x=x*4096
##                    print "HOME{0}-{1}".format(h,x)
                    page_info.append(x)          # To page no in 16 bit format  
                    h=h+1 
                else:
                    pg=page
                    if(y==0 and pg-1==len(check)):       # On previous page click
                        flag_error=1
                        dial = wx.MessageDialog(None, "End of the page",\
                        'Error !!!', wx.OK|wx.STAY_ON_TOP)
                        dial.ShowModal() 
                    if(y==1 and pg==len(check)):        # on next page click
                        flag_error=1
                        self.btn_Next.Disable()
                        dial = wx.MessageDialog(None, "Next page is not present",\
                        'Error !!!', wx.OK|wx.STAY_ON_TOP)
                        dial.ShowModal() 
                    break 
##        print "h at create list....>",h
##        print page_info
        print page_txt  
        
        page_text=str(self.txt_pageno.GetValue())
        if(len(page_info)>len(temp_page_info) and len(page_text)<7 and len(temp_page_info)!=0 ):     # insertion subpages
            for i in range(len(page_info)):
                if(k<len(temp_page_info) and page_info[i]==temp_page_info[k]):
                    k=k+1
                else:
                    change_checki.append(page_info[i])
                    flag_check=1 
##                    print "change_checki{0}".format(change_checki) 
            
        if(len(page_info)<len(temp_page_info) and len(page_text)<7):     # deletion subpages
##            print "temp_page_info{0}".format(temp_page_info) 
##            print "page_info{0}".format(page_info)      
            for i in range(len(temp_page_info)):
                if(k<len(page_info) and temp_page_info[i]==page_info[k]):
                    k=k+1
                else:
                    change_checkd.append(temp_page_info[i])    # mismatch check list is added for deletion
                    flag_check=2 
##            print "change_checkd{0}".format(change_checkd) 
        if(flag_check==1):         # To insert empty page at specific position
            store_subc=[] 
            for i in range(9):
                for j in range(21):
                    store_c.append(63488)
                store_subc.append(store_c)
                store_c=[]     
            m=0   
            for i in range(len(page_info)):
                if(m<len(change_checki) and change_checki[m]==page_info[i]):
                    store_main.insert(i,store_subc)  
                    m=m+1
                else:
                    print "To insert empty page at specific position"            
            
        if(flag_check==2):      # Delete page at specific postion
            m=0  
            k=0    
##            print "change_checkd{0}".format(change_checkd) 
##            print "temp_page_info{0}".format(temp_page_info)        
            for i in range(len(temp_page_info)):
                if(m<len(change_checkd) and change_checkd[m]==temp_page_info[i]):
                    if new_confirm==1:  
                        del store_main[i-k] 
                        m=m+1
                        k=k+1
                else:
                    print "Delete page at specific postion"                  
##        print store_main  
              
        for i in range(9):  # Read grid content and checks valid/invalid
            flag=0
            for j in range(21):
                flag=0
                value=str(self.main_grid.GetCellValue(i, j))
                k=0
                while(flag!=1 and k<len(list)):
                    if(value==list[k]):     # check grid value is valid
                        flag=1  
                        bkColour=self.main_grid.GetCellBackgroundColour(i,j)
##                        print "bkColour",bkColour
                        txcolour=self.main_grid.GetCellTextColour(i,j)
##                        print "txcolour",txcolour
                        a=self.main_grid.GetCellFont(i,j)
                        font_style=a.GetStyle()
                        if(bkColour[0]== 255 and bkColour[1]==255 and bkColour[2]==255 ):
                            print "white",i,j
                            grid_colour='0000'
                        elif(bkColour[0]== 0 and bkColour[1]==255 and bkColour[2]==0):
                            grid_colour='0001'
                        elif(bkColour[0]== 128 and bkColour[1]==128 and bkColour[2]==128):
                            grid_colour='0010'
                        elif(bkColour[0]== 255 and bkColour[1]==170 and bkColour[2]==0):
                            grid_colour='0100'
                        elif(bkColour[0]== 0 and bkColour[1]==255 and bkColour[2]==255 ):
                            grid_colour='0101'
                        elif(bkColour[0]== 255 and bkColour[1]==0 and bkColour[2]==255):
                            grid_colour='0110'
                        elif(bkColour[0]==255 and bkColour[1]==255 and bkColour[2]==0 ):
                            grid_colour='0111'
                        elif(bkColour[0]==255 and bkColour[1]==0 and bkColour[2]==0 ):
                            grid_colour='1000'
                        else:
                            grid_colour='1111'
                            
                        if(txcolour[0]==255 and txcolour[1]==255 and txcolour[2]==255 ):
                            grid_colour=grid_colour+'0000'
                        elif(txcolour[0]==0 and txcolour[1]==255 and txcolour[2]==0 ):
                            grid_colour=grid_colour+'0001'
                        elif(txcolour[0]==128 and txcolour[1]==128 and txcolour[2]==128 ):
                            grid_colour=grid_colour+'0010'
                        elif(txcolour[0]==255 and txcolour[1]==170 and txcolour[2]==0 ):
                            grid_colour=grid_colour+'0100'
                        elif(txcolour[0]==0 and txcolour[1]==255 and txcolour[2]==255 ):
                            grid_colour=grid_colour+'0101'
                        elif(txcolour[0]==255 and txcolour[1]==0 and txcolour[2]==255 ):
                            grid_colour=grid_colour+'0110'
                        elif(txcolour[0]==255 and txcolour[1]==255 and txcolour[2]==0 ):
                            grid_colour=grid_colour+'0111'
                        elif(txcolour[0]==255 and txcolour[1]==0 and txcolour[2]==0 ):
##                            print "red",i,j
                            grid_colour=grid_colour+'1000'
                        else:
                            grid_colour=grid_colour+'1111'
                            
                        if(value!=''):
                            ascii=ord(value)        # Convertion to its ascii value
                            ascii_bin=bin(ascii)
                            if(len(ascii_bin)==8):
                                ascii=ascii_bin.replace('0b','0')
                            else:
                                ascii=ascii_bin.replace('0b','')
                        else:
                            ascii='0000000'
                            
                        grid_colour=grid_colour+ascii
                        
                        if(font_style==90):  
                            grid_colour=grid_colour+'0'  #font_style=90 NO Blink
                        else: 
                            grid_colour=grid_colour+'1'  #font_style=93 Blink
                            
                        value=int(grid_colour,2)                       
                        
                        store.append(value)
                        store[j]=value
                        store1=[] 
                        value=''              
                        break
                    else:
                        store1.append(value)           
                    k=k+1                                   
                if(flag==0):
                    er_flag=1
                    print "er_flag at create--------->",er_flag
                    dial = wx.MessageDialog(None, "Input value '{0}' at row {1} and column {2} is invalid!!".format(value,i+1,j+1),\
                    'Error !!!', wx.OK|wx.STAY_ON_TOP)
                    dial.ShowModal()  
                    break                     
            if(flag==0):
                break  
            store_sub.append(store)
            store=[]
    
        page_no=page-1
     
        if(page_no+1==len(store_main)):      # extend list when new page is created
            store_main[page_no]=store_sub
            store_main.extend(store_main1)
        elif(page_no+1<len(store_main)):     
            store_main[page_no]=store_sub
        store_sub=[] 
        print "y--------->",y
##        print store_main
        
        b=[]
        c=[]
        d=[]
        e=[]
        if(page_no<=len(frequency) ): 
            try:
                b.append(int(str(self.txt_frequency.GetValue())))
                frequency.extend(b)
                frequency[page_no]=b[0]             # To store frequency of every page from grid
##                er_flag=0
            except ValueError:
                flag_error=1
                er_flag=1
                dial = wx.MessageDialog(None, "Frequency should be integer value",\
                'Error !!!', wx.OK|wx.STAY_ON_TOP)
                dial.ShowModal()
            
            try:
                c.append(int(str(self.txt_repeat.GetValue())))
                repeat.extend(c)
                repeat[page_no]=c[0]                # To store repeat of every page
##                er_flag=0
            except ValueError:
                flag_error=1
                er_flag=1
                dial = wx.MessageDialog(None, "Repeat should be integer value",\
                'Error !!!', wx.OK|wx.STAY_ON_TOP)
                dial.ShowModal()
          
            d.append(int(self.main_grid.GetGridCursorRow()))
            print "d--->",d
            cursor_row.extend(d)
            cursor_row[page_no]=d[0]            # To store cursor_row of every page
       
            e.append(int(self.main_grid.GetGridCursorCol()))
            print "e----->",e
            cursor_col.extend(e)
            cursor_col[page_no]=e[0]            # To store cursor_col of every page
##            print "......>frequency",frequency                 
        if(len(store1)<59):  # if less than 59 page has valid content
            if(y==0 and flag_error==0):                          
                if(page==1):  
                    self.btn_Previous.Disable()      
                    dial = wx.MessageDialog(None, "Previous page is not present",\
                    'Error !!!', wx.OK|wx.STAY_ON_TOP)
                    dial.ShowModal()          
                if(page>1):
                    page=page-1
                    q=q-1
                    self.main_grid.SetFocus()
                    self.main_grid.SetGridCursor(cursor_row[page-1],cursor_col[page-1])
                    if(q<len(page_txt)):
                        self.txt_pageno.SetValue(str(page_txt[q]))
                    if(q<len(page_txt) and len(page_txt[q])>6):
                        self.btn_CL1.Disable()
                        self.btn_CL2.Disable()
                        self.btn_CL3.Disable()
                        self.btn_CL4.Disable()
                        self.btn_CR1.Disable()
                        self.btn_CR2.Disable()
                        self.btn_CR3.Disable()
                        self.btn_CR4.Disable()  
                    else:
                        self.btn_CL1.Enable()
                        self.btn_CL2.Enable()
                        self.btn_CL3.Enable()
                        self.btn_CL4.Enable()
                        self.btn_CR1.Enable()
                        self.btn_CR2.Enable()
                        self.btn_CR3.Enable()
                        self.btn_CR4.Enable()     
                    if(page<=len(check)):
                        for j in range(8):
                            if(check[page-1][j]==1):  
                                if(j==0):
                                    btn_cl1=1
                                    self.btn_CL1.SetBackgroundColour('gray')
                                if(j==1):
                                    btn_cl2=1
                                    self.btn_CL2.SetBackgroundColour('gray')
                                if(j==2):
                                    btn_cl3=1
                                    self.btn_CL3.SetBackgroundColour('gray')
                                if(j==3):
                                    btn_cl4=1
                                    self.btn_CL4.SetBackgroundColour('gray')
                                if(j==4):
                                    btn_cr1=1
                                    self.btn_CR1.SetBackgroundColour('gray')
                                if(j==5): 
                                    btn_cr2=1
                                    self.btn_CR2.SetBackgroundColour('gray')
                                if(j==6):
                                    btn_cr3=1
                                    self.btn_CR3.SetBackgroundColour('gray')
                                if(j==7): 
                                    btn_cr4=1
                                    self.btn_CR4.SetBackgroundColour('gray')
                            elif(check[page-1][j]==0):
                                if(j==0):
                                    btn_cl1=0
                                    self.btn_CL1.SetBackgroundColour('white')
                                if(j==1):
                                    btn_cl2=0
                                    self.btn_CL2.SetBackgroundColour('white')
                                if(j==2):
                                    btn_cl3=0
                                    self.btn_CL3.SetBackgroundColour('white')
                                if(j==3):
                                    btn_cl4=0
                                    self.btn_CL4.SetBackgroundColour('white')
                                if(j==4):
                                    btn_cr1=0
                                    self.btn_CR1.SetBackgroundColour('white')
                                if(j==5): 
                                    btn_cr2=0
                                    self.btn_CR2.SetBackgroundColour('white')
                                if(j==6):
                                    btn_cr3=0
                                    self.btn_CR3.SetBackgroundColour('white')
                                if(j==7): 
                                    btn_cr4=0
                                    self.btn_CR4.SetBackgroundColour('white')
                    self.main_grid.ClearGrid()           # clear grid on every previous btn click
                    for i in range (9):
                        for j in range (21):
                            print " setting black on previous..............>",i,j
                            self.main_grid.SetCellBackgroundColour( i,j,"black")
                            self.main_grid.SetCellTextColour( i,j,"red");
                            self.main_grid.SetCellFont(i,j,wx.Font(15, wx.SWISS, wx.NORMAL, wx.BOLD))
                if(q<len(frequency)):
                    self.txt_frequency.SetValue(str(frequency[q]))
                if(q<len(repeat)):
                    self.txt_repeat.SetValue(str(repeat[q]))
               
            elif(y==1 and flag_error==0):           # On next btn click
                page=page+1
                q=q+1
                if(page-1<len(cursor_row)):
                    self.main_grid.SetFocus()
                    self.main_grid.SetGridCursor(cursor_row[page-1],cursor_col[page-1])
                if(q<len(page_txt)):
                    self.txt_pageno.SetValue(str(page_txt[q]))
                if(q<len(page_txt) and len(page_txt[q])>6):
                    btn_cl1=0
                    btn_cl2=0
                    btn_cl3=0
                    btn_cl4=0
                    btn_cr1=0
                    btn_cr2=0
                    btn_cr3=0
                    btn_cr4=0
                    self.btn_CL1.Disable()
                    self.btn_CL2.Disable()
                    self.btn_CL3.Disable()
                    self.btn_CL4.Disable()
                    self.btn_CR1.Disable()
                    self.btn_CR2.Disable()
                    self.btn_CR3.Disable()
                    self.btn_CR4.Disable()   
                else:
                    self.btn_CL1.Enable()
                    self.btn_CL2.Enable()
                    self.btn_CL3.Enable()
                    self.btn_CL4.Enable()
                    self.btn_CR1.Enable()
                    self.btn_CR2.Enable()
                    self.btn_CR3.Enable()
                    self.btn_CR4.Enable()       
                 
                if(page<=len(check)):
                    for j in range(8):
                        if(check[page-1][j]==1):
                            self.btn_CL1.Enable()
                            self.btn_CL2.Enable()
                            self.btn_CL3.Enable()
                            self.btn_CL4.Enable()
                            self.btn_CR1.Enable()
                            self.btn_CR2.Enable()
                            self.btn_CR3.Enable()
                            self.btn_CR4.Enable()  
                            if(j==0):
                                btn_cl1=1
                                self.btn_CL1.SetBackgroundColour('gray')
                            if(j==1):
                                btn_cl2=1
                                self.btn_CL2.SetBackgroundColour('gray')
                            if(j==2):
                                btn_cl3=1
                                self.btn_CL3.SetBackgroundColour('gray')
                            if(j==3):
                                btn_cl4=1
                                self.btn_CL4.SetBackgroundColour('gray')
                            if(j==4):
                                btn_cr1=1
                                self.btn_CR1.SetBackgroundColour('gray')
                            if(j==5): 
                                btn_cr2=1
                                self.btn_CR2.SetBackgroundColour('gray')
                            if(j==6):
                                btn_cr3=1
                                self.btn_CR3.SetBackgroundColour('gray')
                            if(j==7): 
                                btn_cr4=1
                                self.btn_CR4.SetBackgroundColour('gray')
                        elif(check[page-1][j]==0):
                            if(j==0):
                                self.btn_CL1.SetBackgroundColour('white')
                            if(j==1):
                                self.btn_CL2.SetBackgroundColour('white')
                            if(j==2):
                                self.btn_CL3.SetBackgroundColour('white')
                            if(j==3):
                                self.btn_CL4.SetBackgroundColour('white')
                            if(j==4):
                                self.btn_CR1.SetBackgroundColour('white')
                            if(j==5): 
                                self.btn_CR2.SetBackgroundColour('white')
                            if(j==6):
                                self.btn_CR3.SetBackgroundColour('white')
                            if(j==7): 
                                self.btn_CR4.SetBackgroundColour('white')
                if(page>=len(check)):
                    btn_cl1=0
                    btn_cl2=0
                    btn_cl3=0
                    btn_cl4=0
                    btn_cr1=0
                    btn_cr2=0
                    btn_cr3=0
                    btn_cr4=0
                    self.btn_CL1.SetBackgroundColour('white')
                    self.btn_CL2.SetBackgroundColour('white')
                    self.btn_CL3.SetBackgroundColour('white')
                    self.btn_CL4.SetBackgroundColour('white')
                    self.btn_CR1.SetBackgroundColour('white')
                    self.btn_CR2.SetBackgroundColour('white')
                    self.btn_CR3.SetBackgroundColour('white')
                    self.btn_CR4.SetBackgroundColour('white')
                    
                self.main_grid.ClearGrid()          # clear grid on every next btn click
                for i in range (9):
                    for j in range (21):
                        self.main_grid.SetCellBackgroundColour( i,j,"black")
                        self.main_grid.SetCellTextColour( i,j,"red");
                        self.main_grid.SetCellFont(i,j,wx.Font(15, wx.SWISS, wx.NORMAL, wx.BOLD))
                if(q<len(frequency)):
                    self.txt_frequency.SetValue(str(frequency[q]))
                if(q<len(repeat)):
                    self.txt_repeat.SetValue(str(repeat[q]))
##                self.main_grid.SetGridCursor(5,5)
            else:                       # On save btn click
                print "On save"
                flag_error=0
        else:                   # if value is invalid
            print "a"
     
    # Description:
    # Function parameters:
    # Global variables:
                      
    def check_box(self):
        global check,btn_cl1,btn_cl2,btn_cl3,btn_cl4,btn_cr1,btn_cr2,btn_cr3,btn_cr4
        list_check=[0, 0, 0, 0, 0, 0, 0, 0]
        store=[]
        store_sub=[]
        index=[]
        flag=0
        count=0
        count_old=0
        check_sub=[]
        check_sub.append(btn_cl1)
        check_sub.append(btn_cl2)
        check_sub.append(btn_cl3)
        check_sub.append(btn_cl4)
        check_sub.append(btn_cr1)
        check_sub.append(btn_cr2)
        check_sub.append(btn_cr3)
        check_sub.append(btn_cr4)
        print "check_sub",check_sub
        print "btn_cl1",btn_cl1


        page_no=page-1 
        print page_no
##        print "check_sub{0}".format(check_sub)
##        print "page_info-{0} len(check)-{1}".format(len(page_info),len(check))
        
        page_text=str(self.txt_pageno.GetValue())
        if(len(page_text)<7):
            flag=1       
        if(flag==1):
            for i in range(8):
                if(check_sub[i]==1):
                    count=count+1                      #count of new checkbox
            if(page_no<len(check)):  
                for i in range(8):
                    if(check[page_no][i]==1):
                        count_old=count_old+1           #count of old checkbox
                for i in range(8):
                    if(check[page_no][i]!=check_sub[i]):
                        index.append(i)   
##                print "index{0}".format(index)     
            if(len(page_info)==0 and len(check)==0):   # this apply for 1st page
                if(page_no+1>=len(check)):
                    check.extend([1])
                check[page_no]=check_sub
            number=home_creation.home_no
            if((len(page_info)>=len(check) and len(page_info)!=0 and len(check)!=0) or ((h-1)<=number)): 
                if(page_no+1>len(check)):
                    check.extend([1])
            check[page_no]=check_sub
            k=1           
            if(count>count_old):             # addition of check box clicks                
                for j in range(count-count_old):
                    check.insert((page_no+k),list_check)   
                    k=k+1            
            else:                           # deletion of check box clicks
                for m in range(len(index)):
                    del check[(page_no)+1]
                                 
        check_sub=[]
        store_sub=[]
##        print "check{0}".format(check)
##        print "index{0}".format(index)
        
    # Description:
    # Function parameters:
    # Global variables:
        
    def Savexls(self):
        global list,store,store_sub,store_main,page,cursor_col,cursor_row,frequency,repeat,\
        check,page_info,h,filename_xls,er_flag,btn_cl1,btn_cl2,btn_cl3,btn_cl4,btn_cr1,\
        btn_cr2,btn_cr3,btn_cr4
        list_check=[0,0,0,0,0,0,0,0]
        t=0
        s=0
        count=0
        y=2
        q=1
        f=0
        
        print " On save before btn_cl1------",btn_cl1
        print " on save before btn_cl2------",btn_cl2
        self.create_list(y)
        print "after btn_cl1------",btn_cl1
        print "after btn_cl2------",btn_cl2
        print "check",check
        
        number=home_creation.home_no
        cur_home=int(h)-1
        if(number==2 and page==1):
            cur_home=int(h)-2
        if(cur_home==int(number)):           # if all pages are created as per total no of home pages
            print "equal"
            self.write_obj.get_sheet(0).write(0,0,'Page')
            self.write_obj.get_sheet(0).write(0,1,page_info[0])
            self.write_obj.get_sheet(0).write(0,2,'Frequency')
            self.write_obj.get_sheet(0).write(0,3,frequency[0])
            self.write_obj.get_sheet(0).write(0,4,'Repeat')
            self.write_obj.get_sheet(0).write(0,5,repeat[0]) 
            self.write_obj.get_sheet(0).write(0,6,'Cursor Position')
            self.write_obj.get_sheet(0).write(0,7,cursor_row[0])
            self.write_obj.get_sheet(0).write(0,8,cursor_col[0])
            
            for i in range(len(store_main)-1):
                for j in range(9):
                    for k in range(21): 
                        self.write_obj.get_sheet(0).write(j+1+t,k+1,store_main[i][j][k])
                if(q<len(frequency) and q<len(store_main)-1):
                    self.write_obj.get_sheet(0).write(((i+1)+(10*(i+1))),0,'Page')
                    self.write_obj.get_sheet(0).write(((i+1)+(10*(i+1))),1,page_info[q])
                    self.write_obj.get_sheet(0).write(((i+1)+(10*(i+1))),2,'Frequency')
                    self.write_obj.get_sheet(0).write(((i+1)+(10*(i+1))),3,frequency[q])
                    self.write_obj.get_sheet(0).write(((i+1)+(10*(i+1))),4,'Repeat')
                    self.write_obj.get_sheet(0).write(((i+1)+(10*(i+1))),5,repeat[q]) 
                    self.write_obj.get_sheet(0).write(((i+1)+(10*(i+1))),6,'Cursor Position') 
                    self.write_obj.get_sheet(0).write(((i+1)+(10*(i+1))),7,cursor_row[q])
                    self.write_obj.get_sheet(0).write(((i+1)+(10*(i+1))),8,cursor_col[q])   
                self.write_obj.get_sheet(0).write((t+1),0,check[s][0])
                self.write_obj.get_sheet(0).write((t+3),0,check[s][1])
                self.write_obj.get_sheet(0).write((t+5),0,check[s][2])
                self.write_obj.get_sheet(0).write((t+7),0,check[s][3])
                self.write_obj.get_sheet(0).write((t+1),22,check[s][4])
                self.write_obj.get_sheet(0).write((t+3),22,check[s][5])
                self.write_obj.get_sheet(0).write((t+5),22,check[s][6])
                self.write_obj.get_sheet(0).write((t+7),22,check[s][7])
                s=s+1
                t=t+11
                q=q+1
        else: 
            print "not equal"                           # if all pages are not created as per total no of home pages
            for i in range(9):
                for j in range(21):
                    store.append(63488)
                store_sub.append(store)
                store=[]
                
            for h in range(int(h),int(number)+1): # To generate not created page number info
                x=(h)
                x=x*4096
                page_info.append(x)
                
            for h in range(len(frequency),len(page_info)):  # To generate not created page frequency,
                frequency.append(80)                        # repeat,cursor_row,cursor_col,check
                repeat.append(1)                            # and empty page content
                cursor_row.append(0)
                cursor_col.append(0)
                check.append(list_check)
                store_main.insert((page+f),store_sub)
                f=f+1
            print "frequency",frequency
            print "repeat",repeat
            self.write_obj.get_sheet(0).write(0,0,'Page')           # write into xls sheet
            self.write_obj.get_sheet(0).write(0,1,page_info[0])
            self.write_obj.get_sheet(0).write(0,2,'Frequency')
            self.write_obj.get_sheet(0).write(0,3,frequency[0])
            self.write_obj.get_sheet(0).write(0,4,'Repeat')
            self.write_obj.get_sheet(0).write(0,5,repeat[0]) 
            self.write_obj.get_sheet(0).write(0,6,'Cursor Position')
            self.write_obj.get_sheet(0).write(0,7,cursor_row[0])
            self.write_obj.get_sheet(0).write(0,8,cursor_col[0])
            
            for i in range(len(store_main)-1):
                for j in range(9):
                    for k in range(21): 
                        self.write_obj.get_sheet(0).write(j+1+t,k+1,store_main[i][j][k])
                if(q<len(frequency) and q<len(store_main)-1 and q<len(page_info) ):
                    self.write_obj.get_sheet(0).write(((i+1)+(10*(i+1))),0,'Page')
                    self.write_obj.get_sheet(0).write(((i+1)+(10*(i+1))),1,page_info[q])
                    self.write_obj.get_sheet(0).write(((i+1)+(10*(i+1))),2,'Frequency')
                    self.write_obj.get_sheet(0).write(((i+1)+(10*(i+1))),3,frequency[q])
                    self.write_obj.get_sheet(0).write(((i+1)+(10*(i+1))),4,'Repeat')
                    self.write_obj.get_sheet(0).write(((i+1)+(10*(i+1))),5,repeat[q]) 
                    self.write_obj.get_sheet(0).write(((i+1)+(10*(i+1))),6,'Cursor Position') 
                    self.write_obj.get_sheet(0).write(((i+1)+(10*(i+1))),7,cursor_row[q])
                    self.write_obj.get_sheet(0).write(((i+1)+(10*(i+1))),8,cursor_col[q])
                
                self.write_obj.get_sheet(0).write((t+1),0,check[s][0])
                self.write_obj.get_sheet(0).write((t+3),0,check[s][1])
                self.write_obj.get_sheet(0).write((t+5),0,check[s][2])
                self.write_obj.get_sheet(0).write((t+7),0,check[s][3])
                self.write_obj.get_sheet(0).write((t+1),22,check[s][4])
                self.write_obj.get_sheet(0).write((t+3),22,check[s][5])
                self.write_obj.get_sheet(0).write((t+5),22,check[s][6])
                self.write_obj.get_sheet(0).write((t+7),22,check[s][7])
                s=s+1
                t=t+11
                q=q+1
    
        self.write_obj.save(filename_xls)
        self.txt_Filename.SetValue(filename_xls)
##        print page_txt 
        head=os.path.split(filename_xls)
        pathnfile=os.path.join(head[0],"CDUHOTKEY.xls")
        print "pathnfile",pathnfile
        if os.path.exists(pathnfile)==True:
            self.var_exist=0
            self.writetoxls(pathnfile,head)
        else:
            writetobook  = xlwt.Workbook()           # xls file to write into it 
            writetosheet= writetobook .add_sheet(u'First')
            writetobook .save(pathnfile)
            self.var_exist=1
            self.writetoxls(pathnfile,head) 
            
    # Description:
    # Function parameters:
    # Global variables:
            
    def OnCancel(self, event):
        global filename_xls,er_flag
        
        home_creation.home_flag=0
        home_creation.flag_page_creation=0
        
        if(self.flag_change==0 and er_flag==0):  # To display browser window
            dial = wx.MessageDialog(None, 'Do you want to save?', 'Message', wx.STAY_ON_TOP|wx.YES_NO )
            if dial.ShowModal()==wx.ID_YES:
                if(self.flag_save==0):
                    dlg = wx.FileDialog(self, "Choose a file", ".", "", "*.xls", wx.SAVE)
                    if dlg.ShowModal() == wx.ID_OK:
                        global browse
                        browse=1
                        filename_xls = dlg.GetPath()
                        self.flag_save=1
                        self.Savexls()
                else:
                    filename_xls=filename_xls
                    self.Savexls()
        elif(self.flag_save==1):
            filename_xls=filename_xls            
            self.Destroy()                   # Once file is selected,next time onwards it saves to same file
            filename_xls=filename_xls
            self.Destroy()
        self.global_initialisation()
        event.Skip()
    
    # Description:
    # Function parameters:
    # Global variables:
            
    def On_Close(self,event):
        global filename_xls,er_flag
        global page_txt,new_confirm,List_page
        
        List_page=[]
        page_txt=[]
        home_creation.home_flag=0
        home_creation.flag_page_creation=0
        if(self.flag_change==0 and er_flag==0):  # To display browser window
            dial = wx.MessageDialog(None, 'Do you want to save?', 'Message', wx.STAY_ON_TOP|wx.YES_NO)
            if dial.ShowModal()==wx.ID_YES:
                if(self.flag_save==0):
                    dlg = wx.FileDialog(self, "Choose a file", ".", "", "*.xls", wx.SAVE)
                    if dlg.ShowModal() == wx.ID_OK:
                        global browse
                        browse=1
                        filename_xls = dlg.GetPath()
                        self.flag_save=1
                        self.Savexls()
                else:
                    filename_xls=filename_xls
                    self.Savexls()
        elif(self.flag_save==1):             # Once file is selected,next time onwards it saves to same file
            filename_xls=filename_xls            
            self.Destroy()
        self.global_initialisation()
        event.Skip()
        
    # Description:
    # Function parameters:
    # Global variables:
        
    def OnCL1(self, event):
        global btn_cl1
        self.flag_change=0
        
        if(btn_cl1==0):
            btn_cl1=1
            self.List_pages()
            self.btn_CL1.SetBackgroundColour('gray')
        else:
            btn_cl1=0
            self.btn_CL1.SetBackgroundColour('white')
        event.Skip()
    
    # Description:
    # Function parameters:
    # Global variables:
            
    def OnCL2(self, event):
        global btn_cl2
        
        self.flag_change=0
        if(btn_cl2==0):
            btn_cl2=1
            self.List_pages()
            self.btn_CL2.SetBackgroundColour('gray')
        else:
            btn_cl2=0
            self.btn_CL2.SetBackgroundColour('white')
        event.Skip()
    
    # Description:
    # Function parameters:
    # Global variables:
           
    def OnCL3(self, event):
        global btn_cl3
        self.flag_change=0
## 		self.List_page()
        if(btn_cl3==0):
            btn_cl3=1
            self.List_pages()
            self.btn_CL3.SetBackgroundColour('gray')
        else:
            btn_cl3=0
            self.btn_CL3.SetBackgroundColour('white')
        event.Skip()
    
    # Description:
    # Function parameters:
    # Global variables:
           
    def OnCL4(self, event):
        global btn_cl4
        self.flag_change=0
        if(btn_cl4==0):
            btn_cl4=1
            self.List_pages()
            self.btn_CL4.SetBackgroundColour('gray')
        else:
            btn_cl4=0
            self.btn_CL4.SetBackgroundColour('white')
        event.Skip()
    
    # Description:
    # Function parameters:
    # Global variables:
            
    def OnCR1(self, event):
        global btn_cr1
        self.flag_change=0
        if(btn_cr1==0):
            btn_cr1=1
            self.List_pages()
            self.btn_CR1.SetBackgroundColour('gray')
        else:
            btn_cr1=0
            self.btn_CR1.SetBackgroundColour('white')
        event.Skip()
    
    # Description:
    # Function parameters:
    # Global variables:
           
    def OnCR2(self, event):
        global btn_cr2
        self.flag_change=0
        if(btn_cr2==0):
            btn_cr2=1
            self.List_pages()
            self.btn_CR2.SetBackgroundColour('gray')
        else:
            btn_cr2=0
            self.btn_CR2.SetBackgroundColour('white')
        event.Skip()
    
    # Description:
    # Function parameters:
    # Global variables:
            
    def OnCR3(self, event):
        global btn_cr3
        self.flag_change=0
        if(btn_cr3==0):
            btn_cr3=1
            self.List_pages()
            self.btn_CR3.SetBackgroundColour('gray')
        else:
            btn_cr3=0
            self.btn_CR3.SetBackgroundColour('white')
        event.Skip()
    
    # Description:
    # Function parameters:
    # Global variables:
              
    def OnCR4(self, event):
        global btn_cr4
        self.flag_change=0
        if(btn_cr4==0):
            btn_cr4=1
            self.List_pages()
            self.btn_CR4.SetBackgroundColour('gray')
        else:
            btn_cr4=0
            self.btn_CR4.SetBackgroundColour('white')
        event.Skip()
    
    # Description:
    # Function parameters:
    # Global variables:
           
    def Hotkey(self, event):
        global hotkey_configdetail
##        global new_confirm
##        new_confirm=0
##        hotkey_configdetail=self.page_txt
        self.Hotkey_obj = Hotkey.create(None)
        self.Hotkey_obj.Show()
        event.Skip()
    
    # Description:
    # Function parameters:
    # Global variables:
            
    def List_pages(self):
        global List_page
        global new_confirm
        new_confirm=1
##        page_creation.new_confirm=1
        var=0
##        self.create_list(y)
##        List_page=['Home1']
####        val=self.txt_pageno.GetValue()
####        if val in List_page:
######            List_page.append(list_home1[len(list_home1)-1]+str(val_str))
####            List_page.append(val+str(val_str))
####        else:
####            List_page.append(val)
####            List_page.append(val+str(val_str))
######            List_page.append(list_home1[len(list_home1)-1]+str(val_str))    
####        print 'List_page',List_page
##        else:
                
##        if page_txt[len(page_txt)-1] in List_page:
##            List_page=page_txt
##        else:    
##            List_page.append(page_txt[len(page_txt)-1])
##        Listpage=page_txt.append('Home{0}-CL4')

    def create_hotlist(self): 
        global list,store,store_sub,store_main,page,store_main1,store1,cursor_col,cursor_row,frequency,repeat,q,\
        check,page_info1,h,btn_cl1,btn_cl2,btn_cl3,btn_cl4,btn_cr1,btn_cr2,btn_cr3,btn_cr4,er_flag,page_txt1,\
        new_confirm
##        k=0
##        flag=0
##        flag_check=0
##        flag_error=0
##        er_flag=0
##        store1=[]
##        store_c=[]
##        store_subc=[]
##        grid_colour=bin(0)
        
##        self.btn_Previous.Enable()
##        self.btn_Next.Enable()
        
        self.check_box()          # Call to checkbox function to get check clicks
        page_txt1=[]
        change_checki=[]
        change_checkd=[]
##        temp_page_info=[]
##        temp_page_info=page_info
        page_info1=[]
        page_txt=[]                        
        counter=0
        frq_flag=0
        h=1
        p=0
        page_no=page
        page_txt1.append("Home{0}".format(h))    # To store page sequence in list
        x=(h)
        x=x*4096
        page_info1.append(x)
        h=h+1 
        print "check",check
        for i in range(len(check)):
            for j in range(8):
                if(check[i][j]==1):
                    if(j<4):
                        page_txt1.append("Home{0}-CL{1}".format(h-1,(j+1)))
                    else:
                        temp=(j+1)-4
                        page_txt1.append("Home{0}-CR{1}".format(h-1,(temp)))
                    counter=counter+1
                    x=(h-1)
                    x=x*4096
                    z=(j+1)
                    z=z*256
                    x=x+z
                    page_info1.append(x)      # To page no in 16 bit format
                           
            if(i==(counter+p)):
                p=p+1
                number=home_creation.home_no
##                print "h-{0} home-{1} y-{2} ".format(h,home_creation.home_no,y)
                if(int(h) <= int(number)):      # To check pages are within no of home pages
                    page_txt1.append("Home{0}".format(h))
                    x=(h)
                    x=x*4096
##                    print "HOME{0}-{1}".format(h,x)
                    page_info1.append(x)          # To page no in 16 bit format  
                    h=h+1 
                else:
                    pg=page
                    if(y==0 and pg-1==len(check)):       # On previous page click
                        flag_error=1
                        dial = wx.MessageDialog(None, "End of the page",\
                        'Error !!!', wx.OK|wx.STAY_ON_TOP)
                        dial.ShowModal() 
                    if(y==1 and pg==len(check)):        # on next page click
                        flag_error=1
                        self.btn_Next.Disable()
                        dial = wx.MessageDialog(None, "Next page is not present",\
                        'Error !!!', wx.OK|wx.STAY_ON_TOP)
                        dial.ShowModal() 
                    break 
##        print "h at create list....>",h
##        print page_info
        print page_txt1  
        
