#Boa:Frame:Frame1

import wx
import os
import time
import threading,Queue
from threading import Thread
from ctypes import *
import struct
import request_packet
import CDU_TestRig_MainWindow
import com_connection

global dataload1_flag,dataload2_flag,dataload3_flag
dataload1_flag=0
dataload2_flag=0
dataload3_flag=0
open_frame=0
browse=0

def create(parent):
    global inst_Frame
    inst_Frame=Frame1(parent)
    return inst_Frame

[wxID_FRAME1, wxID_FRAME1BUTTON1, wxID_FRAME1BUTTON2, wxID_FRAME1BUTTON3, 
 wxID_FRAME1PANEL1, wxID_FRAME1STATICTEXT1, wxID_FRAME1STATICTEXT2,
 wxID_FRAME1TEXTCTRL1, wxID_FRAME1GAUGE1,wxID_FRAME1STATICTEXT3,
] = [wx.NewId() for _init_ctrls in range(10)]

             

class Frame1(wx.Frame):
    filename_bin=''
    count=0
    def _init_ctrls(self, prnt):
        # generated method, don't edit
        global open_frame
        open_frame=1
        wx.Frame.__init__(self, id=wxID_FRAME1, name='', parent=prnt,
              pos=wx.Point(521, 178), size=wx.Size(454, 108),
              style=wx.SYSTEM_MENU | wx.CAPTION | wx.MINIMIZE_BOX|wx.CLOSE_BOX|wx.STAY_ON_TOP, title='Frame1')
        self.SetClientSize(wx.Size(446, 120))
        self.Bind(wx.EVT_CLOSE, self.OnCancel)

        self.panel1 = wx.Panel(id=wxID_FRAME1PANEL1, name='panel1', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(446, 120),
              style=wx.TAB_TRAVERSAL)

        self.staticText1 = wx.StaticText(id=wxID_FRAME1STATICTEXT1,
              label='File to open:', name='staticText1', parent=self.panel1,
              pos=wx.Point(8, 16), size=wx.Size(60, 13), style=0)

        self.textCtrl1 = wx.TextCtrl(id=wxID_FRAME1TEXTCTRL1, name='textCtrl1',
              parent=self.panel1, pos=wx.Point(88, 8), size=wx.Size(272, 24),
              style=0, value='')

        self.button1 = wx.Button(id=wxID_FRAME1BUTTON1, label='Browse',
              name='button1', parent=self.panel1, pos=wx.Point(368, 8),
              size=wx.Size(75, 24), style=0)
        self.button1.Bind(wx.EVT_BUTTON, self.OnBrowse, id=wxID_FRAME1BUTTON1)
        
        self.staticText2 = wx.StaticText(id=wxID_FRAME1STATICTEXT2,
              label='Number of Files:', name='staticText2', parent=self.panel1,
              pos=wx.Point(10, 50), size=wx.Size(80,25), style=0)
        
        self.staticText3 = wx.StaticText(id=wxID_FRAME1STATICTEXT3,
              label='0%', name='staticText3', parent=self.panel1,
              pos=wx.Point(95, 50), size=wx.Size(50,25), style=0)
              
        self.gauge1 = wx.Gauge(id=wxID_FRAME1GAUGE1, name='gauge1',
              parent=self.panel1, pos=wx.Point(17, 65), range=100,
              size=wx.Size(413, 15),
              style=wx.TRANSPARENT_WINDOW | wx.GA_SMOOTH | wx.NO_BORDER | wx.GA_HORIZONTAL)
        self.gauge1.SetRange(100)
        self.gauge1.SetLabel('Total Files:')
        self.gauge1.SetValue(0)
        self.gauge1.SetThemeEnabled(True)

        self.button2 = wx.Button(id=wxID_FRAME1BUTTON2, label='OK',
              name='button2', parent=self.panel1, pos=wx.Point(128, 90),
              size=wx.Size(75, 23), style=0)
        self.button2.Bind(wx.EVT_BUTTON, self.OnOK, id=wxID_FRAME1BUTTON2)

        self.button3 = wx.Button(id=wxID_FRAME1BUTTON3, label='Cancel',
              name='button3', parent=self.panel1, pos=wx.Point(256, 90),
              size=wx.Size(75, 23), style=0)
        self.button3.Bind(wx.EVT_BUTTON, self.OnCancel, id=wxID_FRAME1BUTTON3)

    def __init__(self, parent):
        self._init_ctrls(parent)
        
    # Description:
    # Function parameters:
    # Global variables:
        
    def OnBrowse(self, event):
        dlg = wx.FileDialog(self, "Choose a file", ".", "", "*.bin", wx.OPEN)
        try:
           if dlg.ShowModal() == wx.ID_OK:
               global browse
               browse=1
               self.textCtrl1.Value = dlg.GetPath()
               self.filename_bin=self.textCtrl1.Value
               
        finally:
           dlg.Destroy()          
        event.Skip()
        
    
    # Description:
    # Function parameters:
    # Global variables:
        
    def OnOK(self, event):
        global dataload1_flag,dataload2_flag,dataload3_flag
        i=0
        ack1_flag=0
        ack2_flag=0
        ack3_flag=0
        data=[]
        bin_sub=[]
        bin_main=[[]]
        bin_main1=[[]]
##        self.Hide()
      
##        instance_obj=CDU_TestRig_MainWindow.ChoiceDialog(self, -1, 'Configure Com port')
        if self.filename_bin!='':

            
            f=open(self.filename_bin,'rb')
##            bin_file=f.read(1)

            size_file=os.path.getsize(self.filename_bin)
            print size_file
            no_pck=float(size_file)/50
                        
            result=isinstance(no_pck,float)

            no_pck=int(no_pck)
            if(result==True):
                no_pck=no_pck+1
                
            start=time.time()       # This gives the current time.
            timeout=5
            end=start+timeout

            while(1):
                if(dataload1_flag==0 and i<4):
                    request_packet.Data_Upload_Init_Packet()
                    print "packet 1"
                    i=i+1
                    print "i",i
                    #time.sleep(1)
                    
                    while(ack1_flag==0 or time.time()<end):
                        if CDU_TestRig_MainWindow.class_var3.maintenance_object_receiver.inWaiting() > 0:
                            b=struct.unpack(">2B",CDU_TestRig_MainWindow.class_var3.maintenance_object_receiver.read(2))
                            print b
                            data.append(b[0])
                            data.append(b[1])
                            if(data[0]==0xAC): 
                                if(data[1]==0xD1): 
                                    flag_process=1
                                    g=struct.unpack(">2B",CDU_TestRig_MainWindow.class_var3.maintenance_object_receiver.read(2))
                                    data.append(g[0])    # acceptance bit
                                    data.append(g[1])    # checksum bit
                                    
                                    Checksum=self.Calculate_Checksum(data,len(data)-1)
                                    print "checksum-------->",Checksum
                                    print "last bit-------->",data[len(data)-1]
                                    if( Checksum == data[len(data)-1] ):
                                        print "ack packet 1"
                                        if(data[2]==0):
                                            i=0
                                            dataload1_flag=0
                                            Timestamp=self.Time_stamp()
                                            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.SetForegroundColour(wx.Colour(255, 0, 0))
                                            temp_text="Invalid Acknowlegement received for data upload init command at "+ str(Timestamp)+"\n"
                                            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                                            
                                            while(1):
                                                if(dataload1_flag==0 and i<2):
                                                    request_packet.Data_Upload_Init_Packet()
                                                    i=i+1
                                                    time.sleep(1)
                                                else:
                                                    break
                                        else:
                                            data=[]
                                            Timestamp=self.Time_stamp()
                                            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.SetForegroundColour(wx.Colour(0, 0, 255))
                                            temp_text="Acknowlegement received data upload command at "+ str(Timestamp)+"\n"
                                            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                                            dataload1_flag=1
                                            ack1_flag=1
                                    else:
                                        Timestamp=self.Time_stamp()
                                        CDU_TestRig_MainWindow.class_var3.txt_statuswindow.SetForegroundColour(wx.Colour(255, 0, 0))
                                        temp_text="Invalid Acknowlegement received for data upload init command at"+ str(Timestamp)+"\n"
                                        CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                                else:
                                    temp_text="Invalid Acknowlegement received at"+ str(Timestamp)+"\n"
                                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)

                else:
                    break
            
            start=time.time()
            timeout=10
            end=start+timeout
##            time.sleep(1)
            if(dataload1_flag==1):
                i=0
                a=size_file/50
                total_size=50*a
                while(1):
                    if(dataload2_flag==0 and i<5):
                        request_packet.Data_Upload_Packet_Info_Cmd(total_size)
                        print "packet 2 sent"
                        i=i+1
                        
                        while(ack2_flag==0 or time.time()<end):
                            if CDU_TestRig_MainWindow.class_var3.maintenance_object_receiver.inWaiting() > 0:
                                b=struct.unpack(">2B",CDU_TestRig_MainWindow.class_var3.maintenance_object_receiver.read(2))
                                data.append(b[0])
                                data.append(b[1])
                                
                                if(data[0]==0xAC): 
                                    if(data[1]==0xD2): 
                                        flag_process=1
                                        g=struct.unpack(">2B",CDU_TestRig_MainWindow.class_var3.maintenance_object_receiver.read(2))
                                        data.append(g[0])    # acceptance bit
                                        data.append(g[1])    # checksum bit
                                        
                                        Checksum=self.Calculate_Checksum(data,len(data)-1)
                                        print "checksum-------->",Checksum
                                        print "last bit-------->",data[len(data)-1]
                                       
                                        if( Checksum == data[len(data)-1] ):
                                            print "ack packet 1"
                                            if(data[2]==0):
                                                i=0
                                                dataload2_flag=0
                                                Timestamp=self.Time_stamp()
                                                CDU_TestRig_MainWindow.class_var3.txt_statuswindow.SetForegroundColour(wx.Colour(255, 0, 0))
                                                temp_text="Invalid Acknowlegement received for packet information command at "+ str(Timestamp)+"\n"
                                                CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                                                
                                                while(1):
                                                    if(dataload2_flag==0 and i<4):
                                                        request_packet.Data_Upload_Packet_Info_Cmd(total_size)
                                                        i=i+1
                                                        time.sleep(1)
                                                    else:
                                                        break
                                            else:
                                                data=[]
                                                Timestamp=self.Time_stamp()
                                                CDU_TestRig_MainWindow.class_var3.txt_statuswindow.SetForegroundColour(wx.Colour(0, 0, 255))
                                                temp_text="Acknowlegement received packet information command at "+ str(Timestamp)+"\n"
                                                CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                                                dataload2_flag=1
                                                ack2_flag=1
                                                print "ack for 2nd packet"
                                        else:
                                            Timestamp=self.Time_stamp()
                                            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.SetForegroundColour(wx.Colour(255, 0, 0))
                                            temp_text="Invalid Acknowlegement received for packet information command at"+ str(Timestamp)+"\n"
                                            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                                            break
                                    else:
                                        temp_text="Invalid Acknowlegement received at"+ str(Timestamp)+"\n"
                                        CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                                        break
                    else:
                        break
            
            t=0
            print "no_pck",no_pck
            for i in range(no_pck):
                for j in range(t,t+50):
                    bin_sub.append(f.read(1))
                    f.seek(j,0)
                f.seek(t+50,0)
                t=t+50
                bin_main[i]=bin_sub
                bin_main.extend(bin_main1)
                print "bin_sub",bin_sub
                bin_sub=[]
                
##            print "6--->",bin_main[5]
##            print bin_main[1]
            value=float(100/no_pck)
            percent=0
                
            if(dataload2_flag==1):
                i=1
                m=0
                ack=i
                while(ack==i):
                    ack=0
                    ack3_flag=0
                    print "i----->",i
                    print "no_pck------>",no_pck
                    
                    while(i<=no_pck):
                        dataload3_flag=0
                        ack3_flag=0
                        if(dataload3_flag==0 and i<=no_pck):
                            print "packet 3 sent"
                            request_packet.Data_Packet_Upload_Init(i,bin_main[i-1])
##                                m=m+1
                        
                            while(ack3_flag==0):
                                if CDU_TestRig_MainWindow.class_var3.maintenance_object_receiver.inWaiting() > 0:
                                    b=struct.unpack(">2B",CDU_TestRig_MainWindow.class_var3.maintenance_object_receiver.read(2))
                                    data.append(b[0])
                                    data.append(b[1])
                                    
                                    if(data[0]==0xAC): 
                                        if(data[1]==0xD3): 
                                            flag_process=1
                                            g=struct.unpack(">5B",CDU_TestRig_MainWindow.class_var3.maintenance_object_receiver.read(5))
                                            for k in range (5):
                                                data.append(g[k])
                                                
                                            Checksum=self.Calculate_Checksum(data,len(data)-1)
                                            print "data",data
                                            print "checksum-------->",Checksum
                                            print "last bit-------->",data[len(data)-1]
                                            if( Checksum == data[len(data)-1] ):
                                                if(data[3]!=i):
                                                    break
                                                    
                                                if(data[4]==0):
                                                    k=0
                                                    dataload3_flag=0
                                                    Timestamp=self.Time_stamp()
                                                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.SetForegroundColour(wx.Colour(255, 0, 0))
                                                    temp_text="Invalid Acknowlegement received for packet information command at "+ str(Timestamp)+"\n"
                                                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                                                    
                                                    while(1):
                                                        if(dataload3_flag==0 and k<2):
                                                            request_packet.Data_Packet_Upload_Init(i+1,bin_main[i-1])
                                                            time.sleep(1)
                                                            k=k+1
                                                        else:
                                                            break
                                                else:
                                                    data=[]
                                                    Timestamp=self.Time_stamp()
                                                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.SetForegroundColour(wx.Colour(0, 0, 255))
                                                    temp_text="Acknowlegement received for packet data at "+ str(Timestamp)+"\n"
                                                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                                                    dataload3_flag=1
                                                    ack3_flag=1
                                                    ack=i
                                                    percent=percent+value
                                                    
                                                    percent1=str(percent)
                                                    self.staticText3.SetLabel(percent1)
                                                    
                                                    self.gauge1.SetValue(percent)                                                    
                                                                                                       
                                            else:
                                                Timestamp=self.Time_stamp()
                                                CDU_TestRig_MainWindow.class_var3.txt_statuswindow.SetForegroundColour(wx.Colour(255, 0, 0))
                                                temp_text="Invalid Acknowlegement received for packet data at"+ str(Timestamp)+"\n"
                                                CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                                                break
                                        else:
                                            Timestamp=self.Time_stamp()
                                            temp_text="Invalid Acknowlegement received at "+ str(Timestamp)+"\n"
                                            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                                            break
                                
                            if(ack!=i):
                                temp_text="Acknowlegement not received for "+ str(i)+" packet\n"
                                CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                                break
                            else:
                                print " ack==i"
                                
                                i=i+1
                                
                                print "i",i
                    
                        else:
                            self.Hide()
                            break
                    
        else:
            temp_text="Select a binary file first\n"
            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
        self.Hide()
##        event.Skip()

    # Description:
    # Function parameters:
    # Global variables:
        
    def OnCancel(self, event):
        global open_frame
        open_frame=0 
        self.Destroy()
        event.Skip()
    
    # Description:
    # Function parameters:
    # Global variables:
            
    def Calculate_Checksum(self,data,bytecount):
        checksum=0
        for i in range(0,bytecount):
           var1=data[i]
           checksum = checksum ^ (var1)
        checksum = checksum & 0xFF
        return checksum  
    
    
    # Description:
    # Function parameters:
    # Global variables:
        
    def Time_stamp(self):
        # To get the local time of system
        self.now=time.localtime(time.time())
        print "self.now", self.now
        year, month, day, hour, minute, second, weekday, yearday, daylight =self.now
        self.a=str(hour)
        self.b=str(minute)
        self.c=str(second)
        if len(self.a)==1:
            self.a='0'+self.a
        if len(self.b)==1:
            self.b='0'+self.b
        if len( self.c)==1:
            self.c='0'+self.c
        self.Timestamp=self.a+":"+self.b+":"+self.c
##        print "Timestamp", self.Timestamp
        return self.Timestamp
               
                

                                
        
        
        
        
        
        
        
        
        
