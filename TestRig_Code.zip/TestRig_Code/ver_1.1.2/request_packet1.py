import struct

PREAMBLE=0xAC
RESET_CMD=0xB1
ERASE_ERROR_LOG_CMD=0xD4

def Erase_Error_Log_Packet():
    bytecount=3
    erase_log=['AC','D4']
    erase_error_log_packet_for_chcksum=struct.pack('>BB',PREAMBLE,ERASE_ERROR_LOG_CMD)
    checksum=Calculate_Checksum(erase_log,bytecount)
    erase_error_log_packet=erase_error_log_packet_for_chcksum+struct.pack('>B',checksum)
    return erase_error_log_packet

def Reset_Packet():
    bytecount=3
    reset=['AC','B1']
    reset_packet_for_chcksum=struct.pack('>BB',PREAMBLE,RESET_CMD)
    checksum=Calculate_Checksum(reset,bytecount)
    reset_packet=reset_packet_for_chcksum+struct.pack('>B',checksum)
    return reset_packet


def Calculate_Checksum(data,byte_count):
        checksum=0
        for i in range(0,byte_count-1):
           var1=int(data[i],16)
           checksum=checksum ^ (var1)
        checksum=checksum&0xFFFFFFFF
        return checksum    
