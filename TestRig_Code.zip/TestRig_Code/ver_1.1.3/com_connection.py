#Boa:Frame:Frame1

import wx
import struct
import time
import os
import wx.lib.buttons
from ctypes import *
import serial
import win32api
from serial import  *
import _winreg as winreg    # To get current opened com port
import itertools            # To get current opened com port
import xlrd
import xlwt
from xlutils.copy import copy
import CDU_TestRig_MainWindow

global instance_comport_receiver,instance_comport_transmitter

def create(parent):
    global class_var5
    class_var5= com_connection(parent)
    return class_var5

[wxID_FRAME1, wxID_FRAME1PANEL1,wxID_COMConfig_WindowSTATICBOX1,
wxID_COMConfig_WindowBUTTON2,wxID_COMConfig_WindowBUTTON1,wxID_FRAME1COMBOBOX2,
wxID_FRAME1COMBOBOX1,wxID_COMConfig_WindowRADIOBOX7,wxID_COMConfig_WindowRADIOBOX6,
wxID_COMConfig_WindowRADIOBOX5,wxID_COMConfig_WindowSTATICBOX3,wxID_COMConfig_WindowBUTTON1,
wxID_COMConfig_WindowSTATICTEXT2,wxID_COMConfig_WindowTEXTCTRL1,wxID_COMConfig_WindowSTATICBOX2,
wxID_COMConfig_WindowRADIOBOX3,wxID_COMConfig_WindowRADIOBOX2,wxID_COMConfig_WindowRADIOBOX1,
] = [wx.NewId() for _init_ctrls in range(18)]

class com_connection(wx.Frame):
    def _init_ctrls(self, prnt):
        # generated method, don't edit
		#Changed for report no-100028: title name
        if(CDU_TestRig_MainWindow.cdu_gnss_flag==1):
            title_var='CDU COM Port Configuration'
        else:
            title_var='GNSS COM Port Configuration'
        
        wx.Frame.__init__(self, id=wxID_FRAME1, name='', parent=prnt,
              pos=wx.Point(206, 238), size=wx.Size(400, 489),
              style=wx.DEFAULT_FRAME_STYLE, title=title_var)
        self.SetClientSize(wx.Size(465, 350))

        self.com_connection_panel = wx.Panel(id=wxID_FRAME1PANEL1, name='com_connection_panel', parent=self,
              pos=wx.Point(160, 96), size=wx.Size(465, 350),
              style=wx.TAB_TRAVERSAL)
              
        self.sta_bx_receiver = wx.StaticBox(id=wxID_COMConfig_WindowSTATICBOX1,label='Reception Port', 
              name='com_connection_panel', parent=self.com_connection_panel,
              pos=wx.Point(8, 8), size=wx.Size(215, 185), style=0)
        
        self.rad_baud_rate = wx.RadioBox(choices=["9600", "19200", "38400", "57600",
              "115200"],id=wxID_COMConfig_WindowRADIOBOX1, label='Baud Rate',
              majorDimension=1, name='rad_baud_rate', parent=self.com_connection_panel,
              pos=wx.Point( 22, 32), size=wx.Size(65, 120),
              style=wx.RA_USE_CHECKBOX)
        self.rad_baud_rate.SetSelection(4)
        
        self.rad_stop_bit = wx.RadioBox(choices=["1", "2"],
              id=wxID_COMConfig_WindowRADIOBOX2, label='Stop Bits', majorDimension=1,
              name='rad_stop_bit', parent=self.com_connection_panel, pos=wx.Point(100, 32),
              size=wx.Size(44, 120), style=wx.RA_SPECIFY_COLS)
              
        self.rad_parity = wx.RadioBox(choices=["None", "Odd", "Even"],
              id=wxID_COMConfig_WindowRADIOBOX3, label='Parity', majorDimension=1,
              name='rad_parity', parent=self.com_connection_panel, pos=wx.Point(158, 32),
              size=wx.Size(52, 120), style=wx.RA_SPECIFY_COLS)
              
        self.sta_bx_path = wx.StaticBox(id=wxID_COMConfig_WindowSTATICBOX2,label='Path for Logging', 
              name='sta_bx_path', parent=self.com_connection_panel,
              pos=wx.Point(8, 206), size=wx.Size(392, 72), style=0)
              
        self.txt_path = wx.TextCtrl(id=wxID_COMConfig_WindowTEXTCTRL1, name='txt_path',
              parent=self.com_connection_panel, pos=wx.Point(80, 225), size=wx.Size(232, 37),
              style=0, value="")
              
        self.dirpath=os.getcwd()
        self.txt_path.SetValue(self.dirpath)
        self.txt_path. SetEditable(0)
        
        self.sta_log = wx.StaticText(id=wxID_COMConfig_WindowSTATICTEXT2,label='Log Folder', 
              name='sta_log', parent=self.com_connection_panel,
              pos=wx.Point(24, 228), size=wx.Size(54, 13), style=0)
              
        self.btn_browse = wx.Button(id=wxID_COMConfig_WindowBUTTON1, label='Browse',
              name='btn_browse', parent=self.com_connection_panel, pos=wx.Point(320, 230),
              size=wx.Size(64, 23), style=0)
        self.btn_browse.Bind(wx.EVT_BUTTON, self.OnBrowse)
        
        
              
        self.sta_bx_transmission = wx.StaticBox(id=wxID_COMConfig_WindowSTATICBOX3,label='Transmission Port', 
              name='sta_bx_transmission', parent=self.com_connection_panel,
              pos=wx.Point(235, 8), size=wx.Size(215,185), style=0)
              
        self.rad_baud_tx = wx.RadioBox(choices=["9600", "19200", "38400", "57600",    #Transmitting
              "115200"],id=wxID_COMConfig_WindowRADIOBOX5, label='Baud Rate',
              majorDimension=1, name='rad_baud_tx', parent=self.com_connection_panel,
              pos=wx.Point(249, 32), size=wx.Size(65, 120),
              style=wx.RA_USE_CHECKBOX)
        self.rad_baud_tx.SetSelection(4)
        
        self.rad_stop_tx= wx.RadioBox(choices=["1", "2"],                #Transmitting
              id=wxID_COMConfig_WindowRADIOBOX6,label='Stop Bits', majorDimension=1,
              name='rad_stop_tx', parent=self.com_connection_panel, pos=wx.Point(327, 32),
              size=wx.Size(44, 120), style=wx.RA_SPECIFY_COLS)
              
        self.rad_parity_tx = wx.RadioBox(choices=["None", "Odd", "Even"],           #Transmitting
              id=wxID_COMConfig_WindowRADIOBOX7,label='Parity', majorDimension=1,
              name='rad_parity_tx', parent=self.com_connection_panel, pos=wx.Point(383, 32),
              size=wx.Size(52, 120), style=wx.RA_SPECIFY_COLS)
       
        port=[]
        path = 'HARDWARE\\DEVICEMAP\\SERIALCOMM'
        try:
            key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, path)
               
        except WindowsError:
            raise IterationError

        for i in itertools.count():
            try:
                val = winreg.EnumValue(key, i)
                port.append(val[1])

            except EnvironmentError:
                break 
            
        self.cmb_receiver = wx.ComboBox(choices=port,
              id=wxID_FRAME1COMBOBOX1,name='cmb_receiver', parent=self.com_connection_panel,
              pos=wx.Point(25, 165), size=wx.Size(120, 21), style=0,
              value='Select COM port')
        self.cmb_receiver.SetEditable(0)
              
        self.cmb_transmission = wx.ComboBox(choices=port,
              id=wxID_FRAME1COMBOBOX2,name='cmb_transmission', parent=self.com_connection_panel,
              pos=wx.Point(252, 165), size=wx.Size(120, 21), style=0,
              value='Select COM port')
        self.cmb_transmission.SetEditable(0)
        
        self.btn_ok = wx.Button(id=wxID_COMConfig_WindowBUTTON1,label='OK',
              name='btn_ok', parent=self.com_connection_panel, pos=wx.Point(120, 284),
              size=wx.Size(75, 23), style=0)
        self.btn_ok .Bind(wx.EVT_BUTTON, self.OnOkButton, id=wxID_COMConfig_WindowBUTTON1)
        
        self.btn_cancel = wx.Button(id=wxID_COMConfig_WindowBUTTON2,label='Cancel',
              name='btn_cancel', parent=self.com_connection_panel, pos=wx.Point(216, 284),
              size=wx.Size(75, 23), style=0)
        self.btn_cancel.Bind(wx.EVT_BUTTON, self.onCancel,id=wxID_COMConfig_WindowBUTTON2)
        
        
        self.Bind(wx.EVT_CLOSE, self.onClose)
        


    def __init__(self, parent):
        self._init_ctrls(parent)
        
    def OnBrowse(self,event):
        dialog = wx.DirDialog (self,message="Pick a directory...")
        self.path_name=os.getcwd()
        
        dialog.SetPath(self.path_name)
        if dialog.ShowModal() == wx.ID_OK:
            self.path_name=dialog.GetPath()
            self.txt_path.SetValue(self.path_name)
        event.skip()  
        
    def OnOkButton(self,event):
##        global flag_maintance
        maintenance_xls=''
        
        CDU_TestRig_MainWindow.com_open=1
##        class_var3.MenuBar.EnableTop(0,True)
##        class_var3.MenuBar.EnableTop(1,True)
        
        com_port =self.rad_baud_rate.GetSelection()    #Receiver
        com_port1 =self.rad_stop_bit.GetSelection()
        com_port2 =self.rad_parity.GetSelection()
        com_port3=self.cmb_receiver.GetValue()
        com1=com_port3.split('COM')
        print "com1--------------->",com1
        instance_comport_receiver.Comport_select=int(com1[1])-1

        com_port4 =self.rad_baud_tx.GetSelection()   #Transmitter
        com_port5 =self.rad_stop_tx.GetSelection()
        com_port6 =self.rad_parity_tx.GetSelection()
        com_port7=self.cmb_transmission.GetValue()
        com1=com_port7.split('COM')
        instance_comport_transmitter.Comport_select=int(com1[1])-1
        
##        print "Comport_select----------->",instance_comport_transmitter.Comport_select
        if(com_port==0):                           #Receiver
            instance_comport_receiver.Baud_Rate="9600"
        elif(com_port==1):
            instance_comport_receiver.Baud_Rate="19200"
        elif(com_port==2):
            instance_comport_receiver.Baud_Rate="38400"
        elif(com_port==3):
            instance_comport_receiver.Baud_Rate="57600" 
        elif(com_port==4):
            instance_comport_receiver.Baud_Rate="115200" 
            
        if(com_port1==0):                              #Receiver
            instance_comport_receiver.Stop_Bits=STOPBITS_ONE
        elif(com_port1==1):
            instance_comport_receiver.Stop_Bits=STOPBITS_TWO
            
        if(com_port2==0):                          #Receiver
            instance_comport_receiver.Parity=PARITY_NONE
        elif(com_port2==1):
            instance_comport_receiver.Parity=PARITY_ODD
        elif(com_port2==2):
            instance_comport_receiver.Parity=PARITY_EVEN
            
        if(com_port4==0):                           #Transmitter
            instance_comport_transmitter.Baud_Rate="9600"
        elif(com_port4==1):
            instance_comport_transmitter.Baud_Rate="19200"
        elif(com_port4==2):
            instance_comport_transmitter.Baud_Rate="38400"
        elif(com_port4==3):
            instance_comport_transmitter.Baud_Rate="57600" 
        elif(com_port4==4):
            instance_comport_transmitter.Baud_Rate="115200" 
            
        if(com_port5==0):                                  #Transmitter
            instance_comport_transmitter.Stop_Bits=STOPBITS_ONE
        elif(com_port5==1):
            instance_comport_transmitter.Stop_Bits=STOPBITS_TWO
            
        if(com_port6==0):                               #Transmitter
            instance_comport_transmitter.Parity=PARITY_NONE
        elif(com_port6==1):
            instance_comport_transmitter.Parity=PARITY_ODD
        elif(com_port6==2):
            instance_comport_transmitter.Parity=PARITY_EVEN
            
        self.path_name= self.txt_path.GetValue()
        maintenance_xls=self.path_name+'\maintenance.xls'

        wtbook = xlwt.Workbook()           # xls file to write CDU status message
        wtsheet =wtbook.add_sheet('Sheet 1') 
        wtbook.save(maintenance_xls)
        rb = xlrd.open_workbook(maintenance_xls, formatting_info=True)
        w=copy(rb)
        #Changed for report no-100028:CDU and GNSS seperate COM connection calls
        if(CDU_TestRig_MainWindow.cdu_gnss_flag==1):        
            CDU_TestRig_MainWindow.class_var3.connection_com_CDU()        
            CDU_TestRig_MainWindow.flag_maintance=1
            
            if(instance_comport_receiver.Comport_select==instance_comport_transmitter.Comport_select):
                if( CDU_TestRig_MainWindow.class_var3.maintenance_object_receiver_CDU!=''):
                    self.Close()
            else:
                if(( CDU_TestRig_MainWindow.class_var3.maintenance_object_receiver_CDU!='') and ( CDU_TestRig_MainWindow.class_var3.maintenance_object_transmitter_CDU!='')):
                    self.Close()
        else:
            CDU_TestRig_MainWindow.class_var3.connection_com_GNSS()        
            CDU_TestRig_MainWindow.flag_maintance=1
            
            if(instance_comport_receiver.Comport_select==instance_comport_transmitter.Comport_select):
                if( CDU_TestRig_MainWindow.class_var3.maintenance_object_receiver_GNSS!=''):
                    self.Close()
            else:
                if(( CDU_TestRig_MainWindow.class_var3.maintenance_object_receiver_GNSS!='') and ( CDU_TestRig_MainWindow.class_var3.maintenance_object_transmitter_GNSS!='')):
                    self.Close()
        
        
            
	# Description:
    # Function parameters:
    # Global variables:
##    def connection_com(self):
##        global flag
##        try:
##            flag=1
##            # 1st position is 4 means com port-4 acts data sends from.
##            
##            if(instance_comport_receiver.Comport_select==instance_comport_transmitter.Comport_select):
##                self.maintenance_object_receiver_CDU = serial.Serial(int(instance_comport_receiver.Comport_select),baudrate=int(instance_comport_receiver.Baud_Rate),timeout=None,bytesize=8, parity=instance_comport_receiver.Parity, stopbits=instance_comport_receiver.Stop_Bits)
##                CDU_TestRig_MainWindow.class_var3.COM_status.SetBitmap(wx.Bitmap(u'green_light.bmp')) 
##                print "green..........."
##            else:
##                self.maintenance_object_receiver_CDU = serial.Serial(int(instance_comport_receiver.Comport_select),baudrate=int(instance_comport_receiver.Baud_Rate),timeout=None,bytesize=8, parity=instance_comport_receiver.Parity, stopbits=instance_comport_receiver.Stop_Bits)
##                self.maintenance_object_transmitter = serial.Serial(int(instance_comport_transmitter.Comport_select),baudrate=int(instance_comport_transmitter.Baud_Rate),timeout=None,bytesize=8, parity=instance_comport_transmitter.Parity, stopbits=instance_comport_transmitter.Stop_Bits)
##                CDU_TestRig_MainWindow.class_var3.COM_status.SetBitmap(wx.Bitmap(u'green_light.bmp')) 
####            TestThread_Ibit()
##        except SerialException:
##            win32api.MessageBox(0, 'COM Port is not Available !', 'Error!!!')
            
        
    def onClose(self, event):
##        global open_frame
        CDU_TestRig_MainWindow.com_open=0
        CDU_TestRig_MainWindow.class_var3.open_status=0
##        self.pt.com_port = -1
##        CDU_TestRig_MainWindow.class_var3.COM_status.SetBitmap(wx.Bitmap(u'red_light.bmp'))
        self.Destroy()
        
    def onCancel(self, event):
##        global open_frame
        CDU_TestRig_MainWindow.com_open=0
        CDU_TestRig_MainWindow.class_var3.open_status=0
##        self.pt.com_port = -1
##        CDU_TestRig_MainWindow.class_var3.COM_status.SetBitmap(wx.Bitmap(u'red_light.bmp'))
        self.Destroy()
        
                
    
class Comport_set_receiver(Structure):
	_fields_ = [
	            ("Baud_Rate",c_char_p),
	            ("Stop_Bits", c_uint),          
                ("Parity",c_char_p),          
                ("Data_Bits", c_char_p), 
                ("Comport_select",c_uint ),  
               ]
instance_comport_receiver=Comport_set_receiver()

class Comport_set_transmitter(Structure):
	_fields_ = [
	            ("Baud_Rate",c_char_p),
	            ("Stop_Bits", c_uint),          
                ("Parity",c_char_p),          
                ("Data_Bits", c_char_p), 
                ("Comport_select",c_uint ),  
               ]
instance_comport_transmitter=Comport_set_transmitter()
