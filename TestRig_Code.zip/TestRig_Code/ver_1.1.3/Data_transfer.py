#Boa:Frame:Frame1

import wx
import struct
from ctypes import *
import time
import os

import COMConfig_Window
import CDU_TestRig_MainWindow

global upgrade_type,flag_ChecksumStatus1,flag_ChecksumStatus2,flag_ChecksumStatus3,i_data,\
i_init,i_info,flag_no_ack1,flag_no_ack2,flag_no_ack3
i_data=1
i_init=1
i_info=1
flag_no_ack1=0
flag_no_ack2=0
flag_no_ack3=0
flag_ChecksumStatus1=0
flag_ChecksumStatus2=0
flag_ChecksumStatus3=0

dataload1_flag=0
dataload2_flag=0
dataload3_flag=0

def create(parent):
    return Frame1(parent)

[wxID_FRAME1, wxID_FRAME1BUTTON1, wxID_FRAME1BUTTON2, wxID_FRAME1PANEL1, 
 wxID_FRAME1RADIOBOX1,wxID_FRAME1STATICTEXT1,wxID_FRAME1STATICTEXT2,wxID_FRAME1GAUGE1,
 wxID_FRAME1STATICTEXT3,
] = [wx.NewId() for _init_ctrls in range(9)]

class Frame1(wx.Frame):
    def _init_ctrls(self, prnt):
        # generated method, don't edit
        wx.Frame.__init__(self, id=wxID_FRAME1, name='', parent=prnt,
              pos=wx.Point(360, 181), size=wx.Size(294, 347),
              style=wx.DEFAULT_FRAME_STYLE, title='Data transfer')
        self.SetClientSize(wx.Size(340, 313))

        self.panel1 = wx.Panel(id=wxID_FRAME1PANEL1, name='panel1', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(340, 313),
              style=wx.TAB_TRAVERSAL)

        self.staticText1 = wx.StaticText(id=wxID_FRAME1STATICTEXT1,
              label='Choose any one of the binary file', name='staticText1',
              parent=self.panel1, pos=wx.Point(16, 15), size=wx.Size(204, 14),
              style=0)
        self.staticText1.SetFont(wx.Font(9, wx.SWISS, wx.NORMAL, wx.BOLD, False,
              'Tahoma'))

        self.radioBox1 = wx.RadioBox(choices=['FLIGHT LOG', 'PILOT REPORT',
              'USER WAYPOINTS', 'FAULT LIST PAGE', 'CHIP DATA', 'HUMS LOG',
              'ALL','GTH'], id=wxID_FRAME1RADIOBOX1, label='', majorDimension=1,
              name='radioBox1', parent=self.panel1, pos=wx.Point(24, 35),
              size=wx.Size(216, 176), style=wx.RA_SPECIFY_COLS)
              
        self.staticText2 = wx.StaticText(id=wxID_FRAME1STATICTEXT2,
              label='Percentage of File:', name='staticText2', parent=self.panel1,
              pos=wx.Point(12, 218), size=wx.Size(98,25), style=0)
              
        self.staticText3 = wx.StaticText(id=wxID_FRAME1STATICTEXT3,
              label='0%', name='staticText2', parent=self.panel1,
              pos=wx.Point(105, 218), size=wx.Size(50,25), style=0)
              
        self.gauge1 = wx.Gauge(id=wxID_FRAME1GAUGE1, name='gauge1',
              parent=self.panel1, pos=wx.Point(17, 240), range=100,
              size=wx.Size(310, 15),
              style=wx.TRANSPARENT_WINDOW | wx.GA_SMOOTH | wx.NO_BORDER | wx.GA_HORIZONTAL)
        self.gauge1.SetRange(100)
        self.gauge1.SetLabel('Total Files:')
        self.gauge1.SetValue(0)
        self.gauge1.SetThemeEnabled(True)

        self.button1 = wx.Button(id=wxID_FRAME1BUTTON1, label='OK',
              name='button1', parent=self.panel1, pos=wx.Point(48, 268),
              size=wx.Size(75, 23), style=0)
        self.button1.Bind(wx.EVT_BUTTON, self.OnOK_click, id=wxID_FRAME1BUTTON1)

        self.button2 = wx.Button(id=wxID_FRAME1BUTTON2, label='Cancel',
              name='button2', parent=self.panel1, pos=wx.Point(144, 268),
              size=wx.Size(75, 23), style=0)
        self.button2.Bind(wx.EVT_BUTTON, self.On_cancel, id=wxID_FRAME1BUTTON2)

    def __init__(self, parent):
        self._init_ctrls(parent)
    
    # Description:
    # Function parameters:
    # Global variables:
            
    def Calculate_Checksum(self,data,bytecount):
        checksum=0
        for i in range(0,bytecount):
           var1=data[i]
           checksum = checksum ^ (var1)
        checksum = checksum & 0xFF
        return checksum 
    
    # Description:
    # Function parameters:
    # Global variables:
        
    def Calculate_Checksum1(self,pkt,byte_count):
        checksum=0
        data=struct.unpack_from('>%dB'%byte_count,pkt)
        for i in range(0,byte_count):
            checksum=checksum+data[i]
        checksum=checksum & 0xFF
        return checksum 
    
        
    #Changed for report no-100028:variables are added.    
    def OnOK_click(self, event):
        global upgrade_type,connect_object,i_no,bin_main,value,percent,\
        dataload1_flag,dataload2_flag,dataload3_flag,total_size,ack,flag_ChecksumStatus1,\
        flag_ChecksumStatus2,flag_ChecksumStatus3,i_init,i_info,k2,flag_no_ack1,flag_no_ack2,\
        flag_no_ack3,i_data
        flag_ChecksumStatus1=0
        flag_ChecksumStatus2=0
        flag_ChecksumStatus3=0  
        i_data=1   
        k2=0 
        i_init=1
        i_info=1
        data=[]
        bin_sub=[]
        bin_main=[[]]
        bin_main1=[[]]
        
        dataload1_flag=0
        dataload2_flag=0
        dataload3_flag=0
        
        file_name =self.radioBox1.GetSelection() 
        if(file_name==0):
            upgrade_type=0x01
            file_name=".\cbinary_file\main_mode\cbinary_file\FLTLOG.bin"
            f=open(file_name,'rb')
            size_file=os.path.getsize(file_name)
            print size_file
        elif(file_name==1):
            upgrade_type=0x02
            file_name=".\cbinary_file\main_mode\cbinary_file\PLTRPT.bin"
            f=open(file_name,'rb')
            size_file=os.path.getsize(file_name)
        elif(file_name==2):
            upgrade_type=0x03
            file_name=".\cbinary_file\main_mode\cbinary_file\USRWP.bin"
            f=open(file_name,'rb')
            size_file=os.path.getsize(file_name)
        elif(file_name==3):
            upgrade_type=0x04
            file_name=".\cbinary_file\main_mode\cbinary_file\FLP.bin"
            f=open(file_name,'rb')
            size_file=os.path.getsize(file_name)
        elif(file_name==4):
            upgrade_type=0x05
            file_name=".\cbinary_file\main_mode\cbinary_file\CHPDAT.bin"
            f=open(file_name,'rb')
            size_file=os.path.getsize(file_name)
        elif(file_name==5):
            upgrade_type=0x06
            file_name=".\cbinary_file\main_mode\cbinary_file\HUMSLOG.bin"
            f=open(file_name,'rb')
            size_file=os.path.getsize(file_name)
        elif(file_name==6):
            upgrade_type=0x07
            file_name=".\cbinary_file\main_mode\cbinary_file\ALL.bin"
            f=open(file_name,'rb')
            size_file=os.path.getsize(file_name)
        else:	
			#Changed for report no-100028: added GNSS upgrade
            upgrade_type=0x07
##            file_name=".\cbinary_file\main_mode\cbinary_file\GTH.bin"
##            f=open(file_name,'rb')
            size_file=0
            temp_text="GTH Upgrade type is selected\n "
            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
       
##        self.data_transfer()
        start=time.time()       # This gives the current time.
        timeout=8
        end=start+timeout
        data=[]
        
        if(CDU_TestRig_MainWindow.close_CDU_flag==1):
            connect_object=CDU_TestRig_MainWindow.class_var3.connect_object_CDU1_receiver
        else:
            connect_object=CDU_TestRig_MainWindow.class_var3.connect_object_CDU2_receiver     
          
        self.gauge1.SetValue(0)    
		#Changed for report no-100028: changed entire ack process
        if(upgrade_type!=0x07):
            i=0 
            while(1):
                print "init i------------>",i            
                if((dataload1_flag==0 and i<3 and flag_ChecksumStatus1<3) or (dataload1_flag==0 and i_init<3)):                    
                    self.Initial_data()
                    i=i+1
                    print "i",i
                    self.ACK_Initial_data()
                    if(flag_no_ack1==0):
                        flag_ChecksumStatus1=flag_ChecksumStatus1+1
                        i_init=i_init+1
                else:
                    if((dataload1_flag==0 and i_init>=3)):
                        CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Acknowledgement is not received for data init command\n")
                    
                    if(flag_ChecksumStatus1>=3 and dataload1_flag==0):
                        Timestamp=self.Time_stamp()
                        temp_text="Retries for data init command exceeded at"+ str(Timestamp)+"\n"
                        CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                    break                
                    
            if(dataload1_flag==1):
                i=0
                a=size_file/50
                total_size=50*a
                while(1):
                    if((dataload2_flag==0 and i<3 and flag_ChecksumStatus2<3) or (dataload2_flag==0 and i_info<3)):
                        self.Packet_Info_Cmd(total_size)
                        print "packet 2 sent"
                        i=i+1
                        self.ACK_Packet_Info_Cmd()
                        if(flag_no_ack2==0):
                            flag_ChecksumStatus2=flag_ChecksumStatus2+1
                            i_info=i_info+1
                    else:
                        if(dataload2_flag==0 and i_info>=3):
                          CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Acknowledgement is not received for packet info command\n")
                        
                        if(flag_ChecksumStatus2>=3 and dataload2_flag==0):
                            Timestamp=self.Time_stamp()
                            temp_text="Retries for packet information command exceeded at"+ str(Timestamp)+"\n"
                            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                        break             
                          
            no_pck=float(size_file)/50 
            result=isinstance(no_pck,float)
            no_pck=int(no_pck)
            
            if(result==True):
                no_pck=no_pck+1
            t=0        
            print "no_pck",no_pck
            for i in range(no_pck):
                for j in range(t,t+50):
                    bin_sub.append(f.read(1))
                    f.seek(j,0)
                f.seek(t+50,0)
                t=t+50
                bin_main[i]=bin_sub
                bin_main.extend(bin_main1)
                print "bin_sub",bin_sub
                bin_sub=[]
                
            value=float(100/no_pck)
            percent=0
            print "value-------------->",value
            
            if(dataload2_flag==1):
                i_no=1
                m=0
                ack=i_no
                while(ack==i_no):
                    ack=0
                    
                    print "i----->",i_no
                    print "no_pck------>",no_pck
                    
                    while(i_no<=no_pck):
                        dataload3_flag=0
                        i=0                       
                        while(1):
                            if((dataload3_flag==0 and i_no<=no_pck and i<3 and flag_ChecksumStatus3<3) or (dataload3_flag==0 and i_data<3)):
                                temp_text="out-flag_ChecksumStatus-"+(str(flag_ChecksumStatus3))+"  i_data-"+(str(i_data))+"\n"
                                CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                                self.Data_Packet(i_no,bin_main[i_no-1])
                                i=i+1
                                self.ACK_Data_Packet()
                                if(flag_no_ack3==0):
                                    flag_ChecksumStatus3=flag_ChecksumStatus3+1
                                    i_data=i_data+1
                            else:
                                if(dataload3_flag==0 and i_data>=3):
                                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Acknowledgement is not received for data packet"+ str(i_no)+"\n")
                                
                                if(flag_ChecksumStatus3>=3 and dataload3_flag==0):
                                    Timestamp=self.Time_stamp()
                                    temp_text="Retries for data packet exceeded at"+ str(Timestamp)+"\n"
                                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                                break                                                
                                                        
                        if(ack!=i_no):
                            print "flag_ChecksumStatus3->",flag_ChecksumStatus3
                            print "i---->",i
                            if(flag_ChecksumStatus3>=3 or i>=3):
                                break
                            else:
                                Timestamp=self.Time_stamp()
                                temp_text="Invalid Acknowlegement received for packet"+ str(i_no)+"at "+str(Timestamp)+"\n"
                                CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)                          
                                break
                        else:                    
                            i_no=i_no+1                        
                            print "i",i_no  
                            i_data=i_data+1 
                            flag_ChecksumStatus3=0              
##        self.Destroy()
        event.Skip()
        
    def ACK_Initial_data(self):
        global dataload1_flag,connect_object,flag_ChecksumStatus1,i_init,flag_no_ack1
        data=[]
        timeout =8
        start = time.time()
        end = start + timeout        
        
        while(time.time()<end):
            print "1-------------"
            if(flag_ChecksumStatus1<3):
                flag_no_ack1=0
                if connect_object.inWaiting() > 0:
                    flag_no_ack1=1
                    b=struct.unpack(">2B",connect_object.read(2))
                    print "b------>",b
                    data.append(b[0])
                    data.append(b[1])
                    
                    if(data[0]==0xAC): 
                        if(data[1]==0xD1): 
                            flag_process=1
                            g=struct.unpack(">2B",connect_object.read(2))
                            data.append(g[0])    # acceptance bit
                            data.append(g[1])    # checksum bit
                           
                            Checksum=self.Calculate_Checksum(data,len(data)-1)
                            print "data----->",data
                            print "checksum-------->",Checksum
                            print "last bit-------->",data[len(data)-1]
                            
                            if( Checksum == data[len(data)-1] ):
                                print "ack packet 1"                                                                    
                                if((data[2]&2)==0):
                                    temp_text="File available in DTD\n "
                                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                                else:
                                    temp_text="File not available in DTD\n "
                                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                                           
                                if((data[2]&1)==0):                            
                                    dataload1_flag=0
                                    Timestamp=self.Time_stamp()
                                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.SetForegroundColour(wx.Colour(255, 0, 0))
                                    temp_text="Invalid Acceptance code received for data init command at "+ str(Timestamp)+"\n"
                                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                                    flag_ChecksumStatus1=flag_ChecksumStatus1+1                                    
                                    while(1):
                                        if(dataload1_flag==0 and i_init<3):
                                            self.Initial_data()
                                            i_init=i_init+1
                                            temp_text="i_init-"+(str(i_init))+"\n "
                                            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                                            self.ACK_Initial_data()
                                            if(flag_no_ack1==0):
                                                flag_ChecksumStatus1=flag_ChecksumStatus1+1
                                            if(flag_ChecksumStatus1>3):
    ##                                            flag_ChecksumStatus1=0                
                                                break
                                        else:
                                            break
                                else:
                                    data=[]
                                    Timestamp=self.Time_stamp()
                                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.SetForegroundColour(wx.Colour(0, 0, 255))
                                    temp_text="Acknowlegement received for data init command at "+ str(Timestamp)+"\n"
                                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                                    dataload1_flag=1                                   
                                     
                                    break
                            else:
                                Timestamp=self.Time_stamp()
                                CDU_TestRig_MainWindow.class_var3.txt_statuswindow.SetForegroundColour(wx.Colour(255, 0, 0))
                                temp_text="Invalid Checksum received for data init command at"+ str(Timestamp)+"\n"
                                CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                                flag_ChecksumStatus1=flag_ChecksumStatus1+1
                               
                                while(1):
                                    if(dataload1_flag==0 and i_init<3):
                                        self.Initial_data()
                                        i_init=i_init+1
                                        self.ACK_Initial_data()
                                        if(flag_no_ack1==0):
                                            flag_ChecksumStatus1=flag_ChecksumStatus1+1
                                        if(flag_ChecksumStatus1>3):                                      
                                            break
                                    else:
                                        break
                        else:
                            Timestamp=self.Time_stamp()
                            temp_text="Invalid Acknowlegement received at"+ str(Timestamp)+"\n"
                            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                            break
                            
                    else:
                        data[0]=data[1]
                        (value,)=struct.unpack(">B",connect_object.read(1))
                        data[1]=(value)


    def ACK_Packet_Info_Cmd(self):
        global dataload2_flag,connect_object,total_size,flag_ChecksumStatus2,i_info,flag_no_ack2
        data=[]
        timeout =8
        start = time.time()
        end = start + timeout 
        
        while(time.time()<end):
            if(flag_ChecksumStatus2<3):
                flag_no_ack2=0
                if connect_object.inWaiting() > 0:
                    flag_no_ack2=1
                    b=struct.unpack(">2B",connect_object.read(2))
                    data.append(b[0])
                    data.append(b[1])
                    
                    if(data[0]==0xAC): 
                        if(data[1]==0xD2): 
                            flag_process=1
                            g=struct.unpack(">2B",connect_object.read(2))
                            data.append(g[0])    # acceptance bit
                            data.append(g[1])    # checksum bit
                            
                            Checksum=self.Calculate_Checksum(data,len(data)-1)
                            print "checksum-------->",Checksum
                            print "last bit-------->",data[len(data)-1]
                           
                            if( Checksum == data[len(data)-1] ):
                                print "ack packet 1"
                                if(data[2]==0):
                                    
                                    dataload2_flag=0
                                    Timestamp=self.Time_stamp()
                                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.SetForegroundColour(wx.Colour(255, 0, 0))
                                    temp_text="Invalid Acceptance code received for packet information command at "+ str(Timestamp)+"\n"
                                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                                    flag_ChecksumStatus2=flag_ChecksumStatus2+1
                                   
                                    while(1):
                                        if(dataload2_flag==0 and i_info<3):
                                            self.Packet_Info_Cmd(total_size)
                                            i_info=i_info+1                                            
                                            self.ACK_Packet_Info_Cmd()
                                            if(flag_no_ack2==0):
                                                flag_ChecksumStatus2=flag_ChecksumStatus2+1
                                            if(flag_ChecksumStatus2>3):              
                                                break
                                        else:
                                            break
                                else:
                                    data=[]
                                    Timestamp=self.Time_stamp()
                                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.SetForegroundColour(wx.Colour(0, 0, 255))
                                    temp_text="Acknowlegement received packet information command at "+ str(Timestamp)+"\n"
                                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                                    dataload2_flag=1
                                    print "ack for 2nd packet"
                                    break
                            else:
                                Timestamp=self.Time_stamp()
                                CDU_TestRig_MainWindow.class_var3.txt_statuswindow.SetForegroundColour(wx.Colour(255, 0, 0))
                                temp_text="Invalid Checksum received for packet information command at "+ str(Timestamp)+"\n"
                                CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                                flag_ChecksumStatus2=flag_ChecksumStatus2+1                    
                                while(1):
                                    if(dataload2_flag==0 and i_info<3):
                                        self.Packet_Info_Cmd(total_size)
                                        i_info=i_info+1
                                        self.ACK_Packet_Info_Cmd()
                                        if(flag_no_ack2==0):
                                            flag_ChecksumStatus2=flag_ChecksumStatus2+1
                                        if(flag_ChecksumStatus2>3):              
                                            break
                                    else:
                                        break
                        else:
                            Timestamp=self.Time_stamp()
                            temp_text="Invalid Acknowlegement received at "+ str(Timestamp)+"\n"
                            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                            break
                    else:
                        data[0]=data[1]
                        (value,)=struct.unpack(">B",connect_object.read(1))
                        data[1]=(value)
                    
    def ACK_Data_Packet(self):
        global dataload3_flag,connect_object,i_no,bin_main,value,percent,ack,flag_ChecksumStatus3,i_data,\
        flag_no_ack3
        data=[]
        timeout =8
        start = time.time()
        end = start + timeout
    
        while(time.time()<end and flag_ChecksumStatus3<3):
            if(flag_ChecksumStatus3<3):
                flag_no_ack3=0
                if connect_object.inWaiting() > 0:
                    flag_no_ack3=1
                    b=struct.unpack(">2B",connect_object.read(2))
                    data.append(b[0])
                    data.append(b[1])
                    
                    if(data[0]==0xAC): 
                        if(data[1]==0xD3): 
                            flag_process=1
                            g=struct.unpack(">5B",connect_object.read(5))
                            for k in range (5):
                                data.append(g[k])
                                
                            Checksum=self.Calculate_Checksum(data,len(data)-1)
                            print "data",data
                            print "checksum-------->",Checksum
                            print "last bit-------->",data[len(data)-1]
                            if( Checksum == data[len(data)-1] ):
                                if(data[3]!=i_no):
                                    Timestamp=self.Time_stamp()                                    
                                    temp_text="Invalid Acknowlegement received for data packet "+str(i_no)+" at "+ str(Timestamp)+"\n"
                                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text) 
                                    flag_ChecksumStatus3=flag_ChecksumStatus3+1
                                   
                                    while(1):
                                        if(dataload3_flag==0 and i_data<3):
                                            self.Data_Packet(i_no,bin_main[i_no-1])
                                            time.sleep(1)
                                            i_data=i_data+1
##                                            temp_text="checksum\n "
##                                            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                                            self.ACK_Data_Packet()
                                            if(flag_no_ack3==0):
                                                flag_ChecksumStatus3=flag_ChecksumStatus3+1
                                            if(flag_ChecksumStatus3>3):              
                                                break                                        
                                        else:
                                            break                                  
                                    
                                elif(data[4]==2):
                                    
                                    dataload3_flag=0
                                    Timestamp=self.Time_stamp()
                                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.SetForegroundColour(wx.Colour(255, 0, 0))
                                    temp_text="Invalid Checksum status received for data packet "+str(i_no)+" at "+ str(Timestamp)+"\n"
                                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                                    flag_ChecksumStatus3=flag_ChecksumStatus3+1
                                   
                                    while(1):
                                        if(dataload3_flag==0 and i_data<3 and flag_ChecksumStatus3<3):
                                            self.Data_Packet(i_no,bin_main[i_no-1])
##                                            time.sleep(1)
                                            i_data=i_data+1
                                            temp_text="i_data-"+(str(i_data))+" flag_ChecksumStatus-"+str(flag_ChecksumStatus3)+"\n "
                                            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                                            self.ACK_Data_Packet()
                                            if(flag_no_ack3==0):
                                                flag_ChecksumStatus3=flag_ChecksumStatus3+1
                                            if(flag_ChecksumStatus3==3):              
                                                break                                        
                                        else:
                                            break
                                else:
                                    data=[]
                                    Timestamp=self.Time_stamp()
                                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.SetForegroundColour(wx.Colour(0, 0, 255))
                                    temp_text="Acknowlegement received for packet data "+str(i_no)+" at "+ str(Timestamp)+"\n"
                                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                                    dataload3_flag=1
                                    
                                    ack=i_no
                                    print "Data packet "+str(i_no)+" ack got it\n "
                                    percent=percent+value
                                    percent1=str(percent)+"%"
                                    self.staticText3.SetLabel(percent1)                                
                                    self.gauge1.SetValue(percent)
                                    break
                                                                                                                      
                            else:
                                Timestamp=self.Time_stamp()
                                CDU_TestRig_MainWindow.class_var3.txt_statuswindow.SetForegroundColour(wx.Colour(255, 0, 0))
                                temp_text="Invalid Checksum received for packet data "+str(i_no)+" at "+ str(Timestamp)+"\n"
                                CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                                flag_ChecksumStatus3=flag_ChecksumStatus3+1                            
                                while(1):
                                    if(dataload3_flag==0 and i_data<3 and flag_ChecksumStatus3<3):
                                        temp_text="checksum--"+(str(flag_ChecksumStatus3))+"\n"
                                        CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                                        self.Data_Packet(i_no,bin_main[i_no-1])
##                                        time.sleep(1)
                                        i_data=i_data+1
                                        self.ACK_Data_Packet()
                                        if(flag_no_ack3==0):
                                            flag_ChecksumStatus3=flag_ChecksumStatus3+1
                                        if(flag_ChecksumStatus3>3):              
                                            break 
                                    else:
                                        break
                        else:
                            Timestamp=self.Time_stamp()
                            temp_text="Invalid Acknowlegement received for data packet "+str(i_no)+"at "+ str(Timestamp)+"\n"
                            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
##                            self.Hide()
                            break
                    else:
                        data[0]=data[1]
                        (value,)=struct.unpack(">B",connect_object.read(1))
                        data[1]=(value)


        
    # Description:
    # Function parameters:
    # Global variables:
        
    def On_cancel(self, event):
        self.Destroy()
        event.Skip()
    
    # Description:
    # Function parameters:
    # Global variables:
            
    def Initial_data(self):
        global upgrade_type
        transfer_cmd=[0xAC,0xD1,upgrade_type,0x44]
        print transfer_cmd
        
        messege_pack1=struct.pack('>BBB',transfer_cmd[0],transfer_cmd[1],transfer_cmd[2])
        
        Checksum=self.Calculate_Checksum(transfer_cmd,len(transfer_cmd)-1)
        transfer_cmd[3]=Checksum
        
        messege_pack2=struct.pack('>B',transfer_cmd[3])
        messege_pack=messege_pack1+messege_pack2
        print "messege_pack:",messege_pack
        
        if(CDU_TestRig_MainWindow.close_CDU_flag==1):    
            if(COMConfig_Window.instance_comport_receiver_CDU1.Comport_select==COMConfig_Window.instance_comport_transmitter_CDU1.Comport_select):
                if(CDU_TestRig_MainWindow.class_var3.connect_object_CDU1_receiver!=''):
                    try: 
                        CDU_TestRig_MainWindow.class_var3.connect_object_CDU1_receiver.write(messege_pack)
                    except:
                        pass 
                else:
                    print "obj is empty"
            else:
                if(CDU_TestRig_MainWindow.class_var3.connect_object_CDU1_transmitter!=''):
                    try: 
                        CDU_TestRig_MainWindow.class_var3.connect_object_CDU1_transmitter.write(messege_pack)
                    except:
                        pass
                else:
                    print "obj is empty"
            Timestamp=self.Time_stamp()
            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.SetForegroundColour(wx.Colour(0, 0, 255))
            temp_text="Initial command sent to CDU\n "
            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
        else:           
            if(COMConfig_Window.instance_comport_receiver_CDU2.Comport_select==COMConfig_Window.instance_comport_transmitter_CDU2.Comport_select):
                if(CDU_TestRig_MainWindow.class_var3.connect_object_CDU2_receiver!=''):
                    try: 
                        CDU_TestRig_MainWindow.class_var3.connect_object_CDU2_receiver.write(messege_pack)
                    except:
                        pass 
                else:
                    print "obj is empty"
            else:
                if(CDU_TestRig_MainWindow.class_var3.connect_object_CDU2_transmitter!=''):
                    try: 
                        CDU_TestRig_MainWindow.class_var3.connect_object_CDU2_transmitter.write(messege_pack)
                    except:
                        pass
                else:
                    print "obj is empty"
            Timestamp=self.Time_stamp()
            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.SetForegroundColour(wx.Colour(0, 0, 255))
            temp_text="Initial command sent to CDU\n "
            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
            
    # Description:
    # Function parameters:
    # Global variables:
                
    def Packet_Info_Cmd(self,total_size):
        data_count=50
        total_packets=total_size/data_count
        if(total_size!=0):
            transfer_cmd=[0xAC,0xD2,total_packets,data_count,total_size,0x00,0x44]
            Checksum=self.Calculate_Checksum(transfer_cmd,len(transfer_cmd)-1)
            transfer_cmd[6]=Checksum
        else:
            transfer_cmd=[0xAC,0xD1,total_packets,0,total_size,0x01,0x44]
            Checksum=self.Calculate_Checksum(transfer_cmd,len(transfer_cmd)-1)
            transfer_cmd[6]=Checksum
        print transfer_cmd
        
        messege_pack1=struct.pack('>BBHHIB',transfer_cmd[0],transfer_cmd[1],transfer_cmd[2],transfer_cmd[3],transfer_cmd[4],transfer_cmd[5])
        
        
        messege_pack2=struct.pack('>B',transfer_cmd[6])
        messege_pack=messege_pack1+messege_pack2
        
        if(CDU_TestRig_MainWindow.close_CDU_flag==1): 
            if(COMConfig_Window.instance_comport_receiver_CDU1.Comport_select==COMConfig_Window.instance_comport_transmitter_CDU1.Comport_select):
                if(CDU_TestRig_MainWindow.class_var3.connect_object_CDU1_receiver!=''):
                    try: 
                        CDU_TestRig_MainWindow.class_var3.connect_object_CDU1_receiver.write(messege_pack)
                    except:
                        pass 
                else:
                    print "obj is empty"
            else:
                if(CDU_TestRig_MainWindow.class_var3.connect_object_CDU1_transmitter!=''):
                    try: 
                        CDU_TestRig_MainWindow.class_var3.connect_object_CDU1_transmitter.write(messege_pack)
                    except:
                        pass
                else:
                    print "obj is empty"
            
            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.SetForegroundColour(wx.Colour(0, 0, 255))
            temp_text="Packet information sent to CDU\n "
            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
        else:           
            if(COMConfig_Window.instance_comport_receiver_CDU2.Comport_select==COMConfig_Window.instance_comport_transmitter_CDU2.Comport_select):
                if(CDU_TestRig_MainWindow.class_var3.connect_object_CDU2_receiver!=''):
                    try: 
                        CDU_TestRig_MainWindow.class_var3.connect_object_CDU2_receiver.write(messege_pack)
                    except:
                        pass 
                else:
                    print "obj is empty"
            else:
                if(CDU_TestRig_MainWindow.class_var3.connect_object_CDU2_transmitter!=''):
                    try: 
                        CDU_TestRig_MainWindow.class_var3.connect_object_CDU2_transmitter.write(messege_pack)
                    except:
                        pass
                else:
                    print "obj is empty"
            
            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.SetForegroundColour(wx.Colour(0, 0, 255))
            temp_text="Packet information sent to CDU\n "
            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
            
    # Description:
    # Function parameters:
    # Global variables:
                    
    def Data_Packet(self,packet_no,data):
        data_count=50
        transfer_cmd=[0xAC,0xD3,packet_no]
        
        data_packet=struct.pack('>%ds'%data_count,str(data))
        
        data_upload_packet_for_checksum=(struct.pack('>BBH',transfer_cmd[0],transfer_cmd[1],packet_no))+data_packet
        Checksum=self.Calculate_Checksum1(data_upload_packet_for_checksum,len(data_upload_packet_for_checksum)-1)
        data_upload_packet=data_upload_packet_for_checksum+struct.pack('>B',Checksum)
        
        if(CDU_TestRig_MainWindow.close_CDU_flag==1): 
            if(COMConfig_Window.instance_comport_receiver_CDU1.Comport_select==COMConfig_Window.instance_comport_transmitter_CDU1.Comport_select):
                if(CDU_TestRig_MainWindow.class_var3.connect_object_CDU1_receiver!=''):
                    try: 
                        CDU_TestRig_MainWindow.class_var3.connect_object_CDU1_receiver.write(data_upload_packet)
                    except:
                        pass 
                else:
                    print "obj is empty"
            else:
                if(CDU_TestRig_MainWindow.class_var3.connect_object_CDU1_transmitter!=''):
                    try: 
                        CDU_TestRig_MainWindow.class_var3.connect_object_CDU1_transmitter.write(data_upload_packet)
                    except:
                        pass
                else:
                    print "obj is empty"
            
            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.SetForegroundColour(wx.Colour(0, 0, 255))
            temp_text="Data packet "+str(packet_no)+" information command sent to CDU\n "
            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
            print "Data packet "+str(packet_no)+" information command sent to CDU\n "
        else:
            if(COMConfig_Window.instance_comport_receiver_CDU2.Comport_select==COMConfig_Window.instance_comport_transmitter_CDU2.Comport_select):
                if(CDU_TestRig_MainWindow.class_var3.connect_object_CDU2_receiver!=''):
                    try: 
                        CDU_TestRig_MainWindow.class_var3.connect_object_CDU2_receiver.write(data_upload_packet)
                    except:
                        pass 
                else:
                    print "obj is empty"
            else:
                if(CDU_TestRig_MainWindow.class_var3.connect_object_CDU2_transmitter!=''):
                    try: 
                        CDU_TestRig_MainWindow.class_var3.connect_object_CDU2_transmitter.write(data_upload_packet)
                    except:
                        pass
                else:
                    print "obj is empty"
            
            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.SetForegroundColour(wx.Colour(0, 0, 255))
            temp_text="Data packet "+str(packet_no)+" information command sent to CDU\n "
            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
            print "Data packet "+str(packet_no)+" information command sent to CDU\n "
        
    # Description:
    # Function parameters:
    # Global variables:
                
    def Time_stamp(self):
        # To get the local time of system
        self.now=time.localtime(time.time())
        print "self.now", self.now
        year, month, day, hour, minute, second, weekday, yearday, daylight =self.now
        self.a=str(hour)
        self.b=str(minute)
        self.c=str(second)
        if len(self.a)==1:
            self.a='0'+self.a
        if len(self.b)==1:
            self.b='0'+self.b
        if len( self.c)==1:
            self.c='0'+self.c
        self.Timestamp=self.a+":"+self.b+":"+self.c
##        print "Timestamp", self.Timestamp
        return self.Timestamp
        
         
     
        
        
        
        
        
        
        
        
