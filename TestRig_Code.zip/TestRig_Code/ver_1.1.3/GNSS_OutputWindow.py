#Boa:Frame:GNSS_OutputWindow

import wx
import wx.grid
import COMConfig_Window
from struct import *
from ctypes import *
global GNSS_msg,i,temp_list,flag_frame1  ,GNSS_version_temp ,GNSS_output_temp,GNSS_health_temp
global flag_display1,flag_display2,flag_display3,flag_save,flag_save1,flag_save2
global flag_position,val_latitude,val_longitude,val_altitude ,GNSS_decoded_output_temp,GNSS_decoded_version_temp 
global filename_GNSS_position_data,filename_GNSS_health_data,filename_GNSS_version_data
import string
import struct
import CDU_TestRig_MainWindow
global class_var   
import serial
import threading,Queue 
import win32api
from threading import Thread
from ctypes import *
import string
from serial import  SerialException
import win32api
import time
import GNSS_InputWindow
flag_save=0
flag_save1=0
flag_save2=0
flag_position=0

def create(parent):
    global class_var
    class_var= GNSS_OutputWindow(parent)
    return class_var

[wxID_GNSS_OutputWindow, wxID_GNSS_OutputWindowGRID1, wxID_GNSS_OutputWindowGRID2, wxID_GNSS_OutputWindowGRID3, 
 wxID_GNSS_OutputWindowGRID4, wxID_GNSS_OutputWindowPANEL1, wxID_GNSS_OutputWindowSTATICTEXT1, 
 wxID_GNSS_OutputWindowSTATICTEXT2, wxID_GNSS_OutputWindowSTATICTEXT3, wxID_GNSS_OutputWindowSTATICTEXT4, 
] = [wx.NewId() for _init_ctrls in range(10)]


class GNSS_OutputWindow(wx.Frame):
    def __init__(self, parent):
        self._init_ctrls(parent)
             
        
    def _init_ctrls(self, prnt):
        # generated method, don't edit
        self.pixel1=wx.GetDisplaySize() 
##        print self.pixel1
        
        ##Length and width of Main Window
        self.Main_window_Length1=self.pixel1[0]/1.0058
        self.Main_window_Width1=self.pixel1[1]/1.246
        self.Main_window_Start_y1=self.pixel1[1]/6.22
        
        wx.Frame.__init__(self, id=wxID_GNSS_OutputWindow, name='', parent=prnt,
              pos=wx.Point(0, self.Main_window_Start_y1), size=wx.Size(1018, 616),
              style=wx.SYSTEM_MENU | wx.CAPTION | wx.MINIMIZE_BOX|wx.CLOSE_BOX, title='CDU TestRig:: GNSS-Output Window')
        self.SetClientSize(wx.Size( 1018, 616))
        self.Bind(wx.EVT_CLOSE, self.OnGNSS_OutputWindowClose)
        self.GNSS_Output_panel = wx.Panel(id=wxID_GNSS_OutputWindowPANEL1, name='GNSS_Output_panel', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(1018, 616),
              style=wx.TAB_TRAVERSAL)
              
        ##Position for StaticText2
        self.StaticText2_Start_x=(self.pixel1[0]/1.55)
        self.StaticText2_Start_y=(self.pixel1[1]/64)
        self.StaticText2_Length=(self.pixel1[0]/3.12)
        self.StaticText_Width=(self.pixel1[1]/59.08)
        
        ##Position for StaticText3
        self.StaticText3_Start_x=(self.pixel1[0]/9.23)
        self.StaticText3_Start_y=(self.pixel1[1]/64)
        self.StaticText3_Length=(self.pixel1[0]/4.63)

        ##Position for StaticText3
        self.StaticText4_Start_x=(self.pixel1[0]/5.9)
        self.StaticText4_Start_y=(self.pixel1[1]/1.69)
        self.StaticText4_Length=(self.pixel1[0]/5.69)
        
        ##Position for grid_position
        self.grid_position_Start_x=(self.pixel1[0]/28.44)
        self.grid_position_Start_y=(self.pixel1[1]/19.69)
        self.grid_position_Length=(self.pixel1[0]/2.33)
        self.grid_position_Width=(self.pixel1[1]/2.037)
        
        ##Position for grid_health
        self.grid_health_Start_x=(self.pixel1[0]/1.86)
        self.grid_health_Start_y=(self.pixel1[1]/19.69)
        self.grid_health_Length=(self.pixel1[0]/2.322)
        self.grid_health_Width=(self.pixel1[1]/1.34)
        
        ##Position for grid_version
        self.grid_version_Start_x=(self.pixel1[0]/28.44)
        self.grid_version_Start_y=(self.pixel1[1]/1.63)
        self.grid_version_Length=(self.pixel1[0]/2.34)
        self.grid_version_Width=(self.pixel1[1]/8.17)
        
        self.sta_GNSS_health = wx.StaticText(id=wxID_GNSS_OutputWindowSTATICTEXT2,
              label='GNSS Status/Receiver Health Message ',
              name='sta_GNSS_health', parent=self.GNSS_Output_panel, pos=wx.Point(635, self.StaticText2_Start_y),
              size=wx.Size(self.StaticText2_Length, self.StaticText_Width), style=0)
        self.sta_GNSS_health.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD, False,   
              'Tahoma'))
        self.sta_GNSS_position = wx.StaticText(id=wxID_GNSS_OutputWindowSTATICTEXT3,
              label='GNSS Output Message (Position, Velocity and Time)', name='sta_GNSS_position',
              parent=self.GNSS_Output_panel, pos=wx.Point(133, 12), size=wx.Size(221, 13),
              style=0)                  
        self.sta_GNSS_position.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD, False,
              'Tahoma'))
        self.sta_GNSS_version= wx.StaticText(id=wxID_GNSS_OutputWindowSTATICTEXT4,
              label='GNSS Receiver Version Message', name='sta_GNSS_version',                            
              parent=self.GNSS_Output_panel, pos=wx.Point(self.StaticText4_Start_x,454), size=wx.Size(self.StaticText4_Length, self.StaticText_Width),
              style=0)
        self.sta_GNSS_version.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD, False,
              'Tahoma'))                               
        self.grid_position = wx.grid.Grid(id=wxID_GNSS_OutputWindowGRID1, name='grid_position',
              parent=self.GNSS_Output_panel, pos=wx.Point(59,39), size=wx.Size(392,377.02), 
              style=wx.SIMPLE_BORDER)
        self.Create_grid_position()
        self.grid_health = wx.grid.Grid(id=wxID_GNSS_OutputWindowGRID3, name='grid_health',
              parent=self.GNSS_Output_panel, pos=wx.Point(525, 39), size=wx.Size(440, 573),
              style=wx.SIMPLE_BORDER )
        self.Create_grid_health()                     
        self.grid_version = wx.grid.Grid(id=wxID_GNSS_OutputWindowGRID4, name='grid_version',
              parent=self.GNSS_Output_panel, pos=wx.Point(59, 480), size=wx.Size(392,
            94), style=wx.SIMPLE_BORDER )
        self.Create_grid_version()
        self.display_heading()
        self.display_heading1()
        self.display_heading2()
        self.timer=wx.Timer(self)
        self.Bind(wx.EVT_TIMER,self.refresh)
        self.timer.Start(1000) 
        self.connect_object=''
    def Create_grid_position(self):
        self.grid_position.CreateGrid(17,3)
        self.grid_position.DisableDragGridSize()
        self.grid_position.DisableDragColSize()
        self.grid_position.DisableDragRowSize()
        self.grid_labels=["Field Name","Value","Unit"]
        for i in range (3):
            self.grid_position.SetColLabelValue(i,self.grid_labels[i])
            for i in range (17):
                for j in range (1):
                    self.grid_position.SetRowSize( i, 20);               
                    self.grid_position.SetColSize( j, 166); 
                    self.grid_position.SetCellAlignment(i,j,wx.ALIGN_LEFT,wx.ALIGN_LEFT)
                    self.grid_position.SetReadOnly(i,j)
            for i in range (17):
                for j in range (1,2):
                    self.grid_position.SetRowSize( i, 20);               
                    self.grid_position.SetColSize( j, 165); 
                    self.grid_position.SetCellAlignment(i,j,wx.ALIGN_LEFT,wx.ALIGN_LEFT)
                    self.grid_position.SetReadOnly(i,j)
            for i in range (17):
                for j in range (2,3):
                    self.grid_position.SetRowSize( i, 20);               
                    self.grid_position.SetColSize( j, 52); 
                    self.grid_position.SetCellAlignment(i,j,wx.ALIGN_LEFT,wx.ALIGN_LEFT)
                    self.grid_position.SetReadOnly(i,j)
                    self.grid_position.SetCellValue(i,j,"  -")
            for i in range (17) :
                for j in range( 2):
                  self.grid_position.SetCellValue(i,j,"  -")
                   
        self.grid_position.SetRowLabelSize(0)
        self.grid_position.SetColLabelSize(30)

    def Create_grid_health(self):
        self.grid_health .CreateGrid(27,3)
        self.grid_health.DisableDragGridSize()
        self.grid_health.DisableDragColSize()
        self.grid_health.DisableDragRowSize()
        self.grid_labels=["Field Name","Value","Unit"]
        for i in range (3):
            self.grid_health.SetColLabelValue(i,self.grid_labels[i])
            for i in range (27):
                for j in range (1):
                    self.grid_health.SetRowSize( i, 20);               
                    self.grid_health.SetColSize( j, 217);
                    self.grid_health.SetCellAlignment(i,j,wx.ALIGN_LEFT,wx.ALIGN_LEFT)
                    self.grid_health.SetReadOnly(i,j)
            for i in range (27):
                for j in range (1,2):
                    self.grid_health.SetRowSize( i, 20);               
                    self.grid_health.SetColSize( j, 165); 
                    self.grid_health.SetCellAlignment(i,j,wx.ALIGN_LEFT,wx.ALIGN_LEFT)
                    self.grid_health.SetReadOnly(i,j)
            for i in range (27):
                for j in range (2,3):
                    self.grid_health.SetRowSize( i, 20);               
                    self.grid_health.SetColSize( j, 52); 
                    self.grid_health.SetCellAlignment(i,j,wx.ALIGN_LEFT,wx.ALIGN_LEFT)
                    self.grid_health.SetReadOnly(i,j)
            for i in range (27):
                for j in range (1,3):
                    self.grid_health.SetCellValue(i,j,"  -") 
        self.grid_health.SetCellFont(1,0,wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD))
        self.grid_health.SetCellFont(11,0,wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD))    
        self.grid_health.SetRowLabelSize(0)
        self.grid_health.SetColLabelSize(30)
            
    def Create_grid_version(self):
        self.grid_version .CreateGrid(3,3)
        self.grid_version.DisableDragGridSize()
        self.grid_version.DisableDragColSize()
        self.grid_version.DisableDragRowSize()
        self.grid_labels=["Field Name","Value","Unit"]
        for i in range (3):
            self.grid_version.SetColLabelValue(i,self.grid_labels[i])
            for i in range (3):
                for j in range (1):
                    self.grid_version.SetRowSize( i, 20);                
                    self.grid_version.SetColSize( j, 166); 
                    self.grid_version.SetCellAlignment(i,j,wx.ALIGN_LEFT,wx.ALIGN_LEFT)
                    self.grid_version.SetReadOnly(i,j)
            for i in range (3):
                for j in range (1,2):
                    self.grid_version.SetRowSize( i, 20);               
                    self.grid_version.SetColSize( j, 165); 
                    self.grid_version.SetCellAlignment(i,j,wx.ALIGN_LEFT,wx.ALIGN_LEFT)
                    self.grid_version.SetReadOnly(i,j)
            for i in range (3):
                for j in range (2,3):
                    self.grid_version.SetRowSize( i, 20);               
                    self.grid_version.SetColSize( j, 52); 
                    self.grid_version.SetCellAlignment(i,j,wx.ALIGN_LEFT,wx.ALIGN_LEFT)
                    self.grid_version.SetReadOnly(i,j) 
            for i in range (3):
                for j in range (1,3):
                    self.grid_version.SetCellValue(i,j,"  -") 
            self.grid_version.SetRowLabelSize(0)
            self.grid_version.SetColLabelSize(30)
                
    def display_heading(self):
        global GNSS_output_temp
        self.grid_position.SetCellValue(0,0,"  Position" )
        self.grid_position.SetCellValue(1,0,"  Receiver Latitude" )
        self.grid_position.SetCellValue(2,0,"  Receiver Longitude" )
        self.grid_position.SetCellValue(3,0,"  Receiver Altitude" )  
        self.grid_position.SetCellValue(4,0,"  Ground speed") 
        self.grid_position.SetCellValue(5,0,"  Heading" )
        self.grid_position.SetCellValue(6,0,"  Receiver North Velocity" )
        self.grid_position.SetCellValue(7,0,"  Receiver East Velocity") 
        self.grid_position.SetCellValue(8,0,"  Receiver Vertical Velocity" ) 
        self.grid_position.SetCellValue(9,0,"  UTC Date")  
        self.grid_position.SetCellValue(10,0, "  UTC Time") 
        self.grid_position.SetCellValue(11,0,"  HPL" ) 
        self.grid_position.SetCellValue(12,0,"  HFOM" )  
        self.grid_position.SetCellValue(13,0,"  VPL" )
        self.grid_position.SetCellValue(14,0,"  VFOM" )   
        self.grid_position.SetCellValue(15,0,"  PPS Status" )
        self.grid_position.SetCellValue(16,0,"  Position Computation by" )
        self.grid_position.SetCellValue(1,2,"  deg")   
        self.grid_position.SetCellValue(2,2,"  deg") 
        self.grid_position.SetCellValue(3,2,"  meters")
        self.grid_position.SetCellValue(4,2,"  knots")
        self.grid_position.SetCellValue(5,2,"  deg" )
        self.grid_position.SetCellValue(6,2,"  knots")  
        self.grid_position.SetCellValue(7,2,"  knots")  
        self.grid_position.SetCellValue(8,2,"  knots")   
        self.grid_position.SetCellValue(9,2,"  -") 
        self.grid_position.SetCellValue(10,2,"  -") 
        self.grid_position.SetCellValue(11,2, "  NM")
        self.grid_position.SetCellValue(12,2, "  NM")   
        self.grid_position.SetCellValue(13,2,"  feet" )      
        self.grid_position.SetCellValue(14,2,"  feet" )  
        self.grid_position.SetCellValue(15,2,"  -" )
        
    def display_heading1(self):
        self.grid_health.SetCellValue(0,0,"  GPS Start Mode" ) 
        self.grid_health.SetCellValue(1,0,"  GNSS Mode")           
        self.grid_health.SetCellValue(2,0,"      Navigation with GAGAN Corrections") 
        self.grid_health.SetCellValue(3,0,"      Navigation with Integrity")        
        self.grid_health.SetCellValue(4,0, "      2D Navigation with Altitude Aid")      
        self.grid_health.SetCellValue(5,0, "      3D Navigation")                   
        self.grid_health.SetCellValue(6,0, "      Fault Integrity Fails During Navigation")
        self.grid_health.SetCellValue(7,0,"  Phase of Flight") 
        self.grid_health.SetCellValue(8,0,"  Number of Tracking GPS Satellites")
        self.grid_health.SetCellValue(9,0,"  Number of Tracking GLONASS Satellites")
        self.grid_health.SetCellValue(10,0,"  Number of Tracking GAGAN Satellites")
        self.grid_health.SetCellValue(11,0,"  Fault Status")
        self.grid_health.SetCellValue(12,0,"      Antenna Connected")
        self.grid_health.SetCellValue(13,0,"      Antenna State")    
        self.grid_health.SetCellValue(14,0,"      RF1 (GPS + GAGAN RF) PLL Locked")     
        self.grid_health.SetCellValue(15,0,"      RF2 (GLONASS) PLL Locked\n")      
        self.grid_health.SetCellValue(16,0,"      CPU1(GPS +GLONASS processor)")    
        self.grid_health.SetCellValue(17,0,"      CPU2 (GAGAN)")     
        self.grid_health.SetCellValue(18,0,"      Satellites Availability") 
        self.grid_health.SetCellValue(19,0,"      PDOP Value") 
        self.grid_health.SetCellValue(20,0,"      GAGAN Satellites are Used for Position Computation") 
        self.grid_health.SetCellValue(21,0,"      GNSS System Failure")  
        self.grid_health.SetCellValue(22,0,"      GNSS Mode")  
        self.grid_health.SetCellValue(23,0,"  PDOP Value") 
        self.grid_health.SetCellValue(24,0,"  HDOP Value")     
        self.grid_health.SetCellValue(25,0,"  VDOP Value")    
        self.grid_health.SetCellValue(26,0,"  TDOP Value")      
           
    def display_heading2(self):
        self.grid_version.SetCellValue(0,0,"  Hardware Version Number" )
        self.grid_version.SetCellValue(1,0,"  Software Version Number" )    
        self.grid_version.SetCellValue(2,0,"  Software Release Date" )     
                          
    def  OnGNSS_OutputWindowClose(self,event):
        CDU_TestRig_MainWindow.flag_frame1=0
        self.Destroy()

    def refresh(self,event):
##        print "refresh"
        global flag_display1,flag_display2,flag_display3,flag_save,flag_save1,flag_save2
        temp_message=message()
        if( flag_save==1):
##            temp_message.display_validate()
            temp_message.display_msg()
        if(flag_save1==1 ):
##            temp_message.display_health_validate()
            temp_message.display1()
        if(flag_save2==1):
##            temp_message.display_version_validate()
            temp_message.display3() 
       
class GNSS_output(Structure):
	_fields_ = [
	            ("Preamble",c_uint),
	            ("Position_availability", c_byte ,1),          
                ("Data_Validity_Flags", c_uint,16 ),          
                ("Position", c_byte,2), 
                ("Receiver_latitude",c_double ),  
                ("Receiver_longitude",c_double),
                ("Receiver_altitude",c_float), 
                ("Ground_Speed",c_float),
                ("Heading",c_uint,16),
                ("Receiver_North_Velocity",c_float),
                ("Receiver_east_velocity",c_float),
                ("Receiver_vertical_velocity",c_float),
                ("UTC_time_Hour",c_ushort,5),
                ("UTC_time_Minutes",c_ushort,6),
                ("UTC_time_Seconds",c_ushort,6),
                ("UTC_time_Date",c_ushort,5),
                ("UTC_time_Month",c_ushort,4),
                ("UTC_time_Year", c_ushort,7),
                ("HPL",c_float),
                ("HFOM",c_float),
                ("VPL",c_float),
                ("VFOM",c_float),
                ("Checksum",c_byte,8),
                ("Linefeed", c_uint,8),                
                ]
class GNSS_decoded_output(Structure):
	_fields_ = [
                ("Position_availability", c_char_p),          
                ("Position_Computation ",c_char_p), 
                ("Receiver_latitude",c_char_p ),  
                ("Receiver_longitude",c_char_p),
                ("Receiver_altitude",c_char_p), 
                ("Ground_Speed",c_char_p),
                ("Heading",c_char_p),
                ("Receiver_North_Velocity",c_char_p),
                ("Receiver_east_velocity",c_char_p),
                ("Receiver_vertical_velocity",c_char_p),
                ("UTC_date",c_char_p),
                ("UTC_time",c_char_p),
                ("HPL",c_char_p),
                ("HFOM",c_char_p),
                ("VPL",c_char_p),
                ("VFOM",c_char_p),
                ("PPS",c_char_p),
                ("Checksum",c_char_p),
                ("Linefeed", c_char_p),                
                ]                
class GNSS_health(Structure):
    _fields_ = [
	            ("Mode",c_byte,7),
	            ("Phase_of_flight", c_byte ,3),          
                ("No_of_tracking_GPS_satellites", c_byte ),          
                ("No_of_tracking_GLONASS_satellites", c_byte), 
                ("No_of_tracking_GAGAN_satellites",c_byte ),  
                ("Fault_Status",c_uint,10),
                ("PDOP",c_ushort), 
                ("HDOP",c_ushort),
                ("VDOP",c_ushort),
                ("TDOP",c_ushort),
                ("Checksum",c_ushort),
                ("Linefeed", c_ushort),                
                ]   
class GNSS_decoded_health(Structure):
	_fields_ = [
	            ("GNSS_Start_Mode",c_char_p),
	            ("Navigation_with_GAGAN", c_char_p),          
                ("Navigation_with_Integrity", c_char_p ),          
                ("Navigation_2D", c_char_p), 
                ("Navigation_3D",c_char_p ),  
                ("FaultIntegrity",c_char_p),
                ("Phase_of_Flight",c_char_p), 
                ("GPS_Satellites",c_char_p),
                ("GLONASS_Satellites",c_char_p),
                ("GAGAN_Satellites",c_char_p),
                ("Antenna",c_char_p),
                ("Antenna_state", c_char_p),  
                ("RF1", c_char_p),    
                ("RF2", c_char_p),
                ("CPU1", c_char_p),
                ("CPU2", c_char_p),
                ("Satellites_avail",c_char_p),
                ("PDOP1",c_char_p),
                ("GAGAN_position",c_char_p),
                ("GNSS_system_failure",c_char_p),
                ("GNSS_mode",c_char_p),
                ("PDOP_value",c_char_p),
                ("HDOP" ,c_char_p),
                ("VDOP",c_char_p),
                ("TDOP",c_char_p),
                ]   
class GNSS_version(Structure):
	_fields_ = [
	            ("Hardware_version_number",c_ubyte ),
	            ("Software_version_x1",c_ubyte  ),
	            ("Software_version_x2",c_ubyte  ),
	            ("Software_version_y1",c_ubyte  ),
	            ("Software_version_y2",c_ubyte  ),
	            ("Software_version_z1",c_ubyte ),   
	            ("Software_version_z2",c_ubyte ),          
                ("Software_release_day", c_byte ),          
                ("Software_release_month", c_byte), 
                ("Software_release_year",c_byte ),  
                ]   
class GNSS_decoded_version(Structure):
	_fields_ = [
	            ("Hardware_version_number",c_char_p ),
	            ("Software_version",c_char_p  ),
	            ("Software_release_date", c_char_p ),          
               ]   

GNSS_output_temp= GNSS_output()
GNSS_health_temp=GNSS_health()
GNSS_version_temp=GNSS_version()
GNSS_decoded_output_temp=GNSS_decoded_output()
GNSS_decoded_health_temp=GNSS_decoded_health()
GNSS_decoded_version_temp=GNSS_decoded_version()                               
                            
class message:    
    def split_msg(self,temp):
        temp4=string.split(temp,'0x')
        len1=len(temp4)
        temp5='0'
        for i in range(len1):
            temp5=temp5+temp4[i]
        temp6 ='0x'+temp5
##        print temp6
        return temp6 

    ##Function to convert hexa value into float
    def convert_to_float(self,list):
            val=''
##            print list
            for element in list:
                valwithout0x=string.split(element,'0x')[1]
                val=val+valwithout0x
##            print val
            value=(struct.unpack('!f', val.decode('hex'))[0])
##            print(value)
            return value
        
    ##Function to convert hexa value into double    
    def convert_to_double(self,list):
            val=''
##            print list
            for element in list:
                valwithout0x=string.split(element,'0x')[1]
                val=val+valwithout0x
##            print val
            value=(struct.unpack('!d', val.decode('hex'))[0])
##            print(value)
            return value             
    def process_msg(self,temp_list):
        global GNSS_output_temp,flag_save
        self.temp_list1=[]
        temp_check=(len(temp_list))-2
##        print temp_check
        for j in range(0,temp_check):
            self.temp_list1.append(temp_list[j])
##        print self.temp_list1  
        # Appending line feed to calculate the checksum
        self.temp_list1.append('0X0a')
##        print self.temp_list1 
        # Function to calculate checksum
        Checksum=self.Calculate_Checksum(self.temp_list1,69)
##        print Checksum
##        print ",,,,   ",len(temp_list)
        GNSS_check=temp_list[temp_check]
        GNSS_check1=int(GNSS_check,16)
##        print "GNSS_check1",GNSS_check1
##        print "checksum",Checksum
        temp_linefeed=len(temp_list)-1
        # Comparing checksum and linefeed
        if((Checksum==GNSS_check1) and (temp_list[temp_linefeed]=='0x0a')):
            flag_save=1
##            print "processing"
            GNSS_output_temp.Position_availability=int(temp_list[4],16)
##            print " GNSS_output_temp.Position_availability", GNSS_output_temp.Position_availability
            temp3=temp_list[5]+temp_list[6]
##            print "temp3",temp3
            temp_validity=self.split_msg(temp3)
##            print temp_validity 
            GNSS_output_temp.Data_Validity_Flags=int(temp_validity,16)
            GNSS_output_temp.Position=int(temp_list[7],16)
            GNSS_output_temp.Receiver_latitude=self.convert_to_double(temp_list[8:16])
            GNSS_output_temp.Receiver_longitude=self.convert_to_double(temp_list[16:24])
            GNSS_output_temp.Receiver_altitude=self.convert_to_float(temp_list[24:28])
            GNSS_output_temp.Ground_Speed=self.convert_to_float(temp_list[28:32])
            temp_heading=(temp_list[32]+temp_list[33]) 
            temp_heading1=self.split_msg(temp_heading)
            GNSS_output_temp.Heading=int(temp_heading1,16)               
            GNSS_output_temp.Receiver_North_Velocity=self.convert_to_float(temp_list[34:38])
            GNSS_output_temp.Receiver_east_velocity=self.convert_to_float(temp_list[38:42])
            GNSS_output_temp.Receiver_vertical_velocity=self.convert_to_float(temp_list[42:46])
            GNSS_output_temp.UTC_time_Hour=int(temp_list[46],16)
            GNSS_output_temp.UTC_time_Minutes=int(temp_list[47],16)
            GNSS_output_temp.UTC_time_Seconds=int(temp_list[48],16)         
            GNSS_output_temp.UTC_time_Date=int(temp_list[49],16)
            GNSS_output_temp.UTC_time_Month=int(temp_list[50],16)
            GNSS_output_temp.UTC_time_Year=int(temp_list[51],16)
            GNSS_output_temp.HPL=self.convert_to_float(temp_list[52:56])
            GNSS_output_temp.HFOM=self.convert_to_float(temp_list[56:60])
            GNSS_output_temp.VPL=self.convert_to_float(temp_list[60:64])
            GNSS_output_temp.VFOM=self.convert_to_float(temp_list[64:68])           
            GNSS_output_temp.Checksum=int(temp_list[69],16)
        else:
            flag_save=0
            Timestamp=self.Time_stamp()
            temp_text="\nGNSS output Message (Position, Velocity and Time) received at  "+ str(Timestamp)+"  instance is invalid " 
            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
##            print "GNSS output Message is Invalid"
    def process_msg1(self,health_list1):
##        print "here1"
        global GNSS_health_temp,flag_save1
        temp_check2=(len(health_list1))-2
        self.temp_list2=[]
        for j in range(0,temp_check2):
            self.temp_list2.append(health_list1[j]) 
        self.temp_list2.append('0x0a')      
        Checksum2=self.Calculate_Checksum(self.temp_list2,16)
##        print "Checksum2",Checksum2
        GNSS_check2=(health_list1[temp_check2])
        
        GNSS_chksum2=int(GNSS_check2,16)
##        print "GNSS_chksum2",GNSS_chksum2
        temp_linefeed2=len(health_list1)-1
        
        
        if((Checksum2==GNSS_chksum2)and(health_list1[temp_linefeed2]=='0x0a')):
            flag_save1=1
            GNSS_health_temp.Mode=int(health_list1[4],16)
            GNSS_health_temp.Phase_of_flight=int(health_list1[5],16)
            GNSS_health_temp.No_of_tracking_GPS_satellites=int(health_list1[6],16)
            GNSS_health_temp.No_of_tracking_GLONASS_satellites=int(health_list1[7],16)
            GNSS_health_temp.No_of_tracking_GAGAN_satellites=int(health_list1[8],16)
            temp_fault=self.split_msg(health_list1[9]+health_list1[10])
            GNSS_health_temp.Fault_Status=int(temp_fault,16)
            GNSS_health_temp.PDOP=int(health_list1[11],16)
            GNSS_health_temp.HDOP=int(health_list1[12],16)
            GNSS_health_temp.VDOP=int(health_list1[13],16)
            GNSS_health_temp.TDOP=int(health_list1[14],16)
        else:
            flag_save1=0
            Timestamp=self.Time_stamp()
            temp_text2="\nGNSS receiver health message received at  "+ str(Timestamp)+"  instance is invalid " 
            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text2)
##            print "GNSS status/receiver health Message is Invalid"
    def process_msg2(self,version_list1):
##        print "here1"
        global flag_save2,GNSS_version_temp
        self.temp_list3=[]
        temp_check3=(len(version_list1))-2 
##        print temp_check3
        for j in range(0,temp_check3):
            self.temp_list3.append(version_list1[j]) 
        self.temp_list3.append('0x0a') 
##        print self.temp_list3      
        Checksum3=self.Calculate_Checksum(self.temp_list3,19)                                    
##        print "Checksum3",Checksum3
        GNSS_check3=(version_list1[temp_check3])
        GNSS_chksum3=int(GNSS_check3,16)
##        print "GNSS_chksum3",GNSS_chksum3
        temp_linefeed3=len(version_list1)-1
##        print "version_list1[temp_linefeed3]",version_list1[temp_linefeed3]
##        print "Checksum3,GNSS_chksum3",Checksum3,GNSS_chksum3
        if((version_list1[temp_linefeed3]=='0x0a')and(Checksum3==GNSS_chksum3)):
            flag_save2=1
            GNSS_version_temp.Hardware_version_number=int(version_list1[4],16)
            GNSS_version_temp.Software_version_x1=int(version_list1[6],16)
            GNSS_version_temp.Software_version_x2= int(version_list1[7],16)
            GNSS_version_temp.Software_version_y1=int(version_list1[8],16)
            GNSS_version_temp.Software_version_y2=int(version_list1[9],16)
            GNSS_version_temp.Software_version_z1=int(version_list1[10],16)
            GNSS_version_temp.Software_version_z2=int(version_list1[11],16)
            GNSS_version_temp.Software_release_day=int(version_list1[12],16)
            GNSS_version_temp.Software_release_month=int(version_list1[13],16) 
            GNSS_version_temp.Software_release_year=int(version_list1[14],16) 
        else:
##            print "invalid"
##            print "version_list1[temp_linefeed3]",version_list1[temp_linefeed3]
##            print "Checksum3,GNSS_chksum3",Checksum3,GNSS_chksum3
            flag_save2=0
            Timestamp=self.Time_stamp()
            temp_text3=" \n GNSS receiver version message received at  "+ str(Timestamp)+"  instance is invalid " 
            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text3)
##            print "GNSS receiver version message is Invalid"
    def display_validate(self):
        global GNSS_output_temp,GNSS_decoded_output_temp
        var_time=''
        if((GNSS_output_temp.Position_availability & 1)==1):
            GNSS_decoded_output_temp.Position_availability="Available"
##            print "..........",  GNSS_decoded_output_temp.Position_availability
        elif((GNSS_output_temp.Position_availability &1)==0):
            GNSS_decoded_output_temp.Position_availability="Unavailable"
##            print "..........",  GNSS_decoded_output_temp.Position_availability
        if((GNSS_output_temp.Data_Validity_Flags & 1)==1):
                if((GNSS_output_temp.Receiver_latitude >= -90) and (GNSS_output_temp.Receiver_latitude <= 90)):
                  GNSS_decoded_output_temp.Receiver_latitude=str(GNSS_output_temp.Receiver_latitude)
                else:
                    GNSS_decoded_output_temp.Receiver_latitude="Out of Range"
                    
                if((GNSS_output_temp.Receiver_longitude >= -180) and (GNSS_output_temp.Receiver_longitude <= 180)):
                  GNSS_decoded_output_temp.Receiver_longitude=str(GNSS_output_temp.Receiver_longitude)
                else:
                   GNSS_decoded_output_temp.Receiver_longitude="Out of Range"
        else:
                GNSS_decoded_output_temp.Receiver_latitude="Invalid"
                GNSS_decoded_output_temp.Receiver_longitude="Invalid"
        if((GNSS_output_temp.Data_Validity_Flags & 2)==2):
             if((GNSS_output_temp.Receiver_altitude >=-1000) and(GNSS_output_temp.Receiver_altitude <=18000)):
                 GNSS_decoded_output_temp.Receiver_altitude=str(GNSS_output_temp.Receiver_altitude)
                 
             else:
                 GNSS_decoded_output_temp.Receiver_altitude="Out of Range"
        else:
            GNSS_decoded_output_temp.Receiver_altitude="Invalid"
            
        if((GNSS_output_temp.Ground_Speed>=0) and (GNSS_output_temp.Ground_Speed<=1000)):  
            GNSS_decoded_output_temp.Ground_Speed=str(GNSS_output_temp.Ground_Speed)
        else:
                GNSS_decoded_output_temp.Ground_Speed="Out of Range"
        if((GNSS_output_temp.Heading <0)or (GNSS_output_temp.Heading >360)):
           GNSS_decoded_output_temp.Heading="Out of Range"
        else:
            if(GNSS_output_temp.Heading==0):
                 GNSS_decoded_output_temp.Heading="Heading Towards North"
            elif(GNSS_output_temp.Heading==180):
                 GNSS_decoded_output_temp.Heading="Heading Towards South" 
            else :
                GNSS_decoded_output_temp.Heading=str(GNSS_output_temp.Heading)
              
        if((GNSS_output_temp.Data_Validity_Flags & 4)==4):
##            print "Receiver_North_Velocity is valid and it's value is",
##            print round(GNSS_output_temp.Receiver_North_Velocity,2)
         
            if((GNSS_output_temp.Receiver_North_Velocity>=-1000)and(GNSS_output_temp.Receiver_North_Velocity<=1000)):
                if(GNSS_output_temp.Receiver_North_Velocity<0):
                    GNSS_decoded_output_temp.Receiver_North_Velocity=str(GNSS_output_temp.Receiver_North_Velocity)+" "+'S'
                else:
                    GNSS_decoded_output_temp.Receiver_North_Velocity=str(GNSS_output_temp.Receiver_North_Velocity)+" "+'N'
                   
            else:
    
               GNSS_decoded_output_temp.Receiver_North_Velocity="Out of Range"
            if((GNSS_output_temp.Receiver_east_velocity>=-1000)and(GNSS_output_temp.Receiver_east_velocity<=1000)):
                  
                    if(GNSS_output_temp.Receiver_east_velocity<0):
                         GNSS_decoded_output_temp.Receiver_east_velocity=str(GNSS_output_temp.Receiver_east_velocity)+'W'
                        
                    else:
                          GNSS_decoded_output_temp.Receiver_east_velocity=str(GNSS_output_temp.Receiver_east_velocity)+'E'
                          
            else:
               GNSS_decoded_output_temp.Receiver_east_velocity="Out of Range"
                                      
        else:
            GNSS_decoded_output_temp.Receiver_North_Velocity="Invalid"
            GNSS_decoded_output_temp.Receiver_east_velocity="Invalid"
        
        if((GNSS_output_temp.Data_Validity_Flags & 8)==8):
            if((GNSS_output_temp.Receiver_vertical_velocity>=-1000)and(GNSS_output_temp.Receiver_vertical_velocity<=1000)):
                GNSS_decoded_output_temp.Receiver_vertical_velocity=str(GNSS_output_temp.Receiver_vertical_velocity )
            else:
                 GNSS_decoded_output_temp.Receiver_vertical_velocity="Out of Range"
        else:
            GNSS_decoded_output_temp.Receiver_vertical_velocity="Invalid"
            
        if((GNSS_output_temp.Data_Validity_Flags & 16)==16):

            if(((GNSS_output_temp.UTC_time_Date>=1) and(GNSS_output_temp.UTC_time_Date<=31)) and \
               ((GNSS_output_temp.UTC_time_Month>=1) and (GNSS_output_temp.UTC_time_Month<=12)) and \
               ((GNSS_output_temp.UTC_time_Year>=0) and (GNSS_output_temp.UTC_time_Year<=127))):
                var_year=GNSS_output_temp.UTC_time_Year+2012
                if((int(GNSS_output_temp.UTC_time_Date>=1))and (int(GNSS_output_temp.UTC_time_Date<=9))):
                    UTC_time_Date_temp="0"+str(GNSS_output_temp.UTC_time_Date)
                else:
                    UTC_time_Date_temp=str(GNSS_output_temp.UTC_time_Date)  
                if((int(GNSS_output_temp.UTC_time_Month>=1))and (int(GNSS_output_temp.UTC_time_Month<=9))):
                    UTC_time_Month_temp="0"+str(GNSS_output_temp.UTC_time_Month)
                else:
                    UTC_time_Month_temp=str(GNSS_output_temp.UTC_time_Month)
                var_date=str(UTC_time_Date_temp)+"/"+\
                str(UTC_time_Month_temp)+"/"+\
                str(var_year)
                GNSS_decoded_output_temp.UTC_date=var_date 
                                       
            else:
                  GNSS_decoded_output_temp.UTC_date="Out of Range"
            if(((GNSS_output_temp.UTC_time_Hour>=0)and(GNSS_output_temp.UTC_time_Hour<=23))and \
               ((GNSS_output_temp.UTC_time_Minutes>=0) and(GNSS_output_temp.UTC_time_Minutes<=59))and \
               ((GNSS_output_temp.UTC_time_Seconds>=0)and (GNSS_output_temp.UTC_time_Seconds<=59))):
                var_time=var_time+str(GNSS_output_temp.UTC_time_Hour)+":"+\
                str(GNSS_output_temp.UTC_time_Minutes)+":"+\
                str(GNSS_output_temp.UTC_time_Seconds)
                GNSS_decoded_output_temp.UTC_time=var_time
            else:
                GNSS_decoded_output_temp.UTC_time="Out of Range"
              
        else:
              GNSS_decoded_output_temp.UTC_date="Invalid"
              GNSS_decoded_output_temp.UTC_time="Invalid"

        if((GNSS_output_temp.Data_Validity_Flags & 32)==32):    
            if((GNSS_output_temp.HPL>=0)and(GNSS_output_temp.HPL<=16)):
                GNSS_decoded_output_temp.HPL=str(GNSS_output_temp.HPL)
            else:
                GNSS_decoded_output_temp.HPL="Out of Range"
        else:
            GNSS_decoded_output_temp.HPL="Invalid"
         
        if((GNSS_output_temp.Data_Validity_Flags & 64)==64): 
            if((GNSS_output_temp.HFOM>=0)and(GNSS_output_temp.HFOM<=16)):  
                GNSS_decoded_output_temp.HFOM=str(GNSS_output_temp.HFOM)
             
            else:
                 GNSS_decoded_output_temp.HFOM="Out of Range"
        else:
             GNSS_decoded_output_temp.HFOM="Invalid"
     
        if((GNSS_output_temp.Data_Validity_Flags & 128)==128): 
            if((GNSS_output_temp.VPL>=0)and(GNSS_output_temp.VPL<=32768)):  
                GNSS_decoded_output_temp.VPL=str(GNSS_output_temp.VPL)
            else:
                GNSS_decoded_output_temp.VPL="Out of Range"
                
        else: 
           GNSS_decoded_output_temp.VPL="Invalid"
        if((GNSS_output_temp.Data_Validity_Flags & 256)==256):
            if((GNSS_output_temp.VFOM>=0)and(GNSS_output_temp.VFOM<=32768)):      
                 GNSS_decoded_output_temp.VFOM=str(GNSS_output_temp.VFOM)
          
            else:
                GNSS_decoded_output_temp.VFOM="Out of Range"
     
        else:
             GNSS_decoded_output_temp.VFOM="Invalid"
            
        if((GNSS_output_temp.Data_Validity_Flags & 512)==512): 
           GNSS_decoded_output_temp.PPS="Available"
        else:
             GNSS_decoded_output_temp.PPS="Not Available"
        if((GNSS_output_temp.Position & 3)==0):
          GNSS_decoded_output_temp.Position_Computation="GPS Only"

        elif((GNSS_output_temp.Position & 3)==1):   
            GNSS_decoded_output_temp.Position_Computation="SGPS(GPS + SBAS)"
        elif((GNSS_output_temp.Position & 3)==2):   
            GNSS_decoded_output_temp.Position_Computation="GLONASS only"
        elif((GNSS_output_temp.Position & 3)==3):   
            GNSS_decoded_output_temp.Position_Computation="SGNSS(GPS+ GLONASS+ SBAS) mode"

    def display_msg(self):
        global GNSS_output_temp,flag_position,GNSS_decoded_output_temp
##        Timestamp=self.Time_stamp()    
##        display_position=" GNSS Output Message(Position,Velocity and Time)is received at  "+ str(Timestamp)+"  instance  " +"\n"
##        CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(display_position)
        class_var.grid_position.SetCellValue(0,1,GNSS_decoded_output_temp.Position_availability )
        class_var.grid_position.SetCellValue(1,1,GNSS_decoded_output_temp.Receiver_latitude)
        class_var.grid_position.SetCellValue(2,1, GNSS_decoded_output_temp.Receiver_longitude)
        class_var.grid_position.SetCellValue(3,1,GNSS_decoded_output_temp.Receiver_altitude)
        class_var.grid_position.SetCellValue(4,1,GNSS_decoded_output_temp.Ground_Speed)
        class_var.grid_position.SetCellValue(5,1,GNSS_decoded_output_temp.Heading )
        class_var.grid_position.SetCellValue(6,1, GNSS_decoded_output_temp.Receiver_North_Velocity )
        class_var.grid_position.SetCellValue(7,1, GNSS_decoded_output_temp.Receiver_east_velocity )
        class_var.grid_position.SetCellValue(8,1, GNSS_decoded_output_temp.Receiver_vertical_velocity)
        class_var.grid_position.SetCellValue(9,1, GNSS_decoded_output_temp.UTC_date) 
        class_var.grid_position.SetCellValue(10,1,GNSS_decoded_output_temp.UTC_time )
        class_var.grid_position.SetCellValue(11,1,  GNSS_decoded_output_temp.HPL)
        class_var.grid_position.SetCellValue(12,1, GNSS_decoded_output_temp.HFOM) 
        class_var.grid_position.SetCellValue(13,1, GNSS_decoded_output_temp.VPL ) 
        class_var.grid_position.SetCellValue(14,1,GNSS_decoded_output_temp.VFOM )
        class_var.grid_position.SetCellValue(15,1,GNSS_decoded_output_temp.PPS) 
        class_var.grid_position.SetCellValue(16,1, GNSS_decoded_output_temp.Position_Computation ) 
       
    def display_health_validate(self):
        global GNSS_health_temp,GNSS_decoded_health_temp
        if(((GNSS_health_temp.Mode & 1)==0) and ((GNSS_health_temp.Mode & 2)==0)) :
             GNSS_decoded_health_temp.GNSS_Start_Mode= "Warm Start"

        elif(((GNSS_health_temp.Mode & 1)==1) and ((GNSS_health_temp.Mode & 2)==0)) :
             GNSS_decoded_health_temp.GNSS_Start_Mode="Cold start"
        elif(((GNSS_health_temp.Mode & 1)==0) and ((GNSS_health_temp.Mode & 2)==2)) :
            GNSS_decoded_health_temp.GNSS_Start_Mode="Hot start"
        else:
            GNSS_decoded_health_temp.GNSS_Start_Mode="Unknown"  
          
        if(((GNSS_health_temp.Mode & 4)==4)):
            GNSS_decoded_health_temp.Navigation_with_GAGAN="Yes"
            
        else:
            GNSS_decoded_health_temp.Navigation_with_GAGAN="No"
            
        if(((GNSS_health_temp.Mode & 8)==8)):
            GNSS_decoded_health_temp.Navigation_with_Integrity="Yes"
                
        else:
            GNSS_decoded_health_temp.Navigation_with_Integrity="No"

        if(((GNSS_health_temp.Mode & 16)==16)):
               GNSS_decoded_health_temp.Navigation_2D="Yes"
        else:
               GNSS_decoded_health_temp.Navigation_2D="No"
                    
        if(((GNSS_health_temp.Mode & 32)==32)):
            GNSS_decoded_health_temp.Navigation_3D= "Yes"
        else:
                GNSS_decoded_health_temp.Navigation_3D= "No"
                
        if(((GNSS_health_temp.Mode & 64)==64)):
           GNSS_decoded_health_temp.FaultIntegrity="Yes"
             
        else:
             GNSS_decoded_health_temp.FaultIntegrity= "No"
             
        if(GNSS_health_temp.Phase_of_flight==1):
            GNSS_decoded_health_temp.Phase_of_Flight="Oceanic/Remote"
        elif(GNSS_health_temp.Phase_of_flight==2):  
            GNSS_decoded_health_temp.Phase_of_Flight="Enroute"
        elif(GNSS_health_temp.Phase_of_flight==3):  
            GNSS_decoded_health_temp.Phase_of_Flight="Terminal" 
        elif(GNSS_health_temp.Phase_of_flight==4):  
            GNSS_decoded_health_temp.Phase_of_Flight="N.P approach"
        else:
            GNSS_decoded_health_temp.Phase_of_Flight="Invalid"
        if((GNSS_health_temp.No_of_tracking_GPS_satellites>=0) and (GNSS_health_temp.No_of_tracking_GPS_satellites<=12)):
            GNSS_decoded_health_temp.GPS_Satellites=str(GNSS_health_temp.No_of_tracking_GPS_satellites)
        else:
            GNSS_decoded_health_temp.GPS_Satellites="Out of Range"
        if((GNSS_health_temp.No_of_tracking_GLONASS_satellites>=0) and (GNSS_health_temp.No_of_tracking_GLONASS_satellites<=12)):
            GNSS_decoded_health_temp.GLONASS_Satellites=str(GNSS_health_temp.No_of_tracking_GLONASS_satellites)
        else:
            GNSS_decoded_health_temp.GLONASS_Satellites="Out of Range"
        if((GNSS_health_temp.No_of_tracking_GAGAN_satellites>=0) and (GNSS_health_temp.No_of_tracking_GAGAN_satellites<=3)):
            GNSS_decoded_health_temp.GAGAN_Satellites=str(GNSS_health_temp.No_of_tracking_GAGAN_satellites)
        else:
            GNSS_decoded_health_temp.GAGAN_Satellites="Out of Range"
        if((GNSS_health_temp.Fault_Status &1)==1):
            GNSS_decoded_health_temp.Antenna="Yes"
        else:
            GNSS_decoded_health_temp.Antenna="No"
          
        if((GNSS_health_temp.Fault_Status &2)==2):
            GNSS_decoded_health_temp.Antenna_state="Short"

        else:
     
            GNSS_decoded_health_temp.Antenna_state="Active"
        if((GNSS_health_temp.Fault_Status &4)==4):
          
            GNSS_decoded_health_temp.RF1="No"
           
        else:
            
            GNSS_decoded_health_temp.RF1="Yes"
           

        if((GNSS_health_temp.Fault_Status &8)==8):
       
            GNSS_decoded_health_temp.RF2="No"
           
        else:
       
            GNSS_decoded_health_temp.RF2="Yes"
          
        if((GNSS_health_temp.Fault_Status &16)==16):
         
            GNSS_decoded_health_temp.CPU1="Fail"
        else:
            GNSS_decoded_health_temp.CPU1="OK"
        if((GNSS_health_temp.Fault_Status &32)==32):
          
            GNSS_decoded_health_temp.CPU2="Fail"
           
        else:
           
            GNSS_decoded_health_temp.CPU2="OK"
        if((GNSS_health_temp.Fault_Status &32)==32):
        
            GNSS_decoded_health_temp.Satellites_avail="No Usable Satellites Available"

        else: 
            
            GNSS_decoded_health_temp.Satellites_avail="Satellites Available for Position Computation"
           
        if((GNSS_health_temp.Fault_Status &64)==64):
        
            GNSS_decoded_health_temp.PDOP1="PDOP value exceeds limit (12)"
          
        else:
            
            GNSS_decoded_health_temp.PDOP1="PDOP Value is Within Limit (12)"

        if((GNSS_health_temp.Fault_Status &128)==128):
####            print "GAGAN satellites are used for position computation "
            GNSS_decoded_health_temp.GAGAN_position="Yes"

        else:
##            print "GAGAN satellites are not used for position computation" 
            GNSS_decoded_health_temp.GAGAN_position="No" 
          
        if((GNSS_health_temp.Fault_Status &256)==256):
##            print " GNSS System Failure "
            GNSS_decoded_health_temp.GNSS_system_failure= "Failure"
        else:
##            print "GNSS System OK"
            GNSS_decoded_health_temp.GNSS_system_failure= "OK"

        if((GNSS_health_temp.Fault_Status &512)==512):
##            print " GNSS in tracking mode"
            GNSS_decoded_health_temp.GNSS_mode="Tracking Mode"
        else:
##            print "GNSS in acquisition mode"
            GNSS_decoded_health_temp.GNSS_mode="Acquisition Mode"
            
        if((GNSS_health_temp.PDOP>=0)and (GNSS_health_temp.PDOP<=99)):
##            print "PDOP value",GNSS_health_temp.PDOP
            GNSS_decoded_health_temp.PDOP_value=str(GNSS_health_temp.PDOP)
        else:
##            print "PDOP value is unknown" 
            GNSS_decoded_health_temp.PDOP_value="Out of Range"
            
        if((GNSS_health_temp.HDOP>=0)and (GNSS_health_temp.HDOP<=99)):
##            print"HDOP value",GNSS_health_temp.HDOP
            GNSS_decoded_health_temp.HDOP=str(GNSS_health_temp.HDOP)
        else:
##            print "HDOP value is unknown" 
            GNSS_decoded_health_temp.HDOP="Out of Range"
         
        if((GNSS_health_temp.VDOP>=0)and (GNSS_health_temp.VDOP<=99)):
##            print"VDOP value",GNSS_health_temp.VDOP
            GNSS_decoded_health_temp.VDOP=str(GNSS_health_temp.VDOP)
           
        else:
##            print "VDOP value is unknown" 
            GNSS_decoded_health_temp.VDOP="Out of Range"
            
        if((GNSS_health_temp.TDOP>=0)and (GNSS_health_temp.TDOP<=99)):
##            print"TDOP value",GNSS_health_temp.TDOP
            GNSS_decoded_health_temp.TDOP=str(GNSS_health_temp.TDOP)
              
        else:
            GNSS_decoded_health_temp.TDOP="Out of Range"
                   
    def display1(self):
        global GNSS_health_temp,GNSS_decoded_health_temp
##        Timestamp=self.Time_stamp()
##        temp_text="GNSS status/receiver health message is received at  "+ str(Timestamp)+"  instance  " +"\n"
##        CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
        class_var.grid_health.SetCellValue(0,1,  GNSS_decoded_health_temp.GNSS_Start_Mode)              
        class_var.grid_health.SetCellValue(2,1,GNSS_decoded_health_temp.Navigation_with_GAGAN)  
        class_var.grid_health.SetCellValue(3,1, GNSS_decoded_health_temp.Navigation_with_Integrity)  
        class_var.grid_health.SetCellValue(4,1, GNSS_decoded_health_temp.Navigation_2D)  
        class_var.grid_health.SetCellValue(5,1,  GNSS_decoded_health_temp.Navigation_3D)   
        class_var.grid_health.SetCellValue(6,1, GNSS_decoded_health_temp.FaultIntegrity) 
        class_var.grid_health.SetCellValue(7,1,GNSS_decoded_health_temp.Phase_of_Flight)  
        class_var.grid_health.SetCellValue(8,1,GNSS_decoded_health_temp.GPS_Satellites )
        class_var.grid_health.SetCellValue(9,1, GNSS_decoded_health_temp.GLONASS_Satellites)
        class_var.grid_health.SetCellValue(10,1, GNSS_decoded_health_temp.GAGAN_Satellites)
        class_var.grid_health.SetCellValue(12,1,GNSS_decoded_health_temp.Antenna)
        class_var.grid_health.SetCellValue(13,1,GNSS_decoded_health_temp.Antenna_state) 
        class_var.grid_health.SetCellValue(14,1,GNSS_decoded_health_temp.RF1) 
        class_var.grid_health.SetCellValue(15,1,GNSS_decoded_health_temp.RF2)  
        class_var.grid_health.SetCellValue(16,1,GNSS_decoded_health_temp.CPU1)    
        class_var.grid_health.SetCellValue(17,1, GNSS_decoded_health_temp.CPU2)
        class_var.grid_health.SetCellValue(18,1,GNSS_decoded_health_temp.Satellites_avail)
        class_var.grid_health.SetCellValue(19,1,GNSS_decoded_health_temp.PDOP1) 
        class_var.grid_health.SetCellValue(20,1,GNSS_decoded_health_temp.GAGAN_position) 
        class_var.grid_health.SetCellValue(21,1,GNSS_decoded_health_temp.GNSS_system_failure)     
        class_var.grid_health.SetCellValue(22,1,GNSS_decoded_health_temp.GNSS_mode)
        class_var.grid_health.SetCellValue(23,1,GNSS_decoded_health_temp.PDOP_value)
        class_var.grid_health.SetCellValue(24,1, GNSS_decoded_health_temp.HDOP)
        class_var.grid_health.SetCellValue(25,1,GNSS_decoded_health_temp.VDOP)  
        class_var.grid_health.SetCellValue(26,1,GNSS_decoded_health_temp.TDOP)        
        
    def display_version_validate(self):
            global GNSS_version_temp,GNSS_decoded_version_temp
          
            if((GNSS_version_temp.Hardware_version_number>=1) and (GNSS_version_temp.Hardware_version_number<=256)) :
##                    print "h/w", GNSS_version_temp.Hardware_version_number 
                    GNSS_decoded_version_temp.Hardware_version_number=str(GNSS_version_temp.Hardware_version_number)  
            else:
                  GNSS_decoded_version_temp.Hardware_version_number="Out of Range"
##                  print "Hardware version number is unknown"
            temp_version_all=str( GNSS_version_temp.Software_version_x1)+str( GNSS_version_temp.Software_version_x2)+\
            str( GNSS_version_temp.Software_version_y1)+str( GNSS_version_temp.Software_version_y2)+\
            str( GNSS_version_temp.Software_version_z1)+str( GNSS_version_temp.Software_version_z2)
##            print  temp_version_all   
            if((int(temp_version_all)>=1)) :
####                    print GNSS_version_temp.Software_version_number
                     temp_version_software=str( GNSS_version_temp.Software_version_x1)+str( GNSS_version_temp.Software_version_x2)+\
                        "."+str( GNSS_version_temp.Software_version_y1)+str( GNSS_version_temp.Software_version_y2)+\
                        "."+str( GNSS_version_temp.Software_version_z1)+str( GNSS_version_temp.Software_version_z2)
                    
                     GNSS_decoded_version_temp.Software_version=str(temp_version_software) 
                                 
            else:
##                 print "Software version number is unknown"
                 GNSS_decoded_version_temp.Software_version="Out of Range"
                                    
            if(((GNSS_version_temp.Software_release_day >=1) and (GNSS_version_temp.Software_release_day <=31)) and\
                ((GNSS_version_temp.Software_release_month>=1) and (GNSS_version_temp.Software_release_month<=12))and\
                ((GNSS_version_temp.Software_release_year>=0) and (GNSS_version_temp.Software_release_year<=99))):
                        
                   
                    if((int(GNSS_version_temp.Software_release_day)>=1)and(int(GNSS_version_temp.Software_release_day<=9))):
                        Software_release_day_temp="0"+str(GNSS_version_temp.Software_release_day)
                    else:
                        Software_release_day_temp=str(GNSS_version_temp.Software_release_day)
                    if((int(GNSS_version_temp.Software_release_month)>=1)and(int(GNSS_version_temp.Software_release_month<=9))):
                        Software_release_month_temp="0"+str(GNSS_version_temp.Software_release_month)
                    else:
                        Software_release_month_temp=str(GNSS_version_temp.Software_release_month)
                    if((int(GNSS_version_temp.Software_release_year)>=0)and(int(GNSS_version_temp.Software_release_year<=9))):
                        Software_release_year_temp="0"+str(GNSS_version_temp.Software_release_year)
                    else:
                        Software_release_year_temp=str(GNSS_version_temp.Software_release_year)
                    day=Software_release_day_temp
                    month=Software_release_month_temp
                    year=Software_release_year_temp
                    GNSS_decoded_version_temp.Software_release_date=day+"/"+month +"/"+year
                  
            else:
##                    print "Unknown" 
                    var_date="  "+"Out of Range"
                    GNSS_decoded_version_temp.Software_release_date="Out of Range"
                   
    def display3(self):
        global GNSS_version_temp
##        Timestamp=self.Time_stamp()
##        temp_text=" GNSS receiver version Message received at  "+ str(Timestamp)+"  instance  " +"\n"
##        CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
        class_var.grid_version.SetCellValue(0,1,GNSS_decoded_version_temp.Hardware_version_number ) 
        class_var.grid_version.SetCellValue(1,1,GNSS_decoded_version_temp.Software_version )
        class_var.grid_version.SetCellValue(2,1,GNSS_decoded_version_temp.Software_release_date) 
          
    def Calculate_Checksum(self,data,bytecount):
        checksum=0
        for i in range(0,bytecount-1):
           var1=int(data[i],16)
##           print "var1..............",var1
           checksum=checksum ^ (var1)
        checksum=checksum&0xFFFFFFFF
        return checksum       

    def Time_stamp(self):
        # To get the local time of system
        now=time.localtime(time.time())
##        print "self.now", self.now
        year, month, day, hour, minute, second, weekday, yearday, daylight =now
        hr=str(hour)
        min=str(minute)
        sec=str(second)
        if len(hr)==1:
            hr='0'+hr
        if len(min)==1:
            min='0'+min
        if len( sec)==1:
            sec='0'+sec
        self.Timestamp=hr+":"+min+":"+sec
        return self.Timestamp
            


