#!/usr/bin/env python
#Boa:App:BoaApp

import wx
import time
import GNSS_OutputWindow
import CDU_TestRig_MainWindow
from wxPython.wx import *
from wxPython.lib.anchors import LayoutAnchors

modules ={u'CDU_TestRig_MainWindow': [0, '', u'CDU_TestRig_MainWindow.py'],
 'Dialog1': [0, '', 'none://Dialog1.py'],
 'Frame1': [0, '', 'none://Frame1.py'],
 'GNSS_OutputWindow': [1,
                       'Main frame of Application',
                       u'../CDU_TestRig on Shrividyar3/Frame3.py']}
global sApp
SLEEP_TIME=2
class BoaApp(wx.App):
    def OnInit(self):
        self.main = CDU_TestRig_MainWindow.create(None)
        self.main.Show()
        self.SetTopWindow(self.main)
        return True

def main():
    application = BoaApp(0)
    application.MainLoop()
    
               
if __name__ == '__main__':
    app = wx.App()
    splash_image = wx.Image('CDU_test-Rig3.bmp').ConvertToBitmap()

    splash_screen = wx.SplashScreen(splash_image, 
            wx.SPLASH_CENTRE_ON_SCREEN|wx.SPLASH_NO_TIMEOUT, 0, None)

    wx.CallLater(1000*SLEEP_TIME, splash_screen.Destroy)
    time.sleep(2)
    main()



   
     
     
     
     
     
     
