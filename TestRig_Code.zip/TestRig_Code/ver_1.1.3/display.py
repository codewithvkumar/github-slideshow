import wx
import xlrd
import xlwt
from xlutils.copy import copy
import struct
from ctypes import *
import time
import CDU_output
import COMConfig_Window
import CDU_TestRig_MainWindow
import KEYreadnsend
import ibit_out

global file_name

CDU_TestRig_MainWindow.CDU_LOG_xls=''


class Ibit(Structure):
   _fields_ = [
                ("Header",c_byte),
                ("Packet_ID", c_byte),
                ("Acceptance_code", c_byte),
                ("Checksum", c_byte),
               ]
Ibit_obj=Ibit()

def Ibit_msg():
    
        ibit_packet=[0xAC,0xE1,0x4D]

        messege_pack1=struct.pack('>BB',ibit_packet[0],ibit_packet[1])
        
        Checksum=Calculate_Checksum(ibit_packet,len(ibit_packet)-1)

        if(Checksum==ibit_packet[2]):
            messege_pack2=struct.pack('>B',ibit_packet[2])
            messege_pack=messege_pack1+messege_pack2

            time.sleep(1)
            if(CDU_TestRig_MainWindow.close_CDU_flag==1):
                if(COMConfig_Window.instance_comport_receiver_CDU1.Comport_select==COMConfig_Window.instance_comport_transmitter_CDU1.Comport_select):
                    try: 
                        CDU_TestRig_MainWindow.class_var3.connect_object_CDU1_receiver.write(messege_pack)
                    except:
                        pass 
                else:
                    try: 
                        CDU_TestRig_MainWindow.class_var3.connect_object_CDU1_transmitter.write(messege_pack)
                    except:
                        pass
                CDU_TestRig_MainWindow.class_var3.txt_statuswindow.SetForegroundColour(wx.Colour(0, 0, 255))
                temp_text="IBIT Message sent to CDU\n "
                CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
            else:
                if(COMConfig_Window.instance_comport_receiver_CDU2.Comport_select==COMConfig_Window.instance_comport_transmitter_CDU2.Comport_select):
                    try: 
                        CDU_TestRig_MainWindow.class_var3.connect_object_CDU2_receiver.write(messege_pack)
                    except:
                        pass 
                else:
                    try: 
                        CDU_TestRig_MainWindow.class_var3.connect_object_CDU2_transmitter.write(messege_pack)
                    except:
                        pass
                CDU_TestRig_MainWindow.class_var3.txt_statuswindow.SetForegroundColour(wx.Colour(0, 0, 255))
                temp_text="IBIT Message sent to CDU\n "
                CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
        else:
            CDU_TestRig_MainWindow.ibit_flag=0		#Changed for report no-100028:variable access 
            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.SetForegroundColour(wx.Colour(255, 0, 0))
            temp_text="Invalid IBIT message\n "
            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
##            print "fail.........."
    
 
     
def Calculate_Checksum(data,bytecount):
        checksum=0
        for i in range(0,bytecount):
           var1=data[i]
           checksum = checksum ^ (var1)
        checksum = checksum & 0xFF
        return checksum  
    
def logging_ibit(no_ibit):
        
        COMConfig_Window.w_ibit.get_sheet(0).write(0,0,'IBIT Status')
        COMConfig_Window.w_ibit.get_sheet(0).write(0,1,'IBIT Result')
        COMConfig_Window.w_ibit.get_sheet(0).write(no_ibit,0,ibit_out.ibit_status)
        COMConfig_Window.w_ibit.get_sheet(0).write(no_ibit,1,ibit_out.ibit_result)
        COMConfig_Window.w_ibit.save(CDU_TestRig_MainWindow.IBIT_log_xls)
    

def Log_Heading(w):
        global file_name
        
##        print "inside -----------------Log_Heading"
        w.get_sheet(0).write(0,0,'Key_Press')
        w.get_sheet(0).write(0,1,'Key_Release')
        w.get_sheet(0).write(0,2,'Brightness_mode')
        w.get_sheet(0).write(0,3,'Functional_mode')
        w.get_sheet(0).write(0,4,'DMC_command')
        w.get_sheet(0).write(0,5,'CDU_Result') 
        w.get_sheet(0).write(0,6,'DTD_Availability')
        w.get_sheet(0).write(0,7,'DTD_DMC_ALL_MAINT')
        w.get_sheet(0).write(0,8,'DTD_DMC_HUMS_HISTORY')
        w.get_sheet(0).write(0,9,'DTD_DMC_HUMS_PRSTS')
        w.get_sheet(0).write(0,10,'DTD_DMC_GTH_DBASE')
        w.get_sheet(0).write(0,11,'DTD_DMC_ALL_FLIGHT')
        w.get_sheet(0).write(0,12,'DTD_DMC_COMM')
        w.get_sheet(0).write(0,13,'DTD_DMC_NAV_DBASE')
        w.get_sheet(0).write(0,14,'DTD_DMC_Header')
        w.get_sheet(0).write(0,15,'DTD_validation') 
        w.get_sheet(0).write(0,16,'Key_press_status')
        w.get_sheet(0).write(0,17,'DTD_DMC_ALL')
        w.get_sheet(0).write(0,18,'Stuck_In_Key')
        w.get_sheet(0).write(0,19,'EEPROM_Memory')
        w.get_sheet(0).write(0,20,'Ram_Memory')
        w.get_sheet(0).write(0,21,'Flash_Memory')
        w.get_sheet(0).write(0,22,'Keyboard_ok')
        w.get_sheet(0).write(0,23,'Heat_Condition')
        w.save(CDU_TestRig_MainWindow.CDU_LOG_xls)


def Write_xls(no):
    global output_obj_c,file_name
##    CDU_output.output_obj_c=output_c()
##    print "inside ........................Write_xls function"
##    print "Key_Press..........",CDU_output.output_obj_c.Data_word.Key.Key_Press
    COMConfig_Window.w.get_sheet(0).write(no,0,CDU_output.output_obj_c.Data_word.Key.Key_Press)
    COMConfig_Window.w.get_sheet(0).write(no,1,CDU_output.output_obj_c.Data_word.Key.Key_Release)
    COMConfig_Window.w.get_sheet(0).write(no,2,CDU_output.output_obj_c.Data_word.Status_Report1.Brightness_mode)
    COMConfig_Window.w.get_sheet(0).write(no,3,CDU_output.output_obj_c.Data_word.Status_Report1.Functional_mode)
    COMConfig_Window.w.get_sheet(0).write(no,4,CDU_output.output_obj_c.Data_word.Status_Report1.DMC_command)
    COMConfig_Window.w.get_sheet(0).write(no,5,CDU_output.output_obj_c.Data_word.Status_Report1.CDU_Result) 
    COMConfig_Window.w.get_sheet(0).write(no,6,CDU_output.output_obj_c.Data_word.Status_Report1.DTD_Availability)
    COMConfig_Window.w.get_sheet(0).write(no,7,CDU_output.output_obj_c.Data_word.Status_Report2.DTD_DMC_ALL_MAINT)
    COMConfig_Window.w.get_sheet(0).write(no,8,CDU_output.output_obj_c.Data_word.Status_Report2.DTD_DMC_HUMS_HISTORY)
    COMConfig_Window.w.get_sheet(0).write(no,9,CDU_output.output_obj_c.Data_word.Status_Report2.DTD_DMC_HUMS_PRSTS)
    COMConfig_Window.w.get_sheet(0).write(no,10,CDU_output.output_obj_c.Data_word.Status_Report2.DTD_DMC_GTH_DBASE)
    COMConfig_Window.w.get_sheet(0).write(no,11,CDU_output.output_obj_c.Data_word.Status_Report2.DTD_DMC_ALL_FLIGHT)
    COMConfig_Window.w.get_sheet(0).write(no,12,CDU_output.output_obj_c.Data_word.Status_Report2.DTD_DMC_COMM)
    COMConfig_Window.w.get_sheet(0).write(no,13,CDU_output.output_obj_c.Data_word.Status_Report2.DTD_DMC_NAV_DBASE)
    COMConfig_Window.w.get_sheet(0).write(no,14,CDU_output.output_obj_c.Data_word.Status_Report2.DTD_DMC_Header)
    COMConfig_Window.w.get_sheet(0).write(no,15,CDU_output.output_obj_c.Data_word.Status_Report3.DTD_validation) 
    COMConfig_Window.w.get_sheet(0).write(no,16,CDU_output.output_obj_c.Data_word.Status_Report3.Key_press_status)
    COMConfig_Window.w.get_sheet(0).write(no,17,CDU_output.output_obj_c.Data_word.Status_Report3.DTD_DMC_ALL)
    COMConfig_Window.w.get_sheet(0).write(no,18,CDU_output.output_obj_c.Data_word.BIT_Result1.Stuck_In_Key)
    COMConfig_Window.w.get_sheet(0).write(no,19,CDU_output.output_obj_c.Data_word.BIT_Result1.EEPROM_Memory)
    COMConfig_Window.w.get_sheet(0).write(no,20,CDU_output.output_obj_c.Data_word.BIT_Result1.Ram_Memory)
    COMConfig_Window.w.get_sheet(0).write(no,21,CDU_output.output_obj_c.Data_word.BIT_Result1.Flash_Memory)
    COMConfig_Window.w.get_sheet(0).write(no,22,CDU_output.output_obj_c.Data_word.BIT_Result1.Keyboard_ok)
    COMConfig_Window.w.get_sheet(0).write(no,23,CDU_output.output_obj_c.Data_word.BIT_Result1.Heat_Condition)
    COMConfig_Window.w.save(CDU_TestRig_MainWindow.CDU_LOG_xls)
