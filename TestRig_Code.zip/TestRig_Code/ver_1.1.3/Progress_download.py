#Boa:Frame:Frame1

import wx
import CDU_TestRig_MainWindow
def create(parent):
    global instance_dwnld
    instance_dwnld=Progress_download(parent)
    return instance_dwnld



[wxID_FRAME1,wxID_FRAME1GAUGE1,wxID_FRAME1STATICTEXT1,wxID_FRAME1STATICTEXT2,wxID_FRAME1PANEL1] = [wx.NewId() for _init_ctrls in range(5)]

class Progress_download(wx.Frame):
    def _init_ctrls(self, prnt):

        wx.Frame.__init__(self, style=wx.DEFAULT_FRAME_STYLE, name='', parent=prnt, 
                title='Download Progress', pos=wx.Point(-1, -1), id=wxID_FRAME1, size=wx.Size(480, 100))
        self.panel1 = wx.Panel(id=wxID_FRAME1PANEL1, name='panel1', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(200, 450),
              style=wx.TAB_TRAVERSAL)
        self.Bind(wx.EVT_CLOSE,self.OnFrameClose)
 
        self.sta_dwld_status = wx.StaticText(id=wxID_FRAME1STATICTEXT1,
              label='Download status:', name='sta_dwld_status', parent=self.panel1,
              pos=wx.Point(28, 20), size=wx.Size(91, 30), style=0)    
        
        self.sta_dwld_percent = wx.StaticText(id=wxID_FRAME1STATICTEXT2,
              label='0 %', name='sta_dwld_status', parent=self.panel1,
              pos=wx.Point(125, 20), size=wx.Size(91, 40), style=0)
              
        self.guage_progressbar = wx.Gauge(id=wxID_FRAME1GAUGE1, name='guage_progressbar',
            parent=self.panel1, pos=wx.Point(30, 35), range=100,
            size=wx.Size(400, 15),
            style=wx.TRANSPARENT_WINDOW | wx.GA_SMOOTH | wx.NO_BORDER | wx.GA_HORIZONTAL)
        self.guage_progressbar.SetRange(100)
        self.guage_progressbar.SetLabel('Total Files:')
        self.guage_progressbar.SetValue(0)
        self.guage_progressbar.SetThemeEnabled(True) 
        
 
    def __init__(self, parent):
        
        self._init_ctrls(parent)
        
    def OnFrameClose(self, event):
        CDU_TestRig_MainWindow.flag_prgs_dwnld=0
        self.Destroy()