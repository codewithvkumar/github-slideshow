import struct
import CDU_TestRig_MainWindow
import com_connection
import maintenance_upload	#Changed for report no-100028:imported
import time

PREAMBLE=0xAC
ERROR_LOG_CMD=0xC1
PACKET_INFO_CMD=0xC2
DATA_PACKET_CMD=0xC3
DATA_UPLOAD_INIT_CMD=0xD1
DATA_PACKET_INFO_CMD=0xD2
DATA_UPLOAD_PACKET_CMD=0xD3
ERASE_ERROR_LOG_CMD=0xD4
RESET_CMD=0xB1
SPARE=0x0

def Error_Log_Packet():
    bytecount=5
    error_log_pack_for_chcksum=struct.pack('>BBH',PREAMBLE,ERROR_LOG_CMD,SPARE)
    checksum=Calculate_Checksum(error_log_pack_for_chcksum,bytecount-1)
    error_log_pack=error_log_pack_for_chcksum+struct.pack('>B',checksum)
    return error_log_pack

def Data_Upload_Init_Packet():
    bytecount=5
    data_upload_init_packet_for_chcksum=struct.pack('>4B',PREAMBLE,DATA_UPLOAD_INIT_CMD,SPARE,SPARE)
    checksum=Calculate_Checksum(data_upload_init_packet_for_chcksum,bytecount-1)
    data_upload_init_packet=data_upload_init_packet_for_chcksum+struct.pack('>B',checksum)
    if(CDU_TestRig_MainWindow.flag_maintance==1):
        if(com_connection.instance_comport_receiver.Comport_select==com_connection.instance_comport_transmitter.Comport_select):
            try:
                maintenance_upload.maintenance_object.write(data_upload_init_packet)	#Changed for report no-100028:access is changed
            except:
                pass
        else:
            try:
                maintenance_upload.maintenance_object_tx.write(data_upload_init_packet)		#Changed for report no-100028:access is changed
            except:
                pass
        Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
        temp_text="Data upload init command sent to CDU at "+ str(Timestamp)+"\n"
        CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
    else:
        temp_text="Com port is not connected\n "
        CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
        
##    return data_upload_init_packet

def Data_Upload_Packet_Info_Cmd(total_size):
    bytecount=11
    data_count=50
    total_packets=total_size/data_count
    ack_upload_packet_for_chcksum=struct.pack('>BBHHI',PREAMBLE,DATA_PACKET_INFO_CMD,total_packets,data_count,total_size)
    checksum=Calculate_Checksum(ack_upload_packet_for_chcksum,bytecount-1)
    ack_upload_packet=ack_upload_packet_for_chcksum+struct.pack('>B',checksum)
    if(CDU_TestRig_MainWindow.flag_maintance==1):
        if(com_connection.instance_comport_receiver.Comport_select==com_connection.instance_comport_transmitter.Comport_select):
           
            try:
                maintenance_upload.maintenance_object.write(ack_upload_packet)		#Changed for report no-100028:access is changed
            except:
                pass
        else:
            try:
                maintenance_upload.maintenance_object_tx.write(ack_upload_packet)		#Changed for report no-100028:access is changed
            except:
                pass
        Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
        temp_text="Packet information command sent to CDU at "+ str(Timestamp)+"\n"
        CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
    else:
        temp_text="Com port is not connected\n "
        CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
    

def Data_Packet_Upload_Init(packet_no,data):
    data_count=50
    bytecount=data_count+5
    data_packet=struct.pack('>%ds'%data_count,str(data))
    data_upload_packet_for_checksum=(struct.pack('>BBH',PREAMBLE,DATA_UPLOAD_PACKET_CMD,packet_no))+data_packet
    checksum=Calculate_Checksum(data_upload_packet_for_checksum,bytecount-1)
    data_upload_packet=data_upload_packet_for_checksum+struct.pack('>B',checksum)
    if(CDU_TestRig_MainWindow.flag_maintance==1):
        if(com_connection.instance_comport_receiver.Comport_select==com_connection.instance_comport_transmitter.Comport_select):
           
            try:
                maintenance_upload.maintenance_object.write(data_upload_packet)		#Changed for report no-100028:access is changed
            except:
                pass
        else:
            try:
                maintenance_upload.maintenance_object_tx.write(data_upload_packet)		#Changed for report no-100028:access is changed
            except:
                pass
        Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
        temp_text="Data packet "+str(packet_no)+" information command sent to CDU at"+ str(Timestamp)+"\n"
        CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
    else:
        temp_text="Com port is not connected\n "
        CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
##    return data_upload_packet

def Erase_Error_Log_Packet():
    bytecount=3
    erase_error_log_packet_for_chcksum=struct.pack('>BB',PREAMBLE,ERASE_ERROR_LOG_CMD)
    checksum=Calculate_Checksum(erase_error_log_packet_for_chcksum,bytecount-1)
    erase_error_log_packet=erase_error_log_packet_for_chcksum+struct.pack('>B',checksum)
    return erase_error_log_packet

def Reset_Packet():
    bytecount=3
    reset_packet_for_chcksum=struct.pack('>BB',PREAMBLE,RESET_CMD)
    checksum=Calculate_Checksum(reset_packet_for_chcksum,bytecount-1)
    reset_packet=reset_packet_for_chcksum+struct.pack('>B',checksum)
    return reset_packet

def Calculate_Checksum(pkt,byte_count):
    checksum=0
    data=struct.unpack_from('>%dB'%byte_count,pkt)
    for i in range(0,byte_count):
        checksum=checksum^data[i]
    checksum=checksum & 0xFF
    return checksum  

