#Boa:Frame:Frame1

import wx
import struct
import win32api
import time
import CDU_TestRig_MainWindow
import os
import pdb
import request_packet
import xlwt
import xlrd
import Progress_download
from xlutils.copy import copy
import com_connection
class Errorlog():
   
    def Errorlog_data(self):
        global open_frame,flag_resend
        global pathnfile
        global ack_no_try
        ack_no_try=0   
##        print self.upgrade,self.header
        no_try_packet_correct1=0
        no_try_packet_correct=0
        Try_req_send=0 
        ack_count=0
        no_try=0
        j=0
        flag_resend=0
        flag_response_true=0
        flag_packet_ack=0
        percent=0
        percent1=0
        send_flag=0
        self.packet=request_packet.Error_Log_Packet()
        CDU_TestRig_MainWindow.flag_prgs_dwnld=1
        while(True):
            if Try_req_send==3  and flag_resend==0:
                Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
                CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("No Acknowledgement received " +str(Timestamp) +"\n")
                
                break
            elif flag_resend==1:
##                print "heellllllllll"
                break
            else:
                self.Req_data_transfer(self.packet)

##                Timestamp=self.Time_stamp()
                Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
                CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Request for Error Log sent"+str(Timestamp) +"\n")
                self.req_response_cdu=self.Response_data_transfer()
                Try_req_send=Try_req_send+1
##                if self.req_response_cdu!=0:
##                    self.prog_dwnload=Progress_download.Create(None) 
##                    self.prog_dwnload.Show()
        if flag_resend==1: 
##            print "heellllllllll"       
            while(True):
    ##            self.req_response_cdu3=[]
                if no_try==3:
                   Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
                   CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Retries for correct acknowledgement reached " +str(Timestamp) +"\n")
                   break
                if Try_req_send==4:
                   Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
                   CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Retries for correct acknowledgement reached " +str(Timestamp) +"\n")
                    
                   break
                elif flag_resend==0:
                    self.req_response_cdu=self.Response_data_transfer()
##                elif no_try>=2 and flag_resend==1:
##                     self.req_response_cdu=self.Response_data_transfer()   
                else:
                     flag_resend=0
                if self.req_response_cdu==0:
                     if no_try==2 or Try_req_send==3:
                         no_try=no_try+1
                     else:
                         self.Req_data_transfer(self.packet)
                     
                         Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
                         CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Request for Error Log sent" +str(Timestamp) +"\n")
                     Try_req_send=Try_req_send+1
                     flag_resend=0 
                                         
                else:
                    self.req_response_cdu3=list(self.req_response_cdu)
                    if self.req_response_cdu[3]==0 :
                        #code added for report no 100028-For logging on to message box
                        Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
                        CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Acknowledgement received with Checksum status value 0 " +str(Timestamp) +"\n")
                        if no_try==2 or Try_req_send==3:
                            no_try=no_try+1
                        else:
                            self.Req_data_transfer(self.packet)
                            no_try=no_try+1
                            flag_resend=0
                            Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
                            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Request for Error Log sent" +str(Timestamp) +"\n")
                        Try_req_send=Try_req_send+1
                    elif self.req_response_cdu[3]==2:
                        #code added for report no 100028-For logging on to message box
                         Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
                         CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Acknowledgement received with Checksum status value 2 " +str(Timestamp) +"\n")
                         if no_try==2 or Try_req_send==3:
                            no_try=no_try+1
                         else:
                             self.Req_data_transfer(self.packet)
                             no_try=no_try+1
                             flag_resend=0
                             Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
                             CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Request for Error Log sent" +str(Timestamp) +"\n")
                         Try_req_send=Try_req_send+1
                    elif self.req_response_cdu[3]==1:
                         flag_response_true=1
                         break
                    if self.req_response_cdu==0:
                         self.Req_data_transfer(self.packet)
                         no_try=no_try+1
                         flag_resend=0
                         Try_req_send=Try_req_send+1
    ##                             break
                
        if flag_response_true==1: 
                 self.ret_ack=0
                 while (True):
##                     pdb.Settrace()
                     if no_try_packet_correct==3:
                        Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
                        CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Retries for correct acknowledgement reached " +str(Timestamp) +"\n")
                        break   
                     self.ret_ack=self.Ack_Response_data_transfer(self.req_response_cdu)
                     if self.ret_ack==1:
                         self.response_cdu1=[]
                         self.response_cdu2=[172,195]
                         i=1
                         instant=1
                         no_try_packet_correct=0
                         ack_count=4
                         flag_packet_ack=1
                         print "innnn------------>",i
                         break
                     elif self.ret_ack==3:
                          Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
                          CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Retries for correct acknowledgement reached " +str(Timestamp) +"\n")
                          break 
                     else:
                         if no_try_packet_correct==2:
                             pass
                         else:
                            self.req_response_cdu=self.Response_data_transfer()
                         
                         print "Control heeeeeeeeeeeeeeeerrrrrrrrreeeeeeee",ack_count
                         ack_count=ack_count+1
                         no_try_packet_correct=no_try_packet_correct+1
                         Try_req_send=Try_req_send+1
##                         if ack_count==4:
                     if self.req_response_cdu==0 :
                        if no_try_packet_correct==3 and Try_req_send==4 :
                         
                            Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
                            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Retries for correct acknowledgement reached " +str(Timestamp) +"\n")
    ##
                            break
                        else:
                            pass 
                         
##                        Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
##                        CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Retries for correct acknowledgement reached " +str(Timestamp) +"\n")
####
##                        break
        
        if flag_packet_ack==1: 
             no_try_packet_correct=0  
             count=0 
             no_packet=0
             status_to_improve=0           
             while(True):
                 #code added for report no 100028- waiting for Data packet
                 if no_try_packet_correct==3:
                    Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
                    if no_packet==1: 
                        
                        CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(" No Data Packet Received"+str(Timestamp) +"\n")
                    else:
                        if percent1==100:
                           CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Download successful"+str(Timestamp) +"\n")
   
                        else:
                                
                            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Retries for Data Packet exceeded"+str(Timestamp) +"\n")
   
                    break
                 if instant<=self.req_response_cdu3[0] and no_try_packet_correct<=2:
                                             
                     print "lok heeeere------------>",i,self.req_response_cdu3[0],no_try_packet_correct
##                     time.sleep(2)
                     self.response_cdu1=self.Response_data_transfer()
                     if self.response_cdu1!=0:
                         self.response_cdu2=[172,195]
                         self.response_cdu3=list(self.response_cdu1)
                         
                         for k in range(len(self.response_cdu1)):
                            self.response_cdu2.append(self.response_cdu3[k])
                         status_to_improve=(100/self.req_response_cdu[0])
                         
                         byte_count=len(self.response_cdu2)-1
                         self.cal_crc=self.Calculate_Checksum1(self.response_cdu2,byte_count)
##                         print "kkkkk------------->",self.req_response_cdu[0]
##                         print self.response_cdu2[len(self.response_cdu2)-1],self.cal_crc,self.response_cdu2
                         
                         if self.response_cdu2[len(self.response_cdu2)-1]== self.cal_crc:
                            if instant== self.response_cdu2[3] :
                                print  "i== self.response_cdu2[3]",i,self.response_cdu2[3]
                                checksum_stat=0x1
    ##                            pathnfile=os.getcwd()+'\Errorlog.xls'
    ##                            wtbook = xlwt.Workbook()
    ##                            wtsheet = wtbook.add_sheet(u'First')
    ##                            wtbook.save(pathnfile)
                                rb = xlrd.open_workbook(pathnfile, formatting_info=True)

                                w=copy(rb)
                                sheet=rb.sheet_by_index(0)
                                rows, cols = sheet.nrows, sheet.ncols
                                for i in range(rows,rows+1):
                                    for k in range(len(self.response_cdu2)):
                                          w.get_sheet(0).write(rows,k,hex(self.response_cdu2[k]))
                                w.save(pathnfile)
    ##                            file_object=open(os.getcwd()+'\Errorlog_old.xls','a')
    ##                            file_object.write(str(self.response_cdu2))
                                instant=instant+1
                                j=j+1
                                percent=percent+status_to_improve
                                percent1=str(percent)
                                Progress_download.instance_dwnld.sta_dwld_percent.SetLabel(percent1)
                                Progress_download.instance_dwnld.guage_progressbar.SetValue(percent)
    ##                            if percent1==str(100):
    ##                               self.prog_dwnload.show() 
    ##                               time.sleep(5)
    ##                               self.prog_dwnload.Destroy()  
    ##                            count=count+status_to_improve
    ##                            self.gauge1.SetValue(count)
    ##                            Timestamp=self.Time_stamp()
                                Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
                                CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(" Data Packet "+ str(instant-1)+" Received"+str(Timestamp) +"\n")
                                no_try_packet_correct=0
                                print "i",i
                            else:
                                checksum_stat=0x0
                                no_try_packet_correct=no_try_packet_correct+1 
                                Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
                                CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Incorrect Data packet received"+str(Timestamp) +"\n")
                                print "i m here----------------->",self.req_response_cdu3[0]
##                            status_to_improve=0
##                            print "i m where----------->"
                         else:
                            checksum_stat=0x0
                            no_try_packet_correct=no_try_packet_correct+1 
        ##                        self.req_response_cdu3[0]=0
##                            Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
                            Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()

                            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Data Packet with Incorrect Checksum Received"+str(Timestamp) +"\n")
##                            print "i m here----------------->",self.req_response_cdu3[0]
                            
                         packet_ack=struct.pack('<BBBBB',0xac,0xc3,self.response_cdu1[0],self.response_cdu1[1],checksum_stat)
        ##                     print "self.response_cdu",self.response_cdu
                         checksum_cal=self.Calculate_Checksum(packet_ack,5) 
                         Checksumcal_pack=struct.pack('<B',checksum_cal)
                         packet_ack=packet_ack+Checksumcal_pack
##                         if no_try_packet_correct==3:
##                                pass
##                         else: 
                         self.Req_data_transfer(packet_ack)
                         Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
                         CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Acknowledgement for Data Packet Received sent at"+str(Timestamp) +"\n")
                         no_packet=2
                        
                     #code added for report no 100028
                     else:
                        if no_packet==2:
                           if no_try_packet_correct==3:
                                pass
                           else:                    
                               self.Req_data_transfer(packet_ack)
                               CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Acknowledgement for Data Packet Received sent at"+str(Timestamp) +"\n")
                           no_packet=2  
                        else:
                            if no_try_packet_correct==2:
                                pass
                            else: 
                                   
                               self.Ack_Response_data_transfer(self.req_response_cdu)
                            no_packet=1
                        no_try_packet_correct=no_try_packet_correct+1
                        
                 else:
                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Download successful"+str(Timestamp) +"\n")
##                    print "No where i m here"
                    break
##                 if self.response_cdu1==0:
##                    break                      

	

    def Req_data_transfer(self,Final_packet):    
        if( CDU_TestRig_MainWindow.class_var3.maintenance_object_receiver_CDU!='' and CDU_TestRig_MainWindow.class_var3.maintenance_object_transmitter_CDU!=''): 
            CDU_TestRig_MainWindow.class_var3.maintenance_object_transmitter_CDU.write(Final_packet)
        else:
            CDU_TestRig_MainWindow.class_var3.maintenance_object_receiver_CDU.write(Final_packet)
            print "heeeee"
##        CDU_TestRig_MainWindow.class_var3.Com_maintenance.connect_object.write(Final_packet)
        
    def Ack_Response_data_transfer(self,response_cdu):
        global ack_no_try

        print "response_cdu",response_cdu
        self.response_cdu1=[172,194]
##        self.response_cdu1=list(response_cdu)
        if response_cdu==0:
            self.acceptance_code=0
            self.Ack_packet=[0xAC,0xC2,self.acceptance_code]
            ack_no_try=ack_no_try+1
            Checksumcal=0
            self.val_temp=1
        else:
            for k in range(len(response_cdu)):
                self.response_cdu1.append(response_cdu[k])
            self.acceptance_code=0
            self.Ack_packet=[0xAC,0xC2,self.acceptance_code]
            print "response_cdu",response_cdu
            self.val_temp=self.response_cdu1[6]
            print "self.respense_cdu1",self.response_cdu1[4]
            byte_count=len(self.response_cdu1)-1
            Checksumcal=self.Calculate_Checksum1(self.response_cdu1,byte_count)
            if Checksumcal==self.val_temp:
                self.acceptance_code=0x1
                ack_no_try=ack_no_try+1
                print "yes        ----------------->"
            else:
                self.acceptance_code=0x0
                Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
                CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Acknowledgement received with checksum error"+str(Timestamp) +"\n")
                ack_no_try=ack_no_try+1
                if ack_no_try==4:
                    return 3
                print "No --------------------->" ,Checksumcal,self.val_temp
        if  ack_no_try<=3:  
            Checksumret=self.Calculate_Checksum1(self.Ack_packet,3)
            data_pack=struct.pack('<BBB',0xAC,0xC2,self.acceptance_code)
            
            Checksumcal_pack=struct.pack('<B',Checksumret)
            Final_packet=data_pack+Checksumcal_pack 
            Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
    ##        CDU_TestRig_MainWindow.class_var3.connect_object_CDU1_receiver.write(Final_packet)
    ##        if ack_no_try==2:
            self.Req_data_transfer(Final_packet)
            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Acknowledgement for Packet Info Command sent"+str(Timestamp) +"\n")
    ##        else:
                
            if Checksumcal==self.val_temp:
                return 1   
            else:
                return 0     
##    def __init__(self, parent):
##        self._init_ctrls(parent)
    def Calculate_Checksum1(self,data,byte_count):
        checksum=0
        for i in range(0,byte_count):
            checksum=checksum^data[i]
        checksum=checksum & 0xFF
        return checksum     
    def Calculate_Checksum(self,data,byte_count):
        checksum=0
##        print "pkt,byte_count------>",pkt
##        packet=[0xAC,0xC1,0x0,0x0] 
##        data=struct.pack('<BBBB',0xAC,0xC1,0,0)
        data1=struct.unpack_from('<%dB'%byte_count,data)
        for i in range(0,byte_count):
            checksum=checksum^data1[i]
        checksum=checksum & 0xFF
        return checksum  
    
       
    def Response_data_transfer(self):
        global flag_resend
        ret_value = 0
        self.byte_count=0
        self.read_char1=[]
        self.read_char=[]
        self.read_char2=[]
##        self.data_recvd=[]
        timeout = 15
        flag_timeout=0
        start = time.time()
        flag=0 
        end = start + timeout
        while time.time() < end:
##        time.sleep(1)
##            print "hellooooooooooooo"
            if CDU_TestRig_MainWindow.class_var3.maintenance_object_receiver_CDU.inWaiting() > 0:
                flag=1
                
##                print "hellooooooooooooo"
                self.read_char = struct.unpack('>BB',CDU_TestRig_MainWindow.class_var3.maintenance_object_receiver_CDU.read(2))
                print "read_char",self.read_char
                if self.read_char[0] == 0xAC :
                    if self.read_char[1] == 0xC2:
                        flag_resend=1
##                        print "vvvvvvvvvvvvvvvvvvv"
                        self.read_char1 = struct.unpack('>HHIBB',CDU_TestRig_MainWindow.class_var3.maintenance_object_receiver_CDU.read(10))
    ##                    data1=struct.unpack('>BHHIBB',self.read_char1)
                        self.data_recvd=self.read_char1
##                        print "Data received---->",self.read_char1
                        flag_timeout=1
##                        Timestamp=self.Time_stamp()
                        Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
                        CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Response for error log received"+str(Timestamp) +"\n")

                        return self.read_char1
                          
                    elif self.read_char[1] == 0xC3:
##                         print "self.data_recvd at first", self.data_recvd
                         
                         data=CDU_TestRig_MainWindow.class_var3.maintenance_object_receiver_CDU.read(self.data_recvd[1]+3)
 
##                         data=MainFrame_CDU.my_instance.Com_maintenance.connect_object.read(MainFrame_CDU.my_instance.Com_maintenance.connect_object.inWaiting())
                         size=len(data)
                         self.read_char2 = struct.unpack('>%dB'%size,data)
##                         print "self.read_char2",self.read_char2
                         flag_timeout=1
                         return self.read_char2          
                    else:
                        return 0
                else:
                    return 0            
                break
        if flag_timeout==0:
            return 0   
##    def Packet_data_receive(self):
##        global flag_resend
##        ret_value = 0
##        self.byte_count=0
##        self.read_char1=[]
##        self.read_char=[]
##        self.read_char2=[]
##        timeout = 60
##        start = time.time()
##        flag=0 
##        end = start + timeout
##        while time.time() < end:
####        time.sleep(1)
####            print "hellooooooooooooo"
##            if MainFrame_CDU.my_instance.Com_maintenance.connect_object.inWaiting() > 0:
##                flag=1
##                
####                print "hellooooooooooooo"
##                self.read_char = struct.unpack('>BB',MainFrame_CDU.my_instance.Com_maintenance.connect_object.read(2))
##                print "read_char",self.read_char
##                if self.read_char[0] == 0xAC :
##                    if self.read_char[1] == 0xC3:
##                         print "self.read_char2", self.data_recvd  
##                         data=MainFrame_CDU.my_instance.Com_maintenance.connect_object.read(self.data_recvd[1]+3)
####                         data=MainFrame_CDU.my_instance.Com_maintenance.connect_object.read(MainFrame_CDU.my_instance.Com_maintenance.connect_object.inWaiting())
##                         size=len(data)
##                         self.read_char2 = struct.unpack('>%dB'%size,data)
##                         print "self.read_char2",self.read_char2
##                         
##                         return self.read_char2          
##                            
##                break 
##                  
##        if flag_timeout==0:
##            return 0  
##   
##    def Time_stamp(self):
##        # To get the local time of system
##        self.now=time.localtime(time.time())
##        print "self.now", self.now
##        year, month, day, hour, minute, second, weekday, yearday, daylight =self.now
##        self.a=str(hour)
##        self.b=str(minute)
##        self.c=str(second)
##        if len(self.a)==1:
##            self.a='0'+self.a
##        if len(self.b)==1:
##            self.b='0'+self.b
##        if len( self.c)==1:
##            self.c='0'+self.c
##        self.Timestamp=self.a+":"+self.b+":"+self.c
##        print "Timestamp", self.Timestamp
##        return self.Timestamp                
    
    def dialog_browse(self):
        global pathnfile
        dialog = wx.DirDialog(None, "Choose a directory:", style=wx.DD_DEFAULT_STYLE | wx.DD_NEW_DIR_BUTTON) 
        if dialog.ShowModal() == wx.ID_OK: 
            self.folder_name= dialog.GetPath()
            pathnfile=self.folder_name+'\Errorlog.xls'
            wtbook = xlwt.Workbook()
            wtsheet = wtbook.add_sheet(u'First')
            wtbook.save(pathnfile) 
            CDU_TestRig_MainWindow.class_var3.maintenece_flag=1
            CDU_TestRig_MainWindow.class_var3.browse_ret=1
            self.prog_dwnload=Progress_download.create(None) 
            self.prog_dwnload.Show()
            
            dialog.Hide()
##            return 1
        else:
            
            CDU_TestRig_MainWindow.class_var3.browse_ret=0 
##            dialog.Close()    