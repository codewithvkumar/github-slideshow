#-----------------------------------------------------------------------------
# Name:        Frame3.py
# Purpose:     
#
# Author:      <your name>
#
# Created:     2013/02/28
# RCS-ID:      $Id: Frame3.py $
# Copyright:   (c) 2006
# Licence:     <your licence>
#-----------------------------------------------------------------------------
#Boa:Frame:CDU_TestRig_MainWindow

import wx
import GNSS_OutputWindow
import GNSS_InputWindow
import COMConfig_Window
import COMConfig_GNSS_Window
import home_creation
import CDU_output
import Update_home
import KEYreadnsend
import maintenance_upload
import display
import ibit_out
import page_creation
import Hotkey
import About_CDU_TestRig
import Data_transfer
import com_connection
import struct
import os
import time
import Loopback_Window
from ctypes import *
import threading
from threading import Thread
import time
from ctypes import *
import serial
import string
from serial import  *
import win32api
from xlutils.copy import copy
import sys
import xlrd
import xlwt
import request_packet
import cdutodmc
import Errorlog_module
import Progress_download
##import Frame_Browse

global flag_frame1,flag_frame2,flag_mainframe,main1,main2,class_var,flag_display1,flag_display2,flag_display3,main3
global GNSS_version_temp ,GNSS_output_temp,GNSS_health_temp,file1,flag_com,COMConfig_Window_flag
global class_var3,temp_message,flag_save,flag_save1,flag_save2,val_latitude,GNSS_decoded_output_temp,GNSS_decoded_version_temp,\
GNSS_decoded_health_temp,flag_ok,GNSS_flag
global class_var4,KEYreadnsend_flag,update_select
global filename_GNSS_position_data,filename_GNSS_health_data,filename_GNSS_version_data,flag_connection
##global data_packet,ibit_flag,data_packet_ibit
global data_packet_ibit,IBIT_log_xls,CDUsend_flag,open_frame,flag_maintance,maintance,com_open,\
COMConfig_GNSS_Window_flag,close_CDU_flag,thread_flag,ibit_flag,cdu_gnss_flag,i_bit,flag_ChecksumStatus1,ack_flag	

#Changed for report no-100028
##data_packet=[]
IBIT_log_xls=''
CDU_LOG_xls=''
data_packet_ibit=[]
i_bit=1
flag_ChecksumStatus1=0
flag=0
ack_flag=0
KEYreadnsend_flag=0
COMConfig_Window_flag=0
flag_display1=0
flag_display2=0 
flag_display3=0
flag_frame1=0
flag_frame2=0 
CDUsend_flag=0 
close_CDU_flag=0
thread_flag=0	#Changed for report no-100028
open_frame=0
cdu_gnss_flag=0		#Changed for report no-100028
##flag_page_creation=0
##flag_Update_page=0
flag_home_creation=0
flag_Update_home=0
flag_CDU_output=0
update_select=0
page_var=0
COMConfig_Window_flag=0
flag_maintance=0
maintance=0
COMConfig_GNSS_Window_flag=0
com_open=0
flag_prgs_dwnld=0
ibit_flag=0  #Changed for report no-100028
##ibit_packet=[]

def create(parent):
     global class_var3
     class_var3=CDU_TestRig_MainWindow(parent)
     return class_var3

[wxID_CDU_TestRig_MainWindow, wxID_CDU_TestRig_MainWindowPANEL3, wxID_CDU_TestRig_MainWindow_GNSS_STATICBOX, wxID_CDU_TestRig_MainWindow_GNSS_status, 
 wxID_CDU_TestRig_MainWindow_CDU_STATICBOX,wxID_CDU_TestRig_MainWindow_CDU_status1,wxID_FRAME1btn_mainmode,
 wxID_CDU_TestRig_MainWindow_Sta_msg_log,wxID_CDU_TestRig_MainWindowTEXTCTRL3,wxID_FRAME1btn_maintenancemode,
 wxID_FRAME1COMSTATICBOX,wxID_FRAME1COM_CDU_HEADING,wxID_CDU_TestRig_MainWindow_CDU_STATICBOX,wxID_CDU_TestRig_MainWindow_CDU_status,
 wxID_CDU_TestRig_MainWindow_CDU_statusgnss,wxID_CDU_TestRig_MainWindow_CDU_STATICBOXgnss
] = [wx.NewId() for _init_ctrls in range(16)]		#Changed for report no-100028

class CDU_TestRig_MainWindow(wx.Frame):
    def _init_ctrls(self, prnt):
        # generated method, don't edit
        ##length and width of Main Window
        pixel=wx.GetDisplaySize() 
        global class_var4

        self.Main_window_length=pixel[0]
        self.Main_window_width=pixel[1]-50
        self.panel1_length=pixel[0]
        self.panel1_width=pixel[1]/9.5
        
        ##Main Frame
        wx.Frame.__init__(self, id=wxID_CDU_TestRig_MainWindow, name='', parent=prnt,
              pos=wx.Point(0, 0), size=wx.Size(self.Main_window_length, self.Main_window_width),
              style=wx.SYSTEM_MENU | wx.CAPTION | wx.MINIMIZE_BOX|wx.CLOSE_BOX    , title='CDU TestRig')
        self.SetClientSize(wx.Size(self.Main_window_length, self.Main_window_width))
##        self.Center()
        self.Bind(wx.EVT_CLOSE, self.OnMainFrameClose)
        self.panel1 = wx.Panel(id=wxID_CDU_TestRig_MainWindowPANEL3, name='panel1', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(self.panel1_length, self.panel1_width),
              style=wx.TAB_TRAVERSAL)
        self.panel2 = wx.Panel(id=wxID_CDU_TestRig_MainWindowPANEL3, name='panel1', parent=self,
              pos=wx.Point(0, self.panel1_width), size=wx.Size(self.panel1_length, self.Main_window_width-self.panel1_length),
              style=wx.TAB_TRAVERSAL)
##        self.CreateMenu()
        #position for labels
        self.sta_box_start_x=(pixel[0]/136.6)
        self.sta_box_start_y=(pixel[1]/76.8)
        self.sta_box_length=(pixel[0]/24)
        self.sta_box_width=(pixel[1]/15)
        
        #positions for bitmap labels
        self.bmp_Start_x=(pixel[0]/35.62)
        self.bmp_Start_y=(pixel[1]/25.6)
        self.bmp_length=pixel[0]/60
        self.bmp_width=pixel[1]/30
        self.bmp_gap=(pixel[0]/18.50) ##60
       
        #Color for bmp 
        self.default_color=[236,233,216]
        #Position for "message log"
        self.sta_box1_Start_x=(pixel[0]/4.65)
        self.sta_box1_Start_y=(pixel[1]/192)
        self.sta_box1_length=(pixel[0]/4.129)
        self.sta_box1_width=(pixel[1]/13.71)
##        self.txtctrl_Start_x=(pixel[0]/4.53)
##        self.txtctrl_Start_y=(pixel[1]/34.9)
##        self.txtctrl_length=(pixel[0]/4.41)
##        self.txtctrl_width=(pixel[1]/32)
        
        #Position for text control
        self.txt_Start_x=(pixel[0]/2.34)
        self.txt_Start_y=(pixel[1]/54.86)
        self.txt_length=(pixel[0]/1.79)
        self.txt_width=(pixel[1]/14.40)
        
        #Position for Sta_msg_log
        self.Sta_msg_log_Start_x=(pixel[0]/2.38)
        self.Sta_msg_log_Start_y=(pixel[1]/768)
        self.Sta_msg_log_length=(pixel[0]/1.75)
        self.Sta_msg_log_width=(pixel[1]/10.67)
        
        self.sta_box_start_xc=pixel[0]/8
        self.sta_box_start_yc=pixel[1]/76.8
        self.sta_box_lengthc=pixel[0]/20
        self.sta_box_widthc=pixel[1]/15.36
        
        self.bmp_Start_xc=pixel[0]/7.00
        self.bmp_Start_yc=pixel[1]/22.6
        self.bmp_lengthc=pixel[0]/52.3
        self.bmp_widthc=pixel[1]/40.4
        self.bmp_gapc=pixel[0]/22.77
        
        #Com port
        self.default_color=[236,233,216]
        self.sta_box_COM = wx.StaticBox(id=wxID_FRAME1COMSTATICBOX,
              label='CDU', name='COM PORT', parent=self.panel1,					#Changed for report no-100028
              pos=wx.Point((2*self.sta_box_start_x),self.sta_box_start_y), size=wx.Size(self.sta_box_length,self.sta_box_width), style=0)
        self.COM_status =  wx.StaticBitmap(bitmap=wx.Bitmap(u'red_light.bmp',
              wx.BITMAP_TYPE_BMP), id=wxID_FRAME1COM_CDU_HEADING,
              name='COM PORT', parent=self, pos=wx.Point(self.bmp_Start_x,self.bmp_Start_y),
              size=wx.Size(self.bmp_length+3,self.bmp_width), style=0)
        self.COM_status.SetBackgroundColour(self.default_color) 
        
        self.COM_status.Hide()
        self.sta_box_COM.Hide()
        
		#Changed for report no-100028
        self.sta_box_GNSSmain = wx.StaticBox(id=wxID_CDU_TestRig_MainWindow_CDU_STATICBOXgnss,
              label='GNSS', name='sta_box_GNSSmain', parent=self.panel1,
              pos=wx.Point((4*self.sta_box_start_x)+self.sta_box_length,self.sta_box_start_y), size=wx.Size(self.sta_box_length,self.sta_box_width), style=0)
        self.GNSS_status2 =  wx.StaticBitmap(bitmap=wx.Bitmap(u'red_light.bmp',
              wx.BITMAP_TYPE_BMP), id=wxID_CDU_TestRig_MainWindow_CDU_statusgnss,
              name='USB', parent=self, pos=wx.Point(self.bmp_Start_x+55,self.bmp_Start_y),
              size=wx.Size(self.bmp_length+3,self.bmp_width), style=0)
        self.GNSS_status2.SetBackgroundColour(self.default_color)
        
        self.sta_box_GNSSmain.Hide()
        self.GNSS_status2.Hide()
        
        #CDU-Connection
        self.sta_box_CDU1 = wx.StaticBox(id=wxID_CDU_TestRig_MainWindow_CDU_STATICBOX,
              label='DMC1', name='sta_box_CDU1', parent=self.panel1,
              pos=wx.Point((2*self.sta_box_start_x),self.sta_box_start_y), size=wx.Size(self.sta_box_length,self.sta_box_width), style=0)
        self.CDU_status1 =  wx.StaticBitmap(bitmap=wx.Bitmap(u'red_light.bmp',
              wx.BITMAP_TYPE_BMP), id=wxID_CDU_TestRig_MainWindow_CDU_status1,
              name='USB', parent=self, pos=wx.Point(self.bmp_Start_x,self.bmp_Start_y),
              size=wx.Size(self.bmp_length+3,self.bmp_width), style=0)
        self.CDU_status1.SetBackgroundColour(self.default_color)
        
        
        self.sta_box_CDU2 = wx.StaticBox(id=wxID_CDU_TestRig_MainWindow_CDU_STATICBOX,
              label='DMC2', name='sta_box_CDU2', parent=self.panel1,
              pos=wx.Point((4*self.sta_box_start_x)+self.sta_box_length,self.sta_box_start_y), size=wx.Size(self.sta_box_length,self.sta_box_width), style=0)
        self.CDU_status2 =  wx.StaticBitmap(bitmap=wx.Bitmap(u'red_light.bmp',
              wx.BITMAP_TYPE_BMP), id=wxID_CDU_TestRig_MainWindow_CDU_status,
              name='USB', parent=self, pos=wx.Point(self.bmp_Start_x+55,self.bmp_Start_y),
              size=wx.Size(self.bmp_length+3,self.bmp_width), style=0)
        self.CDU_status2.SetBackgroundColour(self.default_color)
       
        #GNSS-Connection
        self.sta_box_GNSS = wx.StaticBox(id=wxID_CDU_TestRig_MainWindow_GNSS_STATICBOX,
              label='GNSS', name='sta_box_GNSS', parent=self.panel1,
              pos=wx.Point((11.5*self.sta_box_start_x)+self.sta_box_length,self.sta_box_start_y), size=wx.Size(self.sta_box_length,self.sta_box_width), style=0)        
        self.GNSS_status =  wx.StaticBitmap(bitmap=wx.Bitmap(u'red_light.bmp',      
              wx.BITMAP_TYPE_BMP), id=wxID_CDU_TestRig_MainWindow_GNSS_status,
              name='USB-TB', parent=self, pos=wx.Point(self.bmp_Start_x+self.bmp_gap+55,self.bmp_Start_y),
              size=wx.Size(self.bmp_length+3,self.bmp_width), style=0)    
        self.GNSS_status.SetBackgroundColour(self.default_color)    
        
        
        ##Message Log
        self.txt_statuswindow = wx.TextCtrl(id=wxID_CDU_TestRig_MainWindowTEXTCTRL3, name='txt_statuswindow',
              parent=self.panel1, pos=wx.Point(self.txt_Start_x, self.txt_Start_y), size=wx.Size(self.txt_length, self.txt_width),
              style=wx.TE_MULTILINE , value="")
        self.txt_statuswindow. SetEditable(0)
##        self.txt_statuswindow.SetForegroundColour(wx.Colour(255, 0, 0))
        self.Sta_msg_log = wx.StaticBox(id=wxID_CDU_TestRig_MainWindow_Sta_msg_log,
              label='Message Log', name='Sta_msg_log', parent=self.panel1,
              pos=wx.Point(self.Sta_msg_log_Start_x, self.Sta_msg_log_Start_y), size=wx.Size( self.Sta_msg_log_length, self.Sta_msg_log_width), style=0)   
              
        self.btn_mainmode = wx.Button(id=wxID_FRAME1btn_mainmode, label='Main Mode',
              name='btn_mainmode', parent=self.panel1, pos=wx.Point(195, 38),
              size=wx.Size(75, 23), style=0)
        self.btn_mainmode.Bind(wx.EVT_BUTTON, self.OnMain_mode,
              id=wxID_FRAME1btn_mainmode)
              
        self.btn_maintenancemode = wx.Button(id=wxID_FRAME1btn_maintenancemode, label='Maintenance Mode',
              name='btn_maintenancemode', parent=self.panel1, pos=wx.Point(280, 38),
              size=wx.Size(100, 23), style=0)
        self.btn_maintenancemode.Bind(wx.EVT_BUTTON, self.OnMaintance_mode,
              id=wxID_FRAME1btn_maintenancemode)
              
        self.connect_object_GNSS_receiver=''  
        self.connect_object_GNSS_transmitter=''
        self.connect_object_CDU1_receiver=''
        self.connect_object_CDU2_receiver=''
        self.connect_object_CDU1_transmitter=''
        self.connect_object_CDU2_transmitter=''
        self.filename_GNSS_position_data=''
        self.filename_GNSS_health_data=''
        self.filename_GNSS_version_data=''
		#Changed for report no-100028
        self.maintenance_object_receiver_CDU=''			
        self.maintenance_object_transmitter_CDU=''		
        self.maintenance_object_receiver_GNSS=''		
        self.maintenance_object_transmitter_GNSS=''		
        
        self.writetobook = xlwt.Workbook()           # xls file to write into it
        self.writetosheet = self.writetobook.add_sheet('Sheet 1') 
        self.writetobook.save('CDU_LOG.xls')
        self.read_book = xlrd.open_workbook('CDU_LOG.xls', formatting_info=True)
        self.write_obj=copy(self.read_book)
        self.Cdutodmc_obj=''
        self.maintenance_object=0
        self.var_rec=0
        self.var_rec_reset=0
        self.var_ack=0
                
    def __init__(self, parent):
        self._init_ctrls(parent)
        
    # Description:
    # Function parameters:
    # Global variables:
    def connection_com_CDU(self):		#Changed for report no-100028: variable name changed from
        global flag						# maintenance_object_receiver to maintenance_object_receiver_CDU
        try:
            flag=1
            # 1st position is 4 means com port-4 acts data sends from.
            
            if(com_connection.instance_comport_receiver.Comport_select==com_connection.instance_comport_transmitter.Comport_select):
                self.maintenance_object_receiver_CDU = serial.Serial(int(com_connection.instance_comport_receiver.Comport_select),baudrate=int(com_connection.instance_comport_receiver.Baud_Rate),timeout=None,bytesize=8, parity=com_connection.instance_comport_receiver.Parity, stopbits=com_connection.instance_comport_receiver.Stop_Bits)
                self.COM_status.SetBitmap(wx.Bitmap(u'green_light.bmp')) 
                self.maintenance_object=1
##                print "green..........."
            else:
                self.maintenance_object_receiver_CDU = serial.Serial(int(com_connection.instance_comport_receiver.Comport_select),baudrate=int(com_connection.instance_comport_receiver.Baud_Rate),timeout=None,bytesize=8, parity=com_connection.instance_comport_receiver.Parity, stopbits=com_connection.instance_comport_receiver.Stop_Bits)
                self.maintenance_object_transmitter_CDU = serial.Serial(int(com_connection.instance_comport_transmitter.Comport_select),baudrate=int(com_connection.instance_comport_transmitter.Baud_Rate),timeout=None,bytesize=8, parity=com_connection.instance_comport_transmitter.Parity, stopbits=com_connection.instance_comport_transmitter.Stop_Bits)
                self.COM_status.SetBitmap(wx.Bitmap(u'green_light.bmp')) 
##            TestThread_Ibit()
        except SerialException:
            win32api.MessageBox(0, 'COM Port is not Available !', 'Error!!!')
     
	 	#Changed for report no-100028:   New function added for GNSS    
    def connection_com_GNSS(self):
        global flag
        try:
            flag=1
            # 1st position is 4 means com port-4 acts data sends from.
            
            if(com_connection.instance_comport_receiver.Comport_select==com_connection.instance_comport_transmitter.Comport_select):
                self.maintenance_object_receiver_GNSS = serial.Serial(int(com_connection.instance_comport_receiver.Comport_select),baudrate=int(com_connection.instance_comport_receiver.Baud_Rate),timeout=None,bytesize=8, parity=com_connection.instance_comport_receiver.Parity, stopbits=com_connection.instance_comport_receiver.Stop_Bits)
                self.GNSS_status2.SetBitmap(wx.Bitmap(u'green_light.bmp')) 
##                print "green..........."
            else:
                self.maintenance_object_receiver_GNSS = serial.Serial(int(com_connection.instance_comport_receiver.Comport_select),baudrate=int(com_connection.instance_comport_receiver.Baud_Rate),timeout=None,bytesize=8, parity=com_connection.instance_comport_receiver.Parity, stopbits=com_connection.instance_comport_receiver.Stop_Bits)
                self.maintenance_object_transmitter_GNSS = serial.Serial(int(com_connection.instance_comport_transmitter.Comport_select),baudrate=int(com_connection.instance_comport_transmitter.Baud_Rate),timeout=None,bytesize=8, parity=com_connection.instance_comport_transmitter.Parity, stopbits=com_connection.instance_comport_transmitter.Stop_Bits)
                self.GNSS_status2.SetBitmap(wx.Bitmap(u'green_light.bmp')) 
##            TestThread_Ibit()
        except SerialException:
            win32api.MessageBox(0, 'COM Port is not Available !', 'Error!!!')

        
    def OnMainFrameClose(self, event):    
        global flag_connection,flag,close_CDU_flag
        flag=0
        flag_connection=0
       
        if(COMConfig_Window.instance_comport_receiver_CDU1.Comport_select==COMConfig_Window.instance_comport_transmitter_CDU1.Comport_select):
            if (self.connect_object_GNSS_receiver!='' ):
                flag_connection=0
                time.sleep(1)
                self.connect_object_GNSS_receiver.close()
                self.connect_object_GNSS_receiver='' 
                
            if(close_CDU_flag==1):    
                if(self.connect_object_CDU1_receiver!=''):  
                    time.sleep(1)
                    self.connect_object_CDU1_receiver.close()
                    self.connect_object_CDU1_receiver='' 
            else:
                if(self.connect_object_CDU2_receiver!=''):  
                    time.sleep(1)
                    self.connect_object_CDU2_receiver.close()
                    self.connect_object_CDU2_receiver=''
        else:
            if(self.connect_object_GNSS_receiver!='' and self.connect_object_GNSS_transmitter!=''):
                flag_connection=0
                time.sleep(1)
                self.connect_object_GNSS_receiver.close()
                self.connect_object_GNSS_transmitter.close()
                self.connect_object_GNSS_receiver=''
                self.connect_object_GNSS_transmitter=''
                
            if(close_CDU_flag==1):    
                if(self.connect_object_CDU1_receiver!='' and self.connect_object_CDU1_transmitter!=''):
                    time.sleep(1)
                    self.connect_object_CDU1_receiver.close()
                    self.connect_object_CDU1_receiver='' 
                    self.connect_object_CDU1_transmitter.close()
                    self.connect_object_CDU1_transmitter=''
            else:
                if(self.connect_object_CDU2_receiver!='' and self.connect_object_CDU2_transmitter!=''):
                    time.sleep(1)
                    self.connect_object_CDU2_receiver.close()
                    self.connect_object_CDU2_receiver='' 
                    self.connect_object_CDU2_transmitter.close()
                    self.connect_object_CDU2_transmitter=''
        
		#Changed for report no-100028: variable name changed from
        # maintenance_object_receiver to maintenance_object_receiver_CDU   
		# maintenance_object_receiver_GNSS,maintenance_object_transmitter_GNSS added.
        if(maintance==1 and flag_maintance==1):  
##            flag_maintance=0 
            if(com_connection.instance_comport_receiver.Comport_select==com_connection.instance_comport_transmitter.Comport_select):
                if(self.maintenance_object_receiver_CDU!=''):
                    self.maintenance_object_receiver_CDU.close()
                    self.maintenance_object_receiver_CDU=''
                if(self.maintenance_object_receiver_GNSS!=''):
                    self.maintenance_object_receiver_GNSS.close()
                    self.maintenance_object_receiver_GNSS=''
            else:  
                     
                if((self.maintenance_object_receiver_CDU!='') and (self.maintenance_object_transmitter_CDU!='')):
                    self.maintenance_object_receiver_CDU.close()
                    self.maintenance_object_receiver_CDU=''
                    self.maintenance_object_transmitter_CDU.close()
                    self.maintenance_object_transmitter_CDU=''
                if((self.maintenance_object_receiver_GNSS!='') and (self.maintenance_object_transmitter_GNSS!='')):
                    self.maintenance_object_receiver_GNSS.close()
                    self.maintenance_object_receiver_GNSS=''
                    self.maintenance_object_transmitter_GNSS.close()
                    self.maintenance_object_transmitter_GNSS=''
                    
             
        if(flag_frame1==1):
            self.Gnss_output_obj.Destroy() 
        if(flag_frame2==1):
            self.Gnss_input_obj.Destroy()   
        if(COMConfig_Window_flag==1):
            self.Comconfig_obj.Destroy() 
        if(KEYreadnsend_flag==1):
            self.Keyreadnsend_obj.Destroy()  
        if(flag_home_creation==1): # home_creation dialog Destroy
            self.home_creation_obj.Destroy()
        if(flag_Update_home==1): # Update_homedialog Destroy
            self.update_home_obj.Destroy() 
        if(home_creation.flag_page_creation==1): # page_creation  Destroy
            home_creation.main8.Destroy()
        if(Update_home.flag_Update_page==1): # Update_page  Destroy
            Update_home.main9.Destroy() 
        if(flag_CDU_output==1):      # CDU_output  Destroy
            self.Cdu_ouput_obj.Destroy() 
          
        if (flag_prgs_dwnld==1): # code added for closing progress download frame
            self.Errorlog_instance.prog_dwnload.Destroy()    
     #   if open_frame==1:
         #   self.Com_maintenance.connect_object.close()
            
       #     self.Com_maintenance.Destroy()
            
        if maintenance_upload.open_frame==1:
            maintenance_upload.open_frame=0
            self.Frame_Browse.Destroy()
        if cdutodmc.cdu_open_frame==0:
            if self.Cdutodmc_obj!='':
                self.Cdutodmc_obj.Destroy()
                cdutodmc.cdu_open_frame=0
            else:
                pass         
        if(COMConfig_GNSS_Window_flag==1):
            self.Comconfig_GNSS_obj.Destroy() 
        self.Destroy()  
##        print "close"
     
    # Description:
    # Function parameters:
    # Global variables:
           
    def BuildSubmenu1(self, subMenu):
        subMenuObject = wx.Menu()
        for item in subMenu:
            if not item: #allow now to add separators
                subMenuObject.AppendSeparator()
                continue
            if len(item) == 2:
                title, action = item 
            elif len(item) == 3:
                title,id,action = item 
            if type(action) is list:
                _id = wx.NewId()
                subMenuObject.AppendMenu(_id, title, self.BuildSubmenu1(action))
            else:
                _id = wx.NewId()
                subMenuObject.Append(_id, title)
                wx.EVT_MENU(self, _id, action)
        return subMenuObject
     
    # Description:
    # Function parameters:
    # Global variables:
        
    def BuildMenu1(self, menu):
        mainMenu = wx.MenuBar()
        for title, subMenu in menu:
            mainMenu.Append(self.BuildSubmenu1(subMenu), title)
        return mainMenu
    
    # Description:
    # Function parameters:
    # Global variables:
        
    def BuildSubmenu2(self, subMenu):
        subMenuObject = wx.Menu()
        for item in subMenu:
            if not item: #allow now to add separators
                subMenuObject.AppendSeparator()
                continue
            if len(item) == 2:
                title, action = item 
            elif len(item) == 3:
                title,id,action = item 
            if type(action) is list:
                _id = wx.NewId()
                subMenuObject.AppendMenu(_id, title, self.BuildSubmenu1(action))
            else:
                _id =wx.NewId()
                subMenuObject.Append(_id, title)
                wx.EVT_MENU(self, _id, action)
        return subMenuObject
    
    # Description:
    # Function parameters:
    # Global variables:
        
    def BuildMenu2(self, menu):
        mainMenu = wx.MenuBar()
        for title, subMenu in menu:
            mainMenu.Append(self.BuildSubmenu2(subMenu), title)
        return mainMenu
       
    # Description:
    # Function parameters:
    # Global variables:
    #Changed for report no-100028: variable name changed from 'c' to 'C' and 'p' to 'P'.    
    def CreateMenu_mainmode(self):
        menu = [
                ('&Configure',
                    [
                    ('&Connect to GNSS ', 1,self.connect_port),
                    ('&Connect to CDU', 2,self.Connect_CDU),
                    ('&LoopBack Test',20,self.loopbacktest),
                    ('&Close Connection  ', 14,
                        [
                            ('&GNSS Connection', 15,self.close_GNSS),
                            ('&CDU Connection ', 16,
                                [
                                    ('&DMC1', 17,self.close_CDU1),
                                    ('&DMC2', 18,self.close_CDU2),
                                ]
                            ),
                        ]
                    ),
                    ]
                ),
                ('&CDU',
                    [
                    ('&Create Page ', 3,self.Create_Page),
                    ('&Update Page', 4,self.Update_Pagefn),
                    ('&Send Pages to CDU', 5,self.Send_CDU),
                    ('&Output Message from CDU', 6,self.Output_CDU),
					('&Configure the HotKeys', 7,self.Hotkeys_CDU),
					('&Mission Plan Data', 17,
                       [
                            ('&From DMC to CDU (upload)', 18,self.Data_transfer),
                            ('&From CDU to DMC (download)', 19,self.OnCDUtoDMC),
                       ]
                    ),
                    
                    ('&IBIT Command   ', 8,
                        [
                            ('&IBIT Command Input', 9,self.Ibit_command),
                            ('&IBIT Command Output ', 10,self.Ibit_results),
                        ]
                    ),
                    ]
                ),
                ('&GNSS Messages ',
                   [
                    ('&GNSS Input Message ', 11,self.GNSS_input),
                    ('&GNSS Output Message ', 12,self.GNSS_output1),
                    ]              
                ),   
                ('&Help ',
                   [
                    ('&About CDU-TestRig', 13,self.about_CDU),   
                    ]              
                ),              
               ]
               
        self.Menu_created1=self.BuildMenu1(menu)
        self.SetMenuBar(self.Menu_created1)
    
    # Description:
    # Function parameters:
    # Global variables:
    #Changed for report no-100028: new menu CDU,GNSS is added and its closing.
    def CreateMenu_maintenancemode(self):
        menu = [
                ('&Configure',
                    [
                    ('&Connect to CDU',self.Connect_Port1),
                    ('&Connect to GNSS',self.Connect_Port2),
                    ('&Close COM Port',
                        [
                            ('&Close CDU Connection', 18,self.Close_Port_cdu),
                            ('&Close GNSS Coneection', 19,self.Close_Port_gnss),
                        ]
                    ),
                    ]
                ),
                ('&Maintenance',
                    [
                        ('&Data Load', self.OnDataLoad ),
                        ('&Error Log',
                            [
                                ('&Error Log Request', self.OnErrorLogRequest),
                                ('&Erase Error Log', self.OnErase_Error_LogRequest),
                            ]
                        ),
                        ('&Reset Command', self.OnResetCmd ),
                        
                    ]
                ),
            ]
        self.Menu_created2=self.BuildMenu2(menu)
        self.SetMenuBar(self.Menu_created2)
        
    # Description:           
    # Function parameters:
    # Global variables:
           
    def OnMain_mode(self,event):
        cdutodmc.cdu_open_frame=0
        maintance=0
        self.CreateMenu_mainmode()
        self.sta_box_COM.Hide()
        self.COM_status.Hide()
		#Changed for report no-100028
        self.sta_box_GNSSmain.Hide()		
        self.GNSS_status2.Hide()			
        self.sta_box_CDU1.Show() 
        self.CDU_status1.Show() 
        self.sta_box_CDU2.Show() 
        self.CDU_status2.Show()
        self.sta_box_GNSS.Show() 
        self.GNSS_status.Show() 
        self.btn_mainmode.Disable()
        self.btn_maintenancemode.Enable()
##       event.skip()
    
    # Description:
    # Function parameters:
    # Global variables:
        
    def OnMaintance_mode(self,event):
        global maintance,open_frame
        open_frame=1
        cdutodmc.cdu_open_frame=0
        self.CreateMenu_maintenancemode()
        self.sta_box_COM.Show()
        self.COM_status.Show()
        self.sta_box_GNSSmain.Show()		#Changed for report no-100028
        self.GNSS_status2.Show()			
        maintance=1
        self.sta_box_CDU1.Hide() 
        self.CDU_status1.Hide()
        self.sta_box_CDU2.Hide() 
        self.CDU_status2.Hide() 
        self.sta_box_GNSS.Hide() 
        self.GNSS_status.Hide() 
        self.btn_maintenancemode.Disable()
        self.btn_mainmode.Enable()
##       event.skip()
    # Description:
    # Function parameters:
    # Global variables:
        
    def about_CDU(self,event):
       self.cdu_help = About_CDU_TestRig.create(None)
       self.cdu_help.Show()
##       event.skip()
    
    # Description:
    # Function parameters:
    # Global variables:
        
    def close_GNSS(self,event):
        global flag_connection,flag
        flag=0
        flag_connection=0
        self.GNSS_status.SetBitmap(wx.Bitmap(u'red_light.bmp'))
        if(COMConfig_GNSS_Window.instance_comport_receiver.Comport_select==COMConfig_GNSS_Window.instance_comport_transmitter.Comport_select):
            if (self.connect_object_GNSS_receiver!='' ):
                flag_connection=0
                time.sleep(1)
                self.connect_object_GNSS_receiver.close()
                self.connect_object_GNSS_receiver='' 
        else:
            if(self.connect_object_GNSS_receiver!='' and self.connect_object_GNSS_transmitter!=''):
                flag_connection=0
                time.sleep(1)
                self.connect_object_GNSS_receiver.close()
                self.connect_object_GNSS_transmitter.close()
                self.connect_object_GNSS_receiver=''
                self.connect_object_GNSS_transmitter=''
     
##        event.skip()

    # Description:
    # Function parameters:
    # Global variables:
    def Time_stamp(self):
        # To get the local time of system
        time_now=time.localtime(time.time())
##        print "self.time_now", self.time_now
        year, month, day, hour, minute, second, weekday, yearday, daylight =time_now
        time_hour=str(hour)
        time_min=str(minute)
        time_sec=str(second)
        if len(time_hour)==1:
            time_hour='0'+time_hour
        if len(time_min)==1:
            time_min='0'+time_min
        if len(time_sec)==1:
            time_sec='0'+time_sec
        Timestamp=time_hour+":"+time_min+":"+time_sec
##        print "Timestamp", self.Timestamp
        return Timestamp   
             
    def close_CDU1(self,event):
        global flag_connection,flag,close_CDU_flag
        ##flag=0
        flag_connection=0
        time.sleep(1)
        self.CDU_status1.SetBitmap(wx.Bitmap(u'red_light.bmp'))
        close_CDU_flag=2
        print "cdu1 closed"
        if(COMConfig_Window.instance_comport_receiver_CDU1.Comport_select==COMConfig_Window.instance_comport_transmitter_CDU1.Comport_select):
            if(self.connect_object_CDU1_receiver!=''):  
                time.sleep(1)
                self.connect_object_CDU1_receiver.close()
                self.connect_object_CDU1_receiver=''
        else:
            if(self.connect_object_CDU1_receiver!='' and self.connect_object_CDU1_transmitter!=''):
                time.sleep(1)
                self.connect_object_CDU1_receiver.close()
                self.connect_object_CDU1_receiver='' 
                self.connect_object_CDU1_transmitter.close()
                self.connect_object_CDU1_transmitter=''
        #Changed for report no-100028        
        temp_text="DMC1 connection is closed\n "
        self.txt_statuswindow.WriteText(temp_text)
        if(self.connect_object_CDU2_receiver!=''):
            temp_text="DMC2 is connected\n "
            self.txt_statuswindow.WriteText(temp_text)


            
    def close_CDU2(self,event):
        global flag_connection,flag,close_CDU_flag
        ##flag=0
        flag_connection=0
        self.CDU_status2.SetBitmap(wx.Bitmap(u'red_light.bmp'))
        close_CDU_flag=1
        print "cdu2 closed"
        if(COMConfig_Window.instance_comport_receiver_CDU2.Comport_select==COMConfig_Window.instance_comport_transmitter_CDU2.Comport_select):
            if(self.connect_object_CDU2_receiver!=''):  
                time.sleep(1)
                self.connect_object_CDU2_receiver.close()
                self.connect_object_CDU2_receiver=''
        else:
            if(self.connect_object_CDU2_receiver!='' and self.connect_object_CDU2_transmitter!=''):
                time.sleep(1)
                self.connect_object_CDU2_receiver.close()
                self.connect_object_CDU2_receiver='' 
                self.connect_object_CDU2_transmitter.close()
                self.connect_object_CDU2_transmitter=''
        #Changed for report no-100028
        temp_text="DMC2 connection is closed\n "
        self.txt_statuswindow.WriteText(temp_text)
        if(self.connect_object_CDU1_receiver!=''):
            temp_text="DMC1 is connected\n "
            self.txt_statuswindow.WriteText(temp_text)

    # Description:
    # Function parameters:
    # Global variables:
        
    def Data_transfer(self,event):
        global close_CDU_flag
        if(close_CDU_flag==1):
            if(self.connect_object_CDU1_receiver!='' or self.connect_object_CDU1_transmitter!=''):
                self.data_upload = Data_transfer.create(None)
                self.data_upload.Show()
            else:
                dial = wx.MessageDialog(None, 'COM port is not connected.....!!',
                'Error!!!', wx.OK|wx.STAY_ON_TOP)
                dial.ShowModal()
        else:
            if(self.connect_object_CDU2_receiver!='' or self.connect_object_CDU2_transmitter!=''):
                self.data_upload = Data_transfer.create(None)
                self.data_upload.Show()
            else:
                dial = wx.MessageDialog(None, 'COM port is not connected.....!!',
                'Error!!!', wx.OK|wx.STAY_ON_TOP)
                dial.ShowModal()
        
    # Description:
    # Function parameters:
    # Global variables:
        
    def OnCDUtoDMC(self,event):
        global close_CDU_flag
        if(close_CDU_flag==1):
            if(self.connect_object_CDU1_receiver!='' or self.connect_object_CDU1_transmitter!=''):
               self.Cdutodmc_obj=cdutodmc.create(None)
               self.Cdutodmc_obj.Show()
            else:
                dial = wx.MessageDialog(None, 'COM port is not connected.....!!',
                'Error!!!', wx.OK|wx.STAY_ON_TOP)
                dial.ShowModal()
        else:
            if(self.connect_object_CDU2_receiver!='' or self.connect_object_CDU2_transmitter!=''):
               self.Cdutodmc_obj=cdutodmc.create(None)
               self.Cdutodmc_obj.Show()
            else:
                dial = wx.MessageDialog(None, 'COM port is not connected.....!!',
                'Error!!!', wx.OK|wx.STAY_ON_TOP)
                dial.ShowModal()
            
    # Description:
    # Function parameters:
    # Global variables:
            
    def Hotkeys_CDU(self,event):
	    global page_var,flag 
	    val=0
##            page_creation.new_confirm=0
##            page_var=1
##            home_creation.home_flag=0
##            self.Gnss_output_obj1 = Hotkey.create(None)
##            self.Gnss_output_obj1.Show()
##            if KEYreadnsend.class_var.check_pageselected==1:
##                flag=0
            head=os.getcwd()
##            print head
            file="CDUHOTKEY.xls"
            pathnfile=os.path.join(head,"CDUHOTKEY.xls") 
##            print pathnfile   
            for subdir,dirs,files in os.walk(head):
                for a in files:
                    fullpath=os.path.join(head,a)
                    if(fullpath!=pathnfile):
                        val=1
                    else:
                        val=0
                        break
                break     
            if val==1:
                 m1 = wx.MessageDialog(self, "NO HOTKEYS CONFIGURATION PAGE PRESENT!!!Please create or update page!!!",\
                    " ", style = wx.OK | wx.ICON_INFORMATION|wx.STAY_ON_TOP)
                 if m1.ShowModal() == wx.ID_OK:
                    m1.Destroy()           
                
            else: 
##                print "llllllllllllllllllll"
                page_creation.new_confirm=0
                page_var=1
                home_creation.home_flag=0
                self.Hotkey_obj = Hotkey.create(None)
                self.Hotkey_obj.Show()
##                self.Gnss_output_obj1.MakeModal(True) 

    # Description:
    # Function parameters:
    # Global variables:
        
    def Ibit_results(self,event):
        global close_CDU_flag
        if(close_CDU_flag==1):
            if(self.connect_object_CDU1_receiver!='' or self.connect_object_CDU1_transmitter!=''):
                self.ibit_results = ibit_out.create(None)
                self.ibit_results.Show()
            else:
                dial = wx.MessageDialog(None, 'COM port is not connected.....!!',
                'Error!!!', wx.OK|wx.STAY_ON_TOP)
                dial.ShowModal()
        else:
            if(self.connect_object_CDU2_receiver!='' or self.connect_object_CDU2_transmitter!=''):
                self.ibit_results = ibit_out.create(None)
                self.ibit_results.Show()
            else:
                dial = wx.MessageDialog(None, 'COM port is not connected.....!!',
                'Error!!!', wx.OK|wx.STAY_ON_TOP)
                dial.ShowModal()
        
    
    # Description:
    # Function parameters:
    # Global variables:
     #Changed for report no-100028: ibit acknowledgment fn is removed
	 # from thread and made a seperate fn.
    def Ibit_command(self,event):
        global CDUsend_flag,close_CDU_flag,thread_flag,ibit_flag,i_bit,flag_ChecksumStatus1,ack_flag
        i=0
        ibit_flag=0
        thread_flag=1
        i_bit=1
        flag_ChecksumStatus1=0
        self.ibit_results = ibit_out.create(None)
##        print "close_CDU_flag at click=",close_CDU_flag
        
        ibit_class_instance=ibit_out.ibit_class()
        
        if(close_CDU_flag==1):
            if(self.connect_object_CDU1_receiver!='' or self.connect_object_CDU1_transmitter!=''):
                if(CDUsend_flag==1):
                    while(1):
                        if(ibit_flag==0 and i<3):
                            display.Ibit_msg()
    ##                        print "i=",i
                            i=i+1
                            thread_flag=1
                            self.ACK_Ibit_msg()
                            if(ibit_flag==1):
                                self.ACK_Ibit_msg_final()  
                                if(ack_flag==0):  
                                    self.txt_statuswindow.WriteText("Final packet is not received for IBIT command\n")                        
                        else:
                            if(i>=3 and ibit_flag==0):
                                self.txt_statuswindow.WriteText("Acknowledgement is not received for IBIT command\n")
                                thread_flag=0
                            break
                       
                        if(flag_ChecksumStatus1>=3):                         
                            Timestamp=self.Time_stamp()                            
                            temp_text="Retries for data init command exceeded at"+ str(Timestamp)+"\n"
                            self.txt_statuswindow.WriteText(temp_text)
                            break
                else:
                    dial = wx.MessageDialog(None, 'Pages not sent to CDU.....!!',
                    'Error!!!', wx.OK|wx.STAY_ON_TOP)
                    dial.ShowModal()
                          
            else:
                dial = wx.MessageDialog(None, 'COM port is not connected.....!!',
                'Error!!!', wx.OK|wx.STAY_ON_TOP)
                dial.ShowModal() 
        elif(close_CDU_flag==2):
            if(self.connect_object_CDU2_receiver!='' or self.connect_object_CDU2_transmitter!=''):
                if(CDUsend_flag==1):
                    while(1):
                        if(ibit_flag==0 and i<3):
                            display.Ibit_msg()
    ##                        print "i=",i
                            i=i+1
                            thread_flag=1
                            self.ACK_Ibit_msg()
                            if(ibit_flag==1):
                                self.ACK_Ibit_msg_final()
                                if(ack_flag==0):  
                                    self.txt_statuswindow.WriteText("Final packet is not received for IBIT command\n")
                        else:
                            if(i>=3):
                                self.txt_statuswindow.WriteText("Acknowledgement is not received for IBIT command\n")
                                thread_flag=0
                            break
                else:
                    dial = wx.MessageDialog(None, 'Pages not sent to CDU.....!!',
                    'Error!!!', wx.OK|wx.STAY_ON_TOP)
                    dial.ShowModal()
                          
            else:
                dial = wx.MessageDialog(None, 'COM port is not connected.....!!',
                'Error!!!', wx.OK|wx.STAY_ON_TOP)
                dial.ShowModal()
          
    # Description:
    # Function parameters:
    # Global variables:
                  
    def GNSS_output1(self,event):
            global flag_frame1,Gnss_output_obj
            if(flag_frame1==0):
                self.Gnss_output_obj = GNSS_OutputWindow.create(None)
                self.Gnss_output_obj.Show()
                flag_frame1=1
            else:
                self.Gnss_output_obj.SetFocus()
                self.Gnss_output_obj.Show() 
                
    # Description:
    # Function parameters:
    # Global variables:
   
    def GNSS_input(self,event):
        global flag_frame2,Gnss_input_obj
        if(self.connect_object_GNSS_receiver!='' or self.connect_object_GNSS_transmitter!=''):
            if(flag_frame2==0):
                self.Gnss_input_obj = GNSS_InputWindow.create(None)
                self.Gnss_input_obj.Show()
                flag_frame2=1
            else:
                self.Gnss_input_obj.SetFocus()
                self.Gnss_input_obj.Show() 
        else:
            dial = wx.MessageDialog(None, 'COM port is not connected.....!!',
            'Error!!!', wx.OK|wx.STAY_ON_TOP)
            dial.ShowModal()
            
    # Description:
    # Function parameters:
    # Global variables:
                   
        
    def connect_port(self,evt):
        global main3,GNSS_flag,flag_com,COMConfig_GNSS_Window_flag
        GNSS_flag=1
        flag_com=1
        if(COMConfig_GNSS_Window_flag==0):
            self.Comconfig_GNSS_obj =COMConfig_GNSS_Window.create(None)
            self.Comconfig_GNSS_obj.Show()
            COMConfig_GNSS_Window_flag=1
        else:
            self.Comconfig_GNSS_obj.SetFocus()
            self.Comconfig_obj.Show() 
    
    # Description:
    # Function parameters:
    # Global variables:
    #Changed for report no-100028: changed from COM Port to CDU COM Port        
    def Close_Port_cdu(self,event):
        try:
            global open_frame
            open_frame=0
            self.var_rec=0
            self.var_rec_reset=0
            if(com_connection.instance_comport_receiver.Comport_select==com_connection.instance_comport_transmitter.Comport_select):
                if(self.maintenance_object_receiver_CDU!=''):
                  self.maintenance_object_receiver_CDU.close()
                  self.maintenance_object_receiver_CDU=''
            else:
                if((self.maintenance_object_receiver_CDU!='') and (self.maintenance_object_transmitter_CDU!='')):
                  self.maintenance_object_receiver_CDU.close()
                  self.maintenance_object_receiver_CDU=''
                  self.maintenance_object_transmitter_CDU.close()
                  self.maintenance_object_transmitter_CDU=''
           # self.Com_maintenance.connect_object.close()
           # self.Com_maintenance.Close()
            self.COM_status.SetBitmap(wx.Bitmap(u'red_light.bmp'))
##            self.status_Message.Error_MSG_txt.WriteText("Com port has been closed\n")
            temp_text="Com port has been closed\n"
            self.txt_statuswindow.WriteText(temp_text)
            
        except:
##            self.status_Message.Error_MSG_txt.WriteText("Com port is already closed\n")
            temp_text="Com port is already closed\n"
            self.txt_statuswindow.WriteText(temp_text)
	#Changed for report no-100028: new fn to close GNSS COM Port      
    def Close_Port_gnss(self,event):
        try:
      
            if(com_connection.instance_comport_receiver.Comport_select==com_connection.instance_comport_transmitter.Comport_select):
                if(self.maintenance_object_receiver_GNSS!=''):
                  self.maintenance_object_receiver_GNSS.close()
                  self.maintenance_object_receiver_GNSS=''
            else:
                if((self.maintenance_object_receiver_GNSS!='') and (self.maintenance_object_transmitter_GNSS!='')):
                  self.maintenance_object_receiver_GNSS.close()
                  self.maintenance_object_receiver_GNSS=''
                  self.maintenance_object_transmitter_GNSS.close()
                  self.maintenance_object_transmitter_GNSS=''
           # self.Com_maintenance.connect_object.close()
           # self.Com_maintenance.Close()
            self.GNSS_status2.SetBitmap(wx.Bitmap(u'red_light.bmp'))
##            self.status_Message.Error_MSG_txt.WriteText("Com port has been closed\n")
            temp_text="Com port has been closed\n"
            self.txt_statuswindow.WriteText(temp_text)
            
        except:
##            self.status_Message.Error_MSG_txt.WriteText("Com port is already closed\n")
            temp_text="Com port is already closed\n"
            self.txt_statuswindow.WriteText(temp_text)
      
#Changed for report no-100028: changed from maintenance_object_receiver to maintenance_object_receiver_CDU
              
    def recv_ack(self,val):
        ret_value = 0
        self.byte_count=0
        timeout = 45
        start = time.time()
        flag=0 
        end = start + timeout
        while time.time() < end:
            if self.maintenance_object_receiver_CDU.inWaiting() > 0:
                flag=1
                self.read_char = self.maintenance_object_receiver_CDU.read()
                if self.read_char == "\xAC":
                    self.byte_count=self.byte_count+1
                    self.read_char1 = self.maintenance_object_receiver_CDU.read()
                    (data,)=struct.unpack('>B',self.read_char1)
                    if data==val:
                        self.byte_count=self.byte_count+1
                        self.accpt_code = self.maintenance_object_receiver_CDU.read()
                        if self.accpt_code == "\x00":
                            ret_value = 0         
##                            print " ACK received with 0"
                        else:
                            self.byte_count=self.byte_count+1
                            (self.recv_checksum,) = struct.unpack(">B",self.maintenance_object_receiver_CDU.read())         
                            ret_value = 1
                            self.read_buf=self.read_char+self.read_char1+self.accpt_code 
                    else:
                        ret_val=3     
                break
##        if ret_value == 1:
##            checksum_computed = self.Calculate_Checksum(self.read_buf,self.byte_count)
##            if self.recv_checksum == checksum_computed :
##                ret_value = 1
##            else:
##                ret_value = 0
        if flag==0:
            ret_value=2
        return ret_value
    
    # Description:
    # Function parameters:
    # Global variables:
    #Changed for report no-100028: changed from maintenance_object_receiver to maintenance_object_receiver_CDU            
    def Send_Packet(self,packet):
        global close_CDU_flag
        if(close_CDU_flag==1):
            if(com_connection.instance_comport_receiver_CDU1.Comport_select==com_connection.instance_comport_transmitter_CDU1.Comport_select):
              self.maintenance_object_receiver_CDU.write(packet)
            
            else:
              self.maintenance_object_transmitter_CDU.write(packet)
        elif(close_CDU_flag==2):
            if(com_connection.instance_comport_receiver_CDU2.Comport_select==com_connection.instance_comport_transmitter_CDU2.Comport_select):
              self.maintenance_object_receiver_CDU.write(packet)
            else:
              self.maintenance_object_transmitter_CDU.write(packet)
            
    
    # Description:
    # Function parameters:
    # Global variables:
                
    def loopbacktest(self,event):
        self.loopbacktest_obj =Loopback_Window.create(None)
        self.loopbacktest_obj.Show()
    
    # Description:
    # Function parameters:
    # Global variables:
          
    def Send_Packet_1(self,packet):
        if(com_connection.instance_comport_receiver.Comport_select==com_connection.instance_comport_transmitter.Comport_select):
          self.maintenance_object_receiver_CDU.write(packet)
        else:
          self.maintenance_object_transmitter_CDU.write(packet)

    
    # Description:
    # Function parameters:
    # Global variables:  
    #Changed for report no-100028: changed from maintenance_object_receiver to maintenance_object_receiver_CDU     
    def OnErase_Error_LogRequest(self,evt):
        self.var_i=0
        self.error_log_flag=0
        self.var_ack=0
        self.chsm_erase=0
        if(self.maintenance_object==1):
            if( self.maintenance_object_receiver_CDU !=''):
                self.var_rec=1
        elif(self.maintenance_object_transmitter_CDU!=''):
              self.var_rec=2
        if(self.var_rec==1 or self.var_rec==2):
             while(True):     
                if(self.error_log_flag==0 and self.var_i<3):
                    erase_error_log_packet=request_packet.Erase_Error_Log_Packet()
                    self.Send_Packet_1(erase_error_log_packet)
                    time_n=self.local_time()
                    class_var3.txt_statuswindow.WriteText("Erase Error Log Packet Sent at "+str(time_n)+" instance\n")
                    self.recv_ack_erase()
                    self.var_i=self.var_i+1

                else:
                    if(self.error_log_flag==0 and self.var_ack==0  and self.chsm_erase==0):
                          class_var3.txt_statuswindow.WriteText("Acknowledgement is not received for Erase Error Log Command \n")
                    break
                
        else:
           dial = wx.MessageDialog(None, 'COM Port is not Available !',
            'Error!!!', wx.OK)
           dial.ShowModal()
           
    def local_time(self):
        time_now=time.localtime(time.time())
        time_n=str(time_now.tm_hour)+":"+str(time_now.tm_min)+":"+str(time_now.tm_sec)
        return time_n  
    #Changed for report no-100028: changed from maintenance_object_receiver to maintenance_object_receiver_CDU 
    def OnResetCmd(self,evt):
        self.var_j=0
        self.reset_flag=0
        self.var_ack_reset=0
        self.var_cksm_error=0
        if(self.maintenance_object==1):
            if( self.maintenance_object_receiver_CDU !=''):
                self.var_rec_reset=1
        elif(self.maintenance_object_transmitter_CDU!=''):
              self.var_rec_reset=2
        if(self.var_rec_reset==1 or self.var_rec_reset==2):
            while(True):
                    if(self.reset_flag==0 and self.var_j<3):
                        packet=request_packet.Reset_Packet()
                        self.Send_Packet_1(packet)
                        time_n=self.local_time()
                        class_var3.txt_statuswindow.WriteText("Reset Command Sent at  "+str(time_n)+" \n")
                        self.recv_ack_reset()
                        self.var_j=self.var_j+1
                    else:
                         if(self.reset_flag==0 and self.var_ack_reset==0 and self.var_cksm_error==0  ):
                            class_var3.txt_statuswindow.WriteText("Acknowledgement is not received for Reset Command \n")
                         break
                    
        else:
                dial = wx.MessageDialog(None, 'COM Port is not Available !',
                'Error!!!', wx.OK)
                dial.ShowModal()
    
    
    # Description:
    # Function parameters:
    # Global variables:
     #Changed for report no-100028: changed from maintenance_object_receiver to maintenance_object_receiver_CDU      
    def OnErrorLogRequest(self,event):
##        global flag_maintance
##        print "obj---->",self.maintenance_object_receiver_CDU
        if( self.maintenance_object_receiver_CDU!='' or self.maintenance_object_transmitter_CDU!=''):

##            self.status_Message.Error_MSG_txt.WriteText("Error log request\n")\
            self.Errorlog_instance=Errorlog_module.Errorlog()
            self.Errorlog_instance.dialog_browse()
            self.Errorlog_instance.Errorlog_data()
##            self.status_Message.Error_MSG_txt.WriteText("Error log request\n")n
        else:
##            self.status_Message.Error_MSG_txt.WriteText("Please connect to port first\n")
            temp_text="Please connect to port first \n"
            self.txt_statuswindow.WriteText(temp_text)
    
    # Description:
    # Function parameters:
    # Global variables:
           
    def OnDataLoad(self,event):
        
        if maintenance_upload.open_frame==0:
            self.Frame_Browse=maintenance_upload.create(None)
            self.Frame_Browse.Show()
         
       
    
    # Description:
    # Function parameters:
    # Global variables:
     #Changed for report no-100028:  cdu_gnss_flag is added.         
    def Connect_Port1(self,event):
        global cdu_gnss_flag
        cdu_gnss_flag=1
        if com_open==0:
            self.com_connect_obj =com_connection.create(None) #ChoiceDialog(self, -1, 'Configure Com port')
            self.com_connect_obj.Show()
        else:
            self.com_connect_obj.SetFocus()
            self.com_connect_obj.Show()

	#Changed for report no-100028: Connection fn of gnss
    def Connect_Port2(self,event):
        global cdu_gnss_flag
        cdu_gnss_flag=0
        if com_open==0:
            self.com_connect_obj_gnss =com_connection.create(None) #ChoiceDialog(self, -1, 'Configure Com port')
            self.com_connect_obj_gnss.Show()
        else:
            self.com_connect_obj_gnss.SetFocus()
            self.com_connect_obj_gnss.Show()
        
   #Changed for report no-100028: changed from maintenance_object_receiver to maintenance_object_receiver_CDU                 
    def recv_ack_erase(self):
        timeout =10
        start = time.time()
        end = start + timeout
        while ((time.time())<end):  
            self.byte_count1=0
            list=[]
            if self.maintenance_object_receiver_CDU.inWaiting() > 0:
                b=struct.unpack(">B", self.maintenance_object_receiver_CDU.read(1))
                list.append(b[0])
                if list[0] ==172:
                    self.byte_count1=self.byte_count1+1
                    pkt_id1=struct.unpack(">B", self.maintenance_object_receiver_CDU.read(1)) 
                    list.append(pkt_id1[0])
                    if(list[1]==212):
                        (ac_code,checksum)=struct.unpack('>2B', self.maintenance_object_receiver_CDU.read(2))
                        self.byte_count1=self.byte_count1+3
                        list.append(ac_code)
                        list.append(checksum)
                        cal_checksum=self.Calculate_Checksum(list,self.byte_count1)
                        if(list[3]==cal_checksum):
                            if(list[2]==1):        
                                time_n=self.local_time()
                                class_var3.txt_statuswindow.WriteText("Acknowledgment received with valid acceptance code for erase log command at "+str(time_n)+"\n")
                                #Code has been added for the report number 100028
                                class_var3.txt_statuswindow.WriteText("CDU has erased the error log section in EEPROM\n")
                                self.error_log_flag=1
                                break
                            else:
                                time_n=self.local_time()
                                class_var3.txt_statuswindow.WriteText("Acknowledgment received with invalid acceptance code for erase log command at "+str(time_n)+"\n")
                                if( self.var_i==2):
                                        self.var_ack=1
                                        time_n=self.local_time()
                                        class_var3.txt_statuswindow.WriteText("Retries for erase error log command exceeded at "+str(time_n)+"\n")
                                        break
                        else:
                             time_n=self.local_time()
                             class_var3.txt_statuswindow.WriteText("Acknowledgment received with checksum error at "+str(time_n)+"\n")

                             if( self.var_i==2):
                                 self.chsm_erase=1
                                 time_n=self.local_time()
                                 class_var3.txt_statuswindow.WriteText("Retries for erase error log command exceeded at "+str(time_n)+"\n")

                             break
   	#Changed for report no-100028: changed from maintenance_object_receiver to maintenance_object_receiver_CDU                      
    def recv_ack_reset(self):
        timeout = 10
        start = time.time()
        end = start + timeout
        while((time.time())<end):  
            self.byte_count=0
            list_reset=[]
            if self.maintenance_object_receiver_CDU.inWaiting() > 0:
                b=struct.unpack(">B", self.maintenance_object_receiver_CDU.read(1))
                list_reset.append(b[0])
                if list_reset[0] ==172:
                    self.byte_count=self.byte_count+1
                    pkt_id=struct.unpack(">B", self.maintenance_object_receiver_CDU.read(1)) 
                    list_reset.append(pkt_id[0])
                    if(list_reset[1]==177):
                        (ac_code,checksum)=struct.unpack('>2B', self.maintenance_object_receiver_CDU.read(2))
                        self.byte_count=self.byte_count+3
                        list_reset.append(ac_code)
                        list_reset.append(checksum)
                        cal_checksum=self.Calculate_Checksum(list_reset,self.byte_count)
                        if(list_reset[3]==cal_checksum):
                            if(list_reset[2]==1): 
                                time_n=self.local_time()       
                                class_var3.txt_statuswindow.WriteText("Acknowledgment received with valid acceptance code for reset command at "+str(time_n)+" \n")
                                #Code has been added for the report number 100028
                                class_var3.txt_statuswindow.WriteText("CDU has been reset\n")
                                self.reset_flag=1
                                break
                            else:
                                 time_n=self.local_time()
                                 class_var3.txt_statuswindow.WriteText("Acknowledgment received with invalid acceptance code for reset command at "+str(time_n)+"\n")
                                 if( self.var_j==2):
                                        self.var_ack_reset=1
                                        time_n=self.local_time()
                                        class_var3.txt_statuswindow.WriteText("Retries for reset command exceeded at "+str(time_n)+"\n")
                                        break
                        else:
                              time_n=self.local_time()
                              class_var3.txt_statuswindow.WriteText("Acknowledgment received with checksum error for reset command at "+str(time_n)+"\n")                   

                              if( self.var_j==2):
                                  self.var_cksm_error=1 
                                  time_n=self.local_time()
                                  class_var3.txt_statuswindow.WriteText("Retries for reset command exceeded at "+str(time_n)+" \n")

                              break
    def Calculate_Checksum(self,data,byte_count):
            checksum=0
##            print "data",data
            for i in range(0,byte_count-1):
               var1=data[i]
               checksum=checksum ^ (var1)
            checksum=checksum&0xFFFFFFFF
            return checksum 
	#Changed for report no-100028:       
    def Calculate_Checksum1(self,data,bytecount):
            checksum=0
            for i in range(0,bytecount):
               var1=data[i]
               checksum = checksum ^ (var1)
            checksum = checksum & 0xFF
            return checksum 
    #Changed for report no-100028: seperate ibit ack fn      
    def ACK_Ibit_msg(self):
        global ibit_flag,close_CDU_flag,i_bit,flag_ChecksumStatus1
        flag_process=0
        no_ibit=1
        data=[]
                             
        print "inside ack........."
        
        if(close_CDU_flag==1):
            connect_object=self.connect_object_CDU1_receiver
        else:
            connect_object=self.connect_object_CDU2_receiver
            
        timeout =5
        start = time.time()
        end = start + timeout
        print "flag_ChecksumStatus1-",flag_ChecksumStatus1
        while(time.time()<end):  
            if(flag_ChecksumStatus1<3):      
                if connect_object.inWaiting() > 0:                           
                        val=struct.unpack(">2B",connect_object.read(2))
                        data.append(val[0])
                        data.append(val[1])
                        print data
                        if (val[0]==0xAC)  : 
                            if(val[1]==0xE1):   #Acknowlegement message from CDU
                                flag_process=1
                                g=struct.unpack(">2B",connect_object.read(2))
                                data.append(g[0])    # acceptance bit
                                data.append(g[1])    # checksum bit
                                
                                print "Acknowlegement message from CDU----->",data
                                
                                Checksum=self.Calculate_Checksum1(data,len(data)-1)
                                print "checksum-------->",Checksum
                                print "last bit-------->",data[3]
                                if( Checksum == data[len(data)-1] ):
                                    ibit_flag=1
                                    if(data[2]==0):
                                        ibit_flag=0
                                        i=0
                                        Timestamp=self.Time_stamp()
                                        self.txt_statuswindow.SetForegroundColour(wx.Colour(255, 0, 0))
                                        temp_text="Invalid Acceptance received from CDU at "+ str(Timestamp)+"\n"
                                        self.txt_statuswindow.WriteText(temp_text)
                                        flag_ChecksumStatus1=flag_ChecksumStatus1+1
                                        print "inside--->",flag_ChecksumStatus1
                                        while(1):
                                            if(ibit_flag==0 and i_bit<3):
                                                display.Ibit_msg()                                  
                                                i_bit=i_bit+1
                                                self.ACK_Ibit_msg()
                                                if(flag_ChecksumStatus1>3):
                                                    break
                                            else:
                                                 break
                                    else:  
                                        data=[]               
                                        Timestamp=self.Time_stamp()
                                        self.txt_statuswindow.SetForegroundColour(wx.Colour(0, 0, 255))
                                        temp_text="IBIT Acknowlegement Message received from CDU at "+ str(Timestamp)+"\n"
                                        self.txt_statuswindow.WriteText(temp_text)
                                else:                      
                                    Timestamp=self.Time_stamp()
                                    self.txt_statuswindow.SetForegroundColour(wx.Colour(255, 0, 0))
                                    temp_text="Invalid Checksum Acknowlegement Message received from CDU at "+ str(Timestamp)+"\n"
                                    self.txt_statuswindow.WriteText(temp_text)  
                                    flag_ChecksumStatus1=flag_ChecksumStatus1+1
                                    
                                    while(1):
                                        if(ibit_flag==0 and i_bit<3):
                                            display.Ibit_msg()                                   
                                            i_bit=i_bit+1
                                            self.ACK_Ibit_msg()
                                            if(flag_ChecksumStatus1>3):
                                                break
                                        else:
                                             break                
                            else:
                                
                                if(val[1]==0xE2):
                                    Timestamp=self.Time_stamp()
                                    print "IBIT final packet received without IBIT Acknowlegement at"
                                    temp_text="IBIT final packet received without IBIT Acknowlegement at"+ str(Timestamp)+"\n"
                                    self.txt_statuswindow.WriteText(temp_text)
                                    break
                                else:                                   
                                    Timestamp=self.Time_stamp()
                                    temp_text="Invalid Acknowlegement received at"+ str(Timestamp)+"\n"
                                    self.txt_statuswindow.WriteText(temp_text)
                            
    #Changed for report no-100028: seperate ibit final fn                        
    def ACK_Ibit_msg_final(self):
        global ibit_flag,close_CDU_flag,thread_flag,ack_flag
        flag_process=0
        no_ibit=1
        data=[]
        ack_flag=0 
                             
        print "inside ack final........."
        
        if(close_CDU_flag==1):
            connect_object=self.connect_object_CDU1_receiver
        else:
            connect_object=self.connect_object_CDU2_receiver
        
        validate_instance=CDU_output.validate()
        ibit_class_instance=ibit_out.ibit_class()    
        timeout =5
        start = time.time()
        end = start + timeout
        
        while(time.time()<end):                 
            if connect_object.inWaiting() > 0:           
                    val=struct.unpack(">2B",connect_object.read(2))
                    data.append(val[0])
                    data.append(val[1])                    
                    if (val[0]==0xAC)  :     
                        if(data[1]==0xE2):    #final data from CDU
                            ack_flag=1
                            flag_process=1
                            if(ibit_flag==1):
                                g=struct.unpack(">2B",connect_object.read(2))
                                data.append(g[0]) 
                                data.append(g[1])
                                print "final data at ibit----->",data
                                
                                Checksum=self.Calculate_Checksum1(data,len(data)-1)
                                print "checksum-------->",Checksum
                                print "last bit-------->",data[3]
                                if( Checksum == data[len(data)-1] ):
                        ##                                Ibit_output.ibit_data=data
                                    data_packet_ibit=data
                                    ibit_flag=1
                                    ibitfinal_flag=1
                        ##                                        ibit_class_instance.Setgrid_values(data_packet_ibit)
                                    display.logging_ibit(no_ibit)
                                    no_ibit=no_ibit+1
                                    
                        ##                                        Timestamp=self.Time_stamp()
                                    Timestamp=self.Time_stamp()                                    
                                    temp_text="IBIT final Message received from CDU at "+ str(Timestamp)+"\n"
                                    self.txt_statuswindow.WriteText(temp_text)
                                    
                                    self.ibit_results.Show()
                                    ibit_class_instance.Setgrid_values(data_packet_ibit)
                                    thread_flag=0
                        ##                                    
                                else:
                        ##                                        Timestamp=self.Time_stamp()
                                    Timestamp=self.Time_stamp()
                                    temp_text="Invalid Checksum final Message received from CDU at "+ str(Timestamp)+"\n"
                                    self.txt_statuswindow.WriteText(temp_text)
                                    
                            else:
                        ##                                    Timestamp=self.Time_stamp()
                                Timestamp=self.Time_stamp()
                                temp_text="IBIT Acknowlegement Message not received from CDU at "+ str(Timestamp)+"\n"
                                self.txt_statuswindow.WriteText(temp_text)
        
    # Description:
    # Function parameters:
    # Global variables:
        
    def create_file_GNSS_Data(self):   ##CSV file.
##        print "self",self
        fd=open(self.filename_GNSS_position_data,'w')
        fd.write("Message,")
        fd.write("Position Availability,")
        fd.write("Receiver_latitude,") 
        fd.write("Receiver_longitude,")
        fd.write("Receiver_altitude,")
        fd.write("Ground_Speed,")
        fd.write("Heading,")
        fd.write("Receiver_North_Velocity,")
        fd.write("Receiver_east_velocity,")
        fd.write("Receiver_vertical_velocity,")
        fd.write("UTC Date,")
        fd.write("UTC Time,")
        fd.write("HPL,")
        fd.write("HFOM,")
        fd.write("VPL,")
        fd.write("VFOM,")
        fd.write("PPS Status,")
        fd.write("Position Computation by,") 
        fd.close()
        
        fd1=open(self.filename_GNSS_health_data,'w')
        fd1.write("Message,")
        fd1.write("GPS Start Mode," ) 
##            fd1.write("GNSS Mode,")           
        fd1.write("Navigation with GAGAN Corrections,") 
        fd1.write("Navigation with Integrity,")        
        fd1.write("2D Navigation with Altitude Aid,")      
        fd1.write("3D Navigation,")                   
        fd1.write("Fault Integrity Fails During Navigation,")
        fd1.write("Phase of Flight,") 
        fd1.write("Number of Tracking GPS Satellites,")
        fd1.write("Number of Tracking GLONASS Satellites,")
        fd1.write("Number of Tracking GAGAN Satellites,")
##            fd1.write("Fault Status,")
        fd1.write("Antenna Connected,")
        fd1.write("Antenna State,")    
        fd1.write("RF1 (GPS + GAGAN RF) PLL Locked,")     
        fd1.write("RF2 (GLONASS) PLL Locked,")      
        fd1.write("CPU1(GPS +GLONASS processor,")    
        fd1.write("CPU2 (GAGAN),")     
        fd1.write("Satellites Availability,") 
        fd1.write("PDOP Value,") 
        fd1.write("GAGAN Satellites are Used for Position Computation,") 
        fd1.write("GNSS System Failure,")  
        fd1.write("GNSS Mode,")  
        fd1.write("PDOP Value,") 
        fd1.write("HDOP Value,")     
        fd1.write("VDOP Value,")    
        fd1.write("TDOP Value,")      
        fd1.close()
        
        fd2=open(self.filename_GNSS_version_data,'w')
        fd2.write("Message,")
        fd2.write("Hardware Version number,")
        fd2.write("Software Version number ,")
        fd2.write("Software Release Date ,")
        fd2.close()
##        evt.Skip()    
    
    # Description:
    # Function parameters:
    # Global variables:
        
    def Save_GNSS_fields(self,list1):
##        print "SAving"
        list_str=''
        list3=[]
        for i in range((len(list1))-2):
            list3.append((hex(list1[i])))
            if((len(list3[i]))==3):
                  temp5=string.split(list3[i],'0x')
                  list3[i]='0x'+'0'+temp5[1]
            list3[i]=list3[i].replace("0x",'')
            list_str=list_str+list3[i]
        list_str='0x'+list_str
##        print list_str 
        global flag_position
##        print "self",self
##        print self.filename_GNSS_position_data
        fd=open(self.filename_GNSS_position_data,'a')
        fd.write("\n"+list_str +",")
        fd.write(str(GNSS_OutputWindow.GNSS_decoded_output_temp.Position_availability) +",")
        fd.write(str(GNSS_OutputWindow.GNSS_decoded_output_temp.Receiver_latitude)+",")
        fd.write(str(GNSS_OutputWindow.GNSS_decoded_output_temp.Receiver_longitude)+",")
        fd.write(str(GNSS_OutputWindow.GNSS_decoded_output_temp.Receiver_altitude)+",")
        fd.write(str(GNSS_OutputWindow.GNSS_decoded_output_temp.Ground_Speed)+",")
        fd.write(str(GNSS_OutputWindow.GNSS_decoded_output_temp.Heading)+",")
        fd.write(str(GNSS_OutputWindow.GNSS_decoded_output_temp.Receiver_North_Velocity)+",")
        fd.write(str(GNSS_OutputWindow.GNSS_decoded_output_temp.Receiver_east_velocity)+",")
        fd.write(str(GNSS_OutputWindow.GNSS_decoded_output_temp.Receiver_vertical_velocity)+",")
        fd.write(str(GNSS_OutputWindow.GNSS_decoded_output_temp.UTC_date)+",")
        fd.write(str(GNSS_OutputWindow.GNSS_decoded_output_temp.UTC_time)+",")
        fd.write(str(GNSS_OutputWindow.GNSS_decoded_output_temp.HPL)+",")
        fd.write(str(GNSS_OutputWindow.GNSS_decoded_output_temp.HFOM)+",")
        fd.write(str(GNSS_OutputWindow.GNSS_decoded_output_temp.VPL)+",")
        fd.write(str(GNSS_OutputWindow.GNSS_decoded_output_temp.VFOM)+",")
        fd.write(str(GNSS_OutputWindow.GNSS_decoded_output_temp.PPS)+",")
        fd.write(str(GNSS_OutputWindow.GNSS_decoded_output_temp.Position_Computation)+",")
        fd.close()
    
    # Description:
    # Function parameters:
    # Global variables:
        
    def Save_GNSS_health_fields(self,health_list):
##        print "SAving1"
        global filename_GNSS_health_data
##        global filename_GNSS_position_data,filename_GNSS_health_data,filename_GNSS_version_data,flag_position
        list_str2=''
        list_health=[]
##        print health_list
        for i in range((len(health_list))-2):
            list_health.append((hex(health_list[i])))
            if((len(list_health[i]))==3):
                  temp5=string.split(list_health[i],'0x')
                  list_health[i]='0x'+'0'+temp5[1]
            list_health[i]=list_health[i].replace("0x",'')
            list_str2=list_str2+list_health[i]
        list_str2='0x'+list_str2
##        print list_str2
        fd1=open(self.filename_GNSS_health_data,'a')
        fd1.write("\n"+list_str2+",")
        fd1.write( GNSS_OutputWindow.GNSS_decoded_health_temp.GNSS_Start_Mode+",")              
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.Navigation_with_GAGAN+",")
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.Navigation_with_Integrity+",")
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.Navigation_2D+",")
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.Navigation_3D+",")  
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.FaultIntegrity+",")
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.Phase_of_Flight+",")
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.GPS_Satellites+",")
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.GLONASS_Satellites+",")
        fd1.write( GNSS_OutputWindow.GNSS_decoded_health_temp.GAGAN_Satellites+",")
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.Antenna+",")
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.Antenna_state+",")
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.RF1+",")
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.RF2+",") 
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.CPU1+",")   
        fd1.write( GNSS_OutputWindow.GNSS_decoded_health_temp.CPU2+",")
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.Satellites_avail+",")
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.PDOP1+",")
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.GAGAN_position+",")
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.GNSS_system_failure+",")    
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.GNSS_mode+",")
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.PDOP_value+",")
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.HDOP+",")
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.VDOP+",") 
        fd1.write(GNSS_OutputWindow.GNSS_decoded_health_temp.TDOP+",")       
        fd1.close()
    
    # Description:
    # Function parameters:
    # Global variables:
            
    def Save_GNSS_version_fields(self,version_list):
##        print "SAving2"
        global filename_GNSS_version_data
##        global filename_GNSS_position_data,filename_GNSS_health_data,filename_GNSS_version_data,flag_position
        list_str3=''
        list_version=[]
        for i in range((len(version_list))-2):
            list_version.append((hex(version_list[i])))
            if((len(list_version[i]))==3):
                  temp5=string.split(list_version[i],'0x')
                  list_version[i]='0x'+'0'+temp5[1]
            list_version[i]=list_version[i].replace("0x",'')
            list_str3=list_str3+list_version[i]
        list_str3='0x'+list_str3
##        print list_str3
        fd2=open(self.filename_GNSS_version_data,'a')
        fd2.write("\n"+list_str3+",")
        fd2.write(GNSS_OutputWindow.GNSS_decoded_version_temp.Hardware_version_number+",")
        fd2.write(GNSS_OutputWindow.GNSS_decoded_version_temp.Software_version+",")
        fd2.write(GNSS_OutputWindow.GNSS_decoded_version_temp.Software_release_date+",")
        fd2.close()
    
    # Description:
    # Function parameters:
    # Global variables:
            
    def connection(self):
            global flag_connection
            try:
                flag_connection=1
##                print"GNSS---------->"
                if(COMConfig_GNSS_Window.instance_comport_receiver.Comport_select==COMConfig_GNSS_Window.instance_comport_transmitter.Comport_select):
                    self.connect_object_GNSS_receiver = serial.Serial(int(COMConfig_GNSS_Window.instance_comport_receiver.Comport_select),baudrate=int(COMConfig_GNSS_Window.instance_comport_receiver.Baud_Rate),timeout=None,bytesize=8, parity=COMConfig_GNSS_Window.instance_comport_receiver.Parity, stopbits=COMConfig_GNSS_Window.instance_comport_receiver.Stop_Bits)
                    self.GNSS_status.SetBitmap(wx.Bitmap(u'green_light.bmp')) 
##                    print"GNSS---------->EQUAL"
                else:
                    self.connect_object_GNSS_receiver = serial.Serial(int(COMConfig_GNSS_Window.instance_comport_receiver.Comport_select),baudrate=int(COMConfig_GNSS_Window.instance_comport_receiver.Baud_Rate),timeout=None,bytesize=8, parity=COMConfig_GNSS_Window.instance_comport_receiver.Parity, stopbits=COMConfig_GNSS_Window.instance_comport_receiver.Stop_Bits)
                    self.connect_object_GNSS_transmitter = serial.Serial(int(COMConfig_GNSS_Window.instance_comport_transmitter.Comport_select),baudrate=int(COMConfig_GNSS_Window.instance_comport_transmitter.Baud_Rate),timeout=None,bytesize=8, parity=COMConfig_GNSS_Window.instance_comport_transmitter.Parity, stopbits=COMConfig_GNSS_Window.instance_comport_transmitter.Stop_Bits)
                    self.GNSS_status.SetBitmap(wx.Bitmap(u'green_light.bmp'))
##                    print"GNSS---------->DIFFERENT"
                TestThread()
            except SerialException:
                 dial = wx.MessageDialog(None, 'COM Port is not Available !',
                'Error!!!', wx.OK)
                 dial.ShowModal()
##                win32api.MessageBox(0, 'COM Port is not Available !', 'Error!!!')  
    
    # Description:
    # Function parameters:
    # Global variables:
                        
    def Create_Page(self,event): 
        global flag_home_creation
##        print" global home_creation_obj",home_creation_obj
        update_select=0
       
##        print"flag_home_creation",flag_home_creation
##        print"home_creation.flag_page_creation",home_creation.flag_page_creation
        
        if(flag_home_creation==0 and home_creation.flag_page_creation==0):
            self.home_creation_obj = home_creation.create(None)
            self.home_creation_obj.Show()
            flag_home_creation=1
        elif(flag_home_creation==1 and home_creation.flag_page_creation==0):
            self.home_creation_obj.SetFocus()
            flag_home_creation=1
            self.home_creation_obj.Show() 
        elif(flag_home_creation==0 and home_creation.flag_page_creation==1):
            home_creation.main8.SetFocus()
            home_creation.flag_page_creation=1
            home_creation.main8.Show()
##        else:
##            print "aaaaaaaa"
    
    # Description:
    # Function parameters:
    # Global variables:
                   
    def Update_Pagefn(self,event):
        global filename_xls,prev_page,flag_Update_home,update_select
		
        page_creation.new_confirm=2
        update_select=1
        t=0
##        try:
        if(flag_Update_home==0 and Update_home.flag_Update_page==0):
            dlg = wx.FileDialog(self, "Choose a file", ".", "", "*.xls", wx.OPEN)
            if dlg.ShowModal() == wx.ID_OK:
                global browse
                browse=1
                filename_xls = dlg.GetPath()
                
                wb=xlrd.open_workbook(filename_xls, formatting_info=1)
                sh1=wb.sheet_by_index(0)
                rows=sh1.nrows 
##                    print "rows",rows
##                    temp=(sh1.row_values(rows-10))  
##                    temp1=temp[1]
##                    print "temp[1]",temp
##                    prev_page=int(temp1/4096)
                row_no=(rows+1)/11
##                print "rows",rows
##                print "row_no",row_no
                for i in range(row_no):
                    temp=(sh1.row_values(t)) 
##                    print "temp",temp[1]
 
                    if(temp[1]!=''): 
##                        temp=(sh1.row_values(t-11)) 
##                        print "inside if--->temp",temp
                        prev_page=int(temp[1]/4096)
##                        print "prev_page",prev_page
                    else:
                        break
                    t=t+11
                        
                self.update_home_obj = Update_home.create(None)
                flag_Update_home=1
                self.update_home_obj.Show()
        elif(flag_Update_home==1 and Update_home.flag_Update_page==0):
            self.update_home_obj.SetFocus()
            flag_Update_home=1
            self.update_home_obj.Show() 
        elif(flag_Update_home==0 and Update_home.flag_Update_page==1): 
            Update_home.main9.SetFocus()
            Update_home.flag_Update_page=1
            Update_home.main9.Show()
                
##        except:
##            dial = wx.MessageDialog(None, 'Format not supported.....!!',
##            'Error!!!', wx.OK|wx.STAY_ON_TOP)
##            dial.ShowModal()  
 
           
        
##        event.Skip()
    
    # Description:
    # Function parameters:
    # Global variables:
        
    def Output_CDU(self,event): 
        global flag_CDU_output

        if(close_CDU_flag==1):
            if(self.connect_object_CDU1_receiver!=''):
                if(flag_CDU_output==0):
                    self.Cdu_ouput_obj = CDU_output.create(None)
                    self.Cdu_ouput_obj.Show()
    ##                CDU_output.instance_Frame8.Log_Heading()
    ##                display.Log_Heading()
                else:
                    self.Cdu_ouput_obj.SetFocus()
                    self.Cdu_ouput_obj.Show()
            else:
                dial = wx.MessageDialog(None, 'COM port is not connected.....!!',
                'Error!!!', wx.OK|wx.STAY_ON_TOP)
                dial.ShowModal()
        elif(close_CDU_flag==2):
            if(self.connect_object_CDU2_receiver!=''):
                if(flag_CDU_output==0):
                    self.Cdu_ouput_obj = CDU_output.create(None)
                    self.Cdu_ouput_obj.Show()
    ##                CDU_output.instance_Frame8.Log_Heading()
    ##                display.Log_Heading()
                else:
                    self.Cdu_ouput_obj.SetFocus()
                    self.Cdu_ouput_obj.Show()
            else:
                dial = wx.MessageDialog(None, 'COM port is not connected.....!!',
                'Error!!!', wx.OK|wx.STAY_ON_TOP)
                dial.ShowModal()
        
            
    # Description:
    # Function parameters:
    # Global variables:
        
    def Connect_CDU(self,event): 
        global flag,GNSS_flag,flag_com,COMConfig_Window_flag
        GNSS_flag=0
        flag_com=2
        if(COMConfig_Window_flag==0):
            self.Comconfig_obj = COMConfig_Window.create(None)
            self.Comconfig_obj.Show()
            COMConfig_Window_flag=1
##            display.Log_Heading()
        else:
            self.Comconfig_obj.SetFocus()
            self.Comconfig_obj.Show()
            
    
    # Description:
    # Function parameters:
    # Global variables:
               
    def connnection1(self):
        global flag
        try:
            flag=1
            if(COMConfig_Window.instance_comport_receiver_CDU1.Comport_select==COMConfig_Window.instance_comport_transmitter_CDU1.Comport_select):
                self.connect_object_CDU1_receiver = serial.Serial(int(COMConfig_Window.instance_comport_receiver_CDU1.Comport_select),baudrate=int(COMConfig_Window.instance_comport_receiver_CDU1.Baud_Rate),timeout=None,bytesize=8, parity=COMConfig_Window.instance_comport_receiver_CDU1.Parity, stopbits=COMConfig_Window.instance_comport_receiver_CDU1.Stop_Bits)
                self.CDU_status1.SetBitmap(wx.Bitmap(u'green_light.bmp')) 
                print "equal-------->cdu1"
            else:
                self.connect_object_CDU1_receiver = serial.Serial(int(COMConfig_Window.instance_comport_receiver_CDU1.Comport_select),baudrate=int(COMConfig_Window.instance_comport_receiver_CDU1.Baud_Rate),timeout=None,bytesize=8, parity=COMConfig_Window.instance_comport_receiver_CDU1.Parity, stopbits=COMConfig_Window.instance_comport_receiver_CDU1.Stop_Bits)
                self.connect_object_CDU1_transmitter = serial.Serial(int(COMConfig_Window.instance_comport_transmitter_CDU1.Comport_select),baudrate=int(COMConfig_Window.instance_comport_transmitter_CDU1.Baud_Rate),timeout=None,bytesize=8, parity=COMConfig_Window.instance_comport_transmitter_CDU1.Parity, stopbits=COMConfig_Window.instance_comport_transmitter_CDU1.Stop_Bits)
                self.CDU_status1.SetBitmap(wx.Bitmap(u'green_light.bmp'))
                print "diff------->cdu1"
        except SerialException:
           dial = wx.MessageDialog(None, 'COM Port is not Available in CDU1!',
                'Error!!!', wx.OK)
           dial.ShowModal()
           
        try:
            if(COMConfig_Window.instance_comport_receiver_CDU2.Comport_select==COMConfig_Window.instance_comport_transmitter_CDU2.Comport_select):
                print "equal------->cdu2"
                self.connect_object_CDU2_receiver = serial.Serial(int(COMConfig_Window.instance_comport_receiver_CDU2.Comport_select),baudrate=int(COMConfig_Window.instance_comport_receiver_CDU2.Baud_Rate),timeout=None,bytesize=8, parity=COMConfig_Window.instance_comport_receiver_CDU2.Parity, stopbits=COMConfig_Window.instance_comport_receiver_CDU2.Stop_Bits)
                self.CDU_status2.SetBitmap(wx.Bitmap(u'green_light.bmp')) 
            else:
                print "diff------->cdu2"
                self.connect_object_CDU2_receiver = serial.Serial(int(COMConfig_Window.instance_comport_receiver_CDU2.Comport_select),baudrate=int(COMConfig_Window.instance_comport_receiver_CDU2.Baud_Rate),timeout=None,bytesize=8, parity=COMConfig_Window.instance_comport_receiver_CDU2.Parity, stopbits=COMConfig_Window.instance_comport_receiver_CDU2.Stop_Bits)
                self.connect_object_CDU2_transmitter = serial.Serial(int(COMConfig_Window.instance_comport_transmitter_CDU2.Comport_select),baudrate=int(COMConfig_Window.instance_comport_transmitter_CDU2.Baud_Rate),timeout=None,bytesize=8, parity=COMConfig_Window.instance_comport_transmitter_CDU2.Parity, stopbits=COMConfig_Window.instance_comport_transmitter_CDU2.Stop_Bits)
                self.CDU_status2.SetBitmap(wx.Bitmap(u'green_light.bmp'))
                

        except SerialException:
           dial = wx.MessageDialog(None, 'COM Port is not Available in CDU2 !',
                'Error!!!', wx.OK)
           dial.ShowModal()
                           
                
    
    # Description:
    # Function parameters:
    # Global variables:
                
    def Send_CDU(self,event):   
        global KEYreadnsend_flag,flag

        if(close_CDU_flag==1):
            if (self.connect_object_CDU1_receiver==''):
                m1 = wx.MessageDialog(self, "NO CONNECTION ESTABLISHED!!! PLEASE CONFIGURE",\
                        " ", style = wx.OK | wx.ICON_INFORMATION|wx.STAY_ON_TOP)
                if m1.ShowModal() == wx.ID_OK:
                    m1.Destroy()
            else:
                if(KEYreadnsend_flag==0):
                    flag=1     
                    self.Keyreadnsend_obj = KEYreadnsend.create(None)
                    self.Keyreadnsend_obj.Show()
                    KEYreadnsend_flag=1
    ##                KEYreadnsend.class_var.ShowModal(False)
                else:
                    KEYreadnsend.class_var.OnCancel()
                    flag=1     
                    self.Keyreadnsend_obj = KEYreadnsend.create(None)
                    self.Keyreadnsend_obj.Show()
                    KEYreadnsend_flag=1   
        else:
            if (self.connect_object_CDU2_receiver==''):
                m1 = wx.MessageDialog(self, "NO CONNECTION ESTABLISHED!!! PLEASE CONFIGURE",\
                        " ", style = wx.OK | wx.ICON_INFORMATION|wx.STAY_ON_TOP)
                if m1.ShowModal() == wx.ID_OK:
                    m1.Destroy()
            else:
                if(KEYreadnsend_flag==0):
                    flag=1     
                    self.Keyreadnsend_obj = KEYreadnsend.create(None)
                    self.Keyreadnsend_obj.Show()
                    KEYreadnsend_flag=1
    ##                KEYreadnsend.class_var.ShowModal(False)
                else:
                    KEYreadnsend.class_var.OnCancel()
                    flag=1     
                    self.Keyreadnsend_obj = KEYreadnsend.create(None)
                    self.Keyreadnsend_obj.Show()
                    KEYreadnsend_flag=1
                
    # Description:
    # Function parameters:
    # Global variables:
                      
    def xlsvalidate(self):
        val=0
        head=os.getcwd()
##        print head
        file="CDUHOTKEY.xls"
        pathnfile=os.path.join(head,"CDUHOTKEY.xls") 
##        print pathnfile   
        for subdir,dirs,files in os.walk(head):
            for a in files:
                fullpath=os.path.join(head,a)
                if(fullpath!=pathnfile):
                    val=1
                else:
                    val=0
                    break
            break
        return val 
##        event.Skip()   

# Description:
    # Function parameters:
    # Global variables:
           
    
class TestThread(Thread):       # GNSS 
    def __init__(self):
        Thread.__init__(self)
        self.start()    # start the thread
 
    def run(self):
            global Gnss_output_obj,flag_display1,flag_display2,flag_display3,temp_message,flag_connection
            process_flag=0
            i=0
            list=[]
            list1=[] 
            temp_message=GNSS_OutputWindow.message()
            while(1):
##                print "read"
##                print class_var3.connect_object
##                ser.read(ser.inWaiting())
##                list=[]   
                if flag_connection==0:
                    return
                elif class_var3.connect_object_GNSS_receiver.inWaiting() > 0:
##                    print "**************************************************"
##                    print "**************************************************"
##                    print "message"
##                    a=class_var3.connect_object.read(1)
                    if(process_flag==0):
                        list=[]
                        list1=[]
                        if class_var3.connect_object_GNSS_receiver.inWaiting() < 3:
                            flag_process=0
                            rem_data=struct.unpack("%dB"%(class_var3.connect_object_GNSS_receiver.inWaiting()),class_var3.connect_object_GNSS_receiver.read((class_var3.connect_object_GNSS_receiver.inWaiting()) ))
##                            print rem_data
                        else:
                            b=struct.unpack(">3B",class_var3.connect_object_GNSS_receiver.read(3))
                            flag_process=1
##                    (b,)=struct.unpack('>B',class_var3.connect_object_GNSS_receiver.read(1))
##                            print "b value"
##                            print hex(b[0])
                        
                            list.append(hex(b[0]))
                            list.append(hex(b[1]))
                            list.append(hex(b[2]))
##                            print (b[2])
##                    print list
##                    f=(hex(b[0]))
##                    print f
                    if(flag_process==1):
                        if (list[0]=='0x3f'): 
##                            print "First byte"    
                            if(list[1]=='0x3f'):
##                                print "Second byte"
                                if(list[2]=='0xaf'):
                                    process_flag=0
                                    if class_var3.connect_object_GNSS_receiver.inWaiting() >0:
                                        (e,)=struct.unpack(">B",class_var3.connect_object_GNSS_receiver.read(1))
                                        if(e==0x02):
                                            try:
##                                                print "message id 1"
                                                g=struct.unpack(">66B",class_var3.connect_object_GNSS_receiver.read(66))
##                                                print g 
                                                list1=[] 
                                                list1=g
##                                                print "LIst1.........>",list1
                                                list2=[]
                                                list2[0:4]=['0x3f','0x3f','0xaf','0x02']
                                                for i in range (0,66):
                                                    list2.append(hex(list1[i]))
            ##                                    print list2
                                                ##For converting from hex value to float suffixing with '0'
                                                for i in range (0,(len(list2))):
                                                    if((len(list2[i]))==3):
                                                          temp4=string.split(list2[i],'0x')
                                                          list2[i]='0x'+'0'+temp4[1]
            ##                                              print temp4
            ##                                          print val[i]
##                                                print list2
            ##                                    print list1
            ##                                    print hex(list1[0])
            ##                                    self.Gnss_output_obj = GNSS_OutputWindow.create(None,list2)
##                                                print "list2........" ,list2
                                                #Function to store the data into Structure                                   
                                                temp_message.process_msg(list2)
                                                if(GNSS_OutputWindow.flag_save==1):
                                               
                                                     Timestamp= class_var3.Time_stamp()    
                                                     #Code has been added for the report number 100028
                                                     display_position=" GNSS Output Message(Position,Velocity and Time)is received at  "+ str(Timestamp)+"  instance  " +"\n"
                                                     class_var3.txt_statuswindow.WriteText(display_position)
                                                     # Function to validate the input values
                                                     temp_message.display_validate()
                                                  # Function to save the data into xl file
                                                     class_var3.Save_GNSS_fields(list1)
    ##                                            else:
                                            except:
##                                                print " GNSS Output (Position,Velocity and Time)data is less than 66 bytes\n"
                                                temp_text=" GNSS Output (Position,Velocity and Time)data is less than 66 bytes\n"
                                                class_var3.txt_statuswindow.SetValue(temp_text)
                                                
                                        elif(e==0x03):
                                                try:
##                                                    print "message id2"
                                                    g=struct.unpack(">13B",class_var3.connect_object_GNSS_receiver.read(13))              
##                                                    print g 
                                                    health_list=[]
                                                    health_list1=[]
                                                    health_list =g
                                                    health_list1[0:4]=['0x3f','0x3f','0xaf','0x03']
                                                    for i in range (0,13):
                                                        health_list1.append(hex(health_list[i]))
                ##                                    print list2
                                                    for i in range (0,(len(health_list1))):
                                                        if((len(health_list1[i]))==3):
                                                              temp4=string.split(health_list1[i],'0x')
                                                              health_list1[i]='0x'+'0'+temp4[1]
                ##                                              print temp4
                ##                                          print val[i]
##                                                    print health_list1
                ##                                    print list1
                ##                                    print hex(list1[0])
                ##                                    self.Gnss_output_obj = GNSS_OutputWindow.create(None,list2)
                ##                                    print "list2........" ,list2
                                                    flag_display2=1
                                                    temp_message.process_msg1(health_list1)
                                                   
                                                    if(GNSS_OutputWindow.flag_save1==1):
                                                         Timestamp= class_var3.Time_stamp()
                                                         #Code has been added for the report number 100028
                                                         temp_text="GNSS status/receiver health message is received at  "+ str(Timestamp)+"\n"
                                                         class_var3.txt_statuswindow.WriteText(temp_text)
                                                         temp_message.display_health_validate()
                                                         class_var3.Save_GNSS_health_fields(health_list)
                                                        
                ##                                    flag_display2=1
                                                except:
                                                    temp_text="Insufficient GNSS Output(Health Message)data\n"
                                                    class_var3.txt_statuswindow.WriteText(temp_text)
                                            
                                        elif(e==0x04):
                                            try:
##                                                print "message id3"
                                                g=struct.unpack(">16B",class_var3.connect_object_GNSS_receiver.read(16))    
##                                                print g 
                                                version_list=[]
                                                version_list1=[]
                                                version_list =g
                                                version_list1[0:4]=['0x3f','0x3f','0xaf','0x04']
                                                for i in range (0,16):
                                                    version_list1.append(hex(version_list[i]))
            ##                                    print list2
                                                for i in range (0,(len(version_list1))):
                                                    if((len(version_list1[i]))==3):
                                                          temp4=string.split(version_list1[i],'0x')
                                                          version_list1[i]='0x'+'0'+temp4[1]
     
####                                                print "list2........" ,version_list1
                                                temp_message.process_msg2(version_list1)
                                              
                                                if(GNSS_OutputWindow.flag_save2==1):
                                                    Timestamp=class_var3.Time_stamp()
                                                    #Code has been added for the report number 100028
                                                    temp_text=" GNSS receiver version Message received at  "+ str(Timestamp)+"\n"
                                                    class_var3.txt_statuswindow.WriteText(temp_text) 
                                                    temp_message.display_version_validate()
                                                    class_var3.Save_GNSS_version_fields(version_list)
##                                                flag_display3=1
                                            except:
                                                temp_text="Insufficient GNSS Output(Version Message)data\n"
                                                class_var3.txt_statuswindow.WriteText(temp_text)
                                else:
                                    
                                    process_flag=1
                                    list[0]=list[1]
                                    list[1]=list[2]
##                                    print list[0],list[1]
                                    if class_var3.connect_object_GNSS_receiver.inWaiting() >0:
                                        (c,)=struct.unpack(">B",class_var3.connect_object_GNSS_receiver.read(1))
                                        list[2]=hex(c)
                            else:
                                    process_flag=1
                                    list[0]=list[1]
                                    list[1]=list[2]
##                                    print list[0],list[1]
                                    if class_var3.connect_object_GNSS_receiver.inWaiting() >0:
                                        (c,)=struct.unpack(">B",class_var3.connect_object_GNSS_receiver.read(1))
                                        list[2]=hex(c)
                        else:
                                    process_flag=1
##                                    print "else"
                                    list[0]=list[1]
                                    list[1]=list[2]
##                                    print list[0],list[1]
                                    if class_var3.connect_object_GNSS_receiver.inWaiting() >0:
                                        (c,)=struct.unpack(">B",class_var3.connect_object_GNSS_receiver.read(1))
                                        list[2]=hex(c)
                        
##                GNSS_OutputWindow.class_var.refresh()        
                                    
##        except:
##           print  "Reading RS-232 Exception"


        


       
    