#Boa:Frame:Frame1

import wx
import struct
import time
import CDU_TestRig_MainWindow
import os
import pdb
global cdu_open_frame
import COMConfig_Window
import Errorlog_module
import threading,Queue
from threading import Thread
global ack_no_try
ack_no_try=0
cdu_open_frame=1
def create(parent):
    global cdutodmc
    cdutodmc=Cdutodmc(parent)
    return cdutodmc

[wxID_FRAME1, wxID_FRAME1PANEL1,wxID_FRAME1GAUGE1,wxID_FRAME1BUTTON1,wxID_FRAME1BUTTON2,wxID_FRAME1STATICTEXT1,wxID_FRAME1STATICTEXT2 
] = [wx.NewId() for _init_ctrls in range(7)]

class Cdutodmc(wx.Frame):
    def _init_ctrls(self, prnt):
        # generated method, don't edit
        self.flag_close=0
##        wx.Frame.__init__(self, style=wx.SYSTEM_MENU | wx.CAPTION | wx.MINIMIZE_BOX|wx.STAY_ON_TOP|wx.RESIZE_BORDER , name='', parent=prnt, title='Status Messages', pos=wx.Point(pixel[0]/10,pixel[1]/2), id=wxID_FRAME1, size=wx.Size(self.Log_window_Length, self.Log_window_Width))

        wx.Frame.__init__(self, id=wxID_FRAME1, name='', parent=prnt,
              pos=wx.Point(442, 128), size=wx.Size(450, 449),
              style=wx.SYSTEM_MENU | wx.CAPTION | wx.MINIMIZE_BOX|wx.STAY_ON_TOP|wx.RESIZE_BORDER, title='DTD CDU to DMC')
        self.SetClientSize(wx.Size(450, 350))

        self.panel1 = wx.Panel(id=wxID_FRAME1PANEL1, name='panel1', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(470, 415),
              style=wx.TAB_TRAVERSAL)
        Com_choices = ["NAV DATABASE ","COMMUNICATION","ALL FLIGHT(NAV and COMM)","GTH DATABASE","HUMS PERSET",\
                        "HUMS HISTORY","ALL MAINTENANCE(preset and history)","ALL FILES"]
        self.rbx_select_file = wx.RadioBox(choices=Com_choices, 
              label='Select UPGRADE FILE', majorDimension=1, name='rbx_select_file',
              parent=self.panel1, pos=wx.Point(20, 10), size=wx.Size(220, 200),
              style=wx.RA_SPECIFY_COLS)
        self.rbx_select_file.SetForegroundColour('Black')
        Header_choices=["HEADER FILE","HEADER NOT REQUIRED"]
        self.rbx_select_header = wx.RadioBox(choices=Header_choices, 
              label='Select HEADER FILE', majorDimension=1, name='rbx_select_header',
              parent=self.panel1, pos=wx.Point(250, 10), size=wx.Size(150, 100),
              style=wx.RA_SPECIFY_COLS)
        self.rbx_select_header.SetForegroundColour('Black') 
        self.btn_onok = wx.Button(id=wxID_FRAME1BUTTON1, label='OK',
              name='btn_onok', parent=self.panel1, pos=wx.Point(150, 290),
              size=wx.Size(70, 30), style=0)
        self.btn_onok.Bind(wx.EVT_BUTTON, self.dialog_browse, id=wxID_FRAME1BUTTON1)
        
        self.btn_oncancel = wx.Button(id=wxID_FRAME1BUTTON2, label='CANCEL',
              name='btn_oncancel', parent=self.panel1, pos=wx.Point(230, 290),
              size=wx.Size(70, 30), style=0)
        self.btn_oncancel.Bind(wx.EVT_BUTTON, self.btn_onclose, id=wxID_FRAME1BUTTON2)
        
        self.sta_dwld_status = wx.StaticText(id=wxID_FRAME1STATICTEXT1,
              label='Download status:', name='sta_dwld_status', parent=self.panel1,
              pos=wx.Point(33, 230), size=wx.Size(91, 30), style=0) 
                 
        self.sta_dwld_percent = wx.StaticText(id=wxID_FRAME1STATICTEXT2,
              label='0%', name='sta_dwld_percent', parent=self.panel1,
              pos=wx.Point(133, 230), size=wx.Size(91, 30), style=0) 
              
        self.upgrade=0x00
        self.header=0x00
        self.guage_progressbar = wx.Gauge(id=wxID_FRAME1GAUGE1, name='guage_progressbar',
            parent=self.panel1, pos=wx.Point(30, 250), range=100,
            size=wx.Size(400, 15),
            style=wx.TRANSPARENT_WINDOW | wx.GA_SMOOTH | wx.NO_BORDER | wx.GA_HORIZONTAL)
        self.guage_progressbar.SetRange(100)
        self.guage_progressbar.SetLabel('Total Files:')
        self.guage_progressbar.SetValue(0)
        self.guage_progressbar.SetThemeEnabled(True)
    def btn_on_ok(self):
        self.btn_oncancel.Disable() 
        global open_frame,flag_resend,cdu_open_frame,List_cdu2
        flag_resend=0
        open_frame=1
        cdu_open_frame=1
        dict={0:'0x00',1:'0x01',2:'0x02',3:'0x03',4:'0x04',5:'0x05',6:'0x06',7:'0x07',8:'0x08'}
##        MainFrame_CDU.my_instance.MenuBar.EnableTop(0,True)
##        MainFrame_CDU.my_instance.MenuBar.EnableTop(1,True)
        self.upgrade_val = self.rbx_select_file.GetSelection()
        self.header_val  = self.rbx_select_header.GetSelection()
##        self.upgrade=int(dict[self.upgrade_val],16)
        print self.upgrade_val,self.header_val
        if self.upgrade_val==0:
            self.upgrade=0x1
            self.file_name='\NAVDatabase.bin'
        elif self.upgrade_val==1:
            self.upgrade=0x02
            self.file_name='\Communication.bin'
        elif self.upgrade_val==2:
            self.upgrade=0x03
            self.file_name='\AllFlight'      
        elif self.upgrade_val==3:
            self.upgrade=0x04
            self.file_name='\GthDatabase.bin'
        elif self.upgrade_val==4:
            self.upgrade=0x05
            self.file_name='\HAMSPerset.bin'
        elif self.upgrade_val==5:
            self.upgrade=0x06
            self.file_name='\HUMSHistory.bin'
        elif self.upgrade_val==6:
            self.upgrade=0x07
            self.file_name='\Allmaintenance.bin'
        elif self.upgrade_val==7:
            self.upgrade=0x08
            self.file_name='\AllFiles.bin'
        if  self.header_val==0:
            self.header=0  
        else:
            self.header=0x01
        self.packet=self.createpacket()
        List_cdu2=[]    
        print self.upgrade,self.header
        flag_response_true=0
        flag_packet_ack=0
        no_try_packet_correct1=0
        no_try_packet_correct=0
        Try_req_send=0 
        ack_count=0
        no_try=0
        j=0
        while(True):
            if self.flag_close==1:
                break
            if Try_req_send==3 and flag_resend==0:
                Timestamp=self.Time_stamp()
                CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("No Acknowledgement received " +str(Timestamp) +"\n")
                self.btn_oncancel.Enable()
                break
            elif flag_resend==1:
                break
##            elif flag_resend==2:
##                break
            else:
                self.Req_data_transfer(self.packet)
                Timestamp=self.Time_stamp()
                CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Request for Data Transfer sent" +str(Timestamp) +"\n")
                self.req_response_cdu=self.Response_data_transfer()
                Try_req_send=Try_req_send+1
##            if self.req_response_cdu==0:
##                break  
                
        if flag_resend==1:        
            while(True):
    ##            self.req_response_cdu3=[]
                if no_try==3:
                   Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
                   CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Retries for correct acknowledgement reached " +str(Timestamp) +"\n")
                   break
                if Try_req_send==4:
                   Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
                   CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Retries for correct acknowledgement reached " +str(Timestamp) +"\n")
                    
                   break
                elif flag_resend==0:
                    self.req_response_cdu=self.Response_data_transfer()
##                elif no_try>=2 and flag_resend==1:
##                     self.req_response_cdu=self.Response_data_transfer()   
                else:
                     flag_resend=0
                if self.req_response_cdu==0:
                     if no_try==2 or Try_req_send==3:
                         no_try=no_try+1
                     else:
                         self.Req_data_transfer(self.packet)
                     
                         Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
                         CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Request for Data Transfer sent" +str(Timestamp) +"\n")
                     Try_req_send=Try_req_send+1
                     flag_resend=0 
                else:
                    self.req_response_cdu3=list(self.req_response_cdu)
                    if self.req_response_cdu[3]==0 :
                        #code added for report no 100028-For logging on to message box
                        Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
                        CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Acknowledgement received with Checksum status value 0 " +str(Timestamp) +"\n")
                        if no_try==2 or Try_req_send==3:
                            no_try=no_try+1
                        else:
                            
                            self.Req_data_transfer(self.packet)
                            no_try=no_try+1
                            flag_resend=0
                            Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
                            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("i m in 0 Request for Data Transfer sent" +str(Timestamp) +"\n")
                        Try_req_send=Try_req_send+1
                    elif self.req_response_cdu[3]==2:
                        #code added for report no 100028-For logging on to message box
                         Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
                         CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Acknowledgement received with Checksum status value 2 " +str(Timestamp) +"\n")
                         if no_try==2 or Try_req_send==3:
                            no_try=no_try+1
                         else:
                             self.Req_data_transfer(self.packet)
                             no_try=no_try+1
                             flag_resend=0
                             Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
                             CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(" i m in 2 Request for Data Transfer sent" +str(Timestamp) +"\n")
                         Try_req_send=Try_req_send+1
                    elif self.req_response_cdu[3]==1:
                         flag_response_true=1
                         
                         break
                    if self.req_response_cdu==0:
                         self.Req_data_transfer(self.packet)
                         no_try=no_try+1
                         flag_resend=0
                         Try_req_send=Try_req_send+1
    ##                             break
                
        if flag_response_true==1: 
                 self.ret_ack=0
                 while (True):
##                     pdb.Settrace()
                     if no_try_packet_correct==3:
                        Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
                        CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("rrrrRetries for correct acknowledgement reached " +str(Timestamp) +"\n")
                        break
##                     if Try_req_send==4:
##                        Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
##                        CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Retries for correct acknowledgement reached " +str(Timestamp) +"\n")
##                        
##                        break   
                     self.ret_ack=self.Ack_Response_data_transfer(self.req_response_cdu)
                     if self.ret_ack==1:
                         self.response_cdu1=[]
                         self.response_cdu2=[172,195]
                         i=1
                         no_try_packet_correct=0
                         ack_count=4
                         flag_packet_ack=1
                         print "hhhhhhhhhhhhhhhhhhhhhhhhhhhhh"
                         break
                     elif self.ret_ack==3:
                          Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
                          CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("eeeeeRetries for correct acknowledgement reached " +str(Timestamp) +"\n")
                          break 
                     else:
                         if no_try_packet_correct==2:
                             pass
                         else:
                            self.req_response_cdu=self.Response_data_transfer()
                         
                         print "Control heeeeeeeeeeeeeeeerrrrrrrrreeeeeeee",ack_count
                         ack_count=ack_count+1
                         no_try_packet_correct=no_try_packet_correct+1
                         Try_req_send=Try_req_send+1
##                         if ack_count==4:
                     if self.req_response_cdu==0 :
                        if no_try_packet_correct==3 and Try_req_send==4 :
                         
                            Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
                            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("fffffRetries for correct acknowledgement reached " +str(Timestamp) +"\n")
    ##
                            break
                        else:
                            pass
        if flag_packet_ack==1: 
             no_try_packet_correct=0  
             count=0 
             no_packet=0
             status_to_improve=0           
             while(True):
                                  #code added for report no 100028- waiting for Data packet
                 if no_try_packet_correct==3:
                    Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
                    if no_packet==1: 
                        
                        CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(" No Data Packet Received"+str(Timestamp) +"\n")
                    else:
                        if count==100:
                           CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Download successful"+str(Timestamp) +"\n")
   
                        else:
                                
                            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Retries for Data Packet exceeded"+str(Timestamp) +"\n")
   
                    break

                 if i<=self.req_response_cdu3[0] and no_try_packet_correct<=2:
                     
                     print "lok heeeere------------>",i,self.req_response_cdu3[0],no_try_packet_correct
##                     time.sleep(2)
                     self.response_cdu1=self.Response_data_transfer()
                     if self.response_cdu1!=0:
                         self.response_cdu2=[172,195]
                         self.response_cdu3=list(self.response_cdu1)
                         
                         for k in range(len(self.response_cdu1)):
                            self.response_cdu2.append(self.response_cdu3[k])
                         
                         status_to_improve=(100/self.req_response_cdu[0])
                         
                         byte_count=len(self.response_cdu2)-1
                         self.cal_crc=self.Calculate_Checksum1(self.response_cdu2,byte_count)
                         print "kkkkk------------->",self.req_response_cdu[0]
                         print self.response_cdu2[len(self.response_cdu2)-1],self.cal_crc,self.response_cdu2
                         
                         if self.response_cdu2[len(self.response_cdu2)-1]== self.cal_crc:
                            if i== self.response_cdu2[3] : 
                                List_cdu2.append(self.response_cdu2) 
                                checksum_stat=0x1
        ##                            file_object = open(os.getcwd()+self.file_name, 'a')
        ##                            file_object.write(str(self.response_cdu2))
                                file_object = open(self.folder_name+self.file_name, 'a') 
                                file_object.write(str(self.response_cdu2))    
                                i=i+1
                                j=j+1
                                count=count+status_to_improve
                                TestThread(count)
        ##                            count=count+status_to_improve
                                print "count",count
                                self.sta_dwld_percent.SetLabel(str(count))
                                self.guage_progressbar.SetValue(count)
                                Timestamp=self.Time_stamp()
                                CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(" Data Packet "+ str(i-1)+" Received"+str(Timestamp) +"\n")
                                no_try_packet_correct=0
                                time.sleep(2)

                                print "i m where----------->"
                            else:
                                checksum_stat=0x0
                                no_try_packet_correct=no_try_packet_correct+1 
                                Timestamp=self.Time_stamp()
                                CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Incorrect Data packet received"+str(Timestamp) +"\n")
                                print "i m here----------------->",self.req_response_cdu3[0]
          
                         else:
                            checksum_stat=0x0
                            no_try_packet_correct=no_try_packet_correct+1 
        ##                        self.req_response_cdu3[0]=0
                            Timestamp=self.Time_stamp()
                            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Data packet with incorrect checksum received"+str(Timestamp) +"\n")
                            print "i m here----------------->",self.req_response_cdu3[0]
                            
                         packet_ack=struct.pack('<BBBBB',0xac,0xc3,self.response_cdu1[0],self.response_cdu1[1],checksum_stat)
        ##                     print "self.response_cdu",self.response_cdu
                         checksum_cal=self.Calculate_Checksum(packet_ack,5) 
                         Checksumcal_pack=struct.pack('<B',checksum_cal)
                         packet_ack=packet_ack+Checksumcal_pack
##                         if no_try_packet_correct==3:
##                                pass
##                         else: 
                         self.Req_data_transfer(packet_ack)
                         Timestamp=self.Time_stamp()
                         CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Acknowledgement for Data Packet Received sent at"+str(Timestamp) +"\n")
                         no_packet=2
                     #code added for report no 100028
                     else:
                        if no_packet==2:
                           if no_try_packet_correct==3:
                                pass
                           else:                    
                               self.Req_data_transfer(packet_ack)
                               CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Acknowledgement for Data Packet Received sent at"+str(Timestamp) +"\n")
                           no_packet=2  
                        else:
                            if no_try_packet_correct==2:
                                pass
                            else:    
                                self.Ack_Response_data_transfer(self.req_response_cdu)
                            no_packet=1
                        no_try_packet_correct=no_try_packet_correct+1
                        
                 else:
                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Download successful"+str(Timestamp) +"\n")
 
                    break
##                 if self.response_cdu1==0:
##                         break 
##        #code added for report no 100028
##        if self.upgrade_val==3:
##            for i in range(len(List_cdu2)):
            
        self.btn_oncancel.Enable()             
##        event.Skip()

##                 break 
            
  
	
    def btn_onclose(self, event):
        global open_frame,flag_resend,no_try,cdu_open_frame
        open_frame=0
        self.flag_close=1
        CDU_TestRig_MainWindow.class_var3.Cdutodmc_obj=''
        cdu_open_frame=0
        self.Destroy()
    def createpacket(self):
        global ack_no_try
        ack_no_try=0
        data=''
        Final_packet=''
        print self.upgrade,self.header 
        packet=[0xAC,0xC1,self.upgrade,self.header] 
        byte_count=len(packet)
        for i in range(byte_count):
            print "pack",packet[i],len(packet)
            data=data+struct.pack('<B',packet[i])
##        print "data--------->",data
##        print "data--------->",packet_len     
        Checksumcal=self.Calculate_Checksum(data,byte_count)
        Checksumcal_pack=struct.pack('<B',Checksumcal)
        Final_packet=data+Checksumcal_pack
        return Final_packet
##        self.Req_data_transfer(Final_packet)
##        self.req_response_cdu=self.Response_data_transfer()
##        print "self.req_response_cdu",self.req_response_cdu
##        self.Ack_Response_data_transfer(self.req_response_cdu)
##        self.response_cdu=self.Response_data_transfer()
##        print "self.response_cdu",self.response_cdu
    def Req_data_transfer(self,Final_packet):
        
        if CDU_TestRig_MainWindow.close_CDU_flag==1:
           
            if(COMConfig_Window.instance_comport_receiver_CDU1.Comport_select==COMConfig_Window.instance_comport_transmitter_CDU1.Comport_select):
               CDU_TestRig_MainWindow.class_var3.connect_object_CDU1_receiver.write(Final_packet)
            else:
               CDU_TestRig_MainWindow.class_var3.connect_object_CDU1_transmitter.write(Final_packet)    
        else:
            
            if(COMConfig_Window.instance_comport_receiver_CDU2.Comport_select==COMConfig_Window.instance_comport_transmitter_CDU2.Comport_select):
               CDU_TestRig_MainWindow.class_var3.connect_object_CDU2_receiver.write(Final_packet)
            else:
               CDU_TestRig_MainWindow.class_var3.connect_object_CDU2_transmitter.write(Final_packet)  
            
    def Ack_Response_data_transfer(self,response_cdu):
        global ack_no_try
        print "response_cdu",response_cdu
        self.response_cdu1=[172,194]
        
##        self.response_cdu1=list(response_cdu)
        if response_cdu==0:
            self.acceptance_code=0
            self.Ack_packet=[0xAC,0xC2,self.acceptance_code]
            ack_no_try=ack_no_try+1
            Checksumcal=0
            self.val_temp=1
        else:
            for k in range(len(response_cdu)):
                self.response_cdu1.append(response_cdu[k])
            self.acceptance_code=0
            self.Ack_packet=[0xAC,0xC2,self.acceptance_code]
            print "response_cdu",response_cdu
            self.val_temp=self.response_cdu1[6]
            print "self.respense_cdu1",self.response_cdu1[4]
            byte_count=len(self.response_cdu1)-1
            Checksumcal=self.Calculate_Checksum1(self.response_cdu1,byte_count)
            if Checksumcal==self.val_temp:
                self.acceptance_code=0x1
                ack_no_try=ack_no_try+1
                print "yes        ----------------->"
            else:
                self.acceptance_code=0x0
                Timestamp=self.Time_stamp()
                CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Acknowledgement received with checksum error"+str(Timestamp) +"\n")
                ack_no_try=ack_no_try+1
                if ack_no_try==4:
                    return 3
                print "No --------------------->" ,Checksumcal,self.val_temp
        if  ack_no_try<=3:  
            Checksumret=self.Calculate_Checksum1(self.Ack_packet,3)
            data_pack=struct.pack('<BBB',0xAC,0xC2,self.acceptance_code)
            
            Checksumcal_pack=struct.pack('<B',Checksumret)
            Final_packet=data_pack+Checksumcal_pack 
            Timestamp=self.Time_stamp()
    ##        CDU_TestRig_MainWindow.class_var3.connect_object_CDU1_receiver.write(Final_packet)
    ##        if ack_no_try==2:
            self.Req_data_transfer(Final_packet)
            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Acknowledgement for Packet Info Command sent"+str(Timestamp) +"\n")
    ##        else:
                
            if Checksumcal==self.val_temp:
                return 1   
            else:
                return 0     
    def __init__(self, parent):
        self._init_ctrls(parent)
    def Calculate_Checksum1(self,data,byte_count):
        checksum=0
        for i in range(0,byte_count):
            checksum=checksum^data[i]
        checksum=checksum & 0xFF
        return checksum     
    def Calculate_Checksum(self,data,byte_count):
        checksum=0
##        print "pkt,byte_count------>",pkt
##        packet=[0xAC,0xC1,0x0,0x0] 
##        data=struct.pack('<BBBB',0xAC,0xC1,0,0)
        data1=struct.unpack_from('<%dB'%byte_count,data)
        for i in range(0,byte_count):
            checksum=checksum^data1[i]
        checksum=checksum & 0xFF
        return checksum  
    
       
    def Response_data_transfer(self):
        global flag_resend
        ret_value = 0
        self.byte_count=0
        self.read_char1=[]
        self.read_char=[]
        self.read_char2=[]
##        self.data_recvd=[]
        timeout = 9
        flag_timeout=0
        start = time.time()
        flag=0 
        end = start + timeout
        if(CDU_TestRig_MainWindow.close_CDU_flag==1):
            connect_object=CDU_TestRig_MainWindow.class_var3.connect_object_CDU1_receiver
##                    print "CDU1"
        else:
            connect_object=CDU_TestRig_MainWindow.class_var3.connect_object_CDU2_receiver
        while time.time() < end:
##        time.sleep(1)
##            print "hellooooooooooooo"
##            if self.flag_close==1:
##                break
            if connect_object.inWaiting() > 0:
                flag=1
                
##                print "hellooooooooooooo"
                self.read_char = struct.unpack('>BB',connect_object.read(2))
                print "read_char",self.read_char
                if self.read_char[0] == 0xAC :
                    if self.read_char[1] == 0xC2:
                        flag_resend=1
                        print "vvvvvvvvvvvvvvvvvvv"
                        self.read_char1 = struct.unpack('>HHIBB',connect_object.read(10))
    ##                    data1=struct.unpack('>BHHIBB',self.read_char1)
                        self.data_recvd=self.read_char1
                        print "Data received---->",self.read_char1
                        flag_timeout=1
                        Timestamp=CDU_TestRig_MainWindow.class_var3.Time_stamp()
                        CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Response for Data transfer received"+str(Timestamp) +"\n")

                        return self.read_char1
                          
                    elif self.read_char[1] == 0xC3:
                         print "self.data_recvd at first", self.data_recvd
                         
                         data=connect_object.read(self.data_recvd[1]+3)
 
##                         data=MainFrame_CDU.my_instance.dep.connect_object.read(MainFrame_CDU.my_instance.dep.connect_object.inWaiting())
                         size=len(data)
                         self.read_char2 = struct.unpack('>%dB'%size,data)
                         print "self.read_char2",self.read_char2
                         flag_timeout=1
                         return self.read_char2          
                    else:
                        return 0
                else:
                     return 0           
                break
        if flag_timeout==0:
            return 0   
    def dialog_browse(self,event):
        global pathnfile
        dialog = wx.DirDialog(None, "Choose a directory:", style=wx.DD_DEFAULT_STYLE | wx.DD_NEW_DIR_BUTTON) 
##        dialog.MakeModal()
        if dialog.ShowModal() == wx.ID_OK:
            self.folder_name= dialog.GetPath() 
            self.btn_on_ok()
            dialog.Hide()
        else: 
            dialog.Close()   
##            pathnfile=self.folder_name+self.file_name
##            wtbook = xlwt.Workbook()
##            wtsheet = wtbook.add_sheet(u'First')
##            wtbook.save(pathnfile) 
##            CDU_TestRig_MainWindow.class_var3.maintenece_flag=1
##            self.prog_dwnload=Progress_download.create(None) 
##            self.prog_dwnload.Show()
        
        event.Skip()  
    def Time_stamp(self):
        # To get the local time of system
        self.time_now=time.localtime(time.time())
        print "self.time_now", self.time_now
        year, month, day, hour, minute, second, weekday, yearday, daylight =self.time_now
        self.time_hour=str(hour)
        self.time_min=str(minute)
        self.time_sec=str(second)
        if len(self.time_hour)==1:
            self.time_hour='0'+self.time_hour
        if len(self.time_min)==1:
            self.time_min='0'+self.time_min
        if len( self.time_sec)==1:
            self.time_sec='0'+self.time_sec
        self.Timestamp=self.time_hour+":"+self.time_min+":"+self.time_sec
        print "Timestamp", self.Timestamp
        return self.Timestamp     
                    
class TestThread(Thread):
        def __init__(self,count):
            self.param1 = count
            Thread.__init__(self)
            self.start()    # start the thread

        def run(self): 
##            while(1):
            cdutodmc.sta_dwld_percent.SetLabel(str(self.param1))
            cdutodmc.guage_progressbar.SetValue(self.param1) 
            flag=1
##            time.sleep(1)
            if flag==1:
                return
