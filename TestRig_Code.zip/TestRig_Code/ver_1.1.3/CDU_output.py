#Boa:Frame:Frame8

import wx
import wx.grid
import struct
from ctypes import *
import time

import xlrd
import xlwt
from xlutils.copy import copy

import CDU_TestRig_MainWindow
import KEYreadnsend
global output_obj_c,instance_Frame8
##msg_packet=[]


def create(parent):
    global instance_Frame8
    instance_Frame8=CDU_output(parent)
    return instance_Frame8

[wxID_FRAME9, wxID_FRAME9GRID1, wxID_FRAME9GRID2, wxID_FRAME9GRID3, 
 wxID_FRAME9GRID4, wxID_FRAME9GRID5,wxID_FRAME9STATICTEXT1,wxID_FRAME9STATICTEXT2,
 wxID_FRAME9STATICTEXT3,wxID_FRAME9STATICTEXT4,wxID_FRAME9STATICTEXT5, wxID_FRAME9PANEL1,
] = [wx.NewId() for _init_ctrls in range(12)]


class Key_struct(Structure):
   _fields_ = [
                ("Key_Press",c_ubyte),
                ("Key_Release", c_ubyte),
               ] 
               
class Key_struct_c(Structure):
   _fields_ = [
                ("Key_Press",c_char_p),
                ("Key_Release", c_char_p),
               ] 
               
class Status_Report1_struct(Structure):
    _fields_ = [
                ("Brightness_mode", c_byte, 2),   
                ("Functional_mode", c_byte , 2), 
                ("DMC_command", c_byte, 1),    
                ("CDU_Result", c_byte, 1),  
                ("DTD_Availability",c_byte, 1),   
                ("Spare",c_byte, 1),
               ] 
               
class Status_Report1_struct_c(Structure):
    _fields_ = [
                ("Brightness_mode",c_char_p),   
                ("Functional_mode", c_char_p), 
                ("DMC_command", c_char_p),    
                ("CDU_Result", c_char_p),  
                ("DTD_Availability",c_char_p),   
                ("Spare",c_char_p),
               ] 
               
class Status_Report2_struct(Structure):
    _fields_ = [
                ("DTD_DMC_ALL_MAINT", c_byte, 1),      
                ("DTD_DMC_HUMS_HISTORY", c_byte , 1),  
                ("DTD_DMC_HUMS_PRSTS", c_byte, 1),
                ("DTD_DMC_GTH_DBASE", c_byte, 1),
                ("DTD_DMC_ALL_FLIGHT",c_byte, 1),
                ("DTD_DMC_COMM", c_byte , 1),
                ("DTD_DMC_NAV_DBASE", c_byte, 1),
                ("DTD_DMC_Header", c_byte, 1),
               ] 
               
class Status_Report2_struct_c(Structure):
    _fields_ = [
                ("DTD_DMC_ALL_MAINT", c_char_p),      
                ("DTD_DMC_HUMS_HISTORY", c_char_p),  
                ("DTD_DMC_HUMS_PRSTS", c_char_p),
                ("DTD_DMC_GTH_DBASE", c_char_p),
                ("DTD_DMC_ALL_FLIGHT",c_char_p),
                ("DTD_DMC_COMM", c_char_p),
                ("DTD_DMC_NAV_DBASE", c_char_p),
                ("DTD_DMC_Header", c_char_p),
               ]
               
class Status_Report3_struct(Structure):
    _fields_ = [
                ("Reserved", c_byte, 5),  
                ("DTD_validation", c_byte, 1), 
                ("Key_press_status", c_byte , 1),
                ("DTD_DMC_ALL", c_byte, 1),                        
               ] 
               
class Status_Report3_struct_c(Structure):
    _fields_ = [
                ("Reserved", c_char_p),  
                ("DTD_validation", c_char_p), 
                ("Key_press_status", c_char_p),
                ("DTD_DMC_ALL", c_char_p),                        
               ]
               
               
class BIT_Result1_struct(Structure):
    _fields_ = [
                ("Stuck_In_Key", c_byte, 1),
                ("EEPROM_Memory", c_byte , 1),  
                ("Ram_Memory", c_byte, 1),   
                ("Flash_Memory", c_byte, 1), 
                ("Keyboard_ok",c_byte, 1),  
                ("Heat_Condition", c_byte , 2),
                ("Spare",c_byte, 1),   
               ]  
               
class BIT_Result1_struct_c(Structure):
    _fields_ = [
                ("Stuck_In_Key", c_char_p),
                ("EEPROM_Memory",c_char_p),  
                ("Ram_Memory", c_char_p),   
                ("Flash_Memory", c_char_p), 
                ("Keyboard_ok",c_char_p),  
                ("Heat_Condition", c_char_p),
                ("Spare",c_char_p),   
               ]
                       

class BIT_Result2_struct(Structure):
    _fields_ = [
                ("Spare",c_byte),  
               ]

               
class Software_Version_struct(Structure):
    _fields_ = [
                ("a",c_ubyte),  
                ("b",c_ubyte), 
                ("c",c_ubyte), 
                ("d",c_ubyte), 
                ("e",c_ubyte), 
                ("f",c_ubyte), 
               ]
               
class Data_word_struct(Structure):
   _fields_ = [
                ("Key",Key_struct),
                ("Status_Report1", Status_Report1_struct),
                ("Status_Report2",Status_Report2_struct),
                ("Status_Report3", Status_Report3_struct),
                ("BIT_Result1", BIT_Result1_struct),
                ("BIT_Result2",BIT_Result2_struct),
                ("Software_Version", Software_Version_struct),
               ]
               
class Data_word_struct_c(Structure):
   _fields_ = [
                ("Key",Key_struct_c),
                ("Status_Report1", Status_Report1_struct_c),
                ("Status_Report2",Status_Report2_struct_c),
                ("Status_Report3", Status_Report3_struct_c),
                ("BIT_Result1", BIT_Result1_struct_c),
                ("BIT_Result2",BIT_Result2_struct),
                ("Software_Version", Software_Version_struct),
               ]
               
class output(Structure):
   _fields_ = [
                ("Header",c_byte),
                ("Packet_ID", c_byte),
                ("Data_word",Data_word_struct),
                ("Checksum", c_byte ),
               ]
               
class output_c(Structure):
   _fields_ = [
                ("Header",c_char_p),
                ("Packet_ID", c_char_p),
                ("Data_word",Data_word_struct_c),
                ("Checksum", c_char_p ),
               ]
               
output_obj_c=output_c()
output_obj=output()
    
                              
dict={1:'CL1', 2:'CL2', 3:'CL3' , 4:'CL4' , 5:'CR1' , 6:'CR2',7:'CR3' ,8:'CR4',49:'1',50:'2' ,51:'3' ,52:'4' ,\
53:'5' ,54:'6' ,55:'7' ,56:'8' ,57:'9' ,48:'0' ,91:'P. up', 92:'P. down' , 62:'SYS' ,63:'DAT' ,10:'NAV' ,11:'MNT',\
12:'PER' ,13:'WPN' ,14:'SET' ,15:'+/-', 17:'DEL' ,26:'BCK' ,18:'PREV' , 27:'ESC' ,28:'SPC' ,44:'MRK',29:'ENT' ,22:'BRT.UP' ,\
65:'A' ,66:'B' ,67:'C' ,68:'D' ,69:'E' ,70:'F' ,71:'G' ,72:'H' ,73:'I' ,74:'J' ,75:'K',76:'L' ,77:'M' ,78:'N' ,\
79:'O',80:'P' ,81:'Q' ,82:'R' ,83:'S' ,84:'T' ,85:'U' ,86:'V' ,87:'W' ,88:'X' ,89:'Y' ,90:'Z', 97:'ERS', 98:'DATA XFR',99:'GTH',100:'BRT.DOWN',153:'NoKEY'}

##msg_packet=['0xAC','0xA1','0x5C','0x5B','0x86','0x18','0x02','0xB8','0x00','0x01','0x02','0x03','0x04','0x05',\
##'0x06','0x2F'] 

##msg_packet=['0xAC','0xA1','0x62','0x12','0x68','0xC8','0x01','0x47','0x00','0x01','0x02','0x03','0x04','0x05',\
##'0x06','0x9C'] 25    

##msg_packet=['0xAC','0xA1','0x2C',0x63'','','','','','','','','','','','','','','','']

class CDU_output(wx.Frame):
    def _init_ctrls(self, prnt):
        # generated method, don't edit
        wx.Frame.__init__(self, id=wxID_FRAME9, name='', parent=prnt,
              pos=wx.Point(185, 128), size=wx.Size(664, 548),
              style=wx.SYSTEM_MENU | wx.CAPTION | wx.MINIMIZE_BOX|wx.CLOSE_BOX, title='Status Message from CDU to DMC')
        self.SetClientSize(wx.Size(636, 500))
        self.Center()
        self.panel1 = wx.Panel(id=wxID_FRAME9PANEL1, name='panel1', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(636, 500),
              style=wx.TAB_TRAVERSAL)

        self.grd_key = wx.grid.Grid(id=wxID_FRAME9GRID1, name='grid1',
              parent=self.panel1, pos=wx.Point(0, 30), size=wx.Size(280, 70),
              style=0)
              
        self.sta_txtkeystatus = wx.StaticText(id=wxID_FRAME9STATICTEXT1,
              label='Key Status    ', name='staticText1', parent=self.panel1,
              pos=wx.Point(120, 8), size=wx.Size(200, 20), style=0)
              
        self.sta_txtkeystatus.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD, False,'Tahoma'))

        self.grd_statusdtd = wx.grid.Grid(id=wxID_FRAME9GRID2, name='grid2',
              parent=self.panel1, pos=wx.Point(320, 30), size=wx.Size(295, 280),
              style=0)
              
        self.sta_txt_statusdtd = wx.StaticText(id=wxID_FRAME9STATICTEXT2,
              label='DTD  Status ', name='staticText2', parent=self.panel1,
              pos=wx.Point(450, 8), size=wx.Size(200, 20), style=0)
              
        self.sta_txt_statusdtd.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD, False,'Tahoma'))

        self.grd_statusmode = wx.grid.Grid(id=wxID_FRAME9GRID3, name='grid3',
              parent=self.panel1, pos=wx.Point(0, 140), size=wx.Size(280, 146),
              style=0)
              
        self.sta_txt_statusmode = wx.StaticText(id=wxID_FRAME9STATICTEXT3,
              label='Status mode', name='self.sta_txt_statusmode', parent=self.panel1,
              pos=wx.Point(110, 120), size=wx.Size(200, 20), style=0)
              
        self.sta_txt_statusmode.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD, False,'Tahoma'))

        self.grd_bitresult = wx.grid.Grid(id=wxID_FRAME9GRID4, name='grid4',
              parent=self.panel1, pos=wx.Point(0, 330), size=wx.Size(280, 160),
              style=0)
              
        self.sta_txtbitresult = wx.StaticText(id=wxID_FRAME9STATICTEXT4,
              label='Bit Result', name='staticText4', parent=self.panel1,
              pos=wx.Point(120, 310), size=wx.Size(200, 20), style=0)
              
        self.sta_txtbitresult.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD, False,'Tahoma'))

        self.grd_swversion = wx.grid.Grid(id=wxID_FRAME9GRID5, name='grid5',
              parent=self.panel1, pos=wx.Point(320, 350), size=wx.Size(295, 55),
              style=0)
              
        self.sta_txtswversion = wx.StaticText(id=wxID_FRAME9STATICTEXT5,
              label='Software Version', name='staticText5', parent=self.panel1,
              pos=wx.Point(430, 330), size=wx.Size(200, 20), style=0)
              
        self.sta_txtswversion.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD, False,'Tahoma'))
        
        
##        self.wtbook = xlwt.Workbook()           # xls file to write into it
##        self.wtsheet = self.wtbook.add_sheet('Sheet 1') 
##        self.wtbook.save('CDU_LOG.xls')
##        self.rb = xlrd.open_workbook('CDU_LOG.xls', formatting_info=True)
##        self.w=copy(self.rb)
        
##        self.Log_Heading()
        
        self.timer=wx.Timer(self)
        self.Bind(wx.EVT_TIMER,self.refresh1)
        self.timer.Start(1000) 
              
        self.Key_grids()
        self.Status_mode()
        self.Status_DTD()
        self.Bit_Result()
        self.Software_Version()
        self.display_grid()
        
##        self.initialisation()
 
    def __init__(self, parent):
        self._init_ctrls(parent)
        
    def refresh1(self,event):
        validate_instance=validate()
        
        if(KEYreadnsend.flag_data==1):
##            msg_packet=CDU_TestRig_MainWindow.data
##            print msg_packet
            validate_instance.initialisation(KEYreadnsend.data_packet)
            self.display_grid()
        else:
            print "-------failed"
        
    def Key_grids(self):             # To create key status grid
        self.grd_key.CreateGrid(2,2) 
        self.grd_key.DisableDragGridSize()
        self.grd_key.DisableDragColSize()
        self.grd_key.DisableDragRowSize()
        self.grd_key.SetColLabelValue(0,'Field Name')
        self.grd_key.SetColLabelValue(1,'Value')
        for i in range (2):
             for j in range (2):
                self.grd_key.SetReadOnly(i,j)
                self.grd_key.SetRowSize( i, 22 ) 
                self.grd_key.SetCellFont(i,j,wx.Font(8, wx.SWISS, wx.NORMAL, wx.NORMAL))  
        self.grd_key.SetColSize( 0, 130 ) 
        self.grd_key.SetColSize( 1, 124 )
        self.grd_key.SetRowLabelSize(25)
        self.grd_key.SetColLabelSize(25)
        
        self.grd_key.SetCellValue(0,0,'Key Press')
        self.grd_key.SetCellValue(1,0,'Key Release')
        
    def Status_mode(self):             # To create status mode grid
        self.grd_statusmode.CreateGrid(5,2) 
        self.grd_statusmode.DisableDragGridSize()
        self.grd_statusmode.DisableDragColSize()
        self.grd_statusmode.DisableDragRowSize()
        self.grd_statusmode.SetColLabelValue(0,'Field Name')
        self.grd_statusmode.SetColLabelValue(1,'Value')
        for i in range (5):
             for j in range (2):
                self.grd_statusmode.SetReadOnly(i,j)
                self.grd_statusmode.SetRowSize( i, 24 )   
        self.grd_statusmode.SetColSize( 0, 130 ) 
        self.grd_statusmode.SetColSize( 1, 124 )
        self.grd_statusmode.SetRowLabelSize(25)
        self.grd_statusmode.SetColLabelSize(25)
        
        self.grd_statusmode.SetCellValue(0,0,'Brightness mode')
        self.grd_statusmode.SetCellValue(1,0,'Functional mode')
        self.grd_statusmode.SetCellValue(2,0,'DMC command')
        self.grd_statusmode.SetCellValue(3,0,'CDU Result')
        self.grd_statusmode.SetCellValue(4,0,'DTD Availability')
        
    def Status_DTD(self):             # To create status DTD grid
        self.grd_statusdtd.CreateGrid(11,2) 
        self.grd_statusdtd.DisableDragGridSize()
        self.grd_statusdtd.DisableDragColSize()
        self.grd_statusdtd.DisableDragRowSize()
        self.grd_statusdtd.SetColLabelValue(0,'Field Name')
        self.grd_statusdtd.SetColLabelValue(1,'Value')
        for i in range (11):
             for j in range (2):
                self.grd_statusdtd.SetReadOnly(i,j)
                self.grd_statusdtd.SetRowSize( i, 23 )  
        self.grd_statusdtd.SetColSize( 0, 150 ) 
        self.grd_statusdtd.SetColSize( 1, 118 )
        self.grd_statusdtd.SetRowLabelSize(25)
        self.grd_statusdtd.SetColLabelSize(25)
        
        self.grd_statusdtd.SetCellValue(0,0,'DTD_DMC_ALL_MAINT')
        self.grd_statusdtd.SetCellValue(1,0,'DTD_DMC_HUMS_HISTORY')
        self.grd_statusdtd.SetCellValue(2,0,'DTD_DMC_HUMS_PRSTS')
        self.grd_statusdtd.SetCellValue(3,0,'DTD_DMC_GTH_DBASE')
        self.grd_statusdtd.SetCellValue(4,0,'DTD_DMC_ALL_FLIGHT')
        self.grd_statusdtd.SetCellValue(5,0,'DTD_DMC_COMM')
        self.grd_statusdtd.SetCellValue(6,0,'DTD_DMC_NAV_DBASE')
        self.grd_statusdtd.SetCellValue(7,0,'DTD_DMC_Header')
        self.grd_statusdtd.SetCellValue(8,0,'DTD_validation ')
        self.grd_statusdtd.SetCellValue(9,0,'Key_press_status ')
        self.grd_statusdtd.SetCellValue(10,0,'DTD_DMC_ALL ')
       
        
    def Bit_Result(self):             # To create bit result
        self.grd_bitresult.CreateGrid(6,2) 
        self.grd_bitresult.DisableDragGridSize()
        self.grd_bitresult.DisableDragColSize()
        self.grd_bitresult.DisableDragRowSize()
        self.grd_bitresult.SetColLabelValue(0,'Field Name')
        self.grd_bitresult.SetColLabelValue(1,'Value')
        for i in range (6):
             for j in range (2):
                self.grd_bitresult.SetReadOnly(i,j)
                self.grd_bitresult.SetRowSize( i, 22 );   
        self.grd_bitresult.SetColSize( 0, 130 ) 
        self.grd_bitresult.SetColSize( 1, 124 ) 
        self.grd_bitresult.SetRowLabelSize(25)
        self.grd_bitresult.SetColLabelSize(25)
        
        self.grd_bitresult.SetCellValue(0,0,'Stuck In Key ')
        self.grd_bitresult.SetCellValue(1,0,'EEPROM Memory ')
        self.grd_bitresult.SetCellValue(2,0,'Ram Memory ')
        self.grd_bitresult.SetCellValue(3,0,'Flash Memory')
        self.grd_bitresult.SetCellValue(4,0,'Keyboard ok ')
        self.grd_bitresult.SetCellValue(5,0,'Heat Condition ')
        
          
    def Software_Version(self):             # To create software version
        self.grd_swversion.CreateGrid(1,2) 
        self.grd_swversion.DisableDragGridSize()
        self.grd_swversion.DisableDragColSize()
        self.grd_swversion.DisableDragRowSize()
        self.grd_swversion.SetColLabelValue(0,'Field Name')
        self.grd_swversion.SetColLabelValue(1,'Value')
        for i in range (1):
             for j in range (2):
                self.grd_swversion.SetReadOnly(i,j)
                self.grd_swversion.SetRowSize( i, 27 );   
                
        self.grd_swversion.SetColSize( 0, 150 ) 
        self.grd_swversion.SetColSize( 1, 119 )
        self.grd_swversion.SetRowLabelSize(25)
        self.grd_swversion.SetColLabelSize(25)
        
        self.grd_swversion.SetCellValue(0,0,'Software Version ')
    def display_grid(self):
        global output_obj_c
        if(len(KEYreadnsend.data_packet)!=0):
            print "output_obj_c.Data_word.Key.Key_Press.......",output_obj_c.Data_word.Key.Key_Press
            self.grd_key.SetCellValue(0,1,str(output_obj_c.Data_word.Key.Key_Press))
            print "Key_Release------------->",output_obj_c.Data_word.Key.Key_Release
            self.grd_key.SetCellValue(1,1,str(output_obj_c.Data_word.Key.Key_Release))
##            print "Brightness_mode",output_obj_c.Data_word.Status_Report1.Brightness_mode
            self.grd_statusmode.SetCellValue(0,1,output_obj_c.Data_word.Status_Report1.Brightness_mode)
            self.grd_statusmode.SetCellValue(1,1,output_obj_c.Data_word.Status_Report1.Functional_mode)
##            print "DMC_command",output_obj_c.Data_word.Status_Report1.DMC_command
            
            self.grd_statusmode.SetCellValue(2,1,output_obj_c.Data_word.Status_Report1.DMC_command)
            self.grd_statusmode.SetCellValue(3,1,output_obj_c.Data_word.Status_Report1.CDU_Result) 
            self.grd_statusmode.SetCellValue(4,1,output_obj_c.Data_word.Status_Report1.DTD_Availability)
                    
            self.grd_statusdtd.SetCellValue(0,1,output_obj_c.Data_word.Status_Report2.DTD_DMC_ALL_MAINT)
            self.grd_statusdtd.SetCellValue(1,1,output_obj_c.Data_word.Status_Report2.DTD_DMC_HUMS_HISTORY)
            self.grd_statusdtd.SetCellValue(2,1,output_obj_c.Data_word.Status_Report2.DTD_DMC_HUMS_PRSTS)
            self.grd_statusdtd.SetCellValue(3,1,output_obj_c.Data_word.Status_Report2.DTD_DMC_GTH_DBASE)
            self.grd_statusdtd.SetCellValue(4,1,output_obj_c.Data_word.Status_Report2.DTD_DMC_ALL_FLIGHT)
            self.grd_statusdtd.SetCellValue(5,1,output_obj_c.Data_word.Status_Report2.DTD_DMC_COMM)
            self.grd_statusdtd.SetCellValue(6,1,output_obj_c.Data_word.Status_Report2.DTD_DMC_NAV_DBASE)
            self.grd_statusdtd.SetCellValue(7,1,output_obj_c.Data_word.Status_Report2.DTD_DMC_Header)
            self.grd_statusdtd.SetCellValue(8,1,output_obj_c.Data_word.Status_Report3.DTD_validation) 
            self.grd_statusdtd.SetCellValue(9,1,output_obj_c.Data_word.Status_Report3.Key_press_status)
            self.grd_statusdtd.SetCellValue(10,1,output_obj_c.Data_word.Status_Report3.DTD_DMC_ALL)
            
            self.grd_bitresult.SetCellValue(0,1,output_obj_c.Data_word.BIT_Result1.Stuck_In_Key)
            self.grd_bitresult.SetCellValue(1,1,output_obj_c.Data_word.BIT_Result1.EEPROM_Memory)
            self.grd_bitresult.SetCellValue(2,1,output_obj_c.Data_word.BIT_Result1.Ram_Memory)
            self.grd_bitresult.SetCellValue(3,1,output_obj_c.Data_word.BIT_Result1.Flash_Memory)
            self.grd_bitresult.SetCellValue(4,1,output_obj_c.Data_word.BIT_Result1.Keyboard_ok)
            self.grd_bitresult.SetCellValue(5,1,output_obj_c.Data_word.BIT_Result1.Heat_Condition)
            
            print "a-------------->",output_obj_c.Data_word.Software_Version.a
            print "e-------------->",output_obj_c.Data_word.Software_Version.e
            
            version=str(output_obj.Data_word.Software_Version.a)+str(output_obj.Data_word.Software_Version.b)\
            +'.'+str(output_obj.Data_word.Software_Version.c)+str(output_obj.Data_word.Software_Version.d)\
            +'.'+str(output_obj.Data_word.Software_Version.e)+str(output_obj.Data_word.Software_Version.f)
            
            print "version",version
            
            self.grd_swversion.SetCellValue(0,1,version)
        else:
            self.grd_key.SetCellValue(0,1,'-')
            self.grd_key.SetCellValue(1,1,'-')
            
            self.grd_statusmode.SetCellValue(0,1,'-')
            self.grd_statusmode.SetCellValue(1,1,'-')
            self.grd_statusmode.SetCellValue(2,1,'-')
            self.grd_statusmode.SetCellValue(3,1,'-')
            self.grd_statusmode.SetCellValue(4,1,'-')
            
            
            self.grd_statusdtd.SetCellValue(0,1,'-')
            self.grd_statusdtd.SetCellValue(1,1,'-')
            self.grd_statusdtd.SetCellValue(2,1,'-')
            self.grd_statusdtd.SetCellValue(3,1,'-')
            self.grd_statusdtd.SetCellValue(4,1,'-')
            self.grd_statusdtd.SetCellValue(5,1,'-')
            self.grd_statusdtd.SetCellValue(6,1,'-')
            self.grd_statusdtd.SetCellValue(7,1,'-')
            self.grd_statusdtd.SetCellValue(8,1,'-')
            self.grd_statusdtd.SetCellValue(9,1,'-')
            self.grd_statusdtd.SetCellValue(10,1,'-')
            
            self.grd_bitresult.SetCellValue(0,1,'-')
            self.grd_bitresult.SetCellValue(1,1,'-')
            self.grd_bitresult.SetCellValue(2,1,'-')
            self.grd_bitresult.SetCellValue(3,1,'-')
            self.grd_bitresult.SetCellValue(4,1,'-')
            self.grd_bitresult.SetCellValue(5,1,'-')
            
            self.grd_swversion.SetCellValue(0,1,'-')
        
class validate:   
    def initialisation(self,msg_packet):
        global output_obj_c,output_obj
        flag=0
        function_flag=0
##        output_obj=output()
##        output_obj_c=output_c()
##        print " create obj................."
##        print "msg_packet",msg_packet
        print "in initialisation fn ----->msg_packet",msg_packet
        
        if(len(KEYreadnsend.data_packet)!=0):
        
            output_obj.Header=msg_packet[0]
            output_obj.Packet_ID=msg_packet[1]
            
            output_obj.Checksum=msg_packet[15]
            if(msg_packet[2]<=8):
            
                msg_packet[2]=str(msg_packet[2]).replace('0','')
                msg_packet[3]=str(msg_packet[3]).replace('0','')
                
            print "msg_packet------->",int(msg_packet[2])
            output_obj.Data_word.Key.Key_Press=int(msg_packet[2])
            print "------->",msg_packet[3]
            
##            msg_packet[3]=str(msg_packet[3]).replace('0','')
            output_obj.Data_word.Key.Key_Release=int(msg_packet[3])

            temp1=msg_packet[4]
            temp2=temp1/64
            output_obj.Data_word.Status_Report1.Brightness_mode=temp2
            
            temp1=msg_packet[4]
            temp2=temp1/16
            temp3=temp2%4
            output_obj.Data_word.Status_Report1.Functional_mode=temp3

            temp1=msg_packet[4]
            temp2=temp1/8
            temp3=temp2%2
            output_obj.Data_word.Status_Report1.DMC_command=temp3

            temp1=msg_packet[4]
            temp2=temp1/4
            temp3=temp2%2
            output_obj.Data_word.Status_Report1.CDU_Result=temp3

            temp1=msg_packet[4]
            temp2=temp1/2
            temp3=temp2%2
            output_obj.Data_word.Status_Report1.DTD_Availability=temp3

            temp1=msg_packet[5]
            temp2=temp1/128
            output_obj.Data_word.Status_Report2.DTD_DMC_ALL_MAINT=temp2
   
            temp1=msg_packet[5]
            temp2=temp1/64
            temp3=temp2%2
            output_obj.Data_word.Status_Report2.DTD_DMC_HUMS_HISTORY=temp3

            temp1=msg_packet[5]
            temp2=temp1/32
            temp3=temp2%2
            output_obj.Data_word.Status_Report2.DTD_DMC_HUMS_PRSTS=temp3

            temp1=msg_packet[5]
            temp2=temp1/16
            temp3=temp2%2
            output_obj.Data_word.Status_Report2.DTD_DMC_GTH_DBASE=temp3

            temp1=msg_packet[5]
            temp2=temp1/8
            temp3=temp2%2
            output_obj.Data_word.Status_Report2.DTD_DMC_ALL_FLIGHT=temp3
            
            temp1=msg_packet[5]
            temp2=temp1/4
            temp3=temp2%2
            output_obj.Data_word.Status_Report2.DTD_DMC_COMM=temp3

            temp1=msg_packet[5]
            temp2=temp1/2
            temp3=temp2%2
            output_obj.Data_word.Status_Report2.DTD_DMC_NAV_DBASE=temp3

            temp1=msg_packet[5]
            temp2=temp1%2
            output_obj.Data_word.Status_Report2.DTD_DMC_Header=temp2

            temp1=msg_packet[6]
            temp2=temp1/4
            temp3=temp2%2
            output_obj.Data_word.Status_Report3.Key_press_status=temp3 

            temp1=msg_packet[6]
            temp2=temp1/2
            temp3=temp2%2
            output_obj.Data_word.Status_Report3.DTD_validation=temp3

            temp1=msg_packet[6]
            temp2=temp1%2
            output_obj.Data_word.Status_Report3.DTD_DMC_ALL=temp2

            temp1=msg_packet[7]
            temp2=temp1/128
            output_obj.Data_word.BIT_Result1.Stuck_In_Key=temp2

            temp1=msg_packet[7]
            temp2=temp1/64
            temp3=temp2%2
            output_obj.Data_word.BIT_Result1.EEPROM_Memory=temp3

            temp1=msg_packet[7]
            temp2=temp1/32
            temp3=temp2%2
            output_obj.Data_word.BIT_Result1.Ram_Memory=temp3

            temp1=msg_packet[7]
            temp2=temp1/16
            temp3=temp2%2
            output_obj.Data_word.BIT_Result1.Flash_Memory=temp3
            

            temp1=msg_packet[7]
            temp2=temp1/8
            temp3=temp2%2
            output_obj.Data_word.BIT_Result1.Keyboard_ok=temp3
            

            temp1=msg_packet[7]
            temp2=temp1/2
            temp3=temp2%4
            output_obj.Data_word.BIT_Result1.Heat_Condition=temp3

            print "msg_packet[9]-------->",msg_packet[9]
            output_obj.Data_word.Software_Version.a=msg_packet[9]
            output_obj.Data_word.Software_Version.b=msg_packet[10]
            output_obj.Data_word.Software_Version.c=msg_packet[11]
            output_obj.Data_word.Software_Version.d=msg_packet[12]
            output_obj.Data_word.Software_Version.e=msg_packet[13]
            output_obj.Data_word.Software_Version.f=msg_packet[14]
        
            # store values into grid      
            print "key-------->",output_obj.Data_word.Key.Key_Press
            
            output_obj_c.Data_word.Key.Key_Press=dict[output_obj.Data_word.Key.Key_Press]
             
            print "result",
            result=output_obj.Data_word.Key.Key_Release in dict
            if(result==True):
                output_obj_c.Data_word.Key.Key_Release=dict[output_obj.Data_word.Key.Key_Release]
            else:
                print "else part............>"
                output_obj_c.Data_word.Key.Key_Release='Invalid'
            
            if(output_obj.Data_word.Status_Report1.Brightness_mode & 3== 0):
                output_obj_c.Data_word.Status_Report1.Brightness_mode='Day'
            elif(output_obj.Data_word.Status_Report1.Brightness_mode & 3== 1):
                output_obj_c.Data_word.Status_Report1.Brightness_mode='Night'
            elif(output_obj.Data_word.Status_Report1.Brightness_mode & 3== 2):   
                output_obj_c.Data_word.Status_Report1.Brightness_mode='NVG'
            else:
                output_obj_c.Data_word.Status_Report1.Brightness_mode='Invalid'
                
                
            if(output_obj.Data_word.Status_Report1.Functional_mode & 3== 0):
                output_obj_c.Data_word.Status_Report1.Functional_mode='Main Mode'
            elif(output_obj.Data_word.Status_Report1.Functional_mode & 3== 1):
                output_obj_c.Data_word.Status_Report1.Functional_mode='Debug mode'
            elif(output_obj.Data_word.Status_Report1.Functional_mode & 3== 2):   
                output_obj_c.Data_word.Status_Report1.Functional_mode='Get To Home'
            else:
                output_obj_c.Data_word.Status_Report1.Functional_mode='Invalid'
                 
            if(output_obj.Data_word.Status_Report1.DMC_command & 1== 0):
                output_obj_c.Data_word.Status_Report1.DMC_command='From DMC1 command'
            elif(output_obj.Data_word.Status_Report1.DMC_command & 1== 1):
                output_obj_c.Data_word.Status_Report1.DMC_command='From DMC2 command'

                
            if(output_obj.Data_word.Status_Report1.CDU_Result & 1== 0):
                output_obj_c.Data_word.Status_Report1.CDU_Result='CDU OK'
            elif(output_obj.Data_word.Status_Report1.CDU_Result & 1== 1):
                output_obj_c.Data_word.Status_Report1.CDU_Result='CDU Fail'
            
            if(output_obj.Data_word.Status_Report1.DTD_Availability & 1== 0):
                output_obj_c.Data_word.Status_Report1.DTD_Availability='File not available '
            elif(output_obj.Data_word.Status_Report1.DTD_Availability & 1== 1):
                output_obj_c.Data_word.Status_Report1.DTD_Availability='File available'
   
            if(output_obj.Data_word.Status_Report3.Key_press_status & 1== 0):
                output_obj_c.Data_word.Status_Report3.Key_press_status='No key pressed'
            elif(output_obj.Data_word.Status_Report3.Key_press_status & 1== 1):
                output_obj_c.Data_word.Status_Report3.Key_press_status='One of the key pressed'

                
            if(output_obj.Data_word.Status_Report2.DTD_DMC_ALL_MAINT & 1== 0):
                output_obj_c.Data_word.Status_Report2.DTD_DMC_ALL_MAINT='File available'
            elif(output_obj.Data_word.Status_Report2.DTD_DMC_ALL_MAINT & 1== 1):
                output_obj_c.Data_word.Status_Report2.DTD_DMC_ALL_MAINT='File not available'
                
            if(output_obj.Data_word.Status_Report2.DTD_DMC_HUMS_HISTORY & 1== 0):
                output_obj_c.Data_word.Status_Report2.DTD_DMC_HUMS_HISTORY="File available"
            elif(output_obj.Data_word.Status_Report2.DTD_DMC_HUMS_HISTORY & 1== 1):
                output_obj_c.Data_word.Status_Report2.DTD_DMC_HUMS_HISTORY="File not available"
                
            if(output_obj.Data_word.Status_Report2.DTD_DMC_HUMS_PRSTS & 1== 0):
                output_obj_c.Data_word.Status_Report2.DTD_DMC_HUMS_PRSTS="File available"
            elif(output_obj.Data_word.Status_Report2.DTD_DMC_HUMS_PRSTS & 1== 1):
                output_obj_c.Data_word.Status_Report2.DTD_DMC_HUMS_PRSTS="File not available"
                
            if(output_obj.Data_word.Status_Report2.DTD_DMC_GTH_DBASE & 1== 0):
                output_obj_c.Data_word.Status_Report2.DTD_DMC_GTH_DBASE='File available'
            elif(output_obj.Data_word.Status_Report2.DTD_DMC_GTH_DBASE & 1== 1):
                output_obj_c.Data_word.Status_Report2.DTD_DMC_GTH_DBASE='File not available'
                
            if(output_obj.Data_word.Status_Report2.DTD_DMC_ALL_FLIGHT & 1== 0):
                output_obj_c.Data_word.Status_Report2.DTD_DMC_ALL_FLIGHT='File available'
            elif(output_obj.Data_word.Status_Report2.DTD_DMC_ALL_FLIGHT & 1== 1):
                output_obj_c.Data_word.Status_Report2.DTD_DMC_ALL_FLIGHT='File not available'
                
            if(output_obj.Data_word.Status_Report2.DTD_DMC_COMM & 1== 0):
                output_obj_c.Data_word.Status_Report2.DTD_DMC_COMM='File available'
            elif(output_obj.Data_word.Status_Report2.DTD_DMC_COMM & 1== 1):
                output_obj_c.Data_word.Status_Report2.DTD_DMC_COMM='File not available'
                
            if(output_obj.Data_word.Status_Report2.DTD_DMC_NAV_DBASE & 1== 0):
                output_obj_c.Data_word.Status_Report2.DTD_DMC_NAV_DBASE='File available'
            elif(output_obj.Data_word.Status_Report2.DTD_DMC_NAV_DBASE & 1== 1):
                output_obj_c.Data_word.Status_Report2.DTD_DMC_NAV_DBASE='File not available'
                
            if(output_obj.Data_word.Status_Report2.DTD_DMC_Header & 1== 0):
                output_obj_c.Data_word.Status_Report2.DTD_DMC_Header='File available'
            elif(output_obj.Data_word.Status_Report2.DTD_DMC_Header & 1== 1):
                output_obj_c.Data_word.Status_Report2.DTD_DMC_Header='File not available'
                
            if(output_obj.Data_word.Status_Report3.DTD_validation & 1== 0):
                output_obj_c.Data_word.Status_Report3.DTD_validation='DTD not validated '
            elif(output_obj.Data_word.Status_Report3.DTD_validation & 1== 1):
                output_obj_c.Data_word.Status_Report3.DTD_validation='DTD validated '
                            
            if(output_obj.Data_word.Status_Report3.DTD_DMC_ALL & 1== 0):
                output_obj_c.Data_word.Status_Report3.DTD_DMC_ALL='File available'
            elif(output_obj.Data_word.Status_Report3.DTD_DMC_ALL & 1== 1):
                output_obj_c.Data_word.Status_Report3.DTD_DMC_ALL='File not available'
   
            if(output_obj.Data_word.BIT_Result1.Stuck_In_Key & 1== 0):
##                self.grd_bitresult.SetCellValue(0,1,'Key is not stucked')
                output_obj_c.Data_word.BIT_Result1.Stuck_In_Key='Key is not stucked'
            elif(output_obj.Data_word.BIT_Result1.Stuck_In_Key & 1== 1):
##                self.grd_bitresult.SetCellValue(0,1,'Key is stucked')
                output_obj_c.Data_word.BIT_Result1.Stuck_In_Key='Key is stucked'
            
            
            if(output_obj.Data_word.BIT_Result1.EEPROM_Memory & 1== 0):
##                self.grd_bitresult.SetCellValue(1,1,'No Fault')
                output_obj_c.Data_word.BIT_Result1.EEPROM_Memory='No Fault'
            elif(output_obj.Data_word.BIT_Result1.EEPROM_Memory & 1== 1):
##                self.grd_bitresult.SetCellValue(1,1,'Fault')
                output_obj_c.Data_word.BIT_Result1.EEPROM_Memory='Fault'
                
            if(output_obj.Data_word.BIT_Result1.Ram_Memory & 1== 0):
##                self.grd_bitresult.SetCellValue(2,1,'No Fault')
                output_obj_c.Data_word.BIT_Result1.Ram_Memory='No Fault'
            elif(output_obj.Data_word.BIT_Result1.Ram_Memory & 1== 1):
##                self.grd_bitresult.SetCellValue(2,1,'Fault')
                output_obj_c.Data_word.BIT_Result1.Ram_Memory='Fault'
                
            if(output_obj.Data_word.BIT_Result1.Flash_Memory & 1== 0):
##                self.grd_bitresult.SetCellValue(3,1,'No Fault')
                output_obj_c.Data_word.BIT_Result1.Flash_Memory='No Fault'
            elif(output_obj.Data_word.BIT_Result1.Flash_Memory & 1== 1):
##                self.grd_bitresult.SetCellValue(3,1,'Fault')
                output_obj_c.Data_word.BIT_Result1.Flash_Memory='Fault'
                
            if(output_obj.Data_word.BIT_Result1.Keyboard_ok & 1== 0):
##                self.grd_bitresult.SetCellValue(4,1,'No Fault')
                output_obj_c.Data_word.BIT_Result1.Keyboard_ok='No Fault'
            elif(output_obj.Data_word.BIT_Result1.Keyboard_ok & 1== 1):
##                self.grd_bitresult.SetCellValue(4,1,'Fault')
                output_obj_c.Data_word.BIT_Result1.Keyboard_ok='Fault'
            if(output_obj.Data_word.BIT_Result1.Heat_Condition & 1== 0):
##                self.grd_bitresult.SetCellValue(5,1,'Low Temperature')
                output_obj_c.Data_word.BIT_Result1.Heat_Condition='Low Temperature'
            elif(output_obj.Data_word.BIT_Result1.Heat_Condition & 1== 1):
##                self.grd_bitresult.SetCellValue(5,1,'Normal Temperature')
                output_obj_c.Data_word.BIT_Result1.Heat_Condition='Normal Temperature'
                
##            a=output_obj.Data_word.BIT_Result1.Flash_Memory & 1
##            b=output_obj.Data_word.BIT_Result1.Ram_Memory & 1
##            c=output_obj.Data_word.BIT_Result1.Heat_Condition & 1
##            d=output_obj.Data_word.BIT_Result1.Keyboard_ok & 1
##            e=output_obj.Data_word.BIT_Result1.Stuck_In_Key & 1
##            
##            cdu_ok_fail=a or b or c or d or e
##            if(cdu_ok_fail== 0):
####                self.grd_statusmode.SetCellValue(3,1,'CDU OK')
##                output_obj_c.Data_word.Status_Report1.CDU_Result='CDU OK'
##            elif(cdu_ok_fail== 1):
####                self.grd_statusmode.SetCellValue(3,1,'CDU Fail')
##                output_obj_c.Data_word.Status_Report1.CDU_Result='CDU Fail'
                 
##            self.grd_swversion.SetCellValue(0,1,'17.12.2012')
        else:
            print "else"
          
        