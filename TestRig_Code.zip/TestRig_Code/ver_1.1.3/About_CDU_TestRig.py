#Boa:Frame:Frame2

import wx

def create(parent):
    return About_CDU_TestRig(parent)

[wxID_FRAME2, wxID_FRAME3STATICBITMAP1, wxID_FRAME2PANEL1, 
 wxID_FRAME2STATICTEXT1, wxID_FRAME2STATICTEXT2, wxID_FRAME2STATICTEXT3, 
 wxID_FRAME2STATICTEXT4, wxID_FRAME2STATICTEXT5, wxID_FRAME2STATICTEXT6, 
 wxID_FRAME2STATICTEXT7, wxID_FRAME2STATICTEXT8,wxID_CDU_TestRig_MainWindow_GNSS_STATICBOX,
] = [wx.NewId() for _init_ctrls in range(12)]

class About_CDU_TestRig(wx.Frame):
    def _init_ctrls(self, prnt):
        # generated method, don't edit
        wx.Frame.__init__(self, id=wxID_FRAME2, name='', parent=prnt,
              pos=wx.Point(269, 219), size=wx.Size(400, 362),
              style=wx.DEFAULT_FRAME_STYLE, title='About CDU Test-Rig')
        self.SetClientSize(wx.Size(392, 328))

        self.panel1 = wx.Panel(id=wxID_FRAME2PANEL1, name='panel1', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(392, 328),
              style=wx.TAB_TRAVERSAL)
              
        self.GNSS = wx.StaticBox(id=wxID_CDU_TestRig_MainWindow_GNSS_STATICBOX,
              label='', name='WIFI', parent=self.panel1,
              pos=wx.Point(8,5), size=wx.Size(90,115), style=0)
              
        self.GNSS_status =  wx.StaticBitmap(bitmap=wx.Bitmap(u'accord_logo.bmp',      
              wx.BITMAP_TYPE_BMP), id=wxID_FRAME3STATICBITMAP1,
              name='USB-TB', parent=self, pos=wx.Point(13,18),
              size=wx.Size(78,98), style=0)
              
##        self.GNSS_status = wx.StaticBitmap(bitmap=wx.Bitmap(u' acc_logo.bmp',
##              wx.BITMAP_TYPE_BMP), id=wxID_ACC_logo, name='USB-TB', parent=self.panel1,
##              pos=wx.Point(15, 25), size=wx.Size(100, 100), style=0)
##        self.GNSS_status.SetBackgroundColour(self.default_color)

        self.staticText1 = wx.StaticText(id=wxID_FRAME2STATICTEXT1,
              label='CDU Test-Rig  01.01.03 ', name='staticText1', parent=self.panel1,
              pos=wx.Point(140, 30), size=wx.Size(111, 16), style=0)
        self.staticText1.SetFont(wx.Font(10, wx.SWISS, wx.NORMAL, wx.BOLD,
              False, 'Tahoma'))

        self.staticText2 = wx.StaticText(id=wxID_FRAME2STATICTEXT2,
              label='_________________________________________________________________ ',
              name='staticText2', parent=self.panel1, pos=wx.Point(0, 120),
              size=wx.Size(400, 13), style=0)

        self.staticText3 = wx.StaticText(id=wxID_FRAME2STATICTEXT3,
              label='Contact us at:  ', name='staticText3', parent=self.panel1,
              pos=wx.Point(10, 150), size=wx.Size(84, 13), style=0)
        self.staticText3.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD, False,
              'Tahoma'))

        self.staticText4 = wx.StaticText(id=wxID_FRAME2STATICTEXT4,
              label='Accord Software and Systems Pvt. Ltd.', name='staticText3',
              parent=self.panel1, pos=wx.Point(80, 180), size=wx.Size(198, 13),
              style=0)
        self.staticText4.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD, False,
              'Tahoma'))

        self.staticText5 = wx.StaticText(id=wxID_FRAME2STATICTEXT5,
              label='37, Krishna Reddy Colony,', name='staticText5',
              parent=self.panel1, pos=wx.Point(80, 200), size=wx.Size(128, 13),
              style=0)
        self.staticText5.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.NORMAL,
              False, 'Tahoma'))

        self.staticText6 = wx.StaticText(id=wxID_FRAME2STATICTEXT6,
              label='Domlur Layout,', name='staticText6', parent=self.panel1,
              pos=wx.Point(80, 220), size=wx.Size(128, 13), style=0)

        self.staticText7 = wx.StaticText(id=wxID_FRAME2STATICTEXT7,
              label='Bangalore -560071', name='staticText7', parent=self.panel1,
              pos=wx.Point(80, 240), size=wx.Size(128, 13), style=0)

        self.staticText8 = wx.StaticText(id=wxID_FRAME2STATICTEXT8,
              label='India', name='staticText7', parent=self.panel1,
              pos=wx.Point(80, 260), size=wx.Size(128, 13), style=0)

    def __init__(self, parent):
        self._init_ctrls(parent)
