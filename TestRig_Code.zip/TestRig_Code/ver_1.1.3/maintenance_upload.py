#Boa:Frame:Frame1

import wx
import os
import time
import threading,Queue
from threading import Thread
from ctypes import *
import struct
import request_packet
import CDU_TestRig_MainWindow
import com_connection

global dataload1_flag,dataload2_flag,dataload3_flag,total_size,maintenance_object,maintenance_object_tx,\
flag_ChecksumStatus1,flag_ChecksumStatus2,flag_ChecksumStatus3,i_init,i_info,i_data,\
flag_no_ack1,flag_no_ack2,flag_no_ack3
dataload1_flag=0
dataload2_flag=0
dataload3_flag=0
open_frame=0
browse=0
i_data=1
i_init=1
i_info=1
flag_no_ack1=0
flag_no_ack2=0
flag_no_ack3=0
flag_ChecksumStatus1=0
flag_ChecksumStatus2=0
flag_ChecksumStatus3=0

maintenance_object=''
maintenance_object_tx=''


def create(parent):
    global inst_Frame
    inst_Frame=Frame1(parent)
    return inst_Frame

[wxID_FRAME1, wxID_FRAME1BUTTON1, wxID_FRAME1BUTTON2, wxID_FRAME1BUTTON3, 
 wxID_FRAME1GAUGE1, wxID_FRAME1PANEL1, wxID_FRAME1RADIOBOX1, 
 wxID_FRAME1STATICTEXT1, wxID_FRAME1STATICTEXT2, wxID_FRAME1STATICTEXT3, 
 wxID_FRAME1TEXTCTRL1,wxID_FRAME1STATICTEXT3,
] = [wx.NewId() for _init_ctrls in range(12)]	#Changed for report no-100028:added radio box for CDU,GNSS

             

class Frame1(wx.Frame):
    filename_bin=''
    count=0
    def _init_ctrls(self, prnt):
        # generated method, don't edit
        wx.Frame.__init__(self, id=wxID_FRAME1, name='', parent=prnt,
              pos=wx.Point(181, 179), size=wx.Size(454, 254),
              style=wx.SYSTEM_MENU | wx.CAPTION | wx.MINIMIZE_BOX|wx.CLOSE_BOX|wx.STAY_ON_TOP,
              title='Data Transfer')	#Changed for report no-100028:TITLE is changed.
        self.SetClientSize(wx.Size(446, 220))
        self.Bind(wx.EVT_CLOSE, self.OnCancel)

        self.panel1 = wx.Panel(id=wxID_FRAME1PANEL1, name='panel1', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(446, 220),
              style=wx.TAB_TRAVERSAL)
        #Changed for report no-100028:added radio box, static text     
        self.staticText3 = wx.StaticText(id=wxID_FRAME1STATICTEXT3,
              label='Select:', name='staticText1', parent=self.panel1,
              pos=wx.Point(10, 30), size=wx.Size(35, 13), style=0)
        self.staticText3.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD, False,'Tahoma'))

        self.radioBox1 = wx.RadioBox(choices=['CDU', 'GNSS'],
              id=wxID_FRAME1RADIOBOX1, label='', majorDimension=2,
              name='radioBox1', parent=self.panel1, pos=wx.Point(75, 16),
              size=wx.Size(150, 34), style=wx.RA_SPECIFY_COLS)

        self.staticText1 = wx.StaticText(id=wxID_FRAME1STATICTEXT1,
              label='File to open:', name='staticText1', parent=self.panel1,
              pos=wx.Point(10, 77), size=wx.Size(60, 13), style=0)
        self.staticText1.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD, False,'Tahoma')) 	#Changed for report no-100028:    

        self.textCtrl1 = wx.TextCtrl(id=wxID_FRAME1TEXTCTRL1, name='textCtrl1',
              parent=self.panel1, pos=wx.Point(80, 74), size=wx.Size(272, 24),
              style=0, value='')

        self.button1 = wx.Button(id=wxID_FRAME1BUTTON1, label='Browse',
              name='button1', parent=self.panel1, pos=wx.Point(368, 75),
              size=wx.Size(75, 24), style=0)
        self.button1.Bind(wx.EVT_BUTTON, self.OnBrowse, id=wxID_FRAME1BUTTON1)

        self.staticText2 = wx.StaticText(id=wxID_FRAME1STATICTEXT2,
              label='Download Status:', name='staticText2', parent=self.panel1,
              pos=wx.Point(10, 113), size=wx.Size(120, 25), style=0)
        self.staticText2.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD, False,'Tahoma'))		#Changed for report no-100028:

        self.staticText3 = wx.StaticText(id=wxID_FRAME1STATICTEXT3, label='0%',
              name='staticText3', parent=self.panel1, pos=wx.Point(114, 113),
              size=wx.Size(50, 25), style=0)

        self.gauge1 = wx.Gauge(id=wxID_FRAME1GAUGE1, name='gauge1',
              parent=self.panel1, pos=wx.Point(17, 144), range=100,
              size=wx.Size(413, 15),
              style=wx.TRANSPARENT_WINDOW | wx.GA_SMOOTH | wx.NO_BORDER | wx.GA_HORIZONTAL)
        self.gauge1.SetRange(100)
        self.gauge1.SetLabel('Total Files:')
        self.gauge1.SetValue(0)
        self.gauge1.SetThemeEnabled(True)

        self.button2 = wx.Button(id=wxID_FRAME1BUTTON2, label='OK',
              name='button2', parent=self.panel1, pos=wx.Point(128, 175),
              size=wx.Size(75, 23), style=0)
        self.button2.Bind(wx.EVT_BUTTON, self.OnOK, id=wxID_FRAME1BUTTON2)

        self.button3 = wx.Button(id=wxID_FRAME1BUTTON3, label='Cancel',
              name='button3', parent=self.panel1, pos=wx.Point(228, 175),
              size=wx.Size(75, 23), style=0)
        self.button3.Bind(wx.EVT_BUTTON, self.OnButton3Button,
              id=wxID_FRAME1BUTTON3)

    def __init__(self, parent):
        self._init_ctrls(parent)
        
    # Description:
    # Function parameters:
    # Global variables:
        
    def OnBrowse(self, event):
        dlg = wx.FileDialog(self, "Choose a file", ".", "", "*.bin", wx.OPEN)
        try:
           if dlg.ShowModal() == wx.ID_OK:
               global browse
               browse=1
               self.textCtrl1.Value = dlg.GetPath()
               self.filename_bin=self.textCtrl1.Value
               
        finally:
           dlg.Destroy()          
        event.Skip()
                 
    
    # Description:
    # Function parameters:
    # Global variables:
        
    def OnOK(self, event):
        global dataload1_flag,dataload2_flag,dataload3_flag,total_size,ack,\
        bin_main,i_no,value,percent,maintenance_object,maintenance_object_tx,\
        flag_ChecksumStatus1,flag_ChecksumStatus2,flag_ChecksumStatus3,k1,i_init,i_info,\
        flag_no_ack1,flag_no_ack2,flag_no_ack3,i_data
        flag_ChecksumStatus1=0
        flag_ChecksumStatus2=0
        flag_ChecksumStatus3=0
        i_data=1   
        i=0
        i_init=1
        i_info=1
        
        
        dataload1_flag=0
        dataload2_flag=0
        dataload3_flag=0
        
        
        data=[]
        bin_sub=[]
        bin_main=[[]]
        bin_main1=[[]]
        #Changed for report no-100028: getting tx is by CDU or GNSS
        com_port =self.radioBox1.GetSelection()
        if(com_port==0):
            if(CDU_TestRig_MainWindow.class_var3.maintenance_object_receiver_CDU!=''):
                maintenance_object=CDU_TestRig_MainWindow.class_var3.maintenance_object_receiver_CDU
                maintenance_object_tx=CDU_TestRig_MainWindow.class_var3.maintenance_object_transmitter_CDU
            else:
                dial = wx.MessageDialog(None, 'CDU COM Port is not connected!',
                'Error!!!', wx.OK)
                dial.ShowModal()  
                return   
            
        else:
            if(CDU_TestRig_MainWindow.class_var3.maintenance_object_receiver_GNSS!=''):
                maintenance_object=CDU_TestRig_MainWindow.class_var3.maintenance_object_receiver_GNSS
                maintenance_object_tx=CDU_TestRig_MainWindow.class_var3.maintenance_object_transmitter_GNSS
            else:
                dial = wx.MessageDialog(None, 'GNSS COM Port is not connected!',
                'Error!!!', wx.OK)
                dial.ShowModal()
                return
        
        if self.filename_bin!='':
            self.gauge1.SetValue(0)
            f=open(self.filename_bin,'rb')
##            bin_file=f.read(1)
            size_file=os.path.getsize(self.filename_bin)
            print size_file
            no_pck=(size_file)/50
            print "no_pck",no_pck
                        
            result=isinstance(no_pck,float)
            print "result",result
            no_pck=int(no_pck)
            if(result==True):
                no_pck=no_pck+1
                
            start=time.time()       # This gives the current time.
            timeout=5
            end=start+timeout
            i=0
            while(1):
                if((dataload1_flag==0 and i<3 and flag_ChecksumStatus1<3) or (dataload1_flag==0 and i_init<3)):                    
                    request_packet.Data_Upload_Init_Packet()
                    print "packet 1"
                    i=i+1
                    self.ACK_Data_Upload_Init_Packet()
                    if(flag_no_ack1==0):
                        flag_ChecksumStatus1=flag_ChecksumStatus1+1
                        i_init=i_init+1
                else:
                    if((dataload1_flag==0 and i_init>=3)):
                          CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Acknowledgement is not received for data upload init command \n")
                    
                    if(flag_ChecksumStatus1>=3 and dataload1_flag==0):
                        Timestamp=self.Time_stamp()
                        temp_text="Retries for data upload init command exceeded at"+ str(Timestamp)+"\n"
                        CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                    break            
                               
                                
            if(dataload1_flag==1):
                i=0
                a=size_file/50
                total_size=50*a
                while(1):
                    if((dataload2_flag==0 and i<3 and flag_ChecksumStatus2<3) or (dataload2_flag==0 and i_info<3)):
                        request_packet.Data_Upload_Packet_Info_Cmd(total_size)
                        print "packet 2 sent"
                        i=i+1
                        self.ACK_Data_Upload_Packet_Info_Cmd()
                        if(flag_no_ack2==0):
                            flag_ChecksumStatus2=flag_ChecksumStatus2+1
                            i_info=i_info+1
                    else:
                        if(dataload2_flag==0 and i_info>=3):
                          CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Acknowledgement is not received for packet information command\n")
                        
                        if(flag_ChecksumStatus2>=3 and dataload2_flag==0):
                            Timestamp=self.Time_stamp()
                            temp_text="Retries for packet information command exceeded at"+ str(Timestamp)+"\n"
                            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                        break   
                        
            t=0
            print "no_pck",no_pck
            for i in range(no_pck):
                for j in range(t,t+50):
                    bin_sub.append(f.read(1))
                    f.seek(j,0)
                f.seek(t+50,0)
                t=t+50
                bin_main[i]=bin_sub
                bin_main.extend(bin_main1)
                bin_sub=[]
                
            value=float(100)/float(no_pck)
            print "value-------------------------->",value
            percent=0
                
            if(dataload2_flag==1):
                i_no=1
                m=0
                ack=i_no
                while(ack==i_no):
                    ack=0
                    
                    print "i----->",i_no
                    print "no_pck------>",no_pck
                    
                    while(i_no<=no_pck):
                        dataload3_flag=0
                        i=0
                        while(1):
                            if((dataload3_flag==0 and i_no<=no_pck and i<3 and flag_ChecksumStatus3<3) or (dataload3_flag==0 and i_data<3)):
                                print "packet 3 sent"
                                request_packet.Data_Packet_Upload_Init(i_no,bin_main[(i_no)-1])
                                i=i+1
                                self.ACK_Data_Packet_Upload_Init()
                                if(flag_no_ack3==0):
                                    flag_ChecksumStatus3=flag_ChecksumStatus3+1
                                    i_data=i_data+1
                            else:
                                if(dataload3_flag==0 and i_data>=3):
                                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText("Acknowledgement is not received for data packet"+ str(i_no)+"\n")
                                
                                if(flag_ChecksumStatus3>=3 and dataload3_flag==0):
                                    Timestamp=self.Time_stamp()
                                    temp_text="Retries for data packet exceeded at"+ str(Timestamp)+"\n"
                                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                                break                        
                            
                        if(ack!=i_no):
                            print "flag_ChecksumStatus3",flag_ChecksumStatus3
                            if(flag_ChecksumStatus3>=3 or i>=3):
                                break
                            else:								
	                            temp_text="Invalid Acknowlegement received for packet"+ str(i_no)+"\n"
	                            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
	                            break
                        else:                                
                            i_no=i_no+1
                            i_data=i_data+1
                            flag_ChecksumStatus3=0
                            print "i",i_no
                                                  
        else:
            temp_text="Select a binary file first\n"
            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
        
        
     #Changed for report no-100028:made a seperate ack fn as per issue reported.    
    def ACK_Data_Upload_Init_Packet(self):
        global dataload1_flag,maintenance_object,flag_ChecksumStatus1,i_init,flag_no_ack1
        data=[]
        timeout =5
        start = time.time()
        end = start + timeout
        
        while((time.time())<end):
            if(flag_ChecksumStatus1<3):
                flag_no_ack1=0
                if maintenance_object.inWaiting() > 0:
                    flag_no_ack1=1
                    b=struct.unpack(">2B",maintenance_object.read(2))
                    print b
                    data.append(b[0])
                    data.append(b[1])
                    if(data[0]==0xAC): 
                        if(data[1]==0xD1): 
                            flag_process=1
                            g=struct.unpack(">2B",maintenance_object.read(2))
                            data.append(g[0])    # acceptance bit
                            data.append(g[1])    # checksum bit
                            
                            Checksum=self.Calculate_Checksum(data,len(data)-1)
                            print "checksum-------->",Checksum
                            print "last bit-------->",data[len(data)-1]
                            if( Checksum == data[len(data)-1] ):
                                print "ack packet 1"
                                if(data[2]==0):
                                
                                    dataload1_flag=0
                                    Timestamp=self.Time_stamp()
                                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.SetForegroundColour(wx.Colour(255, 0, 0))
                                    temp_text="Invalid Acceptance code received for data upload init command at "+ str(Timestamp)+"\n"
                                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                                    flag_ChecksumStatus1=flag_ChecksumStatus1+1
                                    while(1):
                                        if(dataload1_flag==0 and i_init<3):
                                            request_packet.Data_Upload_Init_Packet()
                                            i_init=i_init+1
                                            self.ACK_Data_Upload_Init_Packet()
                                            if(flag_no_ack1==0):
                                                flag_ChecksumStatus1=flag_ChecksumStatus1+1
                                            if(flag_ChecksumStatus1>3):                
                                                break
                                        else:
                                            break
                                else:
                                    data=[]
                                    Timestamp=self.Time_stamp()
                                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.SetForegroundColour(wx.Colour(0, 0, 255))
                                    temp_text="Acknowlegement received data upload command at "+ str(Timestamp)+"\n"
                                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                                    dataload1_flag=1
                                    
                                    break
                            else:
                                Timestamp=self.Time_stamp()
                                CDU_TestRig_MainWindow.class_var3.txt_statuswindow.SetForegroundColour(wx.Colour(255, 0, 0))
                                temp_text="Invalid Checksum received for data upload init command at"+ str(Timestamp)+"\n"
                                CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                                flag_ChecksumStatus1=flag_ChecksumStatus1+1
                                
                                while(1):
                                    if(dataload1_flag==0 and i_init<3):
                                        request_packet.Data_Upload_Init_Packet()
                                        i_init=i_init+1
                                        self.ACK_Data_Upload_Init_Packet()
                                        if(flag_no_ack1==0):
                                            flag_ChecksumStatus1=flag_ChecksumStatus1+1
                                        if(flag_ChecksumStatus1>3):                
                                            break
                                    else:
                                        break
                        else:
                            Timestamp=self.Time_stamp()
                            temp_text="Invalid Acknowlegement received for data upload init command at "+ str(Timestamp)+"\n"
                            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                            break
                    else:
                        data[0]=data[1]
                        (value,)=struct.unpack(">B",maintenance_object.read(1))
                        data[1]=(value)

    
    def ACK_Data_Upload_Packet_Info_Cmd(self):
        global dataload2_flag,total_size,maintenance_object,flag_ChecksumStatus2,i_info,flag_no_ack2
        data=[]
        timeout =5
        start = time.time()
        end = start + timeout
        
        while(time.time()<end):
            if(flag_ChecksumStatus2<3):
                flag_no_ack2=0
                if maintenance_object.inWaiting() > 0:
                    flag_no_ack2=1
                    b=struct.unpack(">2B",maintenance_object.read(2))
                    data.append(b[0])
                    data.append(b[1])
                    
                    if(data[0]==0xAC): 
                        if(data[1]==0xD2): 
                            flag_process=1
                            g=struct.unpack(">2B",maintenance_object.read(2))
                            data.append(g[0])    # acceptance bit
                            data.append(g[1])    # checksum bit
                            
                            Checksum=self.Calculate_Checksum(data,len(data)-1)
                            print "checksum-------->",Checksum
                            print "last bit-------->",data[len(data)-1]
                           
                            if( Checksum == data[len(data)-1] ):
                                print "ack packet 1"
                                if(data[2]==0):
                                    
                                    dataload2_flag=0
                                    Timestamp=self.Time_stamp()
                                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.SetForegroundColour(wx.Colour(255, 0, 0))
                                    temp_text="Invalid Acceptance code received for packet information command at "+ str(Timestamp)+"\n"
                                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                                    flag_ChecksumStatus2=flag_ChecksumStatus2+1
                                    
                                    while(1):
                                        if(dataload2_flag==0 and i_info<3):
                                            request_packet.Data_Upload_Packet_Info_Cmd(total_size)
                                            i_info=i_info+1
                                            self.ACK_Data_Upload_Packet_Info_Cmd()
                                            if(flag_no_ack2==0):
                                                flag_ChecksumStatus2=flag_ChecksumStatus2+1
                                            if(flag_ChecksumStatus2>3):                
                                                break
                                        else:
                                            break
                                else:
                                    data=[]
                                    Timestamp=self.Time_stamp()
                                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.SetForegroundColour(wx.Colour(0, 0, 255))
                                    temp_text="Acknowlegement received packet information command at "+ str(Timestamp)+"\n"
                                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                                    dataload2_flag=1
                                    
                                    print "ack for 2nd packet"
                                    break
                            else:
                                Timestamp=self.Time_stamp()
                                CDU_TestRig_MainWindow.class_var3.txt_statuswindow.SetForegroundColour(wx.Colour(255, 0, 0))
                                temp_text="Invalid Checksum received for packet information command at"+ str(Timestamp)+"\n"
                                CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                                flag_ChecksumStatus2=flag_ChecksumStatus2+1
                                while(1):
                                    if(dataload2_flag==0 and i_info<3):
                                        request_packet.Data_Upload_Packet_Info_Cmd(total_size)
                                        i_info=i_info+1
                                        self.ACK_Data_Upload_Packet_Info_Cmd()
                                        if(flag_no_ack2==0):
                                            flag_ChecksumStatus2=flag_ChecksumStatus2+1
                                        if(flag_ChecksumStatus2>3):                
                                            break
                                    else:
                                        break
                        else:
                            Timestamp=self.Time_stamp()
                            temp_text="Invalid Acknowlegement received at info command"+ str(Timestamp)+"\n"
                            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                            break
                    else:
                        data[0]=data[1]
                        (value,)=struct.unpack(">B",maintenance_object.read(1))
                        data[1]=(value)

                    
    def ACK_Data_Packet_Upload_Init(self):
        global ack,dataload3_flag,i_no,bin_main,value,percent,maintenance_object,flag_ChecksumStatus3,k1,\
        flag_no_ack3,i_data
        data=[]
        timeout =5
        start = time.time()
        end = start + timeout
        print "inside ack----------->"
        while(time.time()<end and flag_ChecksumStatus3<3):
            if(flag_ChecksumStatus3<3):
                flag_no_ack3=0
                if maintenance_object.inWaiting() > 0:
                    flag_no_ack3=1
                    b=struct.unpack(">2B",maintenance_object.read(2))
                    data.append(b[0])
                    data.append(b[1])
                    print " read ac,d3"
                    if(data[0]==0xAC): 
                        print "ac is correct"
                        if(data[1]==0xD3): 
                            flag_process=1
                            g=struct.unpack(">5B",maintenance_object.read(5))
                            for k in range (5):
                                data.append(g[k])
                                
                            Checksum=self.Calculate_Checksum(data,len(data)-1)
                            print "data",data
                            print "checksum-------->",Checksum
                            print "last bit-------->",data[len(data)-1]
                            if( Checksum == data[len(data)-1] ):
                                if(data[3]!=i_no):
                                    print "Invalid Acknowlegement received for data packet "
                                    Timestamp=self.Time_stamp()                                    
                                    temp_text="Invalid Acknowlegement received for data packet "+str(i_no)+" at "+ str(Timestamp)+"\n"
                                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text) 
                                    flag_ChecksumStatus3=flag_ChecksumStatus3+1
                                   
                                    while(1):
                                        if(dataload3_flag==0 and i_data<3):
                                            temp_text="checksum status"
                                            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text) 
                                            request_packet.Data_Packet_Upload_Init(i_no,bin_main[(i_no)-1])
                                            time.sleep(1)
                                            i_data=i_data+1
                                            self.ACK_Data_Packet_Upload_Init()
                                            if(flag_no_ack3==0):
                                                flag_ChecksumStatus3=flag_ChecksumStatus3+1
                                            if(flag_ChecksumStatus3>3):                
                                                break                                       
                                        else:
                                            break                                  
                                    
                                elif(data[4]==2):                                    
                                    dataload3_flag=0
                                    Timestamp=self.Time_stamp()
                                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.SetForegroundColour(wx.Colour(255, 0, 0))
                                    temp_text="Invalid Checksum status received for data packet "+str(i_no)+" at "+ str(Timestamp)+"\n"
                                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                                    flag_ChecksumStatus3=flag_ChecksumStatus3+1
                                    while(1):
                                        if(dataload3_flag==0 and i_data<3 and flag_ChecksumStatus3<3):
                                            request_packet.Data_Packet_Upload_Init(i_no,bin_main[(i_no)-1])
                                            time.sleep(1)
                                            i_data=i_data+1
                                            self.ACK_Data_Packet_Upload_Init()
                                            if(flag_no_ack3==0):
                                                flag_ChecksumStatus3=flag_ChecksumStatus3+1
                                            if(flag_ChecksumStatus3>3):                
                                                break
                                        else:
                                            break
                                else:
                                    data=[]
                                    Timestamp=self.Time_stamp()
                                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.SetForegroundColour(wx.Colour(0, 0, 255))
                                    temp_text="Acknowlegement received for packet data"+ str(i_no)+" at "+ str(Timestamp)+"\n"
                                    CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                                    dataload3_flag=1
                                    
                                    ack=i_no  
                                                         
                                    percent=percent+value
                                    print "percent-",percent 
                                    
                                    percent1=str(percent)+"%"
                                    self.staticText3.SetLabel(percent1)
                                    
                                    self.gauge1.SetValue(percent)   
                                    break                                                 
                                                                                       
                            else:
                                Timestamp=self.Time_stamp()
                                CDU_TestRig_MainWindow.class_var3.txt_statuswindow.SetForegroundColour(wx.Colour(255, 0, 0))
                                temp_text="Invalid Checksum received for packet data at"+ str(Timestamp)+"\n"
                                CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                                k=0
                                flag_ChecksumStatus3=flag_ChecksumStatus3+1
                                while(1):
                                    if(dataload3_flag==0 and i_data<3 and flag_ChecksumStatus3<3):
                                        request_packet.Data_Packet_Upload_Init(i_no,bin_main[i_no-1])
                                        time.sleep(1)
                                        i_data=i_data+1
                                        self.ACK_Data_Packet_Upload_Init()
                                        if(flag_no_ack3==0):
                                            flag_ChecksumStatus3=flag_ChecksumStatus3+1
                                        if(flag_ChecksumStatus3>3):                
                                            break
                                    else:
                                        break
                        else:
                            print "d3 is wrong"
                            Timestamp=self.Time_stamp()
                            temp_text="Invalid Acknowlegement received for data packet "+str(i_no)+"at "+ str(Timestamp)+"\n"
                            CDU_TestRig_MainWindow.class_var3.txt_statuswindow.WriteText(temp_text)
                            break
                    else:
                        data[0]=data[1]
                        (value,)=struct.unpack(">B",maintenance_object.read(1))
                        data[1]=(value)



    # Description:
    # Function parameters:
    # Global variables:
        
    def OnCancel(self, event):
        global open_frame
        open_frame=0 
        self.Destroy()
        event.Skip()
    
    # Description:
    # Function parameters:
    # Global variables:
            
    def Calculate_Checksum(self,data,bytecount):
        checksum=0
        for i in range(0,bytecount):
           var1=data[i]
           checksum = checksum ^ (var1)
        checksum = checksum & 0xFF
        return checksum  
    
    
    # Description:
    # Function parameters:
    # Global variables:
        
    def Time_stamp(self):
        # To get the local time of system
        self.now=time.localtime(time.time())
##        print "self.now", self.now
        year, month, day, hour, minute, second, weekday, yearday, daylight =self.now
        self.a=str(hour)
        self.b=str(minute)
        self.c=str(second)
        if len(self.a)==1:
            self.a='0'+self.a
        if len(self.b)==1:
            self.b='0'+self.b
        if len( self.c)==1:
            self.c='0'+self.c
        self.Timestamp=self.a+":"+self.b+":"+self.c
##        print "Timestamp", self.Timestamp
        return self.Timestamp

    def OnButton3Button(self, event):
        self.Destroy()
        event.Skip()
               
                

                                
        
        
        
        
        
        
        
        
        
