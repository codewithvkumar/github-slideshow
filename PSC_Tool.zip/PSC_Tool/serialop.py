import sys,os

########################################################################
# Global Variables


########################################################################
#Find the list of available port
def listAvailablePort():
    print("Under ListAvailablePort()")
    parentlist = ['COM10','COM2','COM3','COM4']
    return parentlist
# print( listAvailablePort() )
########################################################################
#Connect given port
def connectPort(port_name):
    print("Under connectPort()"+port_name)
    return True

# print( connectPort('COM1') )

########################################################################
#Disconnect given port
def disConnectPort(port_name):
    print("Under disConnectPort()"+port_name)   
    return True

# print( disConnectPort('COM1') )
########################################################################