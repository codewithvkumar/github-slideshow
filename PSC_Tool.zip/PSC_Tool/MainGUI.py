import sys,os,time
import getpass,serial
from tkinter import *
from tkinter import messagebox
from PIL import ImageTk, Image
from serialop import *
import serialop

######################## Global Variable #######################################################
Selected_port = None
Flag = 0
Selected_flag_index = None

statusVar=None
statusbar_label=None
################################################################################################
psc_root = Tk()
psc_root.title("Programmable Power Supply Controller")
psc_root.geometry("800x700")
psc_root.minsize(800,700)
psc_root.maxsize(800,700)


def myFunc(args):
    pass
    
main_menu = Menu(psc_root)
main_menu.add_command(label="File", command=myFunc)
main_menu.add_command(label="Exit", command=quit)
psc_root.config(menu=main_menu)
################################################################################################
# Top 1st Frame
f1 = Frame(psc_root, borderwidth=2, relief=SUNKEN)
f1.pack(anchor=NW, fill=X)

#Logo Image
logo=Image.open("PSC_Tool/logo.png")
image = logo.resize((150, 40), Image. ANTIALIAS)
my_img = ImageTk. PhotoImage(image)
logo_level = Label(f1,image=my_img)
logo_level.pack(side=LEFT)

#Title - PSC Tool
title_logo = Label(f1, text="PSC Tool",font="Times 30 bold", fg="brown")
title_logo.pack(side=LEFT, padx=150)

#Delta Image
delta=Image.open("PSC_Tool/delta.png")
image1 = delta.resize((170, 60), Image. ANTIALIAS)
my_img1 = ImageTk. PhotoImage(image1)
delta_image = Label(f1,image=my_img1)
delta_image.pack(side=RIGHT)

################################################################################################
# Top 2nd Frame
f2 = Frame(psc_root, borderwidth=2, relief=SUNKEN)
f2.pack(anchor=NW, fill=X)

#label - NTID
welcome_text = "Welcome "+getpass.getuser()
title_ntid = Label(f2, text=welcome_text,font="Times 20 italic", fg="brown")
title_ntid.pack(side=LEFT, padx=15)

################################################################################################
#bottom frame for stauts bar
bottom_frame = Frame(psc_root,bg="blue",borderwidth=2,relief=RAISED)
bottom_frame.pack(side=BOTTOM, fill=X)

statusVar = StringVar()
statusVar.set("Ready")

statusbar_label = Label(bottom_frame,textvariable=statusVar,anchor=W,bg="blue",fg="white")
statusbar_label.pack(anchor=W)
################################################################################################

right_frame = Frame(psc_root,bg="black",borderwidth=3,relief=SUNKEN)
right_frame.pack(anchor=NE, padx=30)

listbox_port = Listbox(right_frame, relief=RAISED,selectmode=SINGLE)
listbox_port.pack()

#Call function to get available com port list
list_port = serialop.listAvailablePort()

for item in list_port:
    listbox_port.insert(END, item)

def onselect(event, test):
    global Selected_port
    global Flag
    global Selected_flag_index
    # selected_flag_index = None
    w = event.widget
    index = w.curselection()[0]
    Selected_port = w.get(index)
    print("hello India")
       
    if(Flag == 0):
        print("Under if condition")
        serialop.connectPort(Selected_port)
        Flag=1
        Selected_flag_index = w.curselection()[0]
        print("flag is {0} and selected_flag index is {1}".format(Flag,Selected_flag_index))

    elif(Flag == 1 and Selected_flag_index == w.curselection()[0]):
        print("Under else condition")
        serialop.disConnectPort(Selected_port)
        Flag=0
        print("flag is {0} and selected_flag index is {1}".format(Flag,Selected_flag_index))



    # print(w.get(index))
    # print ("You selected: {0} and test variable is {1}".format(index, test) )
    # listbox_pclearort.insert(END, index) # Instead of returning it, why not just insert it here?


l1select = listbox_port.bind('<<ListboxSelect>>',lambda event: onselect(event, 'Test'))


def doThings():
    print("do things")
    messagebox.showinfo( "Hello Python", "Hello World")

b1=Button(psc_root,text="Do Things",command=doThings)
b1.pack()



# selected_port = listbox_port.curselection()
# print("selected_port:",selected_port)


# def helloCallBack():
#     statusVar.set("go!!")
#     statusbar_label.update()
#     messagebox.showinfo( "Hello Python", "Hello World")

# b1=Button(psc_root,text="Change Status", command=helloCallBack)
# b1.pack()


## headline = Label(text="Welcome to PSC Tool ", bg='grey',fg='black',font='comicsansms 19 bold', borderwidth=2, relief=RAISED,padx=20,pady=25)
# headline = Label(text="Welcome to PSC Tool ",fg='black',font='comicsansms 19 bold', borderwidth=2, relief=RIDGE)
# headline.pack(side=TOP, anchor=NW, fill=X)

# # photo = PhotoImage(file="PSC_Tool/logo.png", height=70, width=800)
# # PhotoImage()
# # logo_level = Label(image=photo)
# # logo_level.pack()

# logo=Image.open("PSC_Tool/logo.png")
# image = logo. resize((150, 40), Image. ANTIALIAS)
# my_img = ImageTk. PhotoImage(image)
# logo_level = Label(image=my_img)
# # logo_level.pack(side=TOP, fill=X, padx=0, pady=0)
# logo_level.pack(anchor=NW)





# gui logic here
psc_root.mainloop()


# image = Image. open('path_to_your_image.png')
# # The (450, 350) is (height, width)
# image = image. resize((450, 350), Image. ANTIALIAS)
# my_img = ImageTk. PhotoImage(image)


